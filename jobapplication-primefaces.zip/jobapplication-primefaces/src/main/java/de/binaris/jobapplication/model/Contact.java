package de.binaris.jobapplication.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "contact")
public class Contact implements Serializable {

	private static final long serialVersionUID = 3271789629232176727L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_contact")
	@SequenceGenerator(name = "my_entity_seq_gen_contact", sequenceName = "sequence_contact", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String department;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	@Column(name = "phone_number")
	private String phoneNumber;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Contact)) {
			return false;
		}
		Contact castOther = (Contact) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return name + ", " + department + ", " + phoneNumber;
	}
}
