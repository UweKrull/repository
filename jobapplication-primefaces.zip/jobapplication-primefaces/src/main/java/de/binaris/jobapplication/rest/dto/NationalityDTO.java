package de.binaris.jobapplication.rest.dto;

import java.io.Serializable;
import de.binaris.jobapplication.model.Nationality;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class NationalityDTO implements Serializable
{

   private Long id;
   private String name;

   public NationalityDTO()
   {
   }

   public NationalityDTO(final Nationality entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public Nationality fromDTO(Nationality entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Nationality();
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}