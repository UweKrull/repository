package de.binaris.jobapplication.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ValueChangeEvent;
import javax.faces.event.ValueChangeListener;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import de.binaris.jobapplication.controller.AccountController;
import de.binaris.jobapplication.model.AdditionalInfo;
import de.binaris.jobapplication.model.Customer;

/**
 * Backing bean for AdditionalInfo entities.
 */
@Named
@Stateful
@ConversationScoped
public class AdditionalInfoBean implements Serializable
{
   private static final long serialVersionUID = 1L;

   /*
    * Support creating and retrieving AdditionalInfo entities
    */
   private Long id;

   public Long getId()
   {
	   return this.id;
   }
   
   public void setId(Long id)
   {
	   this.id = id;
   }
   
   private String customerId;
   
   public String getCustomerId()
   {
      return this.customerId;
   }

   public void setCustomerId(String customerId)
   {
	   this.customerId = customerId;
   }
   
   public void setCustomerValue(ValueChangeEvent event)
   {
	   customerId = (String) event.getNewValue();
   }

   private AdditionalInfo additionalInfo;

   public AdditionalInfo getAdditionalInfo()
   {
      return this.additionalInfo;
   }

   @Inject
   private Conversation conversation;

   @Inject
   private AccountController accController;
   
   @PersistenceContext(type = PersistenceContextType.EXTENDED)
   private EntityManager entityManager;

   public String create()
   {
      this.conversation.begin();
      return "create?faces-redirect=true";
   }

   public void retrieve()
   {
      if (FacesContext.getCurrentInstance().isPostback())
      {
         return;
      }
      if (this.conversation.isTransient())
      {
         this.conversation.begin();
      }
      
      if (this.customerId != null) {
    	  paginate();
    	  for (AdditionalInfo info : this.pageItems) {
    		  if (info.getCustomer().getId().longValue() == Long.valueOf(this.customerId).longValue()) {
    			  this.example = info;
    			  this.id = info.getId().longValue();
    		  }
    	  }
      }
      if (this.id == null)
      {
         this.additionalInfo = this.example;
      }
      else
      {
         this.additionalInfo = findById(getId());
      }
   }

   public AdditionalInfo findById(Long id)
   {

      return this.entityManager.find(AdditionalInfo.class, id);
   }

   /*
    * Support updating and deleting AdditionalInfo entities
    */
   public String update()
   {
      this.conversation.end();
      this.additionalInfo.setCustomer(this.accController.getLoggedinCustomer());
      try
      {
         if (this.id == null)
         {
            this.entityManager.persist(this.additionalInfo);
            return "search?faces-redirect=true";
         }
         else
         {
            this.entityManager.merge(this.additionalInfo);
            return "view?faces-redirect=true&id=" + this.additionalInfo.getId();
         }
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   public String delete()
   {
      this.conversation.end();

      try
      {
         AdditionalInfo deletableEntity = findById(getId());

         this.entityManager.remove(deletableEntity);
         this.entityManager.flush();
         return "search?faces-redirect=true";
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   /*
    * Support searching AdditionalInfo entities with pagination
    */
   private int page;
   private long count;
   private List<AdditionalInfo> pageItems;

   private AdditionalInfo example = new AdditionalInfo();

   public int getPage()
   {
      return this.page;
   }

   public void setPage(int page)
   {
      this.page = page;
   }

   public int getPageSize()
   {
      return 10;
   }

   public AdditionalInfo getExample()
   {
      return this.example;
   }

   public void setExample(AdditionalInfo example)
   {
      this.example = example;
   }

   public void search()
   {
      this.page = 0;
   }

   public void paginate()
   {
      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

      // Populate this.count
      CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
      Root<AdditionalInfo> root = countCriteria.from(AdditionalInfo.class);
      countCriteria = countCriteria.select(builder.count(root)).where(
            getSearchPredicates(root));
      this.count = this.entityManager.createQuery(countCriteria)
            .getSingleResult();

      // Populate this.pageItems
      CriteriaQuery<AdditionalInfo> criteria = builder.createQuery(AdditionalInfo.class);
      root = criteria.from(AdditionalInfo.class);
      TypedQuery<AdditionalInfo> query = this.entityManager.createQuery(criteria
            .select(root).where(getSearchPredicates(root)));
      query.setFirstResult(this.page * getPageSize()).setMaxResults(
            getPageSize());
      this.pageItems = query.getResultList();
   }

   private Predicate[] getSearchPredicates(Root<AdditionalInfo> root)
   {
      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
      List<Predicate> predicatesList = new ArrayList<Predicate>();

      String salary = this.example.getSalary();
      if (salary != null && !"".equals(salary))
      {
         predicatesList.add(builder.like(root.<String> get("salary"), '%' + salary + '%'));
      }
      String formerEmployer = this.example.getFormerEmployer();
      if (formerEmployer != null && !"".equals(formerEmployer))
      {
         predicatesList.add(builder.like(root.<String> get("formerEmployer"), '%' + formerEmployer + '%'));
      }
      String quittingOptionTime = this.example.getQuittingOptionTime();
      if (quittingOptionTime != null && !"".equals(quittingOptionTime))
      {
         predicatesList.add(builder.like(root.<String> get("quittingOptionTime"), '%' + quittingOptionTime + '%'));
      }
      Customer customer = this.example.getCustomer();
      if (customer != null)
      {
         predicatesList.add(builder.equal(root.get("customer"), customer));
      }

      return predicatesList.toArray(new Predicate[predicatesList.size()]);
   }

   public List<AdditionalInfo> getPageItems()
   {
      return this.pageItems;
   }

   public long getCount()
   {
      return this.count;
   }

   /*
    * Support listing and POSTing back AdditionalInfo entities (e.g. from inside an
    * HtmlSelectOneMenu)
    */

   public List<AdditionalInfo> getAll()
   {

      CriteriaQuery<AdditionalInfo> criteria = this.entityManager
            .getCriteriaBuilder().createQuery(AdditionalInfo.class);
      return this.entityManager.createQuery(
            criteria.select(criteria.from(AdditionalInfo.class))).getResultList();
   }

   @Resource
   private SessionContext sessionContext;

   public Converter getConverter()
   {

      final AdditionalInfoBean ejbProxy = this.sessionContext.getBusinessObject(AdditionalInfoBean.class);

      return new Converter()
      {

         @Override
         public Object getAsObject(FacesContext context,
               UIComponent component, String value)
         {

            return ejbProxy.findById(Long.valueOf(value));
         }

         @Override
         public String getAsString(FacesContext context,
               UIComponent component, Object value)
         {

            if (value == null)
            {
               return "";
            }

            return String.valueOf(((AdditionalInfo) value).getId());
         }
      };
   }

   /*
    * Support adding children to bidirectional, one-to-many tables
    */

   private AdditionalInfo add = new AdditionalInfo();

   public AdditionalInfo getAdd()
   {
      return this.add;
   }

   public AdditionalInfo getAdded()
   {
      AdditionalInfo added = this.add;
      this.add = new AdditionalInfo();
      return added;
   }
}