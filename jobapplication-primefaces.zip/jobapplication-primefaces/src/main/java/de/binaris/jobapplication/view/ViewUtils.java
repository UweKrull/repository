package de.binaris.jobapplication.view;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.persistence.Id;

/**
 * Utilities for working with Java Server Faces views.
 */
public final class ViewUtils {

	public static <T> List<T> asList(Collection<T> collection) {

		if (collection == null) {
			return null;
		}

		return new ArrayList<T>(collection);
	}

	public static String display(Object object) {

		if (object == null) {
			return null;
		}

		try {
			// Invoke toString if declared in the class. If not found, the
			// NoSuchMethodException is caught and handled
			object.getClass().getDeclaredMethod("toString");
			return object.toString();
		} catch (NoSuchMethodException noMethodEx) {
			try {
				for (Field field : object.getClass().getDeclaredFields()) {
					// Find the primary key field and display it
					if (field.getAnnotation(Id.class) != null) {
						// Find a matching getter and invoke it to display the
						// key
						for (Method method : object.getClass()
								.getDeclaredMethods()) {
							if (method.equals(new PropertyDescriptor(field
									.getName(), object.getClass())
									.getReadMethod())) {
								return method.invoke(object).toString();
							}
						}
					}
				}
				for (Method method : object.getClass().getDeclaredMethods()) {
					// Find the primary key as a property instead of a field,
					// and display it
					if (method.getAnnotation(Id.class) != null) {
						return method.invoke(object).toString();
					}
				}
			} catch (Exception ex) {
				// Unlikely, but abort and stop view generation if any exception
				// is thrown
				throw new RuntimeException(ex);
			}
		}

		return null;
	}

	public static String displayRange(Object object1, Object object2) {
		String text1 = display(object1);
		String text2 = display(object2);
		if (text1 == null || text2 == null
				|| text1.trim() == null || text2.trim() == null) {
			return null;
		}
		return (text1 + "-" + text2);
	}
	
	public static String displayFirst(Object object) {
		String text = display(object);
		if (text == null || text.split("\\s+") == null
				|| text.split("\\s+")[0] == null) {
			return null;
		}
		return (text.split("\\s+")[0] + "...");
	}

	public static String displayShort(Object object, int length) {
		String text = display(object);
		if (text == null || text.split("['.']") == null
				|| text.split("['.']")[0] == null) {
			return null;
		}
		String[] elements = text.split("['.']");
		String result = "";
		int i = 0;
		if (text.length() < length) {
			return text;
		} else {
			result = text.substring(0,length-4) + "..."; 
			return result;
		}
	}
	
	public static <T> int count(Collection<T> collection) {

		if (collection == null) {
			return 0;
		}
		return collection.size();
	}

	public static <T> List<T> listExcludingSelectedOne(
			Collection<T> collection, T selected) {

		if (collection == null) {
			return null;
		}
		if (selected == null) {
			return new ArrayList<T>(collection);
		}
		List<T> list = new ArrayList<T>(collection);
		list.remove(selected);
		return list;
	}

	public static <T> List<T> listAll(T one, T two, T three, T selected) {

		List<T> list = new ArrayList<T>();
		if (one != null) {
			list.add(one);
		}
		if (two != null) {
			list.add(two);
		}
		if (three != null) {
			list.add(three);
		}
		if (selected != null) {
			list.remove(selected);
		}
		return list;
	}

	private ViewUtils() {
		// private C'tor will never be called
	}
}
