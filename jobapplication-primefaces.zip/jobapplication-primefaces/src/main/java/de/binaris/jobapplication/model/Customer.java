package de.binaris.jobapplication.model;

import java.io.Serializable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import de.binaris.jobapplication.annotations.Login;

@Cacheable
@Entity
@NamedQueries({
    @NamedQuery(name = "findByLogin", query = "SELECT c FROM Customer c WHERE c.login = :login"),
    @NamedQuery(name = "findByLoginAndPassword", query = "SELECT c FROM Customer c WHERE c.login = :login AND c.password = :password")
})
@Table(name = "customer")
public class Customer implements Serializable {

	private static final long serialVersionUID = 7575789729659127329L;

    public static final String FIND_BY_LOGIN = "findByLogin";
    public static final String FIND_BY_LOGIN_PASSWORD = "findByLoginAndPassword";
    
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_customer")
	@SequenceGenerator(name = "my_entity_seq_gen_customer", sequenceName = "sequence_customer", allocationSize = 1)
	private Long id;

	private String title;
	
	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String firstName;

	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String familyName;

	private Address address = new Address();

	@NotNull
	@Column(name = "date_of_birth")
	@Past
	@Temporal(TemporalType.DATE)
	private Date dateOfBirth;
	
    @ManyToOne
    private Nationality nationality;

	@NotNull
	private String phone;
	
	@Column(name = "second_phone")
	private String secondPhone;
	
	@NotNull
	@NotEmpty
	@Email(message = "invalid email format")
	private String email;
	
	@ManyToOne
	private Advertising source;
	
	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	@Login
	private String login;
	
    @ManyToOne
    private Mrmrs mrmrs;

	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String password;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Mrmrs getMrmrs() {
		return mrmrs;
	}
	
	public void setMrmrs(Mrmrs mrmrs) {
		this.mrmrs = mrmrs;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getSecondPhone() {
		return secondPhone;
	}
	
	public void setSecondPhone(String secondPhone) {
		this.secondPhone = secondPhone;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public Advertising getSource() {
		return source;
	}

	public void setSource(Advertising source) {
		this.source = source;
	}

	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Nationality getNationality() {
		return nationality;
	}

	public void setNationality(Nationality nationality) {
		this.nationality = nationality;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Customer)) {
			return false;
		}
		Customer castOther = (Customer) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		DateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
		final StringBuilder sb = new StringBuilder();
		sb.append(familyName).append(", ");
		sb.append(firstName);
		sb.append(", ");
		sb.append(formatter.format(dateOfBirth));
		return sb.toString();
	}
}
