package de.binaris.surveyapplication.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import de.binaris.surveyapplication.model.RangeOfAge;

/**
 * Backing bean for RangeOfAge entities.
 * <p>
 * This class provides CRUD functionality for all RangeOfAge entities. It focuses
 * purely on Java EE 6 standards (e.g. <tt>&#64;ConversationScoped</tt> for
 * state management, <tt>PersistenceContext</tt> for persistence,
 * <tt>CriteriaBuilder</tt> for searches) rather than introducing a CRUD framework or
 * custom base class.
 */
@Named
@Stateful
@ConversationScoped
public class RangeOfAgeBean implements Serializable
{

   private static final long serialVersionUID = 1L;

   /*
    * Support creating and retrieving RangeOfAge entities
    */

   private Long id;

   public Long getId()
   {
      return this.id;
   }

   public void setId(Long id)
   {
      this.id = id;
   }

   private String customerId;
   
   public String getCustomerId()
   {
      return this.customerId;
   }

   public void setCustomerId(String customerId)
   {
	   this.customerId = customerId;
   }
   
   public void setCustomerValue(ValueChangeEvent event)
   {
	   customerId = (String) event.getNewValue();
   }
   
   private RangeOfAge rangeOfAge;

   public RangeOfAge getRangeOfAge()
   {
      return this.rangeOfAge;
   }

   @Inject
   private Conversation conversation;

   @PersistenceContext(type = PersistenceContextType.EXTENDED)
   private EntityManager entityManager;

   public String create()
   {

      this.conversation.begin();
      return "create?faces-redirect=true";
   }

   public void retrieve()
   {

      if (FacesContext.getCurrentInstance().isPostback())
      {
         return;
      }

      if (this.conversation.isTransient())
      {
         this.conversation.begin();
      }

      if (this.id == null)
      {
         this.rangeOfAge = this.example;
      }
      else
      {
         this.rangeOfAge = findById(getId());
      }
   }

   public RangeOfAge findById(Long id)
   {

      return this.entityManager.find(RangeOfAge.class, id);
   }

   /*
    * Support updating and deleting Buying entities
    */

   public String update()
   {
      this.conversation.end();

      try
      {
         if (this.id == null)
         {
            this.entityManager.persist(this.rangeOfAge);
            return "search?faces-redirect=true";
         }
         else
         {
            this.entityManager.merge(this.rangeOfAge);
            return "view?faces-redirect=true&id=" + this.rangeOfAge.getId();
         }
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   public String delete()
   {
      this.conversation.end();

      try
      {
    	  RangeOfAge deletableEntity = findById(getId());

         this.entityManager.remove(deletableEntity);
         this.entityManager.flush();
         return "search?faces-redirect=true";
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   /*
    * Support searching Buying entities with pagination
    */

   private int page;
   private long count;
   private List<RangeOfAge> pageItems;

   private RangeOfAge example = new RangeOfAge();

   public int getPage()
   {
      return this.page;
   }

   public void setPage(int page)
   {
      this.page = page;
   }

   public int getPageSize()
   {
      return 10;
   }

   public RangeOfAge getExample()
   {
      return this.example;
   }

   public void setExample(RangeOfAge example)
   {
      this.example = example;
   }

   public void search()
   {
      this.page = 0;
   }

   public void paginate()
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

      // Populate this.count

      CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
      Root<RangeOfAge> root = countCriteria.from(RangeOfAge.class);
      countCriteria = countCriteria.select(builder.count(root)).where(
            getSearchPredicates(root));
      this.count = this.entityManager.createQuery(countCriteria)
            .getSingleResult();

      // Populate this.pageItems

      CriteriaQuery<RangeOfAge> criteria = builder.createQuery(RangeOfAge.class);
      root = criteria.from(RangeOfAge.class);
      TypedQuery<RangeOfAge> query = this.entityManager.createQuery(criteria
            .select(root).where(getSearchPredicates(root)));
      query.setFirstResult(this.page * getPageSize()).setMaxResults(
            getPageSize());
      this.pageItems = query.getResultList();
   }

   private Predicate[] getSearchPredicates(Root<RangeOfAge> root)
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
      List<Predicate> predicatesList = new ArrayList<Predicate>();

      RangeOfAge rangeOfAge = this.example;
      if (rangeOfAge != null)
      {
         predicatesList.add(builder.equal(root.get("rangeOfAge"), rangeOfAge));
      }

      return predicatesList.toArray(new Predicate[predicatesList.size()]);
   }

   public List<RangeOfAge> getPageItems()
   {
      return this.pageItems;
   }

   public long getCount()
   {
      return this.count;
   }

   /*
    * Support listing and POSTing back Buying entities (e.g. from inside an
    * HtmlSelectOneMenu)
    */
   public List<RangeOfAge> getAll()
   {

      CriteriaQuery<RangeOfAge> criteria = this.entityManager
            .getCriteriaBuilder().createQuery(RangeOfAge.class);
      return this.entityManager.createQuery(
            criteria.select(criteria.from(RangeOfAge.class))).getResultList();
   }

   @Resource
   private SessionContext sessionContext;

   public Converter getConverter()
   {

      final RangeOfAgeBean ejbProxy = this.sessionContext.getBusinessObject(RangeOfAgeBean.class);

      return new Converter()
      {

         @Override
         public Object getAsObject(FacesContext context,
               UIComponent component, String value)
         {

            return ejbProxy.findById(Long.valueOf(value));
         }

         @Override
         public String getAsString(FacesContext context,
               UIComponent component, Object value)
         {

            if (value == null)
            {
               return "";
            }

            return String.valueOf(((RangeOfAge) value).getId());
         }
      };
   }

   /*
    * Support adding children to bidirectional, one-to-many tables
    */

   private RangeOfAge add = new RangeOfAge();

   public RangeOfAge getAdd()
   {
      return this.add;
   }

   public RangeOfAge getAdded()
   {
	  RangeOfAge added = this.add;
      this.add = new RangeOfAge();
      return added;
   }
}