package de.binaris.surveyapplication.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.surveyapplication.model.OnlineShop;
import de.binaris.surveyapplication.rest.dto.OnlineShopDTO;

/**
 * 
 */
@Stateless
@Path("/onlineshops")
public class OnlineShopEndpoint
{
   @PersistenceContext(unitName = "SurveyapplicationPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(OnlineShopDTO dto)
   {
      OnlineShop entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(OnlineShopEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      OnlineShop entity = em.find(OnlineShop.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<OnlineShop> findByIdQuery = em.createQuery("SELECT DISTINCT o FROM OnlineShop o WHERE o.id = :entityId ORDER BY o.id", OnlineShop.class);
      findByIdQuery.setParameter("entityId", id);
      OnlineShop entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      OnlineShopDTO dto = new OnlineShopDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<OnlineShopDTO> listAll()
   {
      final List<OnlineShop> searchResults = em.createQuery("SELECT DISTINCT o FROM OnlineShop o ORDER BY o.id", OnlineShop.class).getResultList();
      final List<OnlineShopDTO> results = new ArrayList<OnlineShopDTO>();
      for (OnlineShop searchResult : searchResults)
      {
         OnlineShopDTO dto = new OnlineShopDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, OnlineShopDTO dto)
   {
      TypedQuery<OnlineShop> findByIdQuery = em.createQuery("SELECT DISTINCT o FROM OnlineShop o WHERE o.id = :entityId ORDER BY o.id", OnlineShop.class);
      findByIdQuery.setParameter("entityId", id);
      OnlineShop entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}