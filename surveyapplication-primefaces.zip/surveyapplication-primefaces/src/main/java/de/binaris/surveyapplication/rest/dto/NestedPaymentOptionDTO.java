package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;
import de.binaris.surveyapplication.model.PaymentOption;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedPaymentOptionDTO implements Serializable
{

   private Long id;
   private String name;

   public NestedPaymentOptionDTO()
   {
   }

   public NestedPaymentOptionDTO(final PaymentOption entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public PaymentOption fromDTO(PaymentOption entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new PaymentOption();
      }
      if (this.id != null)
      {
         TypedQuery<PaymentOption> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT p FROM PaymentOption p WHERE p.id = :entityId",
                     PaymentOption.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}