package de.binaris.surveyapplication.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.surveyapplication.model.Feedback;
import de.binaris.surveyapplication.rest.dto.FeedbackDTO;

/**
 * 
 */
@Stateless
@Path("/feedbacks")
public class FeedbackEndpoint
{
   @PersistenceContext(unitName = "SurveyapplicationPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(FeedbackDTO dto)
   {
      Feedback entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(FeedbackEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Feedback entity = em.find(Feedback.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Feedback> findByIdQuery = em.createQuery("SELECT DISTINCT f FROM Feedback f WHERE f.id = :entityId ORDER BY f.id", Feedback.class);
      findByIdQuery.setParameter("entityId", id);
      Feedback entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      FeedbackDTO dto = new FeedbackDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<FeedbackDTO> listAll()
   {
      final List<Feedback> searchResults = em.createQuery("SELECT DISTINCT f FROM Feedback f ORDER BY f.id", Feedback.class).getResultList();
      final List<FeedbackDTO> results = new ArrayList<FeedbackDTO>();
      for (Feedback searchResult : searchResults)
      {
         FeedbackDTO dto = new FeedbackDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, FeedbackDTO dto)
   {
      TypedQuery<Feedback> findByIdQuery = em.createQuery("SELECT DISTINCT f FROM Feedback f WHERE f.id = :entityId ORDER BY f.id", Feedback.class);
      findByIdQuery.setParameter("entityId", id);
      Feedback entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}