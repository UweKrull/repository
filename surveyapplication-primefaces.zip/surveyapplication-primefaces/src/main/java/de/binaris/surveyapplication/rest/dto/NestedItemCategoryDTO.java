package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;
import de.binaris.surveyapplication.model.ItemCategory;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedItemCategoryDTO implements Serializable
{

   private Long id;
   private String name;

   public NestedItemCategoryDTO()
   {
   }

   public NestedItemCategoryDTO(final ItemCategory entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public ItemCategory fromDTO(ItemCategory entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ItemCategory();
      }
      if (this.id != null)
      {
         TypedQuery<ItemCategory> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT i FROM ItemCategory i WHERE i.id = :entityId",
                     ItemCategory.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}