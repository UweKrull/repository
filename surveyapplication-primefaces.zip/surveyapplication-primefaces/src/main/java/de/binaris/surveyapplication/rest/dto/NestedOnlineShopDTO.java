package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;
import de.binaris.surveyapplication.model.OnlineShop;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedOnlineShopDTO implements Serializable
{

   private Long id;
   private String name;

   public NestedOnlineShopDTO()
   {
   }

   public NestedOnlineShopDTO(final OnlineShop entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public OnlineShop fromDTO(OnlineShop entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new OnlineShop();
      }
      if (this.id != null)
      {
         TypedQuery<OnlineShop> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT o FROM OnlineShop o WHERE o.id = :entityId",
                     OnlineShop.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}