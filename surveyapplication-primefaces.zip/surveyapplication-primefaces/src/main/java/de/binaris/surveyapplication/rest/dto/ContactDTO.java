package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;
import de.binaris.surveyapplication.model.Contact;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ContactDTO implements Serializable
{

   private Long id;
   private String phoneNumber;
   private String department;
   private String name;

   public ContactDTO()
   {
   }

   public ContactDTO(final Contact entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.phoneNumber = entity.getPhoneNumber();
         this.department = entity.getDepartment();
         this.name = entity.getName();
      }
   }

   public Contact fromDTO(Contact entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Contact();
      }
      entity.setPhoneNumber(this.phoneNumber);
      entity.setDepartment(this.department);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getPhoneNumber()
   {
      return this.phoneNumber;
   }

   public void setPhoneNumber(final String phoneNumber)
   {
      this.phoneNumber = phoneNumber;
   }

   public String getDepartment()
   {
      return this.department;
   }

   public void setDepartment(final String department)
   {
      this.department = department;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}