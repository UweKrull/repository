package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;

import de.binaris.surveyapplication.model.RetailShopper;
import de.binaris.surveyapplication.rest.dto.NestedCustomerDTO;
import de.binaris.surveyapplication.rest.dto.NestedFrequencyDTO;
import de.binaris.surveyapplication.rest.dto.NestedOnlineShopDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RetailShopperDTO implements Serializable
{

   private Long id;
   private NestedOnlineShopDTO onlineShop;
   private NestedFrequencyDTO frequency;
   private NestedCustomerDTO customer;

   public RetailShopperDTO()
   {
   }

   public RetailShopperDTO(final RetailShopper entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.onlineShop = new NestedOnlineShopDTO(entity.getOnlineShop());
         this.frequency = new NestedFrequencyDTO(entity.getFrequency());
         this.customer = new NestedCustomerDTO(entity.getCustomer());
      }
   }

   public RetailShopper fromDTO(RetailShopper entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new RetailShopper();
      }
      if (this.onlineShop != null)
      {
         entity.setOnlineShop(this.onlineShop.fromDTO(
               entity.getOnlineShop(), em));
      }
      if (this.frequency != null)
      {
         entity.setFrequency(this.frequency.fromDTO(entity.getFrequency(),
               em));
      }
      if (this.customer != null)
      {
         entity.setCustomer(this.customer.fromDTO(entity.getCustomer(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedOnlineShopDTO getOnlineShop()
   {
      return this.onlineShop;
   }

   public void setOnlineShop(final NestedOnlineShopDTO onlineShop)
   {
      this.onlineShop = onlineShop;
   }

   public NestedFrequencyDTO getFrequency()
   {
      return this.frequency;
   }

   public void setFrequency(final NestedFrequencyDTO frequency)
   {
      this.frequency = frequency;
   }

   public NestedCustomerDTO getCustomer()
   {
      return this.customer;
   }

   public void setCustomer(final NestedCustomerDTO customer)
   {
      this.customer = customer;
   }
}