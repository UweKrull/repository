package de.binaris.surveyapplication.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.surveyapplication.model.ShoppingExperience;
import de.binaris.surveyapplication.rest.dto.ShoppingExperienceDTO;

/**
 * 
 */
@Stateless
@Path("/shoppingexperiences")
public class ShoppingExperienceEndpoint
{
   @PersistenceContext(unitName = "SurveyapplicationPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(ShoppingExperienceDTO dto)
   {
      ShoppingExperience entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(ShoppingExperienceEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      ShoppingExperience entity = em.find(ShoppingExperience.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<ShoppingExperience> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM ShoppingExperience s LEFT JOIN FETCH s.feedback LEFT JOIN FETCH s.customer WHERE s.id = :entityId ORDER BY s.id", ShoppingExperience.class);
      findByIdQuery.setParameter("entityId", id);
      ShoppingExperience entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      ShoppingExperienceDTO dto = new ShoppingExperienceDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<ShoppingExperienceDTO> listAll()
   {
      final List<ShoppingExperience> searchResults = em.createQuery("SELECT DISTINCT s FROM ShoppingExperience s LEFT JOIN FETCH s.feedback LEFT JOIN FETCH s.customer ORDER BY s.id", ShoppingExperience.class).getResultList();
      final List<ShoppingExperienceDTO> results = new ArrayList<ShoppingExperienceDTO>();
      for (ShoppingExperience searchResult : searchResults)
      {
         ShoppingExperienceDTO dto = new ShoppingExperienceDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, ShoppingExperienceDTO dto)
   {
      TypedQuery<ShoppingExperience> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM ShoppingExperience s LEFT JOIN FETCH s.feedback LEFT JOIN FETCH s.customer WHERE s.id = :entityId ORDER BY s.id", ShoppingExperience.class);
      findByIdQuery.setParameter("entityId", id);
      ShoppingExperience entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}