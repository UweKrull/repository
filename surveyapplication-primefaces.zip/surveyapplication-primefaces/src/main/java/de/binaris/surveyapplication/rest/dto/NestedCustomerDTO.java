package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;
import de.binaris.surveyapplication.model.Customer;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedCustomerDTO implements Serializable
{

   private Long id;
   private String login;
   private String password;

   public NestedCustomerDTO()
   {
   }

   public NestedCustomerDTO(final Customer entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.login = entity.getLogin();
         this.password = entity.getPassword();
      }
   }

   public Customer fromDTO(Customer entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Customer();
      }
      if (this.id != null)
      {
         TypedQuery<Customer> findByIdQuery = em.createQuery(
               "SELECT DISTINCT c FROM Customer c WHERE c.id = :entityId",
               Customer.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setLogin(this.login);
      entity.setPassword(this.password);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }
}