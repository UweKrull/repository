package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;

import de.binaris.surveyapplication.model.Buying;
import de.binaris.surveyapplication.rest.dto.NestedCustomerDTO;
import de.binaris.surveyapplication.rest.dto.NestedItemCategoryDTO;
import de.binaris.surveyapplication.rest.dto.NestedPaymentOptionDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BuyingDTO implements Serializable
{

   private Long id;
   private NestedCustomerDTO customer;
   private NestedPaymentOptionDTO paymentOption;
   private NestedItemCategoryDTO itemCategory;

   public BuyingDTO()
   {
   }

   public BuyingDTO(final Buying entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.customer = new NestedCustomerDTO(entity.getCustomer());
         this.paymentOption = new NestedPaymentOptionDTO(
               entity.getPaymentOption());
         this.itemCategory = new NestedItemCategoryDTO(
               entity.getItemCategory());
      }
   }

   public Buying fromDTO(Buying entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Buying();
      }
      if (this.customer != null)
      {
         entity.setCustomer(this.customer.fromDTO(entity.getCustomer(), em));
      }
      if (this.paymentOption != null)
      {
         entity.setPaymentOption(this.paymentOption.fromDTO(
               entity.getPaymentOption(), em));
      }
      if (this.itemCategory != null)
      {
         entity.setItemCategory(this.itemCategory.fromDTO(
               entity.getItemCategory(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedCustomerDTO getCustomer()
   {
      return this.customer;
   }

   public void setCustomer(final NestedCustomerDTO customer)
   {
      this.customer = customer;
   }

   public NestedPaymentOptionDTO getPaymentOption()
   {
      return this.paymentOption;
   }

   public void setPaymentOption(final NestedPaymentOptionDTO paymentOption)
   {
      this.paymentOption = paymentOption;
   }

   public NestedItemCategoryDTO getItemCategory()
   {
      return this.itemCategory;
   }

   public void setItemCategory(final NestedItemCategoryDTO itemCategory)
   {
      this.itemCategory = itemCategory;
   }
}