package de.binaris.greetingcardsadmin.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Query;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

/**
 * The persistent class for the card_sent database table.
 * 
 */
@Entity
@Table(name="card_sent")
public class CardSent implements Serializable {
	private static final long serialVersionUID = 577756789101312L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="my_entity_seq_gen_sent")
	@SequenceGenerator(name = "my_entity_seq_gen_sent", sequenceName="sequence_card_sent", allocationSize=1)
	private Long idCardSent;

    @Temporal( TemporalType.DATE)
	@Column(name="CREATE_DATE", updatable = false)
	private Date createDate;

    @Temporal( TemporalType.DATE)
	@Column(name="EXPIRE_ARCHIV", updatable = false)
	private Date expireArchiv;

    @Temporal( TemporalType.DATE)
	@Column(name="EXPIRE_DATE", updatable = false)
	private Date expireDate;

	@Column(name="FROM_EMAIL")
	@Email
	private String fromEmail;

	@Column(name="FROM_NAME")
	@Size(min = 1, max = 300, message = "must be 1-300 letters and spaces long")
	private String fromName;

	@Column(name="FROM_VORNAME")
	@Size(min = 1, max = 300, message = "must be 1-300 letters and spaces long")
	private String fromVorname;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private CardInfo cardInfo;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Image image;

	@Min(value = 0, message = "possible values: 0 (not yet sent), 1 (sent)")
	@Max(value = 1, message = "possible values: 0 (not yet sent), 1 (sent)")
	@Column(name="IS_SENT")
	private Short isSent;

	@Column(name="SEEN_COUNT")
	private Short seenCount;

    @Temporal(TemporalType.DATE)
	@Column(name="SEEN_DATE")
	private Date seenDate;

	@Column(name="SEND_ON_PICKUP")
	private String sendOnPickup;

	@Column(name="TO_EMAIL")
	@Email
	private String toEmail;

	@Column(name="TO_NAME")
	@Size(min = 1, max = 300, message = "must be 1-300 letters and spaces long")
	private String toName;

	@Column(name="TO_VORNAME")
	@Size(min = 1, max = 300, message = "must be 1-300 letters and spaces long")
	private String toVorname;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Customer customer;
	
    public CardSent() {
    }

	public Long getIdCardSent() {
		return this.idCardSent;
	}

	public void setIdCardSent(Long idCardSent) {
		this.idCardSent = idCardSent;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getExpireArchiv() {
		return this.expireArchiv;
	}

	public void setExpireArchiv(Date expireArchiv) {
		this.expireArchiv = expireArchiv;
	}

	public Date getExpireDate() {
		return this.expireDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	public String getFromEmail() {
		return this.fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getFromName() {
		return this.fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getFromVorname() {
		return this.fromVorname;
	}

	public void setFromVorname(String fromVorname) {
		this.fromVorname = fromVorname;
	}
	
	public CardInfo getCardInfo() {
		return this.cardInfo;
	}

	public void setCardInfo(CardInfo cardInfo) {
		this.cardInfo = cardInfo;
	}

	public Image getImage() {
		return this.image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public Short getIsSent() {
		return this.isSent;
	}

	public void setIsSent(Short isSent) {
		this.isSent = isSent;
	}

	public Short getSeenCount() {
		return this.seenCount;
	}

	public void setSeenCount(Short seenCount) {
		this.seenCount = seenCount;
	}

	public Date getSeenDate() {
		return this.seenDate;
	}

	public void setSeenDate(Date seenDate) {
		this.seenDate = seenDate;
	}

	public String getSendOnPickup() {
		return this.sendOnPickup;
	}

	public void setSendOnPickup(String sendOnPickup) {
		this.sendOnPickup = sendOnPickup;
	}

	public String getToEmail() {
		return this.toEmail;
	}

	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}

	public String getToName() {
		return this.toName;
	}

	public void setToName(String toName) {
		this.toName = toName;
	}

	public String getToVorname() {
		return this.toVorname;
	}

	public void setToVorname(String toVorname) {
		this.toVorname = toVorname;
	}
	
    @Override
    public int hashCode() {
        return idCardSent != null ? idCardSent.hashCode() : System.identityHashCode(this);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CardSent)) {
            return false;
        }
        CardSent castOther = (CardSent) object;
        return idCardSent != null ? idCardSent.equals(castOther.getIdCardSent()) : false;
    }
    
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
//		sb.append("CardSent: ");
		sb.append(fromEmail);
		sb.append(", ").append(toEmail);
//		sb.append(", ").append(isSent);
		sb.append(", ").append(seenDate);
		return sb.toString();
	}
	
    public static Long getCardSentMaxId(EntityManager em) {
        final Query q = em.createQuery("select max(c.idCardSent) from CardSent as c");
        return ((Long) q.getSingleResult());
    }
}