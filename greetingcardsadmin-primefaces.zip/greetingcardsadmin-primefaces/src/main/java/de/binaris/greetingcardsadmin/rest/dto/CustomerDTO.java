package de.binaris.greetingcardsadmin.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

import de.binaris.greetingcardsadmin.model.CardSent;
import de.binaris.greetingcardsadmin.model.Customer;
import de.binaris.greetingcardsadmin.rest.dto.AddressDTO;
import de.binaris.greetingcardsadmin.rest.dto.NestedCardSentDTO;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerDTO implements Serializable {

	private static final long serialVersionUID = 5795172319129215252L;

	private Date dateOfBirth;
	private String lastName;
	private String phone;
	private String password;
	private Long id;
	private String createdBy;
	private String email;
	private Set<NestedCardSentDTO> cardsSent = new HashSet<NestedCardSentDTO>();
	private AddressDTO address;
	private Date lastChangeDate;
	private String login;
	private String firstName;

	public CustomerDTO() {
	}

	public CustomerDTO(final Customer entity) {
		if (entity != null) {
			this.dateOfBirth = entity.getDateOfBirth();
			this.lastName = entity.getLastName();
			this.phone = entity.getPhone();
			this.password = entity.getPassword();
			this.id = entity.getId();
			this.createdBy = entity.getCreatedBy();
			this.email = entity.getEmail();
			Iterator<CardSent> iterCardsSent = entity.getCardsSent().iterator();
			for (; iterCardsSent.hasNext();) {
				CardSent element = iterCardsSent.next();
				this.cardsSent.add(new NestedCardSentDTO(element));
			}
			this.address = new AddressDTO(entity.getAddress());
			this.lastChangeDate = entity.getLastChangeDate();
			this.login = entity.getLogin();
			this.firstName = entity.getFirstName();
		}
	}

	public Customer fromDTO(Customer entity, EntityManager em) {
		if (entity == null) {
			entity = new Customer();
		}
		entity.setDateOfBirth(this.dateOfBirth);
		entity.setLastName(this.lastName);
		entity.setPhone(this.phone);
		entity.setPassword(this.password);
		entity.setCreatedBy(this.createdBy);
		entity.setEmail(this.email);
		Iterator<CardSent> iterCardsSent = entity.getCardsSent().iterator();
		for (; iterCardsSent.hasNext();) {
			boolean found = false;
			CardSent cardSent = iterCardsSent.next();
			Iterator<NestedCardSentDTO> iterDtoCardsSent = this.getCardsSent()
					.iterator();
			for (; iterDtoCardsSent.hasNext();) {
				NestedCardSentDTO dtoCardSent = iterDtoCardsSent.next();
				if (dtoCardSent.getIdCardSent()
						.equals(cardSent.getIdCardSent())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterCardsSent.remove();
			}
		}
		Iterator<NestedCardSentDTO> iterDtoCardsSent = this.getCardsSent()
				.iterator();
		for (; iterDtoCardsSent.hasNext();) {
			boolean found = false;
			NestedCardSentDTO dtoCardSent = iterDtoCardsSent.next();
			iterCardsSent = entity.getCardsSent().iterator();
			for (; iterCardsSent.hasNext();) {
				CardSent cardSent = iterCardsSent.next();
				if (dtoCardSent.getIdCardSent()
						.equals(cardSent.getIdCardSent())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<CardSent> resultIter = em
						.createQuery("SELECT DISTINCT c FROM CardSent c",
								CardSent.class).getResultList().iterator();
				for (; resultIter.hasNext();) {
					CardSent result = resultIter.next();
					if (result.getIdCardSent().equals(
							dtoCardSent.getIdCardSent())) {
						entity.getCardsSent().add(result);
						break;
					}
				}
			}
		}
		if (this.address != null) {
			entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
		}
		entity.setLastChangeDate(this.lastChangeDate);
		entity.setLogin(this.login);
		entity.setFirstName(this.firstName);
		entity = em.merge(entity);
		return entity;
	}

	public Date getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(final Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(final String phone) {
		this.phone = phone;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(final String password) {
		this.password = password;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(final String createdBy) {
		this.createdBy = createdBy;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public Set<NestedCardSentDTO> getCardsSent() {
		return this.cardsSent;
	}

	public void setCardsSent(final Set<NestedCardSentDTO> cardsSent) {
		this.cardsSent = cardsSent;
	}

	public AddressDTO getAddress() {
		return this.address;
	}

	public void setAddress(final AddressDTO address) {
		this.address = address;
	}

	public Date getLastChangeDate() {
		return this.lastChangeDate;
	}

	public void setLastChangeDate(final Date lastChangeDate) {
		this.lastChangeDate = lastChangeDate;
	}

	public String getLogin() {
		return this.login;
	}

	public void setLogin(final String login) {
		this.login = login;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}
}