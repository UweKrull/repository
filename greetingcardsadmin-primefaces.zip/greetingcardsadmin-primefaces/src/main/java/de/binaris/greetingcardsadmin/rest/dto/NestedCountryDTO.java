package de.binaris.greetingcardsadmin.rest.dto;

import java.io.Serializable;

import de.binaris.greetingcardsadmin.model.Country;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedCountryDTO implements Serializable {

	private static final long serialVersionUID = 7175711757175157721L;

	private Long id;
	private String printableName;
	private String numcode;
	private String name;
	private String iso3;
	private String isoCode;

	public NestedCountryDTO() {
	}

	public NestedCountryDTO(final Country entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.printableName = entity.getPrintableName();
			this.numcode = entity.getNumcode();
			this.name = entity.getName();
			this.iso3 = entity.getIso3();
			this.isoCode = entity.getIsoCode();
		}
	}

	public Country fromDTO(Country entity, EntityManager em) {
		if (entity == null) {
			entity = new Country();
		}
		if (this.id != null) {
			TypedQuery<Country> findByIdQuery = em.createQuery(
					"SELECT DISTINCT c FROM Country c WHERE c.id = :entityId",
					Country.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setPrintableName(this.printableName);
		entity.setNumcode(this.numcode);
		entity.setName(this.name);
		entity.setIso3(this.iso3);
		entity.setIsoCode(this.isoCode);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getPrintableName() {
		return this.printableName;
	}

	public void setPrintableName(final String printableName) {
		this.printableName = printableName;
	}

	public String getNumcode() {
		return this.numcode;
	}

	public void setNumcode(final String numcode) {
		this.numcode = numcode;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public String getIso3() {
		return this.iso3;
	}

	public void setIso3(final String iso3) {
		this.iso3 = iso3;
	}

	public String getIsoCode() {
		return this.isoCode;
	}

	public void setIsoCode(final String isoCode) {
		this.isoCode = isoCode;
	}
}