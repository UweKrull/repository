package de.binaris.greetingcardsadmin.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.greetingcardsadmin.model.SubcategoryMedia;
import de.binaris.greetingcardsadmin.rest.dto.SubcategoryMediaDTO;

/**
 * 
 */
@Stateless
@Path("/subcategorymedias")
public class SubcategoryMediaEndpoint
{
   @PersistenceContext(unitName = "GreetingcardsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(SubcategoryMediaDTO dto)
   {
      SubcategoryMedia entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(SubcategoryMediaEndpoint.class).path(String.valueOf(entity.getIdSubcategoryMedia())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      SubcategoryMedia entity = em.find(SubcategoryMedia.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<SubcategoryMedia> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM SubcategoryMedia s LEFT JOIN FETCH s.media WHERE s.idSubcategoryMedia = :entityId ORDER BY s.idSubcategoryMedia", SubcategoryMedia.class);
      findByIdQuery.setParameter("entityId", id);
      SubcategoryMedia entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      SubcategoryMediaDTO dto = new SubcategoryMediaDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<SubcategoryMediaDTO> listAll()
   {
      final List<SubcategoryMedia> searchResults = em.createQuery("SELECT DISTINCT s FROM SubcategoryMedia s LEFT JOIN FETCH s.media ORDER BY s.idSubcategoryMedia", SubcategoryMedia.class).getResultList();
      final List<SubcategoryMediaDTO> results = new ArrayList<SubcategoryMediaDTO>();
      for (SubcategoryMedia searchResult : searchResults)
      {
         SubcategoryMediaDTO dto = new SubcategoryMediaDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, SubcategoryMediaDTO dto)
   {
      TypedQuery<SubcategoryMedia> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM SubcategoryMedia s LEFT JOIN FETCH s.media WHERE s.idSubcategoryMedia = :entityId ORDER BY s.idSubcategoryMedia", SubcategoryMedia.class);
      findByIdQuery.setParameter("entityId", id);
      SubcategoryMedia entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}