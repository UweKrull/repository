package de.binaris.greetingcardsadmin.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Query;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The persistent class for the subcategory database table.
 */
@Entity
@Table(name="subcategory")
public class Subcategory implements Serializable {
	private static final long serialVersionUID = 19875064320198765L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="my_entity_seq_gen_sub")
	@SequenceGenerator(name = "my_entity_seq_gen_sub", sequenceName="sequence_subcategory", allocationSize=1)
	private Long idSubcategory;

	@NotNull
	@Min(value = 0, message = "possible values: 0 (not approved), 1 (approved)")
	@Max(value = 1, message = "possible values: 0 (not approved), 1 (approved)")
	private Short approved;

	@Column(name="CATEGORY_DESCRIPTION")
	private String categoryDescription;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Category category;

	private String commercial;
	
	@NotNull
	@Size(min = 3, max = 400, message = "must be 3-400 letters and spaces long")
	private String description;

	@Column(name="FONT_SIZE")
	private String fontSize;

	@Column(name="HTML_DESCRIPTION")
	private String htmlDescription;

	@Column(name="HTML_KEYWORD")
	private String htmlKeyword;

	@Column(name="HTML_TITLE")
	private String htmlTitle;

	@Column(name="SUBCATEGORY_ID")
	@NotNull
	@Min(value = 1,  message = "real subcategory values range from 1-99")
	@Max(value = 99, message = "real subcategory values range from 1-99")
	private Integer subcategoryId;

	@Column(name="TEXT_COLOR")
	private String textColor;

	@Column(name="TEXT_LINK")
	private String textLink;

    public Subcategory() {
    }

	public Long getIdSubcategory() {
		return this.idSubcategory;
	}

	public void setIdSubcategory(Long idSubcategory) {
		this.idSubcategory = idSubcategory;
	}

	public Short getApproved() {
		return this.approved;
	}

	public void setApproved(Short approved) {
		this.approved = approved;
	}

	public String getCategoryDescription() {
		return this.categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getCommercial() {
		return this.commercial;
	}

	public void setCommercial(String commercial) {
		this.commercial = commercial;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFontSize() {
		return this.fontSize;
	}

	public void setFontSize(String fontSize) {
		this.fontSize = fontSize;
	}

	public String getHtmlDescription() {
		return this.htmlDescription;
	}

	public void setHtmlDescription(String htmlDescription) {
		this.htmlDescription = htmlDescription;
	}

	public String getHtmlKeyword() {
		return this.htmlKeyword;
	}

	public void setHtmlKeyword(String htmlKeyword) {
		this.htmlKeyword = htmlKeyword;
	}

	public String getHtmlTitle() {
		return this.htmlTitle;
	}

	public void setHtmlTitle(String htmlTitle) {
		this.htmlTitle = htmlTitle;
	}

	public Integer getSubcategoryId() {
		return this.subcategoryId;
	}

	public void setSubcategoryId(Integer subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public String getTextColor() {
		return this.textColor;
	}

	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}

	public String getTextLink() {
		return this.textLink;
	}

	public void setTextLink(String textLink) {
		this.textLink = textLink;
	}

    @Override
    public int hashCode() {
        return idSubcategory != null ? idSubcategory.hashCode() : System.identityHashCode(this);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Subcategory)) {
            return false;
        }
        Subcategory castOther = (Subcategory) object;
        return idSubcategory != null ? idSubcategory.equals(castOther.getIdSubcategory()) : false;
    }
    
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("Subcategory: ");
		sb.append('\'').append(description).append('\'');
		sb.append('\'').append(approved).append('\'');
		sb.append('\'').append(subcategoryId).append('\'');
		sb.append('\'').append(category.getIdCategory()).append('\'');
		return sb.toString();
	}
	
    public static Long getSubcategoryMaxId(EntityManager em) {
        final Query q = em.createQuery("select max(s.idSubcategory) from Subcategory as s");
        return ((Long) q.getSingleResult());
    }
}