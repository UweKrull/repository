package de.binaris.greetingcardsadmin.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.greetingcardsadmin.model.Image;
import de.binaris.greetingcardsadmin.rest.dto.ImageDTO;

/**
 * 
 */
@Stateless
@Path("/images")
public class ImageEndpoint
{
   @PersistenceContext(unitName = "GreetingcardsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(ImageDTO dto)
   {
      Image entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(ImageEndpoint.class).path(String.valueOf(entity.getIdImage())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Image entity = em.find(Image.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Image> findByIdQuery = em.createQuery("SELECT DISTINCT i FROM Image i LEFT JOIN FETCH i.subcategoryMedia WHERE i.idImage = :entityId ORDER BY i.idImage", Image.class);
      findByIdQuery.setParameter("entityId", id);
      Image entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      ImageDTO dto = new ImageDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<ImageDTO> listAll()
   {
      final List<Image> searchResults = em.createQuery("SELECT DISTINCT i FROM Image i LEFT JOIN FETCH i.subcategoryMedia ORDER BY i.idImage", Image.class).getResultList();
      final List<ImageDTO> results = new ArrayList<ImageDTO>();
      for (Image searchResult : searchResults)
      {
         ImageDTO dto = new ImageDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, ImageDTO dto)
   {
      TypedQuery<Image> findByIdQuery = em.createQuery("SELECT DISTINCT i FROM Image i LEFT JOIN FETCH i.subcategoryMedia WHERE i.idImage = :entityId ORDER BY i.idImage", Image.class);
      findByIdQuery.setParameter("entityId", id);
      Image entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}