package de.binaris.greetingcardsadmin.rest.dto;

import java.io.Serializable;

import de.binaris.greetingcardsadmin.model.Image;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedImageDTO implements Serializable {

	private static final long serialVersionUID = 7755771257679151379L;

	private String fullUrl;
	private String link;
	private Long idImage;
	private Long extId;
	private String url;
	private Integer extRubrik;
	private Short approved;
	private String name;
	private Integer extNr;
	private Integer mediaTypeId;
	private String picName;
	private Integer poolId;

	public NestedImageDTO() {
	}

	public NestedImageDTO(final Image entity) {
		if (entity != null) {
			this.fullUrl = entity.getFullUrl();
			this.link = entity.getLink();
			this.idImage = entity.getIdImage();
			this.extId = entity.getExtId();
			this.url = entity.getUrl();
			this.extRubrik = entity.getExtRubrik();
			this.approved = entity.getApproved();
			this.name = entity.getName();
			this.extNr = entity.getExtNr();
			this.mediaTypeId = entity.getMediaTypeId();
			this.picName = entity.getPicName();
			this.poolId = entity.getPoolId();
		}
	}

	public Image fromDTO(Image entity, EntityManager em) {
		if (entity == null) {
			entity = new Image();
		}
		if (this.idImage != null) {
			TypedQuery<Image> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT i FROM Image i WHERE i.idImage = :entityId",
							Image.class);
			findByIdQuery.setParameter("entityId", this.idImage);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setFullUrl(this.fullUrl);
		entity.setLink(this.link);
		entity.setExtId(this.extId);
		entity.setUrl(this.url);
		entity.setExtRubrik(this.extRubrik);
		entity.setApproved(this.approved);
		entity.setName(this.name);
		entity.setExtNr(this.extNr);
		entity.setMediaTypeId(this.mediaTypeId);
		entity.setPicName(this.picName);
		entity.setPoolId(this.poolId);
		entity = em.merge(entity);
		return entity;
	}

	public String getFullUrl() {
		return this.fullUrl;
	}

	public void setFullUrl(final String fullUrl) {
		this.fullUrl = fullUrl;
	}

	public String getLink() {
		return this.link;
	}

	public void setLink(final String link) {
		this.link = link;
	}

	public Long getIdImage() {
		return this.idImage;
	}

	public void setIdImage(final Long idImage) {
		this.idImage = idImage;
	}

	public Long getExtId() {
		return this.extId;
	}

	public void setExtId(final Long extId) {
		this.extId = extId;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(final String url) {
		this.url = url;
	}

	public Integer getExtRubrik() {
		return this.extRubrik;
	}

	public void setExtRubrik(final Integer extRubrik) {
		this.extRubrik = extRubrik;
	}

	public Short getApproved() {
		return this.approved;
	}

	public void setApproved(final Short approved) {
		this.approved = approved;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public Integer getExtNr() {
		return this.extNr;
	}

	public void setExtNr(final Integer extNr) {
		this.extNr = extNr;
	}

	public Integer getMediaTypeId() {
		return this.mediaTypeId;
	}

	public void setMediaTypeId(final Integer mediaTypeId) {
		this.mediaTypeId = mediaTypeId;
	}

	public String getPicName() {
		return this.picName;
	}

	public void setPicName(final String picName) {
		this.picName = picName;
	}

	public Integer getPoolId() {
		return this.poolId;
	}

	public void setPoolId(final Integer poolId) {
		this.poolId = poolId;
	}
}