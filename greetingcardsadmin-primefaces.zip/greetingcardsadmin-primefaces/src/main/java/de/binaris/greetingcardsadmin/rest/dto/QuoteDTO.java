package de.binaris.greetingcardsadmin.rest.dto;

import java.io.Serializable;

import de.binaris.greetingcardsadmin.model.Quote;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class QuoteDTO implements Serializable {

	private static final long serialVersionUID = 2529391357197123371L;

	private String spruchText;
	private String spruchType;
	private Long idQuote;

	public QuoteDTO() {
	}

	public QuoteDTO(final Quote entity) {
		if (entity != null) {
			this.spruchText = entity.getSpruchText();
			this.spruchType = entity.getSpruchType();
			this.idQuote = entity.getIdQuote();
		}
	}

	public Quote fromDTO(Quote entity, EntityManager em) {
		if (entity == null) {
			entity = new Quote();
		}
		entity.setSpruchText(this.spruchText);
		entity.setSpruchType(this.spruchType);
		entity = em.merge(entity);
		return entity;
	}

	public String getSpruchText() {
		return this.spruchText;
	}

	public void setSpruchText(final String spruchText) {
		this.spruchText = spruchText;
	}

	public String getSpruchType() {
		return this.spruchType;
	}

	public void setSpruchType(final String spruchType) {
		this.spruchType = spruchType;
	}

	public Long getIdQuote() {
		return this.idQuote;
	}

	public void setIdQuote(final Long idQuote) {
		this.idQuote = idQuote;
	}
}