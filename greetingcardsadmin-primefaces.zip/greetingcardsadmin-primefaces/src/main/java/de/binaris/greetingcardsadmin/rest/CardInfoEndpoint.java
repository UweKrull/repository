package de.binaris.greetingcardsadmin.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.greetingcardsadmin.model.CardInfo;
import de.binaris.greetingcardsadmin.rest.dto.CardInfoDTO;

/**
 * 
 */
@Stateless
@Path("/cardinfos")
public class CardInfoEndpoint
{
   @PersistenceContext(unitName = "GreetingcardsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(CardInfoDTO dto)
   {
      CardInfo entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(CardInfoEndpoint.class).path(String.valueOf(entity.getIdCardInfo())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      CardInfo entity = em.find(CardInfo.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<CardInfo> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM CardInfo c LEFT JOIN FETCH c.image LEFT JOIN FETCH c.category LEFT JOIN FETCH c.subcategory LEFT JOIN FETCH c.imageBg LEFT JOIN FETCH c.customer WHERE c.idCardInfo = :entityId ORDER BY c.idCardInfo", CardInfo.class);
      findByIdQuery.setParameter("entityId", id);
      CardInfo entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      CardInfoDTO dto = new CardInfoDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<CardInfoDTO> listAll()
   {
      final List<CardInfo> searchResults = em.createQuery("SELECT DISTINCT c FROM CardInfo c LEFT JOIN FETCH c.image LEFT JOIN FETCH c.category LEFT JOIN FETCH c.subcategory LEFT JOIN FETCH c.imageBg LEFT JOIN FETCH c.customer ORDER BY c.idCardInfo", CardInfo.class).getResultList();
      final List<CardInfoDTO> results = new ArrayList<CardInfoDTO>();
      for (CardInfo searchResult : searchResults)
      {
         CardInfoDTO dto = new CardInfoDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, CardInfoDTO dto)
   {
      TypedQuery<CardInfo> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM CardInfo c LEFT JOIN FETCH c.image LEFT JOIN FETCH c.category LEFT JOIN FETCH c.subcategory LEFT JOIN FETCH c.imageBg LEFT JOIN FETCH c.customer WHERE c.idCardInfo = :entityId ORDER BY c.idCardInfo", CardInfo.class);
      findByIdQuery.setParameter("entityId", id);
      CardInfo entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}