Binaris Grusskarten: 
====================
Technologies: CDI, JSF, JPA, EJB, JPA, JAX-RS, 
Summary: An example that incorporates multiple technologies
Target Product: EAP

What is it?
-----------
A sample, deployable Maven 3 project developing with Java EE 6 on JBoss Enterprise Application Platform 6 or JBoss AS 7. 
This project creates a compliant Java EE 6 application using JSF 2.0, CDI 1.0, EJB 3.1, JPA 2.0 and RichFaces.
It includes a persistence unit and some sample persistence and transaction code with enterprise Java database access.

System requirements
-------------------
Java 6.0 (Java SDK 1.6) or higher, Maven 3.0 or higher.
The application this project produces is designed to be run on JBoss Enterprise Application Platform 6.3 (which is JBoss AS 7.4). 
 
Start JBoss EAP 6.3 Server
--------------------------
1. Open a command line and navigate to the root of the JBoss server directory.
2. The following shows the command line to start the server with the web profile:

        For Linux:   JBOSS_HOME/bin/standalone.sh
        For Windows: JBOSS_HOME\bin\standalone.bat
 
Build and Deploy the Grusskarten
--------------------------------
NOTE: The following build command assumes you have configured your Maven user settings. If you have not, you must include Maven setting arguments on the command line. See [Build and Deploy the Quickstarts](../README.md#buildanddeploy) for complete instructions and additional options.

1. Make sure you have started the JBoss Server as described above.
2. Open a command line and navigate to the root directory of this quickstart.
3. Type this command to build and deploy the archive:

        mvn clean package jboss-as:deploy

4. This will deploy `target/grusskarten.war` to the running instance of the server.
 
Access the application 
---------------------
The application will be running at the following URL: <http://localhost:8080/grusskarten/>.

Just fill in a name, an email, and a message to be sent, then klick on a greetingcard to
send it to the existing recipient email.

Remember: The recipient will get the message within the greetingcard email, but the 
			chosen picture will only be available, if the application is running on
			a publicly accessable domain usually different from http://localhost.
