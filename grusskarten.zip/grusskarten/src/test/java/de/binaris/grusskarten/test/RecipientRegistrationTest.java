package de.binaris.grusskarten.test;

import static org.junit.Assert.assertNotNull;

import java.util.logging.Logger;

import javax.inject.Inject;

import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.shrinkwrap.api.Archive;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.asset.EmptyAsset;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Test;
import org.junit.runner.RunWith;

import de.binaris.grusskarten.model.Recipient;
import de.binaris.grusskarten.service.RecipientRegistration;
import de.binaris.grusskarten.util.Resources;

@RunWith(Arquillian.class)
public class RecipientRegistrationTest {
    @Deployment
    public static Archive<?> createTestArchive() {
        return ShrinkWrap.create(WebArchive.class, "test.war")
                .addClasses(Recipient.class, RecipientRegistration.class, Resources.class)
                .addAsResource("META-INF/test-persistence.xml", "META-INF/persistence.xml")
                .addAsWebInfResource(EmptyAsset.INSTANCE, "beans.xml")
                // deploy the test datasource
                .addAsWebInfResource("grusskarten-test-ds.xml");
    }

    @Inject
    RecipientRegistration recipientRegistration;

    @Inject
    Logger recipientLogger;

    @Test
    public void testRegister() throws Exception {
        Recipient newRecipient = new Recipient();
        newRecipient.setName("Jane Doe");
        newRecipient.setEmail("jane@mailinator.com");
        newRecipient.setMessage("Hey Jane, please call me.");
        newRecipient.setPathToCard("resources/gfx/galleria1.jpg");
        recipientRegistration.register(newRecipient);
        assertNotNull(newRecipient.getId());
        recipientLogger.info(newRecipient.getName() + " was persisted with id " + newRecipient.getId());
    }
}
