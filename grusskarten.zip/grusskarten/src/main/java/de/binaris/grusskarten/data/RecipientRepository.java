package de.binaris.grusskarten.data;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import java.util.List;

import de.binaris.grusskarten.model.Recipient;

@ApplicationScoped
public class RecipientRepository {

    @Inject
    private EntityManager em;

    public Recipient findById(Long id) {
        return em.find(Recipient.class, id);
    }

    public Recipient findByEmail(String email) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Recipient> criteria = cb.createQuery(Recipient.class);
        Root<Recipient> recipient = criteria.from(Recipient.class);
        // Swap criteria statements to try out type-safe criteria queries, a new
        // feature in JPA 2.0
        // criteria.select(member).where(cb.equal(member.get(Recipient_.name), email));
        criteria.select(recipient).where(cb.equal(recipient.get("email"), email));
        return em.createQuery(criteria).getSingleResult();
    }

    public List<Recipient> findAllOrderedByName() {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Recipient> criteria = cb.createQuery(Recipient.class);
        Root<Recipient> recipient = criteria.from(Recipient.class);
        // Swap criteria statements to try out type-safe criteria queries, a new
        // feature in JPA 2.0
        // criteria.select(recipient).orderBy(cb.asc(member.get(Recipient_.name)));
        criteria.select(recipient).orderBy(cb.asc(recipient.get("name")));
        return em.createQuery(criteria).getResultList();
    }
}
