package de.binaris.grusskarten.controller;

import java.util.HashMap;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import de.binaris.grusskarten.model.Recipient;
import de.binaris.grusskarten.service.RecipientRegistration;

@Model
public class RecipientController {

    @Inject
    private FacesContext facesContext;

    @Inject
    private RecipientRegistration recipientRegistration;

    @Produces
    @Named
    private Recipient newRecipient;

    @PostConstruct
    public void initNewRecipient() {
    	newRecipient = new Recipient();
    }
    
    public void register(String pathToCard) throws Exception {
        try {
            Logger log = Logger.getLogger("RecipientController");
        	HashMap<String, String> cardsRecipient = new HashMap<String, String>();
        	newRecipient.setPathToCard(pathToCard);
        	cardsRecipient.put("mailRecipientName", newRecipient.getName());
        	cardsRecipient.put("mailRecipientEmail", newRecipient.getEmail());
        	cardsRecipient.put("message", newRecipient.getMessage());
        	cardsRecipient.put("pathToCard", newRecipient.getPathToCard());
        	recipientRegistration.setCardsRecipient(cardsRecipient);
        	recipientRegistration.register(newRecipient);
        	
        	log.info("register: cardsRecipient.get('"+"mailRecipientName"+"'): "+cardsRecipient.get("mailRecipientName"));
        	log.info("register: cardsRecipient.get('"+"mailRecipientEmail"+"'): "+cardsRecipient.get("mailRecipientEmail"));
        	log.info("register: cardsRecipient.get('"+"message"+"'): "+cardsRecipient.get("message"));
        	log.info("register: cardsRecipient.get('"+"pathToCard"+"'): "+cardsRecipient.get("pathToCard"));
        	
        	initNewRecipient();
        	
            FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_INFO, "Recipient registered, card sent!", "Registration successful");
            facesContext.addMessage(null, m);
        } catch (Exception e) {
            String errorMessage = getRootErrorMessage(e);
            FacesMessage m = new FacesMessage(FacesMessage.SEVERITY_ERROR, errorMessage, "Registration unsuccessful");
            facesContext.addMessage(null, m);
        }
    }

    private String getRootErrorMessage(Exception e) {
        // Default to general error message that registration failed.
        String errorMessage = "Registration failed. See server log for more information";
        if (e == null) {
            // default error messages
            return errorMessage;
        }
        // find the root cause
        Throwable t = e;
        while (t != null) {
            // Get the message from the Throwable class instance
            errorMessage = t.getLocalizedMessage();
            t = t.getCause();
        }
        // root cause message
        return errorMessage;
    }
}
