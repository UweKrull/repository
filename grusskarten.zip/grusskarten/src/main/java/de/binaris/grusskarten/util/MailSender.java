package de.binaris.grusskarten.util;

import java.util.Properties;
import java.util.logging.Logger;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 * Util class for mailing the greetingcard message via yahoo mail account. 
 * The pic is not sent as an attachment, but provided by a link to the pic.
 * 
 * @author uwe
 */
public class MailSender {

	/**
	 * send a mail multipart message using userMail address and password pass
	 * 
	 * @param userMail
	 * @param pass
	 * @throws AddressException
	 * @throws MessagingException
	 */
	public static void sendMessage(String userMail, String pass, String recipientName, String recipientMail, String text, String pathToImage) throws AddressException, MessagingException {
		
		final Session session = getMailSenderSessionYahoo(userMail);
		final MimeMessage message = getMimeMessage(session);
		
		String urlToImage = "http://91.250.116.208:8485/grusskarten/"+pathToImage;
        final Logger log = Logger.getLogger("MailSender");
        log.info("urlToImage: "+urlToImage);
        String subject = "Sie haben eine Grusskarte erhalten / You have received a greetingcard";
		message.addRecipient(Message.RecipientType.TO, 
					new InternetAddress(recipientMail));
		message.addRecipient(Message.RecipientType.CC, 
					new InternetAddress(userMail));
		message.setSubject(subject, "UTF-8");
		
		String emailBody = ""+
		        "<p>Sehr geehrte(r) "+recipientName+", </p><br />"+
		        "<p>soeben haben Sie eine Grusskarte mit folgendem Text erhalten: </p><br />"+
		        "<p>"+text+"</p><br />"+
		        "<p>Das Grusskartenbild kann hier betrachtet werden: </p><br />"+
		        "<p><a href="+'"'+urlToImage+'"'+">"+urlToImage+"</a></p><br />"+
		        "<p>Freundlichst </p><br />"+
	            "<p>Ihr Grusskarten Team der Bitech AG. </p><br />"+
	            "<p>------------------------------------------------------------ </p><br />"+
	            "<p>Dear "+recipientName+", </p><br />"+
	            "<p>you have just received a greetingcard with the following message: </p><br />"+
	            "<p>"+text+"</p><br />"+
	            "<p>The related greetingcard can be viewed here: </p><br />"+
	            "<p><a href="+'"'+urlToImage+'"'+">"+urlToImage+"</a></p><br />"+
	            "<p>Best wishes and kind regards. </p><br />"+
	            "<p>Bitech AG Greetingcards Team </p><br />";
		MimeBodyPart mbp = new MimeBodyPart();
        mbp.setContent(emailBody, "text/html;charset=utf-8");
        
        Multipart mp = new MimeMultipart();
        mp.addBodyPart(mbp);
        
		message.setContent(mp);
		message.setFrom(new InternetAddress(userMail));
		message.setReplyTo(new Address[]{new InternetAddress(userMail)});
		message.setSentDate(new java.util.Date());
		log.info("emailBody: "+emailBody);
		
		final Transport transport = session.getTransport("smtp");
		log.info("Trying to send greetingcard mail: ");
		log.info("Trying to connect... ");
		int port = 465;
		try {
			transport.connect("smtp.mail.yahoo.com", port, userMail, pass);
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		log.info("Connected... ");
		log.info("Trying to sendMessage... ");
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					transport.sendMessage(message, message.getAllRecipients());
					Thread.sleep(2000);
					log.info("Message has been sent... ");
					transport.close();
					log.info("Transport closed... ");
				} catch (MessagingException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}).start();
	}
	
	/**
	 * get a Yahoo mail account session to send the email via account userMail
	 * 
	 * @param userMail
	 * @return Session
	 */
	public static Session getMailSenderSessionYahoo(String userMail) {
		
		final Properties props = System.getProperties();
		props.setProperty( "mail.smtp.from", userMail);
	    props.setProperty( "mail.smtp.host", "smtp.mail.yahoo.com" );
	    props.setProperty( "mail.smtp.auth", "true" );
	    props.setProperty( "mail.smtp.port", "465" );
	    props.setProperty( "mail.smtp.starttls.enable", "true");
	    props.setProperty( "mail.smtp.quitwait", "false");
	    props.setProperty( "mail.smtp.ssl.enabled", "true");
	    props.setProperty( "mail.smtp.socketFactory.port", "465" );
	    props.setProperty( "mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory" );
	    return Session.getInstance( props, null);
	}
	
	public static MimeMessage getMimeMessage(Session session) {
		return new MimeMessage(session);
	}

}
