package de.binaris.grusskarten.data;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.event.Reception;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import java.util.List;

import de.binaris.grusskarten.data.RecipientRepository;
import de.binaris.grusskarten.model.Recipient;

@RequestScoped
public class RecipientListProducer {

    @Inject
    private RecipientRepository recipientRepository;

    private List<Recipient> recipients;

    // @Named annotation provides access by EL variable name "recipients" in the UI (e.g. Facelets or JSP view)
    @Produces
    @Named
    public List<Recipient> getRecipients() {
        return recipients;
    }

    // @Observes annotation provides notification and action for observer bean with changes of variable name "recipients" in the UI (e.g. Facelets or JSP view)
    public void onRecipientListChanged(@Observes(notifyObserver = Reception.IF_EXISTS) final Recipient member) {
        retrieveAllRecipientsOrderedByName();
    }

    @PostConstruct
    public void retrieveAllRecipientsOrderedByName() {
        recipients = recipientRepository.findAllOrderedByName();
    }
}
