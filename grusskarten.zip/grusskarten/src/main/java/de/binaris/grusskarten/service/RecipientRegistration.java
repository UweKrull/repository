package de.binaris.grusskarten.service;

import java.util.HashMap;
import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.persistence.EntityManager;

import de.binaris.grusskarten.model.Recipient;
import de.binaris.grusskarten.util.MailSender;

// @Stateless annotation without explicit manual transaction demarcation
@Stateless
public class RecipientRegistration {

    @Inject
    private Logger recipientLogger;

    @Inject
    private EntityManager em;

    @Inject
    private Event<Recipient> recipientEventSrc;

    private HashMap<String, String> cardsRecipient;
    
    public void register(Recipient recipient) throws Exception {
    	recipientLogger.info("Registering " + recipient.getName());
        em.persist(recipient);
        recipientEventSrc.fire(recipient);
        
        recipientLogger.info("Registered. ");
        new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					MailSender.sendMessage("chuck.banana@yahoo.com", 
							"greetingcards_1234", 
							cardsRecipient.get("mailRecipientName"),
							cardsRecipient.get("mailRecipientEmail"), 
							cardsRecipient.get("message"), 
							cardsRecipient.get("pathToCard"));
				} catch (AddressException e) {
					e.printStackTrace();
				} catch (MessagingException e) {
					e.printStackTrace();
				}
			}
        }).start();
    }
    
    public void setCardsRecipient(HashMap<String, String> cardsRecipient) {
    	this.cardsRecipient = cardsRecipient;
    }
    
    public HashMap<String, String> getCardsRecipient() {
    	return cardsRecipient;
    }
}
