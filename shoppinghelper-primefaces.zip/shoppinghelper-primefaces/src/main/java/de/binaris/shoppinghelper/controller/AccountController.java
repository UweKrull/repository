package de.binaris.shoppinghelper.controller;

import java.io.Serializable;

import javax.enterprise.context.Conversation;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import de.binaris.shoppinghelper.model.User;
import de.binaris.shoppinghelper.view.UserBean;
import de.binaris.shoppinghelper.annotations.CatchException;
import de.binaris.shoppinghelper.annotations.Loggable;
import de.binaris.shoppinghelper.annotations.LoggedIn;

@Named
@SessionScoped
@Loggable
@CatchException
public class AccountController extends Controller implements Serializable {

	private static final long serialVersionUID = 7970527273097745972L;

	@Inject
    private UserBean userService;

    @Inject
    private Credentials credentials;

    @Inject
    private Conversation conversation;

    @Produces
    @LoggedIn
    @SessionScoped
    private User loggedinUser;

    @Inject
    @SessionScoped
    private transient LoginContext loginContext;

    public String doLogin() throws LoginException {
        if ("".equals(credentials.getLogin())) {
            return null;
        }
        if ("".equals(credentials.getPassword())) {
            return null;
        }
        loginContext.login();
        loggedinUser = userService.findByLogin(credentials.getLogin());
        return "main.faces";
    }

    public String doLoginUser() throws LoginException {
    	if (credentials == null || "".equals(credentials.getLogin())) {
    		return "signon?faces-redirect=true";
    	}
    	if ("".equals(credentials.getPassword())) {
    		return "signon?faces-redirect=true";
    	}
    	loginContext.login();
    	loggedinUser = userService.findUser(credentials.getLogin(), credentials.getPassword());
    	if (loggedinUser != null) {
    		return "/index1.xhtml";
    	} else {
  		    return "signon?faces-redirect=true";
    	}
    }
    
    public String doCreateNewAccount() {
        return "create1?faces-redirect=true";
    }

    public String doCreateUser() {
    	userService.setUser(loggedinUser);
    	userService.setId(null);
        userService.update();
        loggedinUser = userService.getUser();
        return "main.faces";
    }

    public String doLogout() {
        loggedinUser = null;
        // Stop conversation
        if (!conversation.isTransient()) {
            conversation.end();
        }
        return "/index.xhtml";
    }

    public String doUpdateAccount() {
    	userService.setUser(loggedinUser);
    	userService.setId(loggedinUser.getId());
        userService.update();
        loggedinUser = userService.getUser();
        return "edit?faces-redirect=true";
    }

    public boolean isLoggedIn() {
        return loggedinUser != null;
    }

    public User getLoggedinUser() {
        return loggedinUser;
    }

    public String setLoggedinUser(User loggedinUser) {
        this.loggedinUser = loggedinUser;
        return "";
    }
}
