package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;

import de.binaris.shoppinghelper.model.SelectedItem;
import de.binaris.shoppinghelper.rest.dto.NestedCategoryDTO;
import de.binaris.shoppinghelper.rest.dto.NestedItemDTO;
import de.binaris.shoppinghelper.rest.dto.NestedPriceAtRetailerDTO;
import de.binaris.shoppinghelper.rest.dto.NestedShoppingListDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SelectedItemDTO implements Serializable
{

   private Long id;
   private NestedPriceAtRetailerDTO priceAtRetailer;
   private NestedCategoryDTO category;
   private String title;
   private NestedShoppingListDTO shoppingList;
   private NestedItemDTO item;

   public SelectedItemDTO()
   {
   }

   public SelectedItemDTO(final SelectedItem entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.priceAtRetailer = new NestedPriceAtRetailerDTO(
               entity.getPriceAtRetailer());
         this.category = new NestedCategoryDTO(entity.getCategory());
         this.title = entity.getTitle();
         this.shoppingList = new NestedShoppingListDTO(
               entity.getShoppingList());
         this.item = new NestedItemDTO(entity.getItem());
      }
   }

   public SelectedItem fromDTO(SelectedItem entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new SelectedItem();
      }
      if (this.priceAtRetailer != null)
      {
         entity.setPriceAtRetailer(this.priceAtRetailer.fromDTO(
               entity.getPriceAtRetailer(), em));
      }
      if (this.category != null)
      {
         entity.setCategory(this.category.fromDTO(entity.getCategory(), em));
      }
      entity.setTitle(this.title);
      if (this.shoppingList != null)
      {
         entity.setShoppingList(this.shoppingList.fromDTO(
               entity.getShoppingList(), em));
      }
      if (this.item != null)
      {
         entity.setItem(this.item.fromDTO(entity.getItem(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedPriceAtRetailerDTO getPriceAtRetailer()
   {
      return this.priceAtRetailer;
   }

   public void setPriceAtRetailer(
         final NestedPriceAtRetailerDTO priceAtRetailer)
   {
      this.priceAtRetailer = priceAtRetailer;
   }

   public NestedCategoryDTO getCategory()
   {
      return this.category;
   }

   public void setCategory(final NestedCategoryDTO category)
   {
      this.category = category;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public NestedShoppingListDTO getShoppingList()
   {
      return this.shoppingList;
   }

   public void setShoppingList(final NestedShoppingListDTO shoppingList)
   {
      this.shoppingList = shoppingList;
   }

   public NestedItemDTO getItem()
   {
      return this.item;
   }

   public void setItem(final NestedItemDTO item)
   {
      this.item = item;
   }
}