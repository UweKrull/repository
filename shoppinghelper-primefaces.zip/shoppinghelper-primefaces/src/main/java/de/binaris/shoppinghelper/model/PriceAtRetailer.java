package de.binaris.shoppinghelper.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "price_at_retailer")
public class PriceAtRetailer implements Serializable {

	private static final long serialVersionUID = 2525779723359122329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_price_at_retailer")
	@SequenceGenerator(name = "my_entity_seq_gen_price_at_retailer", sequenceName = "sequence_price_at_retailer", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 80, message = "must be 2-80 letters and spaces")
	private String pricePerPackage;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPricePerPackage() {
		return pricePerPackage;
	}

	public void setPricePerPackage(String pricePerPackage) {
		this.pricePerPackage = pricePerPackage;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof PriceAtRetailer)) {
			return false;
		}
		PriceAtRetailer castOther = (PriceAtRetailer) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return pricePerPackage;
	}
}
