package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;

import de.binaris.shoppinghelper.model.Category;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.shoppinghelper.model.SelectedItem;
import de.binaris.shoppinghelper.rest.dto.NestedSelectedItemDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable
{

   private Long id;
   private String description;
   private Set<NestedSelectedItemDTO> item = new HashSet<NestedSelectedItemDTO>();
   private String name;

   public CategoryDTO()
   {
   }

   public CategoryDTO(final Category entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         Iterator<SelectedItem> iterItem = entity.getItem().iterator();
         for (; iterItem.hasNext();)
         {
            SelectedItem element = iterItem.next();
            this.item.add(new NestedSelectedItemDTO(element));
         }
         this.name = entity.getName();
      }
   }

   public Category fromDTO(Category entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Category();
      }
      entity.setDescription(this.description);
      Iterator<SelectedItem> iterItem = entity.getItem().iterator();
      for (; iterItem.hasNext();)
      {
         boolean found = false;
         SelectedItem selectedItem = iterItem.next();
         Iterator<NestedSelectedItemDTO> iterDtoItem = this.getItem()
               .iterator();
         for (; iterDtoItem.hasNext();)
         {
            NestedSelectedItemDTO dtoSelectedItem = iterDtoItem.next();
            if (dtoSelectedItem.getId().equals(selectedItem.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterItem.remove();
         }
      }
      Iterator<NestedSelectedItemDTO> iterDtoItem = this.getItem().iterator();
      for (; iterDtoItem.hasNext();)
      {
         boolean found = false;
         NestedSelectedItemDTO dtoSelectedItem = iterDtoItem.next();
         iterItem = entity.getItem().iterator();
         for (; iterItem.hasNext();)
         {
            SelectedItem selectedItem = iterItem.next();
            if (dtoSelectedItem.getId().equals(selectedItem.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<SelectedItem> resultIter = em
                  .createQuery("SELECT DISTINCT s FROM SelectedItem s",
                        SelectedItem.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               SelectedItem result = resultIter.next();
               if (result.getId().equals(dtoSelectedItem.getId()))
               {
                  entity.getItem().add(result);
                  break;
               }
            }
         }
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public Set<NestedSelectedItemDTO> getItem()
   {
      return this.item;
   }

   public void setItem(final Set<NestedSelectedItemDTO> item)
   {
      this.item = item;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}