package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;
import de.binaris.shoppinghelper.model.PriceAtRetailer;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedPriceAtRetailerDTO implements Serializable
{

   private Long id;
   private String pricePerPackage;

   public NestedPriceAtRetailerDTO()
   {
   }

   public NestedPriceAtRetailerDTO(final PriceAtRetailer entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.pricePerPackage = entity.getPricePerPackage();
      }
   }

   public PriceAtRetailer fromDTO(PriceAtRetailer entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new PriceAtRetailer();
      }
      if (this.id != null)
      {
         TypedQuery<PriceAtRetailer> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT p FROM PriceAtRetailer p WHERE p.id = :entityId",
                     PriceAtRetailer.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setPricePerPackage(this.pricePerPackage);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getPricePerPackage()
   {
      return this.pricePerPackage;
   }

   public void setPricePerPackage(final String pricePerPackage)
   {
      this.pricePerPackage = pricePerPackage;
   }
}