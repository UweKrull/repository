package de.binaris.shoppinghelper.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.shoppinghelper.model.ShoppingList;
import de.binaris.shoppinghelper.rest.dto.ShoppingListDTO;

/**
 * 
 */
@Stateless
@Path("/shoppinglists")
public class ShoppingListEndpoint
{
   @PersistenceContext(unitName = "ShoppinghelperPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(ShoppingListDTO dto)
   {
      ShoppingList entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(ShoppingListEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      ShoppingList entity = em.find(ShoppingList.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<ShoppingList> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM ShoppingList s LEFT JOIN FETCH s.user LEFT JOIN FETCH s.selectedItem WHERE s.id = :entityId ORDER BY s.id", ShoppingList.class);
      findByIdQuery.setParameter("entityId", id);
      ShoppingList entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      ShoppingListDTO dto = new ShoppingListDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<ShoppingListDTO> listAll()
   {
      final List<ShoppingList> searchResults = em.createQuery("SELECT DISTINCT s FROM ShoppingList s LEFT JOIN FETCH s.user LEFT JOIN FETCH s.selectedItem ORDER BY s.id", ShoppingList.class).getResultList();
      final List<ShoppingListDTO> results = new ArrayList<ShoppingListDTO>();
      for (ShoppingList searchResult : searchResults)
      {
         ShoppingListDTO dto = new ShoppingListDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, ShoppingListDTO dto)
   {
      TypedQuery<ShoppingList> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM ShoppingList s LEFT JOIN FETCH s.user LEFT JOIN FETCH s.selectedItem WHERE s.id = :entityId ORDER BY s.id", ShoppingList.class);
      findByIdQuery.setParameter("entityId", id);
      ShoppingList entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}