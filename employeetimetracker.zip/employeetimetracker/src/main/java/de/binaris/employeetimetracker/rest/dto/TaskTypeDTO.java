package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.TaskType;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TaskTypeDTO implements Serializable
{

   private Long id;
   private String color;
   private String description;
   private String name;

   public TaskTypeDTO()
   {
   }

   public TaskTypeDTO(final TaskType entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.color = entity.getColor();
         this.description = entity.getDescription();
         this.name = entity.getName();
      }
   }

   public TaskType fromDTO(TaskType entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new TaskType();
      }
      entity.setColor(this.color);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getColor()
   {
      return this.color;
   }

   public void setColor(final String color)
   {
      this.color = color;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}