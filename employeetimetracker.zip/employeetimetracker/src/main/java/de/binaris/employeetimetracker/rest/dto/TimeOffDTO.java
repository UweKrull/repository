package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

import de.binaris.employeetimetracker.model.TimeOff;

@XmlRootElement
public class TimeOffDTO implements Serializable {

	private Float total;
	private Date toDateTime;
	private Long id;
	private NestedTimeOffReasonDTO timeOffReason;
	private Date fromDateTime;
	private NestedUserDTO user;

	public TimeOffDTO() {
	}

	public TimeOffDTO(final TimeOff entity) {
		if (entity != null) {
			this.total = entity.getTotal();
			this.toDateTime = entity.getToDateTime();
			this.id = entity.getId();
			this.timeOffReason = new NestedTimeOffReasonDTO(entity.getTimeOffReason());
			this.fromDateTime = entity.getFromDateTime();
			this.user = new NestedUserDTO(entity.getUser());
		}
	}

	public TimeOff fromDTO(TimeOff entity, EntityManager em) {
		if (entity == null) {
			entity = new TimeOff();
		}
		entity.setToDateTime(this.toDateTime);
		entity.setTimeOffReason(this.timeOffReason.fromDTO(entity.getTimeOffReason(), em));
		entity.setFromDateTime(this.fromDateTime);
		if (this.user != null) {
			entity.setUser(this.user.fromDTO(entity.getUser(), em));
		}
		entity = em.merge(entity);
		return entity;
	}

	public Float getTotal() {
		return this.total;
	}

	public void setTotal(final Float total) {
		this.total = total;
	}

	public Date getToDateTime() {
		return this.toDateTime;
	}

	public void setTo(final Date toDateTime) {
		this.toDateTime = toDateTime;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Date getFromDateTime() {
		return this.fromDateTime;
	}

	public void setFromDateTime(final Date fromDateTime) {
		this.fromDateTime = fromDateTime;
	}

	public NestedUserDTO getUser() {
		return this.user;
	}

	public void setUser(final NestedUserDTO user) {
		this.user = user;
	}
	
	public NestedTimeOffReasonDTO getTimeOffReason() {
		return this.timeOffReason;
	}
	
	public void setTimeOffReason(final NestedTimeOffReasonDTO timeOffReason) {
		this.timeOffReason = timeOffReason;
	}
}