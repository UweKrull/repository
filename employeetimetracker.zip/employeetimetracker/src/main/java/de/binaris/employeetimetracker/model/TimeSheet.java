package de.binaris.employeetimetracker.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>
 * An TimeSheet may consist of one or more projectTasks.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "time_sheet")
public class TimeSheet implements Serializable {

	private static final long serialVersionUID = 7278921756755562965L;

	/**
	 * The ID of the Project.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_time_sheet")
	@SequenceGenerator(name = "my_entity_seq_gen_time_sheet", sequenceName = "sequence_time_sheet", allocationSize = 1)
	private Long id;

	@NotNull
	@Temporal(TemporalType.DATE)
	@Column(name = "started_at", updatable = false)
	private Date startedAt;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private User user;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "timeSheet")
	private Set<ProjectTask> projectTasks = new HashSet<ProjectTask>();

	@ManyToOne
	private ActivityType activityType;
	
	private Float hours;

	private String description;

	@NotNull
	@Size(min = 1, max = 10, message = "must be 1-10 letters and spaces")
	private String status;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@PrePersist
	private void setDefaultData() {
//		startedAt = new Date();
	}

	public Date getStartedAt() {
		return startedAt;
	}

	public void setStartedAt(Date startedAt) {
		this.startedAt = startedAt;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Set<ProjectTask> getProjectTasks() {
		return projectTasks;
	}

	public void setProjectTasks(Set<ProjectTask> projectTasks) {
		this.projectTasks = projectTasks;
	}

	public ActivityType getActivityType() {
		return activityType;
	}

	public void setActivityType(ActivityType activityType) {
		this.activityType = activityType;
	}

	public Float getHours() {
		return hours;
	}

	public void setHours(Float hours) {
		this.hours = hours;
	}

	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Float getTotal() {
		if (projectTasks == null || projectTasks.isEmpty()) {
			return 0f;
		}
		Float sum = 0f;
		for (ProjectTask projectTask : projectTasks) {
			sum += (projectTask.getSubTotal());
			this.hours = sum;
		}
		return hours;
	}

	/*
	 * toString(), equals() and hashCode() for TimeSheet, using the natural
	 * identity of the object
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof TimeSheet)) {
			return false;
		}
		TimeSheet castOther = (TimeSheet) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append('\'').append(startedAt);
		sb.append(", ").append('\'').append(user).append('\'');
		if (activityType != null) {
			sb.append(", ").append('\'').append(activityType).append('\'');
		}
		sb.append(", ").append('\'').append(projectTasks).append('\'');
		return sb.toString();
	}
}
