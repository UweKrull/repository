package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Date;

import de.binaris.employeetimetracker.model.ActivityType;
import de.binaris.employeetimetracker.model.ProjectTask;
import de.binaris.employeetimetracker.model.TimeSheet;
import de.binaris.employeetimetracker.rest.dto.NestedActivityTypeDTO;
import de.binaris.employeetimetracker.rest.dto.NestedProjectTaskDTO;
import de.binaris.employeetimetracker.rest.dto.NestedUserDTO;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TimeSheetDTO implements Serializable
{

   private Float total;
   private Long id;
   private Set<NestedProjectTaskDTO> projectTasks = new HashSet<NestedProjectTaskDTO>();
   private String status;
   private String description;
   private Float hours;
   private Date startedAt;
   private NestedUserDTO user;
   private NestedActivityTypeDTO activityType;

   public TimeSheetDTO()
   {
   }

   public TimeSheetDTO(final TimeSheet entity)
   {
      if (entity != null)
      {
         this.total = entity.getTotal();
         this.id = entity.getId();
         Iterator<ProjectTask> iterProjectTasks = entity.getProjectTasks()
               .iterator();
         for (; iterProjectTasks.hasNext();)
         {
            ProjectTask element = iterProjectTasks.next();
            this.projectTasks.add(new NestedProjectTaskDTO(element));
         }
         this.status = entity.getStatus();
         this.description = entity.getDescription();
         this.hours = entity.getHours();
         this.startedAt = entity.getStartedAt();
         this.user = new NestedUserDTO(entity.getUser());
         this.activityType = new NestedActivityTypeDTO(entity.getActivityType());
      }
   }

   public TimeSheet fromDTO(TimeSheet entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new TimeSheet();
      }
      Iterator<ProjectTask> iterProjectTasks = entity.getProjectTasks()
            .iterator();
      for (; iterProjectTasks.hasNext();)
      {
         boolean found = false;
         ProjectTask projectTask = iterProjectTasks.next();
         Iterator<NestedProjectTaskDTO> iterDtoProjectTasks = this
               .getProjectTasks().iterator();
         for (; iterDtoProjectTasks.hasNext();)
         {
            NestedProjectTaskDTO dtoProjectTask = iterDtoProjectTasks
                  .next();
            if (dtoProjectTask.getId().equals(projectTask.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterProjectTasks.remove();
         }
      }
      Iterator<NestedProjectTaskDTO> iterDtoProjectTasks = this
            .getProjectTasks().iterator();
      for (; iterDtoProjectTasks.hasNext();)
      {
         boolean found = false;
         NestedProjectTaskDTO dtoProjectTask = iterDtoProjectTasks.next();
         iterProjectTasks = entity.getProjectTasks().iterator();
         for (; iterProjectTasks.hasNext();)
         {
            ProjectTask projectTask = iterProjectTasks.next();
            if (dtoProjectTask.getId().equals(projectTask.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<ProjectTask> resultIter = em
                  .createQuery("SELECT DISTINCT p FROM ProjectTask p",
                        ProjectTask.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               ProjectTask result = resultIter.next();
               if (result.getId().equals(dtoProjectTask.getId()))
               {
                  entity.getProjectTasks().add(result);
                  break;
               }
            }
         }
      }
      entity.setStatus(this.status);
      entity.setDescription(this.description);
      entity.setHours(this.hours);
      entity.setStartedAt(this.startedAt);
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      if (this.activityType != null) {
    	  entity.setActivityType(this.activityType.fromDTO(entity.getActivityType(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Float getTotal()
   {
      return this.total;
   }

   public void setTotal(final Float total)
   {
      this.total = total;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedProjectTaskDTO> getProjectTasks()
   {
      return this.projectTasks;
   }

   public void setProjectTasks(final Set<NestedProjectTaskDTO> projectTasks)
   {
      this.projectTasks = projectTasks;
   }

   public String getStatus()
   {
      return this.status;
   }

   public void setStatus(final String status)
   {
      this.status = status;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public Float getHours()
   {
      return this.hours;
   }

   public void setHours(final Float hours)
   {
      this.hours = hours;
   }

   public Date getStartedAt()
   {
      return this.startedAt;
   }

   public void setStartedAt(final Date startedAt)
   {
      this.startedAt = startedAt;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }

   public NestedActivityTypeDTO getActivityType()
   {
      return this.activityType;
   }

   public void setActivityType(final NestedActivityTypeDTO activityType)
   {
      this.activityType = activityType;
   }
}