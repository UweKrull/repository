package de.binaris.employeetimetracker.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "activity_type")
public class ActivityType implements Serializable {

	private static final long serialVersionUID = 75727232757127579L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_activity_type")
	@SequenceGenerator(name = "my_entity_seq_gen_activity_type", sequenceName = "sequence_activity_type", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@NotNull
	@Size(min = 1, max = 10, message = "must be 1-10 letters and spaces")
	private String color;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof ActivityType)) {
			return false;
		}
		ActivityType castOther = (ActivityType) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return name + ", " + description;
	}
}
