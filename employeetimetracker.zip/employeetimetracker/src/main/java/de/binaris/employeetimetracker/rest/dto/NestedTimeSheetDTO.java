package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.TimeSheet;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import java.util.Date;

public class NestedTimeSheetDTO implements Serializable
{

   private Float total;
   private Long id;
   private String status;
   private String description;
   private Float hours;
   private Date startedAt;

   public NestedTimeSheetDTO()
   {
   }

   public NestedTimeSheetDTO(final TimeSheet entity)
   {
      if (entity != null)
      {
         this.total = entity.getTotal();
         this.id = entity.getId();
         this.status = entity.getStatus();
         this.description = entity.getDescription();
         this.hours = entity.getHours();
         this.startedAt = entity.getStartedAt();
      }
   }

   public TimeSheet fromDTO(TimeSheet entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new TimeSheet();
      }
      if (this.id != null)
      {
         TypedQuery<TimeSheet> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT t FROM TimeSheet t WHERE t.id = :entityId",
                     TimeSheet.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setStatus(this.status);
      entity.setDescription(this.description);
      entity.setHours(this.hours);
      entity.setStartedAt(this.startedAt);
      entity = em.merge(entity);
      return entity;
   }

   public Float getTotal()
   {
      return this.total;
   }

   public void setTotal(final Float total)
   {
      this.total = total;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getStatus()
   {
      return this.status;
   }

   public void setStatus(final String status)
   {
      this.status = status;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public Float getHours()
   {
      return this.hours;
   }

   public void setHours(final Float hours)
   {
      this.hours = hours;
   }

   public Date getStartedAt()
   {
      return this.startedAt;
   }

   public void setStartedAt(final Date startedAt)
   {
      this.startedAt = startedAt;
   }
}