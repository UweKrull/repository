package de.binaris.employeetimetracker.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>
 * A ProjectTask may have one TaskType.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "project_task")
public class ProjectTask implements Serializable {

	private static final long serialVersionUID = 5015012375678916915L;

	/**
	 * The ID of the ProjectTask.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_project_task")
	@SequenceGenerator(name = "my_entity_seq_gen_project_task", sequenceName = "sequence_project_task", allocationSize = 1)
	private Long id;

	/**
	 * The TaskType of the ProjectTask.
	 */
	@ManyToOne
	@NotNull
	private TaskType tasktype;

	/**
	 * The project of the ProjectTask.
	 */
	@ManyToOne
	@NotNull
	private Project project;

	/**
	 * The timeSheet of the ProjectTask.
	 */
	@ManyToOne
	@NotNull
	private TimeSheet timeSheet;
	
	@NotNull
	@Temporal(TemporalType.DATE)
	@Column(name = "start_on", updatable = true)
	private Date startOn;

	@NotNull
	@Temporal(TemporalType.DATE)
	@Column(name = "due_on", updatable = true)
	private Date dueOn;
	
	@NotNull
	@Size(min = 1, max = 10, message = "must be 1-10 letters and spaces")
	private String color;
	
	@NotNull
	@Size(min = 1, max = 10, message = "must be 1-10 letters and spaces")
	private String status;
	
	@NotNull
	@Size(min = 1, max = 60, message = "must be 1-60 letters and spaces")
	private String name;
	
	@Column(name = "bid_hours", updatable = true)
	private Float bidHours;

	private String description;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TaskType getTasktype() {
		return tasktype;
	}

	public void setTasktype(TaskType tasktype) {
		this.tasktype = tasktype;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public TimeSheet getTimeSheet() {
		return timeSheet;
	}
	
	public void setTimeSheet(TimeSheet timeSheet) {
		this.timeSheet = timeSheet;
	}
	
	public Date getStartOn() {
		return startOn;
	}

	public void setStartOn(Date startOn) {
		this.startOn = startOn;
	}

	public Date getDueOn() {
		return dueOn;
	}
	
	public void setDueOn(Date dueOn) {
		this.dueOn = dueOn;
	}
	
	public void setColor(String color) {
	    this.color = color;
	}

	public String getColor() {
		return color;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Float getBidHours() {
		return bidHours;
	}

	public void setBidHours(Float bidHours) {
		this.bidHours = bidHours;
	}

	public Float getSubTotal() {
		return bidHours;
//		return (taskType != null)? taskType.getUnitCost() * quantity : 0F;
	}

	/*
	 * toString(), equals() and hashCode() for ProjectTask, using the natural
	 * identity of the object
	 */

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof ProjectTask)) {
			return false;
		}
		ProjectTask castOther = (ProjectTask) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append('\'').append(", ProjectTask: ").append(getName()).append('\'');
		sb.append('\'').append(", description: ").append(getDescription()).append('\'');
		sb.append('\'').append(", tasktype.name: ").append(tasktype.getName()).append('\'');
		return sb.toString();
	}
}
