package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;

import de.binaris.employeetimetracker.model.Project;
import de.binaris.employeetimetracker.model.ProjectTask;
import de.binaris.employeetimetracker.rest.dto.NestedProjectTaskDTO;
import de.binaris.employeetimetracker.rest.dto.NestedUserDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProjectDTO implements Serializable
{

   private Date startOn;
   private Long id;
   private Set<NestedProjectTaskDTO> projectTasks = new HashSet<NestedProjectTaskDTO>();
   private String status;
   private String color;
   private String description;
   private String name;
   private String companyName;
   private NestedUserDTO user;
   private String companyCode;

   public ProjectDTO()
   {
   }

   public ProjectDTO(final Project entity)
   {
      if (entity != null)
      {
         this.startOn = entity.getStartOn();
         this.id = entity.getId();
         Iterator<ProjectTask> iterProjectTasks = entity.getProjectTasks()
               .iterator();
         for (; iterProjectTasks.hasNext();)
         {
            ProjectTask element = iterProjectTasks.next();
            this.projectTasks.add(new NestedProjectTaskDTO(element));
         }
         this.status = entity.getStatus();
         this.color = entity.getColor();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.companyName = entity.getCompanyName();
         this.user = new NestedUserDTO(entity.getUser());
         this.companyCode = entity.getCompanyCode();
      }
   }

   public Project fromDTO(Project entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Project();
      }
      entity.setStartOn(this.startOn);
      Iterator<ProjectTask> iterProjectTasks = entity.getProjectTasks()
            .iterator();
      for (; iterProjectTasks.hasNext();)
      {
         boolean found = false;
         ProjectTask projectTask = iterProjectTasks.next();
         Iterator<NestedProjectTaskDTO> iterDtoProjectTasks = this
               .getProjectTasks().iterator();
         for (; iterDtoProjectTasks.hasNext();)
         {
            NestedProjectTaskDTO dtoProjectTask = iterDtoProjectTasks
                  .next();
            if (dtoProjectTask.getId().equals(projectTask.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterProjectTasks.remove();
         }
      }
      Iterator<NestedProjectTaskDTO> iterDtoProjectTasks = this
            .getProjectTasks().iterator();
      for (; iterDtoProjectTasks.hasNext();)
      {
         boolean found = false;
         NestedProjectTaskDTO dtoProjectTask = iterDtoProjectTasks.next();
         iterProjectTasks = entity.getProjectTasks().iterator();
         for (; iterProjectTasks.hasNext();)
         {
            ProjectTask projectTask = iterProjectTasks.next();
            if (dtoProjectTask.getId().equals(projectTask.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<ProjectTask> resultIter = em
                  .createQuery("SELECT DISTINCT p FROM ProjectTask p",
                        ProjectTask.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               ProjectTask result = resultIter.next();
               if (result.getId().equals(dtoProjectTask.getId()))
               {
                  entity.getProjectTasks().add(result);
                  break;
               }
            }
         }
      }
      entity.setStatus(this.status);
      entity.setColor(this.color);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setCompanyName(this.companyName);
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity.setCompanyCode(this.companyCode);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartOn()
   {
      return this.startOn;
   }

   public void setStartOn(final Date startOn)
   {
      this.startOn = startOn;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedProjectTaskDTO> getProjectTasks()
   {
      return this.projectTasks;
   }

   public void setProjectTasks(final Set<NestedProjectTaskDTO> projectTasks)
   {
      this.projectTasks = projectTasks;
   }

   public String getStatus()
   {
      return this.status;
   }

   public void setStatus(final String status)
   {
      this.status = status;
   }

   public String getColor()
   {
      return this.color;
   }

   public void setColor(final String color)
   {
      this.color = color;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getCompanyName()
   {
      return this.companyName;
   }

   public void setCompanyName(final String companyName)
   {
      this.companyName = companyName;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }

   public String getCompanyCode()
   {
      return this.companyCode;
   }

   public void setCompanyCode(final String companyCode)
   {
      this.companyCode = companyCode;
   }
}