package de.binaris.employeetimetracker.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.employeetimetracker.model.TimeSheet;
import de.binaris.employeetimetracker.rest.dto.TimeSheetDTO;

/**
 * 
 */
@Stateless
@Path("/timesheets")
public class TimeSheetEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(TimeSheetDTO dto)
   {
      TimeSheet entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(TimeSheetEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      TimeSheet entity = em.find(TimeSheet.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<TimeSheet> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TimeSheet t LEFT JOIN FETCH t.user LEFT JOIN FETCH t.projectTasks LEFT JOIN FETCH t.activityTypes WHERE t.id = :entityId ORDER BY t.id", TimeSheet.class);
      findByIdQuery.setParameter("entityId", id);
      TimeSheet entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      TimeSheetDTO dto = new TimeSheetDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<TimeSheetDTO> listAll()
   {
      final List<TimeSheet> searchResults = em.createQuery("SELECT DISTINCT t FROM TimeSheet t LEFT JOIN FETCH t.user LEFT JOIN FETCH t.projectTasks LEFT JOIN FETCH t.activityTypes ORDER BY t.id", TimeSheet.class).getResultList();
      final List<TimeSheetDTO> results = new ArrayList<TimeSheetDTO>();
      for (TimeSheet searchResult : searchResults)
      {
         TimeSheetDTO dto = new TimeSheetDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, TimeSheetDTO dto)
   {
      TypedQuery<TimeSheet> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TimeSheet t LEFT JOIN FETCH t.user LEFT JOIN FETCH t.projectTasks LEFT JOIN FETCH t.activityTypes WHERE t.id = :entityId ORDER BY t.id", TimeSheet.class);
      findByIdQuery.setParameter("entityId", id);
      TimeSheet entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}