package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.TimeOff;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import java.util.Date;

public class NestedTimeOffDTO implements Serializable
{

   private Float total;
   private Date toDateTime;
   private Long id;
   private Date fromDateTime;

   public NestedTimeOffDTO()
   {
   }

   public NestedTimeOffDTO(final TimeOff entity)
   {
      if (entity != null)
      {
         this.total = entity.getTotal();
         this.toDateTime = entity.getToDateTime();
         this.id = entity.getId();
         this.fromDateTime = entity.getFromDateTime();
      }
   }

   public TimeOff fromDTO(TimeOff entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new TimeOff();
      }
      if (this.id != null)
      {
         TypedQuery<TimeOff> findByIdQuery = em.createQuery(
               "SELECT DISTINCT t FROM TimeOff t WHERE t.id = :entityId",
               TimeOff.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setToDateTime(this.toDateTime);
      entity.setFromDateTime(this.fromDateTime);
      entity = em.merge(entity);
      return entity;
   }

   public Float getTotal()
   {
      return this.total;
   }

   public void setTotal(final Float total)
   {
      this.total = total;
   }

   public Date getToDateTime()
   {
      return this.toDateTime;
   }

   public void setTo(final Date toDateTime)
   {
      this.toDateTime = toDateTime;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Date getFrom()
   {
      return this.fromDateTime;
   }

   public void setFrom(final Date fromDateTime)
   {
      this.fromDateTime = fromDateTime;
   }
}