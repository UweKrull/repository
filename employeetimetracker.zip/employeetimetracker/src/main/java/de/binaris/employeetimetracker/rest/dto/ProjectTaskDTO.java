package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.ProjectTask;
import de.binaris.employeetimetracker.rest.dto.NestedProjectDTO;
import de.binaris.employeetimetracker.rest.dto.NestedTaskTypeDTO;
import de.binaris.employeetimetracker.rest.dto.NestedTimeSheetDTO;

import javax.persistence.EntityManager;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ProjectTaskDTO implements Serializable {

	private Date startOn;
	private Long id;
	private NestedProjectDTO project;
	private Float bidHours;
	private Float subTotal;
	private String status;
	private String color;
	private String description;
	private String name;
	private NestedTaskTypeDTO taskType;
	private Date dueOn;
	private NestedTimeSheetDTO timeSheet;

	public ProjectTaskDTO() {
	}

	public ProjectTaskDTO(final ProjectTask entity) {
		if (entity != null) {
			this.startOn = entity.getStartOn();
			this.id = entity.getId();
			this.project = new NestedProjectDTO(entity.getProject());
			this.bidHours = entity.getBidHours();
			this.subTotal = entity.getSubTotal();
			this.status = entity.getStatus();
			this.color = entity.getColor();
			this.description = entity.getDescription();
			this.name = entity.getName();
			this.taskType = new NestedTaskTypeDTO(entity.getTasktype());
			this.dueOn = entity.getDueOn();
			this.timeSheet = new NestedTimeSheetDTO(entity.getTimeSheet());
		}
	}

	public ProjectTask fromDTO(ProjectTask entity, EntityManager em) {
		if (entity == null) {
			entity = new ProjectTask();
		}
		entity.setStartOn(this.startOn);
		if (this.project != null) {
			entity.setProject(this.project.fromDTO(entity.getProject(), em));
		}
		entity.setBidHours(this.bidHours);
		entity.setStatus(this.status);
		entity.setColor(this.color);
		entity.setDescription(this.description);
		entity.setName(this.name);
		if (this.taskType != null) {
			entity.setTasktype(this.taskType.fromDTO(entity.getTasktype(), em));
		}
		entity.setDueOn(this.dueOn);
		if (this.timeSheet != null) {
			entity.setTimeSheet(this.timeSheet.fromDTO(entity.getTimeSheet(),
					em));
		}
		entity = em.merge(entity);
		return entity;
	}

	public Date getStartOn() {
		return this.startOn;
	}

	public void setStartOn(final Date startOn) {
		this.startOn = startOn;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public NestedProjectDTO getProject() {
		return this.project;
	}

	public void setProject(final NestedProjectDTO project) {
		this.project = project;
	}

	public Float getBidHours() {
		return this.bidHours;
	}

	public void setBidHours(final Float bidHours) {
		this.bidHours = bidHours;
	}

	public Float getSubTotal() {
		return this.subTotal;
	}

	public void setSubTotal(final Float subTotal) {
		this.subTotal = subTotal;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(final String status) {
		this.status = status;
	}

	public String getColor() {
		return this.color;
	}

	public void setColor(final String color) {
		this.color = color;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public NestedTaskTypeDTO getTaskType() {
		return this.taskType;
	}

	public void setTaskType(final NestedTaskTypeDTO taskType) {
		this.taskType = taskType;
	}

	public Date getDueOn() {
		return this.dueOn;
	}

	public void setDueOn(final Date dueOn) {
		this.dueOn = dueOn;
	}

	public NestedTimeSheetDTO getTimeSheet() {
		return this.timeSheet;
	}

	public void setTimeSheet(final NestedTimeSheetDTO timeSheet) {
		this.timeSheet = timeSheet;
	}
}