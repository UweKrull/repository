package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;
import de.binaris.businessdinners.model.AvailableGender;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedAvailableGenderDTO implements Serializable
{

   private Long id;
   private String title;

   public NestedAvailableGenderDTO()
   {
   }

   public NestedAvailableGenderDTO(final AvailableGender entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
      }
   }

   public AvailableGender fromDTO(AvailableGender entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new AvailableGender();
      }
      if (this.id != null)
      {
         TypedQuery<AvailableGender> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT a FROM AvailableGender a WHERE a.id = :entityId",
                     AvailableGender.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
}