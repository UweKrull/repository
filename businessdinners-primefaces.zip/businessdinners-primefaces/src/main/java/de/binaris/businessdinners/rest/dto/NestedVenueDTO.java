package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.Venue;
import de.binaris.businessdinners.rest.dto.AddressDTO;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedVenueDTO implements Serializable
{

   private Long id;
   private AddressDTO address;
   private String website;
   private String location;
   private String name;
   private String linkGooglemaps;

   public NestedVenueDTO()
   {
   }

   public NestedVenueDTO(final Venue entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.address = new AddressDTO(entity.getAddress());
         this.website = entity.getWebsite();
         this.location = entity.getLocation();
         this.name = entity.getName();
         this.linkGooglemaps = entity.getLinkGooglemaps();
      }
   }

   public Venue fromDTO(Venue entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Venue();
      }
      if (this.id != null)
      {
         TypedQuery<Venue> findByIdQuery = em.createQuery(
               "SELECT DISTINCT v FROM Venue v WHERE v.id = :entityId",
               Venue.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setWebsite(this.website);
      entity.setLocation(this.location);
      entity.setName(this.name);
      entity.setLinkGooglemaps(this.linkGooglemaps);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getWebsite()
   {
      return this.website;
   }

   public void setWebsite(final String website)
   {
      this.website = website;
   }

   public String getLocation()
   {
      return this.location;
   }

   public void setLocation(final String location)
   {
      this.location = location;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLinkGooglemaps()
   {
      return this.linkGooglemaps;
   }

   public void setLinkGooglemaps(final String linkGooglemaps)
   {
      this.linkGooglemaps = linkGooglemaps;
   }
}