package de.binaris.businessdinners.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.validation.ValidationException;

import de.binaris.businessdinners.model.User;

/**
 * Backing bean for User entities.
 */
@Named
@Stateful
@ConversationScoped
public class UserBean implements Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	private User user;

	public void setCustomer(User user) {
		this.user = user;
	}
	
	public User getCustomer() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public User getUser() {
		return this.user;
	}

	@Inject
	private Conversation conversation;

	@PersistenceContext(type = PersistenceContextType.EXTENDED)
	private EntityManager entityManager;

	public String create() {

		this.conversation.begin();
		return "create?faces-redirect=true";
	}

	public void retrieve() {

		if (FacesContext.getCurrentInstance().isPostback()) {
			return;
		}

		if (this.conversation.isTransient()) {
			this.conversation.begin();
		}

		if (this.id == null) {
			this.user = this.example;
		} else {
			this.user = findById(getId());
		}
	}

	public User findById(Long id) {
		return this.entityManager.find(User.class, id);
	}

	public User findByLogin(String login) {
        TypedQuery<User> typedQuery = this.entityManager.createNamedQuery(User.FIND_BY_LOGIN, User.class);
        typedQuery.setParameter("login", login);
        try {
            return typedQuery.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
	}
	
	public User findCustomer(String login, String pwd) {
		TypedQuery<User> typedQuery = this.entityManager.createNamedQuery(User.FIND_BY_LOGIN_PASSWORD, User.class);
		typedQuery.setParameter("login", login);
		typedQuery.setParameter("password", pwd);
		try {
			return typedQuery.getSingleResult();
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public String createNew() {
		this.conversation.end();

		try {
			if (this.id == null) {
				this.entityManager.persist(this.user);
				return "signon?faces-redirect=true";
			} else {
				this.entityManager.merge(this.user);
				return "signon?faces-redirect=true&id=" + this.user.getId();
			}
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}

	public String update() {
		this.conversation.end();
		
		try {
			if (this.id == null) {
				this.entityManager.persist(this.user);
				return "search?faces-redirect=true";
			} else {
				this.entityManager.merge(this.user);
				return "view?faces-redirect=true&id=" + this.user.getId();
			}
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}
	
	public String delete() {
		this.conversation.end();

		try {
			User deletableEntity = findById(getId());
			this.entityManager.remove(deletableEntity);
			this.entityManager.flush();
			return "search?faces-redirect=true";
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}

    public boolean doesLoginAlreadyExist(final String login) {
        if (login == null)
            throw new ValidationException("Login cannot be null");
        // Login has to be unique
        TypedQuery<User> typedQuery = this.entityManager.createNamedQuery(User.FIND_BY_LOGIN, User.class);
        typedQuery.setParameter("login", login);
        try {
            typedQuery.getSingleResult();
            return true;
        } catch (NoResultException e) {
            return false;
        }
    }
    
	private int page;
	private long count;
	private List<User> pageItems;

	private User example = new User();

	public int getPage() {
		return this.page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return 10;
	}

	public User getExample() {
		return this.example;
	}

	public void setExample(User example) {
		this.example = example;
	}

	public void search() {
		this.page = 0;
	}

	public void paginate() {

		if (this.id == null) {
			this.user = this.example;
		} else {
			this.user = findById(getId());
		}

		CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

		// Populate this.count
		CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
		Root<User> root = countCriteria.from(User.class);
		countCriteria = countCriteria.select(builder.count(root)).where(
				getSearchPredicates(root));
		this.count = this.entityManager.createQuery(countCriteria)
				.getSingleResult();

		// Populate this.pageItems
		CriteriaQuery<User> criteria = builder.createQuery(User.class);
		root = criteria.from(User.class);
		TypedQuery<User> query = this.entityManager.createQuery(criteria
				.select(root).where(getSearchPredicates(root)));
		query.setFirstResult(this.page * getPageSize()).setMaxResults(
				getPageSize());
		this.pageItems = query.getResultList();

//		if (this.user != null) {
//			this.pageItems = new ArrayList<User>();
//			this.pageItems.add(this.user);
//		}
	}

	public void findAll() {
		
		if (this.id == null) {
			this.user = this.example;
		} else {
			this.user = findById(getId());
		}
		
		CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
		
		// Populate this.count
		CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
		Root<User> root = countCriteria.from(User.class);
		countCriteria = countCriteria.select(builder.count(root)).where(
				getSearchPredicates(root));
		this.count = this.entityManager.createQuery(countCriteria)
				.getSingleResult();
		
		// Populate this.pageItems
		CriteriaQuery<User> criteria = builder.createQuery(User.class);
		root = criteria.from(User.class);
		TypedQuery<User> query = this.entityManager.createQuery(criteria
				.select(root).where(getSearchPredicates(root)));
		query.setFirstResult(this.page * getPageSize()).setMaxResults(
				getPageSize());
		this.pageItems = query.getResultList();
	}
	
	private Predicate[] getSearchPredicates(Root<User> root) {

		CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
		List<Predicate> predicatesList = new ArrayList<Predicate>();

		String login = this.example.getLogin();
		if (login != null && !"".equals(login)) {
			predicatesList.add(builder.like(root.<String> get("login"),
					'%' + login + '%'));
		}
		return predicatesList.toArray(new Predicate[predicatesList.size()]);
	}

	public List<User> getPageItems() {
		return this.pageItems;
	}

	public long getCount() {
		return this.count;
	}

	public List<User> getAll() {

		CriteriaQuery<User> criteria = this.entityManager
				.getCriteriaBuilder().createQuery(User.class);
		return this.entityManager.createQuery(
				criteria.select(criteria.from(User.class))).getResultList();
	}

	@Resource
	private SessionContext sessionContext;

	public Converter getConverter() {

		final UserBean ejbProxy = this.sessionContext
				.getBusinessObject(UserBean.class);

		return new Converter() {

			@Override
			public Object getAsObject(FacesContext context,
					UIComponent component, String value) {

				return ejbProxy.findById(Long.valueOf(value));
			}

			@Override
			public String getAsString(FacesContext context,
					UIComponent component, Object value) {

				if (value == null) {
					return "";
				}
				return String.valueOf(((User) value).getId());
			}
		};
	}

	private User add = new User();

	public User getAdd() {
		return this.add;
	}

	public User getAdded() {
		User added = this.add;
		this.add = new User();
		return added;
	}
}