package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.Category;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessdinners.model.Dinner;
import de.binaris.businessdinners.rest.dto.NestedDinnerDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable
{

   private Long id;
   private String description;
   private String name;
   private Set<NestedDinnerDTO> appointment = new HashSet<NestedDinnerDTO>();

   public CategoryDTO()
   {
   }

   public CategoryDTO(final Category entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         Iterator<Dinner> iterAppointment = entity.getAppointment()
               .iterator();
         for (; iterAppointment.hasNext();)
         {
            Dinner element = iterAppointment.next();
            this.appointment.add(new NestedDinnerDTO(element));
         }
      }
   }

   public Category fromDTO(Category entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Category();
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      Iterator<Dinner> iterAppointment = entity.getAppointment().iterator();
      for (; iterAppointment.hasNext();)
      {
         boolean found = false;
         Dinner dinner = iterAppointment.next();
         Iterator<NestedDinnerDTO> iterDtoAppointment = this
               .getAppointment().iterator();
         for (; iterDtoAppointment.hasNext();)
         {
            NestedDinnerDTO dtoDinner = iterDtoAppointment.next();
            if (dtoDinner.getId().equals(dinner.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterAppointment.remove();
         }
      }
      Iterator<NestedDinnerDTO> iterDtoAppointment = this.getAppointment()
            .iterator();
      for (; iterDtoAppointment.hasNext();)
      {
         boolean found = false;
         NestedDinnerDTO dtoDinner = iterDtoAppointment.next();
         iterAppointment = entity.getAppointment().iterator();
         for (; iterAppointment.hasNext();)
         {
            Dinner dinner = iterAppointment.next();
            if (dtoDinner.getId().equals(dinner.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Dinner> resultIter = em
                  .createQuery("SELECT DISTINCT d FROM Dinner d",
                        Dinner.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Dinner result = resultIter.next();
               if (result.getId().equals(dtoDinner.getId()))
               {
                  entity.getAppointment().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Set<NestedDinnerDTO> getAppointment()
   {
      return this.appointment;
   }

   public void setAppointment(final Set<NestedDinnerDTO> appointment)
   {
      this.appointment = appointment;
   }
}