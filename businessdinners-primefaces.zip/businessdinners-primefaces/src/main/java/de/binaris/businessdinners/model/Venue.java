package de.binaris.businessdinners.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import de.binaris.businessdinners.model.Address;
import de.binaris.businessdinners.model.Dinner;

@Cacheable
@Entity
@Table(name = "venue")
public class Venue implements Serializable {

	private static final long serialVersionUID = 1575729729659127329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_venue")
	@SequenceGenerator(name = "my_entity_seq_gen_venue", sequenceName = "sequence_venue", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String name;								   // appointment place, e.g. a lounge

	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String location;							   // locationName of the lounge, e.g. Hilton Honours
	
	@Size(min = 0, max = 500, message = "optional max. 500 letters and spaces")
	private String website;

	@Size(min = 0, max = 500, message = "optional max. 500 letters and spaces")
	private String linkGooglemaps;
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "venue")
	private Set<Dinner> appointment = new HashSet<Dinner>();
	
	private Address address = new Address();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public Set<Dinner> getAppointment() {
		return appointment;
	}
	
	public void setAppointment(Set<Dinner> appointment) {
		this.appointment = appointment;
	}
	
	public String getLinkGooglemaps() {
		return linkGooglemaps;
	}
	
	public void setLinkGooglemaps(String linkGooglemaps) {
		this.linkGooglemaps = linkGooglemaps;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Venue)) {
			return false;
		}
		Venue castOther = (Venue) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name).append(", ");
		sb.append(location).append(", ");
		return sb.toString();
	}
}
