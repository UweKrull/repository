package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;
import de.binaris.businessdinners.model.AvailableHobby;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedAvailableHobbyDTO implements Serializable
{

   private Long id;
   private String title;

   public NestedAvailableHobbyDTO()
   {
   }

   public NestedAvailableHobbyDTO(final AvailableHobby entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
      }
   }

   public AvailableHobby fromDTO(AvailableHobby entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new AvailableHobby();
      }
      if (this.id != null)
      {
         TypedQuery<AvailableHobby> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT a FROM AvailableHobby a WHERE a.id = :entityId",
                     AvailableHobby.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
}