package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.Dinner;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessdinners.model.SeatsList;

import java.util.Iterator;

import de.binaris.businessdinners.model.JobsList;
import de.binaris.businessdinners.model.HobbiesList;
import de.binaris.businessdinners.model.GendersList;
import de.binaris.businessdinners.model.PrivateOnlyType;
import de.binaris.businessdinners.rest.dto.NestedCategoryDTO;
import de.binaris.businessdinners.rest.dto.NestedGendersListDTO;
import de.binaris.businessdinners.rest.dto.NestedHobbiesListDTO;
import de.binaris.businessdinners.rest.dto.NestedJobsListDTO;
import de.binaris.businessdinners.rest.dto.NestedSeatingChartDTO;
import de.binaris.businessdinners.rest.dto.NestedSeatsListDTO;
import de.binaris.businessdinners.rest.dto.NestedVenueDTO;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DinnerDTO implements Serializable
{

   private String linkDrinkMenu;
   private Set<NestedSeatsListDTO> seatsList = new HashSet<NestedSeatsListDTO>();
   private Set<NestedJobsListDTO> jobsList = new HashSet<NestedJobsListDTO>();
   private Set<NestedHobbiesListDTO> hobbiesList = new HashSet<NestedHobbiesListDTO>();
   private String hostname;
   private NestedSeatingChartDTO seatingChart;
   private NestedVenueDTO venue;
   private String dressCode;
   private Long id;
   private NestedCategoryDTO category;
   private String schedule;
   private Set<NestedGendersListDTO> gendersList = new HashSet<NestedGendersListDTO>();
   private String dinnerWebsite;
   private String description;
   private String name;
   private String linkDetails;
   private String linkGooglemaps;
   private PrivateOnlyType privateOnly;

   public DinnerDTO()
   {
   }

   public DinnerDTO(final Dinner entity)
   {
      if (entity != null)
      {
         this.linkDrinkMenu = entity.getLinkDrinkMenu();
         Iterator<SeatsList> iterSeatsList = entity.getSeatsList()
               .iterator();
         for (; iterSeatsList.hasNext();)
         {
            SeatsList element = iterSeatsList.next();
            this.seatsList.add(new NestedSeatsListDTO(element));
         }
         Iterator<JobsList> iterJobsList = entity.getJobsList().iterator();
         for (; iterJobsList.hasNext();)
         {
            JobsList element = iterJobsList.next();
            this.jobsList.add(new NestedJobsListDTO(element));
         }
         Iterator<HobbiesList> iterHobbiesList = entity.getHobbiesList()
               .iterator();
         for (; iterHobbiesList.hasNext();)
         {
            HobbiesList element = iterHobbiesList.next();
            this.hobbiesList.add(new NestedHobbiesListDTO(element));
         }
         this.hostname = entity.getHostname();
         this.seatingChart = new NestedSeatingChartDTO(
               entity.getSeatingChart());
         this.venue = new NestedVenueDTO(entity.getVenue());
         this.dressCode = entity.getDressCode();
         this.id = entity.getId();
         this.category = new NestedCategoryDTO(entity.getCategory());
         this.schedule = entity.getSchedule();
         Iterator<GendersList> iterGendersList = entity.getGendersList()
               .iterator();
         for (; iterGendersList.hasNext();)
         {
            GendersList element = iterGendersList.next();
            this.gendersList.add(new NestedGendersListDTO(element));
         }
         this.dinnerWebsite = entity.getDinnerWebsite();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.linkDetails = entity.getLinkDetails();
         this.linkGooglemaps = entity.getLinkGooglemaps();
         this.privateOnly = entity.getPrivateOnly();
      }
   }

   public Dinner fromDTO(Dinner entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Dinner();
      }
      entity.setLinkDrinkMenu(this.linkDrinkMenu);
      Iterator<SeatsList> iterSeatsList = entity.getSeatsList().iterator();
      for (; iterSeatsList.hasNext();)
      {
         boolean found = false;
         SeatsList seatsList = iterSeatsList.next();
         Iterator<NestedSeatsListDTO> iterDtoSeatsList = this.getSeatsList()
               .iterator();
         for (; iterDtoSeatsList.hasNext();)
         {
            NestedSeatsListDTO dtoSeatsList = iterDtoSeatsList.next();
            if (dtoSeatsList.getId().equals(seatsList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterSeatsList.remove();
         }
      }
      Iterator<NestedSeatsListDTO> iterDtoSeatsList = this.getSeatsList()
            .iterator();
      for (; iterDtoSeatsList.hasNext();)
      {
         boolean found = false;
         NestedSeatsListDTO dtoSeatsList = iterDtoSeatsList.next();
         iterSeatsList = entity.getSeatsList().iterator();
         for (; iterSeatsList.hasNext();)
         {
            SeatsList seatsList = iterSeatsList.next();
            if (dtoSeatsList.getId().equals(seatsList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<SeatsList> resultIter = em
                  .createQuery("SELECT DISTINCT s FROM SeatsList s",
                        SeatsList.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               SeatsList result = resultIter.next();
               if (result.getId().equals(dtoSeatsList.getId()))
               {
                  entity.getSeatsList().add(result);
                  break;
               }
            }
         }
      }
      Iterator<JobsList> iterJobsList = entity.getJobsList().iterator();
      for (; iterJobsList.hasNext();)
      {
         boolean found = false;
         JobsList jobsList = iterJobsList.next();
         Iterator<NestedJobsListDTO> iterDtoJobsList = this.getJobsList()
               .iterator();
         for (; iterDtoJobsList.hasNext();)
         {
            NestedJobsListDTO dtoJobsList = iterDtoJobsList.next();
            if (dtoJobsList.getId().equals(jobsList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterJobsList.remove();
         }
      }
      Iterator<NestedJobsListDTO> iterDtoJobsList = this.getJobsList()
            .iterator();
      for (; iterDtoJobsList.hasNext();)
      {
         boolean found = false;
         NestedJobsListDTO dtoJobsList = iterDtoJobsList.next();
         iterJobsList = entity.getJobsList().iterator();
         for (; iterJobsList.hasNext();)
         {
            JobsList jobsList = iterJobsList.next();
            if (dtoJobsList.getId().equals(jobsList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<JobsList> resultIter = em
                  .createQuery("SELECT DISTINCT j FROM JobsList j",
                        JobsList.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               JobsList result = resultIter.next();
               if (result.getId().equals(dtoJobsList.getId()))
               {
                  entity.getJobsList().add(result);
                  break;
               }
            }
         }
      }
      Iterator<HobbiesList> iterHobbiesList = entity.getHobbiesList()
            .iterator();
      for (; iterHobbiesList.hasNext();)
      {
         boolean found = false;
         HobbiesList hobbiesList = iterHobbiesList.next();
         Iterator<NestedHobbiesListDTO> iterDtoHobbiesList = this
               .getHobbiesList().iterator();
         for (; iterDtoHobbiesList.hasNext();)
         {
            NestedHobbiesListDTO dtoHobbiesList = iterDtoHobbiesList.next();
            if (dtoHobbiesList.getId().equals(hobbiesList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterHobbiesList.remove();
         }
      }
      Iterator<NestedHobbiesListDTO> iterDtoHobbiesList = this
            .getHobbiesList().iterator();
      for (; iterDtoHobbiesList.hasNext();)
      {
         boolean found = false;
         NestedHobbiesListDTO dtoHobbiesList = iterDtoHobbiesList.next();
         iterHobbiesList = entity.getHobbiesList().iterator();
         for (; iterHobbiesList.hasNext();)
         {
            HobbiesList hobbiesList = iterHobbiesList.next();
            if (dtoHobbiesList.getId().equals(hobbiesList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<HobbiesList> resultIter = em
                  .createQuery("SELECT DISTINCT h FROM HobbiesList h",
                        HobbiesList.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               HobbiesList result = resultIter.next();
               if (result.getId().equals(dtoHobbiesList.getId()))
               {
                  entity.getHobbiesList().add(result);
                  break;
               }
            }
         }
      }
      entity.setHostname(this.hostname);
      if (this.seatingChart != null)
      {
         entity.setSeatingChart(this.seatingChart.fromDTO(
               entity.getSeatingChart(), em));
      }
      if (this.venue != null)
      {
         entity.setVenue(this.venue.fromDTO(entity.getVenue(), em));
      }
      entity.setDressCode(this.dressCode);
      if (this.category != null)
      {
         entity.setCategory(this.category.fromDTO(entity.getCategory(), em));
      }
      entity.setSchedule(this.schedule);
      Iterator<GendersList> iterGendersList = entity.getGendersList()
            .iterator();
      for (; iterGendersList.hasNext();)
      {
         boolean found = false;
         GendersList gendersList = iterGendersList.next();
         Iterator<NestedGendersListDTO> iterDtoGendersList = this
               .getGendersList().iterator();
         for (; iterDtoGendersList.hasNext();)
         {
            NestedGendersListDTO dtoGendersList = iterDtoGendersList.next();
            if (dtoGendersList.getId().equals(gendersList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterGendersList.remove();
         }
      }
      Iterator<NestedGendersListDTO> iterDtoGendersList = this
            .getGendersList().iterator();
      for (; iterDtoGendersList.hasNext();)
      {
         boolean found = false;
         NestedGendersListDTO dtoGendersList = iterDtoGendersList.next();
         iterGendersList = entity.getGendersList().iterator();
         for (; iterGendersList.hasNext();)
         {
            GendersList gendersList = iterGendersList.next();
            if (dtoGendersList.getId().equals(gendersList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<GendersList> resultIter = em
                  .createQuery("SELECT DISTINCT g FROM GendersList g",
                        GendersList.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               GendersList result = resultIter.next();
               if (result.getId().equals(dtoGendersList.getId()))
               {
                  entity.getGendersList().add(result);
                  break;
               }
            }
         }
      }
      entity.setDinnerWebsite(this.dinnerWebsite);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setLinkDetails(this.linkDetails);
      entity.setLinkGooglemaps(this.linkGooglemaps);
      entity.setPrivateOnly(this.privateOnly);
      entity = em.merge(entity);
      return entity;
   }

   public String getLinkDrinkMenu()
   {
      return this.linkDrinkMenu;
   }

   public void setLinkDrinkMenu(final String linkDrinkMenu)
   {
      this.linkDrinkMenu = linkDrinkMenu;
   }

   public Set<NestedSeatsListDTO> getSeatsList()
   {
      return this.seatsList;
   }

   public void setSeatsList(final Set<NestedSeatsListDTO> seatsList)
   {
      this.seatsList = seatsList;
   }

   public Set<NestedJobsListDTO> getJobsList()
   {
      return this.jobsList;
   }

   public void setJobsList(final Set<NestedJobsListDTO> jobsList)
   {
      this.jobsList = jobsList;
   }

   public Set<NestedHobbiesListDTO> getHobbiesList()
   {
      return this.hobbiesList;
   }

   public void setHobbiesList(final Set<NestedHobbiesListDTO> hobbiesList)
   {
      this.hobbiesList = hobbiesList;
   }

   public String getHostname()
   {
      return this.hostname;
   }

   public void setHostname(final String hostname)
   {
      this.hostname = hostname;
   }

   public NestedSeatingChartDTO getSeatingChart()
   {
      return this.seatingChart;
   }

   public void setSeatingChart(final NestedSeatingChartDTO seatingChart)
   {
      this.seatingChart = seatingChart;
   }

   public NestedVenueDTO getVenue()
   {
      return this.venue;
   }

   public void setVenue(final NestedVenueDTO venue)
   {
      this.venue = venue;
   }

   public String getDressCode()
   {
      return this.dressCode;
   }

   public void setDressCode(final String dressCode)
   {
      this.dressCode = dressCode;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedCategoryDTO getCategory()
   {
      return this.category;
   }

   public void setCategory(final NestedCategoryDTO category)
   {
      this.category = category;
   }

   public String getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final String schedule)
   {
      this.schedule = schedule;
   }

   public Set<NestedGendersListDTO> getGendersList()
   {
      return this.gendersList;
   }

   public void setGendersList(final Set<NestedGendersListDTO> gendersList)
   {
      this.gendersList = gendersList;
   }

   public String getDinnerWebsite()
   {
      return this.dinnerWebsite;
   }

   public void setDinnerWebsite(final String dinnerWebsite)
   {
      this.dinnerWebsite = dinnerWebsite;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLinkDetails()
   {
      return this.linkDetails;
   }

   public void setLinkDetails(final String linkDetails)
   {
      this.linkDetails = linkDetails;
   }

   public String getLinkGooglemaps()
   {
      return this.linkGooglemaps;
   }

   public void setLinkGooglemaps(final String linkGooglemaps)
   {
      this.linkGooglemaps = linkGooglemaps;
   }

   public PrivateOnlyType getPrivateOnly()
   {
      return this.privateOnly;
   }

   public void setPrivateOnly(final PrivateOnlyType privateOnly)
   {
      this.privateOnly = privateOnly;
   }
}