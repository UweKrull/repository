package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.SeatsList;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessdinners.model.AvailableSeat;
import de.binaris.businessdinners.rest.dto.NestedAvailableSeatDTO;
import de.binaris.businessdinners.rest.dto.NestedDinnerDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SeatsListDTO implements Serializable
{

   private NestedDinnerDTO dinner;
   private Long id;
   private String title;
   private Set<NestedAvailableSeatDTO> availableSeat = new HashSet<NestedAvailableSeatDTO>();

   public SeatsListDTO()
   {
   }

   public SeatsListDTO(final SeatsList entity)
   {
      if (entity != null)
      {
         this.dinner = new NestedDinnerDTO(entity.getDinner());
         this.id = entity.getId();
         this.title = entity.getTitle();
         Iterator<AvailableSeat> iterAvailableSeat = entity
               .getAvailableSeat().iterator();
         for (; iterAvailableSeat.hasNext();)
         {
            AvailableSeat element = iterAvailableSeat.next();
            this.availableSeat.add(new NestedAvailableSeatDTO(element));
         }
      }
   }

   public SeatsList fromDTO(SeatsList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new SeatsList();
      }
      if (this.dinner != null)
      {
         entity.setDinner(this.dinner.fromDTO(entity.getDinner(), em));
      }
      entity.setTitle(this.title);
      Iterator<AvailableSeat> iterAvailableSeat = entity.getAvailableSeat()
            .iterator();
      for (; iterAvailableSeat.hasNext();)
      {
         boolean found = false;
         AvailableSeat availableSeat = iterAvailableSeat.next();
         Iterator<NestedAvailableSeatDTO> iterDtoAvailableSeat = this
               .getAvailableSeat().iterator();
         for (; iterDtoAvailableSeat.hasNext();)
         {
            NestedAvailableSeatDTO dtoAvailableSeat = iterDtoAvailableSeat
                  .next();
            if (dtoAvailableSeat.getId().equals(availableSeat.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterAvailableSeat.remove();
         }
      }
      Iterator<NestedAvailableSeatDTO> iterDtoAvailableSeat = this
            .getAvailableSeat().iterator();
      for (; iterDtoAvailableSeat.hasNext();)
      {
         boolean found = false;
         NestedAvailableSeatDTO dtoAvailableSeat = iterDtoAvailableSeat
               .next();
         iterAvailableSeat = entity.getAvailableSeat().iterator();
         for (; iterAvailableSeat.hasNext();)
         {
            AvailableSeat availableSeat = iterAvailableSeat.next();
            if (dtoAvailableSeat.getId().equals(availableSeat.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<AvailableSeat> resultIter = em
                  .createQuery("SELECT DISTINCT a FROM AvailableSeat a",
                        AvailableSeat.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               AvailableSeat result = resultIter.next();
               if (result.getId().equals(dtoAvailableSeat.getId()))
               {
                  entity.getAvailableSeat().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public NestedDinnerDTO getDinner()
   {
      return this.dinner;
   }

   public void setDinner(final NestedDinnerDTO dinner)
   {
      this.dinner = dinner;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public Set<NestedAvailableSeatDTO> getAvailableSeat()
   {
      return this.availableSeat;
   }

   public void setAvailableSeat(final Set<NestedAvailableSeatDTO> availableSeat)
   {
      this.availableSeat = availableSeat;
   }
}