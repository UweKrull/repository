package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;
import de.binaris.businessdinners.model.Dinner;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.businessdinners.model.PrivateOnlyType;

public class NestedDinnerDTO implements Serializable
{

   private String linkDrinkMenu;
   private String hostname;
   private String dressCode;
   private Long id;
   private String schedule;
   private String dinnerWebsite;
   private String description;
   private String name;
   private String linkDetails;
   private String linkGooglemaps;
   private PrivateOnlyType privateOnly;

   public NestedDinnerDTO()
   {
   }

   public NestedDinnerDTO(final Dinner entity)
   {
      if (entity != null)
      {
         this.linkDrinkMenu = entity.getLinkDrinkMenu();
         this.hostname = entity.getHostname();
         this.dressCode = entity.getDressCode();
         this.id = entity.getId();
         this.schedule = entity.getSchedule();
         this.dinnerWebsite = entity.getDinnerWebsite();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.linkDetails = entity.getLinkDetails();
         this.linkGooglemaps = entity.getLinkGooglemaps();
         this.privateOnly = entity.getPrivateOnly();
      }
   }

   public Dinner fromDTO(Dinner entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Dinner();
      }
      if (this.id != null)
      {
         TypedQuery<Dinner> findByIdQuery = em.createQuery(
               "SELECT DISTINCT d FROM Dinner d WHERE d.id = :entityId",
               Dinner.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setLinkDrinkMenu(this.linkDrinkMenu);
      entity.setHostname(this.hostname);
      entity.setDressCode(this.dressCode);
      entity.setSchedule(this.schedule);
      entity.setDinnerWebsite(this.dinnerWebsite);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setLinkDetails(this.linkDetails);
      entity.setLinkGooglemaps(this.linkGooglemaps);
      entity.setPrivateOnly(this.privateOnly);
      entity = em.merge(entity);
      return entity;
   }

   public String getLinkDrinkMenu()
   {
      return this.linkDrinkMenu;
   }

   public void setLinkDrinkMenu(final String linkDrinkMenu)
   {
      this.linkDrinkMenu = linkDrinkMenu;
   }

   public String getHostname()
   {
      return this.hostname;
   }

   public void setHostname(final String hostname)
   {
      this.hostname = hostname;
   }

   public String getDressCode()
   {
      return this.dressCode;
   }

   public void setDressCode(final String dressCode)
   {
      this.dressCode = dressCode;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final String schedule)
   {
      this.schedule = schedule;
   }

   public String getDinnerWebsite()
   {
      return this.dinnerWebsite;
   }

   public void setDinnerWebsite(final String dinnerWebsite)
   {
      this.dinnerWebsite = dinnerWebsite;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLinkDetails()
   {
      return this.linkDetails;
   }

   public void setLinkDetails(final String linkDetails)
   {
      this.linkDetails = linkDetails;
   }

   public String getLinkGooglemaps()
   {
      return this.linkGooglemaps;
   }

   public void setLinkGooglemaps(final String linkGooglemaps)
   {
      this.linkGooglemaps = linkGooglemaps;
   }

   public PrivateOnlyType getPrivateOnly()
   {
      return this.privateOnly;
   }

   public void setPrivateOnly(final PrivateOnlyType privateOnly)
   {
      this.privateOnly = privateOnly;
   }
}