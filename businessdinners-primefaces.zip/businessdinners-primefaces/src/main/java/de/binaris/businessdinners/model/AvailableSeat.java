package de.binaris.businessdinners.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "available_seat")
public class AvailableSeat implements Serializable {

	private static final long serialVersionUID = 7975171029657126323L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_available_seat")
	@SequenceGenerator(name = "my_entity_seq_gen_available_seat", sequenceName = "sequence_available_seat", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private SeatsList seatsList;
	
	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String title;

	@ManyToOne
	private Seat seat;
	
	@ManyToOne
	private User user;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public SeatsList getSeatsList() {
		return seatsList;
	}

	public void setSeatsList(SeatsList seatsList) {
		this.seatsList = seatsList;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Seat getSeat() {
		return seat;
	}

	public void setSeat(Seat seat) {
		this.seat = seat;
	}

	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof AvailableSeat)) {
			return false;
		}
		AvailableSeat castOther = (AvailableSeat) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		if (title.length() > 20) {
			sb.append(title.substring(0, 20));
			sb.append("...");
		} else {
			sb.append(title);
		}
		return sb.toString();
	}
}
