package de.binaris.businessdinners.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "hobbies_list")
public class HobbiesList implements Serializable {

	private static final long serialVersionUID = 7975779629657127325L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_hobbies_list")
	@SequenceGenerator(name = "my_entity_seq_gen_hobbies_list", sequenceName = "sequence_hobbies_list", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Dinner dinner;
	
	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String title;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "hobbiesList")
	private Set<AvailableHobby> availableHobby = new HashSet<AvailableHobby>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Dinner getDinner() {
		return dinner;
	}

	public void setDinner(Dinner dinner) {
		this.dinner = dinner;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Set<AvailableHobby> getAvailableHobby() {
		return availableHobby;
	}

	public void setAvailableHobby(Set<AvailableHobby> availableHobby) {
		this.availableHobby = availableHobby;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof HobbiesList)) {
			return false;
		}
		HobbiesList castOther = (HobbiesList) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		if (title.length() > 20) {
			sb.append(title.substring(0, 20));
			sb.append("...");
		} else {
			sb.append(title);
		}
		return sb.toString();
	}
}
