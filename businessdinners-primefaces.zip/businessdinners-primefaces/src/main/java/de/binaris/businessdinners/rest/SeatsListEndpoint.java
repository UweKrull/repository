package de.binaris.businessdinners.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.businessdinners.model.SeatsList;
import de.binaris.businessdinners.rest.dto.SeatsListDTO;

/**
 * 
 */
@Stateless
@Path("/seatslists")
public class SeatsListEndpoint
{
   @PersistenceContext(unitName = "BusinessdinnersPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(SeatsListDTO dto)
   {
      SeatsList entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(SeatsListEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      SeatsList entity = em.find(SeatsList.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<SeatsList> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM SeatsList s LEFT JOIN FETCH s.dinner LEFT JOIN FETCH s.availableSeat WHERE s.id = :entityId ORDER BY s.id", SeatsList.class);
      findByIdQuery.setParameter("entityId", id);
      SeatsList entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      SeatsListDTO dto = new SeatsListDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<SeatsListDTO> listAll()
   {
      final List<SeatsList> searchResults = em.createQuery("SELECT DISTINCT s FROM SeatsList s LEFT JOIN FETCH s.dinner LEFT JOIN FETCH s.availableSeat ORDER BY s.id", SeatsList.class).getResultList();
      final List<SeatsListDTO> results = new ArrayList<SeatsListDTO>();
      for (SeatsList searchResult : searchResults)
      {
         SeatsListDTO dto = new SeatsListDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, SeatsListDTO dto)
   {
      TypedQuery<SeatsList> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM SeatsList s LEFT JOIN FETCH s.dinner LEFT JOIN FETCH s.availableSeat WHERE s.id = :entityId ORDER BY s.id", SeatsList.class);
      findByIdQuery.setParameter("entityId", id);
      SeatsList entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}