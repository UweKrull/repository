package de.binaris.businessdinners.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "seating_chart")
public class SeatingChart implements Serializable {

	private static final long serialVersionUID = 7995777625699126629L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_seating_chart")
	@SequenceGenerator(name = "my_entity_seq_gen_seating_chart", sequenceName = "sequence_seating_chart", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 80, message = "must be 1-80 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 10, max = 200, message = "must be 2-100 letters and spaces")
	@Column(name = "url")
	private String url;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof SeatingChart)) {
			return false;
		}
		SeatingChart castOther = (SeatingChart) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return name;
	}
}
