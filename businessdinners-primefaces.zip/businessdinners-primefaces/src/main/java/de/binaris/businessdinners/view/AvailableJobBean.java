package de.binaris.businessdinners.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import de.binaris.businessdinners.model.AvailableJob;
import de.binaris.businessdinners.model.Job;
import de.binaris.businessdinners.model.JobsList;
import de.binaris.businessdinners.model.User;

/**
 * Backing bean for AvailableJob entities.
 * <p>
 * This class provides CRUD functionality for all AvailableJob entities. It focuses
 * purely on Java EE 6 standards (e.g. <tt>&#64;ConversationScoped</tt> for
 * state management, <tt>PersistenceContext</tt> for persistence,
 * <tt>CriteriaBuilder</tt> for searches) rather than introducing a CRUD framework or
 * custom base class.
 */

@Named
@Stateful
@ConversationScoped
public class AvailableJobBean implements Serializable
{

   private static final long serialVersionUID = 1L;

   /*
    * Support creating and retrieving AvailableJob entities
    */

   private Long id;

   public Long getId()
   {
      return this.id;
   }

   public void setId(Long id)
   {
      this.id = id;
   }

   private AvailableJob availableJob;

   public AvailableJob getAvailableJob()
   {
      return this.availableJob;
   }

   @Inject
   private Conversation conversation;

   @PersistenceContext(type = PersistenceContextType.EXTENDED)
   private EntityManager entityManager;

   public String create()
   {

      this.conversation.begin();
      return "create?faces-redirect=true";
   }

   public void retrieve()
   {

      if (FacesContext.getCurrentInstance().isPostback())
      {
         return;
      }

      if (this.conversation.isTransient())
      {
         this.conversation.begin();
      }

      if (this.id == null)
      {
         this.availableJob = this.example;
      }
      else
      {
         this.availableJob = findById(getId());
      }
   }

   public AvailableJob findById(Long id)
   {

      return this.entityManager.find(AvailableJob.class, id);
   }

   /*
    * Support updating and deleting AvailableJob entities
    */

   public String update()
   {
      this.conversation.end();

      try
      {
         if (this.id == null)
         {
            this.entityManager.persist(this.availableJob);
            return "search?faces-redirect=true";
         }
         else
         {
            this.entityManager.merge(this.availableJob);
            return "view?faces-redirect=true&id=" + this.availableJob.getId();
         }
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   public String delete()
   {
      this.conversation.end();

      try
      {
         AvailableJob deletableEntity = findById(getId());
         JobsList jobsList = deletableEntity.getJobsList();
         jobsList.getAvailableJob().remove(deletableEntity);
         deletableEntity.setJobsList(null);
         this.entityManager.merge(jobsList);
         this.entityManager.remove(deletableEntity);
         this.entityManager.flush();
         return "search?faces-redirect=true";
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   /*
    * Support searching AvailableJob entities with pagination
    */

   private int page;
   private long count;
   private List<AvailableJob> pageItems;

   private AvailableJob example = new AvailableJob();

   public int getPage()
   {
      return this.page;
   }

   public void setPage(int page)
   {
      this.page = page;
   }

   public int getPageSize()
   {
      return 10;
   }

   public AvailableJob getExample()
   {
      return this.example;
   }

   public void setExample(AvailableJob example)
   {
      this.example = example;
   }

   public void search()
   {
      this.page = 0;
   }

   public void paginate()
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

      // Populate this.count

      CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
      Root<AvailableJob> root = countCriteria.from(AvailableJob.class);
      countCriteria = countCriteria.select(builder.count(root)).where(
            getSearchPredicates(root));
      this.count = this.entityManager.createQuery(countCriteria)
            .getSingleResult();

      // Populate this.pageItems

      CriteriaQuery<AvailableJob> criteria = builder.createQuery(AvailableJob.class);
      root = criteria.from(AvailableJob.class);
      TypedQuery<AvailableJob> query = this.entityManager.createQuery(criteria
            .select(root).where(getSearchPredicates(root)));
      query.setFirstResult(this.page * getPageSize()).setMaxResults(
            getPageSize());
      this.pageItems = query.getResultList();
   }

   private Predicate[] getSearchPredicates(Root<AvailableJob> root)
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
      List<Predicate> predicatesList = new ArrayList<Predicate>();

      JobsList jobsList = this.example.getJobsList();
      if (jobsList != null)
      {
         predicatesList.add(builder.equal(root.get("jobsList"), jobsList));
      }
      String title = this.example.getTitle();
      if (title != null && !"".equals(title))
      {
         predicatesList.add(builder.like(root.<String> get("title"), '%' + title + '%'));
      }
      Job job = this.example.getJob();
      if (job != null)
      {
         predicatesList.add(builder.equal(root.get("job"), job));
      }
      User user = this.example.getUser();
      if (user != null)
      {
         predicatesList.add(builder.equal(root.get("user"), user));
      }

      return predicatesList.toArray(new Predicate[predicatesList.size()]);
   }

   public List<AvailableJob> getPageItems()
   {
      return this.pageItems;
   }

   public long getCount()
   {
      return this.count;
   }

   /*
    * Support listing and POSTing back AvailableJob entities (e.g. from inside an
    * HtmlSelectOneMenu)
    */

   public List<AvailableJob> getAll()
   {

      CriteriaQuery<AvailableJob> criteria = this.entityManager
            .getCriteriaBuilder().createQuery(AvailableJob.class);
      return this.entityManager.createQuery(
            criteria.select(criteria.from(AvailableJob.class))).getResultList();
   }

   @Resource
   private SessionContext sessionContext;

   public Converter getConverter()
   {

      final AvailableJobBean ejbProxy = this.sessionContext.getBusinessObject(AvailableJobBean.class);

      return new Converter()
      {

         @Override
         public Object getAsObject(FacesContext context,
               UIComponent component, String value)
         {

            return ejbProxy.findById(Long.valueOf(value));
         }

         @Override
         public String getAsString(FacesContext context,
               UIComponent component, Object value)
         {

            if (value == null)
            {
               return "";
            }

            return String.valueOf(((AvailableJob) value).getId());
         }
      };
   }

   /*
    * Support adding children to bidirectional, one-to-many tables
    */

   private AvailableJob add = new AvailableJob();

   public AvailableJob getAdd()
   {
      return this.add;
   }

   public AvailableJob getAdded()
   {
      AvailableJob added = this.add;
      this.add = new AvailableJob();
      return added;
   }
}