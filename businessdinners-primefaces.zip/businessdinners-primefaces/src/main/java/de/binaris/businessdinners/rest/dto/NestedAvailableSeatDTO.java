package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;
import de.binaris.businessdinners.model.AvailableSeat;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedAvailableSeatDTO implements Serializable
{

   private Long id;
   private String title;

   public NestedAvailableSeatDTO()
   {
   }

   public NestedAvailableSeatDTO(final AvailableSeat entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
      }
   }

   public AvailableSeat fromDTO(AvailableSeat entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new AvailableSeat();
      }
      if (this.id != null)
      {
         TypedQuery<AvailableSeat> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT a FROM AvailableSeat a WHERE a.id = :entityId",
                     AvailableSeat.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
}