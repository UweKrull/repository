package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.AvailableHobby;
import de.binaris.businessdinners.rest.dto.NestedHobbiesListDTO;
import de.binaris.businessdinners.rest.dto.NestedHobbyDTO;
import de.binaris.businessdinners.rest.dto.NestedUserDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AvailableHobbyDTO implements Serializable
{

   private Long id;
   private String title;
   private NestedHobbiesListDTO hobbiesList;
   private NestedHobbyDTO hobby;
   private NestedUserDTO user;

   public AvailableHobbyDTO()
   {
   }

   public AvailableHobbyDTO(final AvailableHobby entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.hobbiesList = new NestedHobbiesListDTO(entity.getHobbiesList());
         this.hobby = new NestedHobbyDTO(entity.getHobby());
         this.user = new NestedUserDTO(entity.getUser());
      }
   }

   public AvailableHobby fromDTO(AvailableHobby entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new AvailableHobby();
      }
      entity.setTitle(this.title);
      if (this.hobbiesList != null)
      {
         entity.setHobbiesList(this.hobbiesList.fromDTO(
               entity.getHobbiesList(), em));
      }
      if (this.hobby != null)
      {
         entity.setHobby(this.hobby.fromDTO(entity.getHobby(), em));
      }
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public NestedHobbiesListDTO getHobbiesList()
   {
      return this.hobbiesList;
   }

   public void setHobbiesList(final NestedHobbiesListDTO hobbiesList)
   {
      this.hobbiesList = hobbiesList;
   }

   public NestedHobbyDTO getHobby()
   {
      return this.hobby;
   }

   public void setHobby(final NestedHobbyDTO hobby)
   {
      this.hobby = hobby;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }
}