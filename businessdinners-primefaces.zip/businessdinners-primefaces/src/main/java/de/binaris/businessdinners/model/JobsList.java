package de.binaris.businessdinners.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "jobs_list")
public class JobsList implements Serializable {

	private static final long serialVersionUID = 7975779629657127325L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_jobs_list")
	@SequenceGenerator(name = "my_entity_seq_gen_jobs_list", sequenceName = "sequence_jobs_list", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Dinner dinner;
	
	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String title;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "jobsList")
	private Set<AvailableJob> availableJob = new HashSet<AvailableJob>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Dinner getDinner() {
		return dinner;
	}

	public void setDinner(Dinner dinner) {
		this.dinner = dinner;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Set<AvailableJob> getAvailableJob() {
		return availableJob;
	}

	public void setAvailableJob(Set<AvailableJob> availableJob) {
		this.availableJob = availableJob;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof JobsList)) {
			return false;
		}
		JobsList castOther = (JobsList) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		if (title.length() > 20) {
			sb.append(title.substring(0, 20));
			sb.append("...");
		} else {
			sb.append(title);
		}
		return sb.toString();
	}
}
