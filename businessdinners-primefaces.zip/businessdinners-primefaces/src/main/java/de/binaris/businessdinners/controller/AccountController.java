package de.binaris.businessdinners.controller;

import java.io.Serializable;

import javax.enterprise.context.Conversation;
import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import de.binaris.businessdinners.model.User;
import de.binaris.businessdinners.view.UserBean;
import de.binaris.businessdinners.annotations.CatchException;
import de.binaris.businessdinners.annotations.Loggable;
import de.binaris.businessdinners.annotations.LoggedIn;

@Named
@SessionScoped
@Loggable
@CatchException
public class AccountController extends Controller implements Serializable {

	private static final long serialVersionUID = 2271527273097745972L;

	@Inject
    private UserBean customerService;

    @Inject
    private Credentials credentials;

    @Inject
    private Conversation conversation;

    @Produces
    @LoggedIn
    @SessionScoped
    private User loggedinCustomer;

    @Inject
    @SessionScoped
    private transient LoginContext loginContext;

    public String doLogin() throws LoginException {
        if ("".equals(credentials.getLogin())) {
            return null;
        }
        if ("".equals(credentials.getPassword())) {
            return null;
        }
        loginContext.login();
        loggedinCustomer = customerService.findByLogin(credentials.getLogin());
        return "main.faces";
    }

    public String doLoginCustomer() throws LoginException {
    	if (credentials == null || "".equals(credentials.getLogin())) {
    		return "signon?faces-redirect=true";
    	}
    	if ("".equals(credentials.getPassword())) {
    		return "signon?faces-redirect=true";
    	}
//    	loginContext.login();
    	loggedinCustomer = customerService.findCustomer(credentials.getLogin(), credentials.getPassword());
    	if (loggedinCustomer != null) {
    		return "/index1.xhtml";
    	} else {
    		return "signon?faces-redirect=true";
    	}
    }
    
    public String doCreateNewAccount() {
        return "create1?faces-redirect=true";
    }

    public String doCreateCustomer() {
    	customerService.setCustomer(loggedinCustomer);
        customerService.update();
        loggedinCustomer = customerService.getCustomer();
        return "main.faces";
    }

    public String doLogout() {
        loggedinCustomer = null;
        // Stop conversation
        if (!conversation.isTransient()) {
            conversation.end();
        }
        return "/index.xhtml";
    }

    public String doUpdateAccount() {
    	customerService.setCustomer(loggedinCustomer);
        customerService.update();
        loggedinCustomer = customerService.getCustomer();
        return "edit?faces-redirect=true";
    }

    public boolean isLoggedIn() {
        return loggedinCustomer != null;
    }

    public User getLoggedinCustomer() {
        return loggedinCustomer;
    }

    public String setLoggedinCustomer(User loggedinCustomer) {
        this.loggedinCustomer = loggedinCustomer;
        return "";
    }
}
