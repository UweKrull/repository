package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.JobsList;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessdinners.model.AvailableJob;
import de.binaris.businessdinners.rest.dto.NestedAvailableJobDTO;
import de.binaris.businessdinners.rest.dto.NestedDinnerDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class JobsListDTO implements Serializable
{

   private NestedDinnerDTO dinner;
   private Long id;
   private String title;
   private Set<NestedAvailableJobDTO> availableJob = new HashSet<NestedAvailableJobDTO>();

   public JobsListDTO()
   {
   }

   public JobsListDTO(final JobsList entity)
   {
      if (entity != null)
      {
         this.dinner = new NestedDinnerDTO(entity.getDinner());
         this.id = entity.getId();
         this.title = entity.getTitle();
         Iterator<AvailableJob> iterAvailableJob = entity.getAvailableJob()
               .iterator();
         for (; iterAvailableJob.hasNext();)
         {
            AvailableJob element = iterAvailableJob.next();
            this.availableJob.add(new NestedAvailableJobDTO(element));
         }
      }
   }

   public JobsList fromDTO(JobsList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new JobsList();
      }
      if (this.dinner != null)
      {
         entity.setDinner(this.dinner.fromDTO(entity.getDinner(), em));
      }
      entity.setTitle(this.title);
      Iterator<AvailableJob> iterAvailableJob = entity.getAvailableJob()
            .iterator();
      for (; iterAvailableJob.hasNext();)
      {
         boolean found = false;
         AvailableJob availableJob = iterAvailableJob.next();
         Iterator<NestedAvailableJobDTO> iterDtoAvailableJob = this
               .getAvailableJob().iterator();
         for (; iterDtoAvailableJob.hasNext();)
         {
            NestedAvailableJobDTO dtoAvailableJob = iterDtoAvailableJob
                  .next();
            if (dtoAvailableJob.getId().equals(availableJob.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterAvailableJob.remove();
         }
      }
      Iterator<NestedAvailableJobDTO> iterDtoAvailableJob = this
            .getAvailableJob().iterator();
      for (; iterDtoAvailableJob.hasNext();)
      {
         boolean found = false;
         NestedAvailableJobDTO dtoAvailableJob = iterDtoAvailableJob.next();
         iterAvailableJob = entity.getAvailableJob().iterator();
         for (; iterAvailableJob.hasNext();)
         {
            AvailableJob availableJob = iterAvailableJob.next();
            if (dtoAvailableJob.getId().equals(availableJob.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<AvailableJob> resultIter = em
                  .createQuery("SELECT DISTINCT a FROM AvailableJob a",
                        AvailableJob.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               AvailableJob result = resultIter.next();
               if (result.getId().equals(dtoAvailableJob.getId()))
               {
                  entity.getAvailableJob().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public NestedDinnerDTO getDinner()
   {
      return this.dinner;
   }

   public void setDinner(final NestedDinnerDTO dinner)
   {
      this.dinner = dinner;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public Set<NestedAvailableJobDTO> getAvailableJob()
   {
      return this.availableJob;
   }

   public void setAvailableJob(final Set<NestedAvailableJobDTO> availableJob)
   {
      this.availableJob = availableJob;
   }
}