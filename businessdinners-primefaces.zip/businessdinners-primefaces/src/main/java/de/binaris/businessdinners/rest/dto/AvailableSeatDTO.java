package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.AvailableSeat;
import de.binaris.businessdinners.rest.dto.NestedSeatDTO;
import de.binaris.businessdinners.rest.dto.NestedSeatsListDTO;
import de.binaris.businessdinners.rest.dto.NestedUserDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AvailableSeatDTO implements Serializable
{

   private Long id;
   private String title;
   private NestedSeatsListDTO seatsList;
   private NestedSeatDTO seat;
   private NestedUserDTO user;

   public AvailableSeatDTO()
   {
   }

   public AvailableSeatDTO(final AvailableSeat entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.seatsList = new NestedSeatsListDTO(entity.getSeatsList());
         this.seat = new NestedSeatDTO(entity.getSeat());
         this.user = new NestedUserDTO(entity.getUser());
      }
   }

   public AvailableSeat fromDTO(AvailableSeat entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new AvailableSeat();
      }
      entity.setTitle(this.title);
      if (this.seatsList != null)
      {
         entity.setSeatsList(this.seatsList.fromDTO(entity.getSeatsList(),
               em));
      }
      if (this.seat != null)
      {
         entity.setSeat(this.seat.fromDTO(entity.getSeat(), em));
      }
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public NestedSeatsListDTO getSeatsList()
   {
      return this.seatsList;
   }

   public void setSeatsList(final NestedSeatsListDTO seatsList)
   {
      this.seatsList = seatsList;
   }

   public NestedSeatDTO getSeat()
   {
      return this.seat;
   }

   public void setSeat(final NestedSeatDTO seat)
   {
      this.seat = seat;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }
}