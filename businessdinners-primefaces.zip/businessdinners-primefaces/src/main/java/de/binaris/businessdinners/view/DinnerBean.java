package de.binaris.businessdinners.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import de.binaris.businessdinners.model.Dinner;
import de.binaris.businessdinners.model.Category;
import de.binaris.businessdinners.model.GendersList;
import de.binaris.businessdinners.model.HobbiesList;
import de.binaris.businessdinners.model.JobsList;
import de.binaris.businessdinners.model.SeatsList;
import de.binaris.businessdinners.model.Venue;
import java.util.Iterator;

/**
 * Backing bean for Dinner entities.
 * <p>
 * This class provides CRUD functionality for all Dinner entities. It focuses
 * purely on Java EE 6 standards (e.g. <tt>&#64;ConversationScoped</tt> for
 * state management, <tt>PersistenceContext</tt> for persistence,
 * <tt>CriteriaBuilder</tt> for searches) rather than introducing a CRUD framework or
 * custom base class.
 */

@Named
@Stateful
@ConversationScoped
public class DinnerBean implements Serializable
{

   private static final long serialVersionUID = 1L;

   /*
    * Support creating and retrieving Dinner entities
    */

   private Long id;

   public Long getId()
   {
      return this.id;
   }

   public void setId(Long id)
   {
      this.id = id;
   }

   private Dinner dinner;

   public Dinner getDinner()
   {
      return this.dinner;
   }

   @Inject
   private Conversation conversation;

   @PersistenceContext(type = PersistenceContextType.EXTENDED)
   private EntityManager entityManager;

   public String create()
   {

      this.conversation.begin();
      return "create?faces-redirect=true";
   }

   public void retrieve()
   {

      if (FacesContext.getCurrentInstance().isPostback())
      {
         return;
      }

      if (this.conversation.isTransient())
      {
         this.conversation.begin();
      }

      if (this.id == null)
      {
         this.dinner = this.example;
      }
      else
      {
         this.dinner = findById(getId());
      }
   }

   public Dinner findById(Long id)
   {

      return this.entityManager.find(Dinner.class, id);
   }

   /*
    * Support updating and deleting Dinner entities
    */

   public String update()
   {
      this.conversation.end();

      try
      {
         if (this.id == null)
         {
            this.entityManager.persist(this.dinner);
            return "search?faces-redirect=true";
         }
         else
         {
            this.entityManager.merge(this.dinner);
            return "view?faces-redirect=true&id=" + this.dinner.getId();
         }
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   public String delete()
   {
      this.conversation.end();

      try
      {
         Dinner deletableEntity = findById(getId());
         Venue venue = deletableEntity.getVenue();
         venue.getAppointment().remove(deletableEntity);
         deletableEntity.setVenue(null);
         this.entityManager.merge(venue);
         Category category = deletableEntity.getCategory();
         category.getAppointment().remove(deletableEntity);
         deletableEntity.setCategory(null);
         this.entityManager.merge(category);
         Iterator<HobbiesList> iterHobbiesList = deletableEntity.getHobbiesList().iterator();
         for (; iterHobbiesList.hasNext();)
         {
            HobbiesList nextInHobbiesList = iterHobbiesList.next();
            nextInHobbiesList.setDinner(null);
            iterHobbiesList.remove();
            this.entityManager.merge(nextInHobbiesList);
         }
         Iterator<JobsList> iterJobsList = deletableEntity.getJobsList().iterator();
         for (; iterJobsList.hasNext();)
         {
            JobsList nextInJobsList = iterJobsList.next();
            nextInJobsList.setDinner(null);
            iterJobsList.remove();
            this.entityManager.merge(nextInJobsList);
         }
         Iterator<GendersList> iterGendersList = deletableEntity.getGendersList().iterator();
         for (; iterGendersList.hasNext();)
         {
            GendersList nextInGendersList = iterGendersList.next();
            nextInGendersList.setDinner(null);
            iterGendersList.remove();
            this.entityManager.merge(nextInGendersList);
         }
         Iterator<SeatsList> iterSeatsList = deletableEntity.getSeatsList().iterator();
         for (; iterSeatsList.hasNext();)
         {
            SeatsList nextInSeatsList = iterSeatsList.next();
            nextInSeatsList.setDinner(null);
            iterSeatsList.remove();
            this.entityManager.merge(nextInSeatsList);
         }
         this.entityManager.remove(deletableEntity);
         this.entityManager.flush();
         return "search?faces-redirect=true";
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   /*
    * Support searching Dinner entities with pagination
    */

   private int page;
   private long count;
   private List<Dinner> pageItems;

   private Dinner example = new Dinner();

   public int getPage()
   {
      return this.page;
   }

   public void setPage(int page)
   {
      this.page = page;
   }

   public int getPageSize()
   {
      return 10;
   }

   public Dinner getExample()
   {
      return this.example;
   }

   public void setExample(Dinner example)
   {
      this.example = example;
   }

   public void search()
   {
      this.page = 0;
   }

   public void paginate()
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

      // Populate this.count

      CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
      Root<Dinner> root = countCriteria.from(Dinner.class);
      countCriteria = countCriteria.select(builder.count(root)).where(
            getSearchPredicates(root));
      this.count = this.entityManager.createQuery(countCriteria)
            .getSingleResult();

      // Populate this.pageItems

      CriteriaQuery<Dinner> criteria = builder.createQuery(Dinner.class);
      root = criteria.from(Dinner.class);
      TypedQuery<Dinner> query = this.entityManager.createQuery(criteria
            .select(root).where(getSearchPredicates(root)));
      query.setFirstResult(this.page * getPageSize()).setMaxResults(
            getPageSize());
      this.pageItems = query.getResultList();
   }

   private Predicate[] getSearchPredicates(Root<Dinner> root)
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
      List<Predicate> predicatesList = new ArrayList<Predicate>();

      String name = this.example.getName();
      if (name != null && !"".equals(name))
      {
         predicatesList.add(builder.like(root.<String> get("name"), '%' + name + '%'));
      }
      Venue venue = this.example.getVenue();
      if (venue != null)
      {
         predicatesList.add(builder.equal(root.get("venue"), venue));
      }
      String description = this.example.getDescription();
      if (description != null && !"".equals(description))
      {
         predicatesList.add(builder.like(root.<String> get("description"), '%' + description + '%'));
      }
      Category category = this.example.getCategory();
      if (category != null)
      {
         predicatesList.add(builder.equal(root.get("category"), category));
      }
      String schedule = this.example.getSchedule();
      if (schedule != null && !"".equals(schedule))
      {
         predicatesList.add(builder.like(root.<String> get("schedule"), '%' + schedule + '%'));
      }

      return predicatesList.toArray(new Predicate[predicatesList.size()]);
   }

   public List<Dinner> getPageItems()
   {
      return this.pageItems;
   }

   public long getCount()
   {
      return this.count;
   }

   /*
    * Support listing and POSTing back Dinner entities (e.g. from inside an
    * HtmlSelectOneMenu)
    */

   public List<Dinner> getAll()
   {

      CriteriaQuery<Dinner> criteria = this.entityManager
            .getCriteriaBuilder().createQuery(Dinner.class);
      return this.entityManager.createQuery(
            criteria.select(criteria.from(Dinner.class))).getResultList();
   }

   @Resource
   private SessionContext sessionContext;

   public Converter getConverter()
   {

      final DinnerBean ejbProxy = this.sessionContext.getBusinessObject(DinnerBean.class);

      return new Converter()
      {

         @Override
         public Object getAsObject(FacesContext context,
               UIComponent component, String value)
         {

            return ejbProxy.findById(Long.valueOf(value));
         }

         @Override
         public String getAsString(FacesContext context,
               UIComponent component, Object value)
         {

            if (value == null)
            {
               return "";
            }

            return String.valueOf(((Dinner) value).getId());
         }
      };
   }

   /*
    * Support adding children to bidirectional, one-to-many tables
    */

   private Dinner add = new Dinner();

   public Dinner getAdd()
   {
      return this.add;
   }

   public Dinner getAdded()
   {
      Dinner added = this.add;
      this.add = new Dinner();
      return added;
   }
}