package de.binaris.recipeadmin.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.ServingDirection;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedServingDirectionDTO implements Serializable
{

   private Long id;
   private String howToServe;

   public NestedServingDirectionDTO()
   {
   }

   public NestedServingDirectionDTO(final ServingDirection entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.howToServe = entity.getHowToServe();
      }
   }

   public ServingDirection fromDTO(ServingDirection entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ServingDirection();
      }
      if (this.id != null)
      {
         TypedQuery<ServingDirection> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT s FROM ServingDirection s WHERE s.id = :entityId",
                     ServingDirection.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setHowToServe(this.howToServe);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getHowToServe()
   {
      return this.howToServe;
   }

   public void setHowToServe(final String howToServe)
   {
      this.howToServe = howToServe;
   }
}