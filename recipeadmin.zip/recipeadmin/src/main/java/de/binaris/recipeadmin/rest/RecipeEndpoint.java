package de.binaris.recipeadmin.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.recipeadmin.model.Recipe;
import de.binaris.recipeadmin.rest.dto.RecipeDTO;

/**
 * 
 */
@Stateless
@Path("/recipes")
public class RecipeEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(RecipeDTO dto)
   {
      Recipe entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(RecipeEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Recipe entity = em.find(Recipe.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Recipe> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM Recipe r LEFT JOIN FETCH r.user LEFT JOIN FETCH r.category LEFT JOIN FETCH r.ingredient LEFT JOIN FETCH r.preparationDirection LEFT JOIN FETCH r.servingDirection WHERE r.id = :entityId ORDER BY r.id", Recipe.class);
      findByIdQuery.setParameter("entityId", id);
      Recipe entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      RecipeDTO dto = new RecipeDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<RecipeDTO> listAll()
   {
      final List<Recipe> searchResults = em.createQuery("SELECT DISTINCT r FROM Recipe r LEFT JOIN FETCH r.user LEFT JOIN FETCH r.category LEFT JOIN FETCH r.ingredient LEFT JOIN FETCH r.preparationDirection LEFT JOIN FETCH r.servingDirection ORDER BY r.id", Recipe.class).getResultList();
      final List<RecipeDTO> results = new ArrayList<RecipeDTO>();
      for (Recipe searchResult : searchResults)
      {
         RecipeDTO dto = new RecipeDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, RecipeDTO dto)
   {
      TypedQuery<Recipe> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM Recipe r LEFT JOIN FETCH r.user LEFT JOIN FETCH r.category LEFT JOIN FETCH r.ingredient LEFT JOIN FETCH r.preparationDirection LEFT JOIN FETCH r.servingDirection WHERE r.id = :entityId ORDER BY r.id", Recipe.class);
      findByIdQuery.setParameter("entityId", id);
      Recipe entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}