package de.binaris.recipeadmin.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>
 * An PreparationDirection may consist of one howToPrepare text.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "preparation_direction")
public class PreparationDirection implements Serializable {

	private static final long serialVersionUID = 1212121756789162315L;

	/**
	 * The ID of the PreparationDirection.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_preparation_direction")
	@SequenceGenerator(name = "my_entity_seq_gen_preparation_direction", sequenceName = "sequence_preparation_direction", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Recipe recipe;

	@NotNull
	@Size(min = 1, max = 300, message = "must be 1-300 letters and spaces")
	private String howToPrepare;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Recipe getRecipe() {
		return recipe;
	}

	public void setRecipe(Recipe recipe) {
		this.recipe = recipe;
	}

	public String getHowToPrepare() {
		return howToPrepare;
	}
	
	public void setHowToPrepare(String howToPrepare) {
		this.howToPrepare = howToPrepare;
	}
	
	/*
	 * toString(), equals() and hashCode() for PreparationDirection, using the natural
	 * identity of the object
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof PreparationDirection)) {
			return false;
		}
		PreparationDirection castOther = (PreparationDirection) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return howToPrepare;
	}
}
