
angular.module('appointmentplannerangularjs').controller('NewAvailabilityTypeController', function ($scope, $location, locationParser, AvailabilityTypeResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.availabilityType = $scope.availabilityType || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/AvailabilityTypes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AvailabilityTypeResource.save($scope.availabilityType, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/AvailabilityTypes");
    };
});