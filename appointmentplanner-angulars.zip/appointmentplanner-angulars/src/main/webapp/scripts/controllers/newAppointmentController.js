
angular.module('appointmentplannerangularjs').controller('NewAppointmentController', function ($scope, $location, locationParser, AppointmentResource , AppointmentCategoryResource, ParticipantListResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.appointment = $scope.appointment || {};
    
    $scope.appointmentCategoryList = AppointmentCategoryResource.queryAll(function(items){
        $scope.appointmentCategorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("appointmentCategorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.appointment.appointmentCategory = {};
            $scope.appointment.appointmentCategory.id = selection.value;
        }
    });
    
    $scope.participantListList = ParticipantListResource.queryAll(function(items){
        $scope.participantListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("participantListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.appointment.participantList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.participantList.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Appointments/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AppointmentResource.save($scope.appointment, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Appointments");
    };
});