
angular.module('appointmentplannerangularjs').controller('NewAppointmentCategoryController', function ($scope, $location, locationParser, AppointmentCategoryResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.appointmentCategory = $scope.appointmentCategory || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/AppointmentCategorys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AppointmentCategoryResource.save($scope.appointmentCategory, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/AppointmentCategorys");
    };
});