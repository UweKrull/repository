

angular.module('appointmentplannerangularjs').controller('SearchAvailabilityController', function($scope, $http, AvailabilityResource , GeneralAvailabilityResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource) {

    $scope.search={};
    $scope.currentPage = 0;
    $scope.pageSize= 10;
    $scope.searchResults = [];
    $scope.filteredResults = [];
    $scope.pageRange = [];
    $scope.numberOfPages = function() {
        var result = Math.ceil($scope.filteredResults.length/$scope.pageSize);
        var max = (result == 0) ? 1 : result;
        $scope.pageRange = [];
        for(var ctr=0;ctr<max;ctr++) {
            $scope.pageRange.push(ctr);
        }
        return max;
    };
    $scope.generalAvailabilityList = GeneralAvailabilityResource.queryAll();
    $scope.availabilityDay1List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay2List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay3List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay4List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay5List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay6List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay7List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay8List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay9List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay10List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay11List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay12List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay13List = AvailabilityTypeResource.queryAll();
    $scope.availabilityDay14List = AvailabilityTypeResource.queryAll();

    $scope.performSearch = function() {
        $scope.searchResults = AvailabilityResource.queryAll(function(){
            $scope.numberOfPages();
        });
    };
    
    $scope.previous = function() {
       if($scope.currentPage > 0) {
           $scope.currentPage--;
       }
    };
    
    $scope.next = function() {
       if($scope.currentPage < ($scope.numberOfPages() - 1) ) {
           $scope.currentPage++;
       }
    };
    
    $scope.setPage = function(n) {
       $scope.currentPage = n;
    };

    $scope.performSearch();
});