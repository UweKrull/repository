
angular.module('appointmentplannerangularjs').controller('NewAvailabilityController', function ($scope, $location, locationParser, AvailabilityResource , GeneralAvailabilityResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.availability = $scope.availability || {};
    
    $scope.generalAvailabilityList = GeneralAvailabilityResource.queryAll(function(items){
        $scope.generalAvailabilitySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("generalAvailabilitySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.generalAvailability = {};
            $scope.availability.generalAvailability.id = selection.value;
        }
    });
    
    $scope.availabilityDay1List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay1SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay1Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay1 = {};
            $scope.availability.availabilityDay1.id = selection.value;
        }
    });
    
    $scope.availabilityDay2List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay2SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay2Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay2 = {};
            $scope.availability.availabilityDay2.id = selection.value;
        }
    });
    
    $scope.availabilityDay3List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay3SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay3Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay3 = {};
            $scope.availability.availabilityDay3.id = selection.value;
        }
    });
    
    $scope.availabilityDay4List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay4SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay4Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay4 = {};
            $scope.availability.availabilityDay4.id = selection.value;
        }
    });
    
    $scope.availabilityDay5List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay5SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay5Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay5 = {};
            $scope.availability.availabilityDay5.id = selection.value;
        }
    });
    
    $scope.availabilityDay6List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay6SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay6Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay6 = {};
            $scope.availability.availabilityDay6.id = selection.value;
        }
    });
    
    $scope.availabilityDay7List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay7SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay7Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay7 = {};
            $scope.availability.availabilityDay7.id = selection.value;
        }
    });
    
    $scope.availabilityDay8List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay8SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay8Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay8 = {};
            $scope.availability.availabilityDay8.id = selection.value;
        }
    });
    
    $scope.availabilityDay9List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay9SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay9Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay9 = {};
            $scope.availability.availabilityDay9.id = selection.value;
        }
    });
    
    $scope.availabilityDay10List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay10SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay10Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay10 = {};
            $scope.availability.availabilityDay10.id = selection.value;
        }
    });
    
    $scope.availabilityDay11List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay11SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay11Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay11 = {};
            $scope.availability.availabilityDay11.id = selection.value;
        }
    });
    
    $scope.availabilityDay12List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay12SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay12Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay12 = {};
            $scope.availability.availabilityDay12.id = selection.value;
        }
    });
    
    $scope.availabilityDay13List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay13SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay13Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay13 = {};
            $scope.availability.availabilityDay13.id = selection.value;
        }
    });
    
    $scope.availabilityDay14List = AvailabilityTypeResource.queryAll(function(items){
        $scope.availabilityDay14SelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("availabilityDay14Selection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availability.availabilityDay14 = {};
            $scope.availability.availabilityDay14.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Availabilitys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AvailabilityResource.save($scope.availability, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Availabilitys");
    };
});