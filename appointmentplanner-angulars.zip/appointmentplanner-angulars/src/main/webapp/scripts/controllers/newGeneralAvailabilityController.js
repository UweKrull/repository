
angular.module('appointmentplannerangularjs').controller('NewGeneralAvailabilityController', function ($scope, $location, locationParser, GeneralAvailabilityResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.generalAvailability = $scope.generalAvailability || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/GeneralAvailabilitys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        GeneralAvailabilityResource.save($scope.generalAvailability, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/GeneralAvailabilitys");
    };
});