
angular.module('appointmentplannerangularjs').controller('NewParticipantListController', function ($scope, $location, locationParser, ParticipantListResource , AppointmentResource, ParticipantResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.participantList = $scope.participantList || {};
    
    $scope.appointmentList = AppointmentResource.queryAll(function(items){
        $scope.appointmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.timeRangeAsString
            });
        });
    });
    $scope.$watch("appointmentSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.participantList.appointment = {};
            $scope.participantList.appointment.id = selection.value;
        }
    });
    
    $scope.participantsList = ParticipantResource.queryAll(function(items){
        $scope.participantsSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.aliasName
            });
        });
    });
    $scope.$watch("participantsSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.participantList.participants = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.participantList.participants.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/ParticipantLists/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ParticipantListResource.save($scope.participantList, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/ParticipantLists");
    };
});