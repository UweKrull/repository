

angular.module('appointmentplannerangularjs').controller('EditAppointmentController', function($scope, $routeParams, $location, AppointmentResource , AppointmentCategoryResource, ParticipantListResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.appointment = new AppointmentResource(self.original);
            AppointmentCategoryResource.queryAll(function(items) {
                $scope.appointmentCategorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.appointment.appointmentCategory && item.id == $scope.appointment.appointmentCategory.id) {
                        $scope.appointmentCategorySelection = labelObject;
                        $scope.appointment.appointmentCategory = wrappedObject;
                        self.original.appointmentCategory = $scope.appointment.appointmentCategory;
                    }
                    return labelObject;
                });
            });
            ParticipantListResource.queryAll(function(items) {
                $scope.participantListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.appointment.participantList){
                        $.each($scope.appointment.participantList, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.participantListSelection.push(labelObject);
                                $scope.appointment.participantList.push(wrappedObject);
                            }
                        });
                        self.original.participantList = $scope.appointment.participantList;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Appointments");
        };
        AppointmentResource.get({AppointmentId:$routeParams.AppointmentId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.appointment);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.appointment.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Appointments");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Appointments");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.appointment.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("appointmentCategorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.appointment.appointmentCategory = {};
            $scope.appointment.appointmentCategory.id = selection.value;
        }
    });
    $scope.participantListSelection = $scope.participantListSelection || [];
    $scope.$watch("participantListSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.appointment) {
            $scope.appointment.participantList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.participantList.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});