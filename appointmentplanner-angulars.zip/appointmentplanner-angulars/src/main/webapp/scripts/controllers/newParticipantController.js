
angular.module('appointmentplannerangularjs').controller('NewParticipantController', function ($scope, $location, locationParser, ParticipantResource , ParticipantListResource, AvailabilityResource, CustomerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.participant = $scope.participant || {};
    
    $scope.participantListList = ParticipantListResource.queryAll(function(items){
        $scope.participantListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("participantListSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.participant.participantList = {};
            $scope.participant.participantList.id = selection.value;
        }
    });
    
    $scope.availabilityList = AvailabilityResource.queryAll(function(items){
        $scope.availabilitySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : (new Date(item.startDateTime)).toISOString().replace('T',' ').replace('.000Z','')+" - "+(new Date(item.endDateTime)).toISOString().replace('T',' ').replace('.000Z','')
            });
        });
    });
    $scope.$watch("availabilitySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.participant.availability = {};
            $scope.participant.availability.id = selection.value;
        }
    });
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.participant.customer = {};
            $scope.participant.customer.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Participants/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ParticipantResource.save($scope.participant, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Participants");
    };
});