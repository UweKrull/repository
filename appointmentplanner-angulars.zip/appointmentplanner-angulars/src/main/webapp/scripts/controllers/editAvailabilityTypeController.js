

angular.module('appointmentplannerangularjs').controller('EditAvailabilityTypeController', function($scope, $routeParams, $location, AvailabilityTypeResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.availabilityType = new AvailabilityTypeResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/AvailabilityTypes");
        };
        AvailabilityTypeResource.get({AvailabilityTypeId:$routeParams.AvailabilityTypeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.availabilityType);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.availabilityType.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/AvailabilityTypes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/AvailabilityTypes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.availabilityType.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});