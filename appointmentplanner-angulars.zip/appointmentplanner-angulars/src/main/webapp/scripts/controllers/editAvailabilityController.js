

angular.module('appointmentplannerangularjs').controller('EditAvailabilityController', function($scope, $routeParams, $location, AvailabilityResource , GeneralAvailabilityResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource, AvailabilityTypeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.availability = new AvailabilityResource(self.original);
            GeneralAvailabilityResource.queryAll(function(items) {
                $scope.generalAvailabilitySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.generalAvailability && item.id == $scope.availability.generalAvailability.id) {
                        $scope.generalAvailabilitySelection = labelObject;
                        $scope.availability.generalAvailability = wrappedObject;
                        self.original.generalAvailability = $scope.availability.generalAvailability;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay1SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay1 && item.id == $scope.availability.availabilityDay1.id) {
                        $scope.availabilityDay1Selection = labelObject;
                        $scope.availability.availabilityDay1 = wrappedObject;
                        self.original.availabilityDay1 = $scope.availability.availabilityDay1;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay2SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay2 && item.id == $scope.availability.availabilityDay2.id) {
                        $scope.availabilityDay2Selection = labelObject;
                        $scope.availability.availabilityDay2 = wrappedObject;
                        self.original.availabilityDay2 = $scope.availability.availabilityDay2;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay3SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay3 && item.id == $scope.availability.availabilityDay3.id) {
                        $scope.availabilityDay3Selection = labelObject;
                        $scope.availability.availabilityDay3 = wrappedObject;
                        self.original.availabilityDay3 = $scope.availability.availabilityDay3;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay4SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay4 && item.id == $scope.availability.availabilityDay4.id) {
                        $scope.availabilityDay4Selection = labelObject;
                        $scope.availability.availabilityDay4 = wrappedObject;
                        self.original.availabilityDay4 = $scope.availability.availabilityDay4;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay5SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay5 && item.id == $scope.availability.availabilityDay5.id) {
                        $scope.availabilityDay5Selection = labelObject;
                        $scope.availability.availabilityDay5 = wrappedObject;
                        self.original.availabilityDay5 = $scope.availability.availabilityDay5;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay6SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay6 && item.id == $scope.availability.availabilityDay6.id) {
                        $scope.availabilityDay6Selection = labelObject;
                        $scope.availability.availabilityDay6 = wrappedObject;
                        self.original.availabilityDay6 = $scope.availability.availabilityDay6;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay7SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay7 && item.id == $scope.availability.availabilityDay7.id) {
                        $scope.availabilityDay7Selection = labelObject;
                        $scope.availability.availabilityDay7 = wrappedObject;
                        self.original.availabilityDay7 = $scope.availability.availabilityDay7;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay8SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay8 && item.id == $scope.availability.availabilityDay8.id) {
                        $scope.availabilityDay8Selection = labelObject;
                        $scope.availability.availabilityDay8 = wrappedObject;
                        self.original.availabilityDay8 = $scope.availability.availabilityDay8;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay9SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay9 && item.id == $scope.availability.availabilityDay9.id) {
                        $scope.availabilityDay9Selection = labelObject;
                        $scope.availability.availabilityDay9 = wrappedObject;
                        self.original.availabilityDay9 = $scope.availability.availabilityDay9;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay10SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay10 && item.id == $scope.availability.availabilityDay10.id) {
                        $scope.availabilityDay10Selection = labelObject;
                        $scope.availability.availabilityDay10 = wrappedObject;
                        self.original.availabilityDay10 = $scope.availability.availabilityDay10;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay11SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay11 && item.id == $scope.availability.availabilityDay11.id) {
                        $scope.availabilityDay11Selection = labelObject;
                        $scope.availability.availabilityDay11 = wrappedObject;
                        self.original.availabilityDay11 = $scope.availability.availabilityDay11;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay12SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay12 && item.id == $scope.availability.availabilityDay12.id) {
                        $scope.availabilityDay12Selection = labelObject;
                        $scope.availability.availabilityDay12 = wrappedObject;
                        self.original.availabilityDay12 = $scope.availability.availabilityDay12;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay13SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay13 && item.id == $scope.availability.availabilityDay13.id) {
                        $scope.availabilityDay13Selection = labelObject;
                        $scope.availability.availabilityDay13 = wrappedObject;
                        self.original.availabilityDay13 = $scope.availability.availabilityDay13;
                    }
                    return labelObject;
                });
            });
            AvailabilityTypeResource.queryAll(function(items) {
                $scope.availabilityDay14SelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availability.availabilityDay14 && item.id == $scope.availability.availabilityDay14.id) {
                        $scope.availabilityDay14Selection = labelObject;
                        $scope.availability.availabilityDay14 = wrappedObject;
                        self.original.availabilityDay14 = $scope.availability.availabilityDay14;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Availabilitys");
        };
        AvailabilityResource.get({AvailabilityId:$routeParams.AvailabilityId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.availability);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.availability.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Availabilitys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Availabilitys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.availability.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("generalAvailabilitySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.generalAvailability = {};
            $scope.availability.generalAvailability.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay1Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay1 = {};
            $scope.availability.availabilityDay1.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay2Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay2 = {};
            $scope.availability.availabilityDay2.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay3Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay3 = {};
            $scope.availability.availabilityDay3.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay4Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay4 = {};
            $scope.availability.availabilityDay4.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay5Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay5 = {};
            $scope.availability.availabilityDay5.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay6Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay6 = {};
            $scope.availability.availabilityDay6.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay7Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay7 = {};
            $scope.availability.availabilityDay7.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay8Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay8 = {};
            $scope.availability.availabilityDay8.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay9Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay9 = {};
            $scope.availability.availabilityDay9.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay10Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay10 = {};
            $scope.availability.availabilityDay10.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay11Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay11 = {};
            $scope.availability.availabilityDay11.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay12Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay12 = {};
            $scope.availability.availabilityDay12.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay13Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay13 = {};
            $scope.availability.availabilityDay13.id = selection.value;
        }
    });
    $scope.$watch("availabilityDay14Selection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availability.availabilityDay14 = {};
            $scope.availability.availabilityDay14.id = selection.value;
        }
    });
    
    $scope.get();
});