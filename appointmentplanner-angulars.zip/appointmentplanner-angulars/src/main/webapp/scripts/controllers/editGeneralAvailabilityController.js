

angular.module('appointmentplannerangularjs').controller('EditGeneralAvailabilityController', function($scope, $routeParams, $location, GeneralAvailabilityResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.generalAvailability = new GeneralAvailabilityResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/GeneralAvailabilitys");
        };
        GeneralAvailabilityResource.get({GeneralAvailabilityId:$routeParams.GeneralAvailabilityId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.generalAvailability);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.generalAvailability.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/GeneralAvailabilitys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/GeneralAvailabilitys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.generalAvailability.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});