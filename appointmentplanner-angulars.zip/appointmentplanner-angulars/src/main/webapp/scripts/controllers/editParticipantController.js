

angular.module('appointmentplannerangularjs').controller('EditParticipantController', function($scope, $routeParams, $location, ParticipantResource , ParticipantListResource, AvailabilityResource, CustomerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.participant = new ParticipantResource(self.original);
            ParticipantListResource.queryAll(function(items) {
                $scope.participantListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.participant.participantList && item.id == $scope.participant.participantList.id) {
                        $scope.participantListSelection = labelObject;
                        $scope.participant.participantList = wrappedObject;
                        self.original.participantList = $scope.participant.participantList;
                    }
                    return labelObject;
                });
            });
            AvailabilityResource.queryAll(function(items) {
                $scope.availabilitySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : (new Date(item.startDateTime)).toISOString().replace('T',' ').replace('.000Z','')+" - "+(new Date(item.endDateTime)).toISOString().replace('T',' ').replace('.000Z','')
                    };
                    if($scope.participant.availability && item.id == $scope.participant.availability.id) {
                        $scope.availabilitySelection = labelObject;
                        $scope.participant.availability = wrappedObject;
                        self.original.availability = $scope.participant.availability;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.participant.customer && item.id == $scope.participant.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.participant.customer = wrappedObject;
                        self.original.customer = $scope.participant.customer;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Participants");
        };
        ParticipantResource.get({ParticipantId:$routeParams.ParticipantId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.participant);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.participant.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Participants");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Participants");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.participant.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("participantListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.participant.participantList = {};
            $scope.participant.participantList.id = selection.value;
        }
    });
    $scope.$watch("availabilitySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.participant.availability = {};
            $scope.participant.availability.id = selection.value;
        }
    });
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.participant.customer = {};
            $scope.participant.customer.id = selection.value;
        }
    });
    
    $scope.get();
});