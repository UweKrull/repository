

angular.module('appointmentplannerangularjs').controller('EditAppointmentCategoryController', function($scope, $routeParams, $location, AppointmentCategoryResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.appointmentCategory = new AppointmentCategoryResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/AppointmentCategorys");
        };
        AppointmentCategoryResource.get({AppointmentCategoryId:$routeParams.AppointmentCategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.appointmentCategory);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.appointmentCategory.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/AppointmentCategorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/AppointmentCategorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.appointmentCategory.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});