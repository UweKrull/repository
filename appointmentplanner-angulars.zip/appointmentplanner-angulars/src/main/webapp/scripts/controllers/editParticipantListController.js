

angular.module('appointmentplannerangularjs').controller('EditParticipantListController', function($scope, $routeParams, $location, ParticipantListResource , AppointmentResource, ParticipantResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.participantList = new ParticipantListResource(self.original);
            AppointmentResource.queryAll(function(items) {
                $scope.appointmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.timeRangeAsString
                    };
                    if($scope.participantList.appointment && item.id == $scope.participantList.appointment.id) {
                        $scope.appointmentSelection = labelObject;
                        $scope.participantList.appointment = wrappedObject;
                        self.original.appointment = $scope.participantList.appointment;
                    }
                    return labelObject;
                });
            });
            ParticipantResource.queryAll(function(items) {
                $scope.participantsSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.aliasName
                    };
                    if($scope.participantList.participants){
                        $.each($scope.participantList.participants, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.participantsSelection.push(labelObject);
                                $scope.participantList.participants.push(wrappedObject);
                            }
                        });
                        self.original.participants = $scope.participantList.participants;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/ParticipantLists");
        };
        ParticipantListResource.get({ParticipantListId:$routeParams.ParticipantListId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.participantList);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.participantList.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/ParticipantLists");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/ParticipantLists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.participantList.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.participantList.appointment = {};
            $scope.participantList.appointment.id = selection.value;
        }
    });
    $scope.participantsSelection = $scope.participantsSelection || [];
    $scope.$watch("participantsSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.participantList) {
            $scope.participantList.participants = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.participantList.participants.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});