angular.module('appointmentplannerangularjs').factory('ParticipantListResource', function($resource){
    var resource = $resource('rest/participantlists/:ParticipantListId',{ParticipantListId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});