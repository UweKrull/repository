angular.module('appointmentplannerangularjs').factory('ParticipantResource', function($resource){
    var resource = $resource('rest/participants/:ParticipantId',{ParticipantId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});