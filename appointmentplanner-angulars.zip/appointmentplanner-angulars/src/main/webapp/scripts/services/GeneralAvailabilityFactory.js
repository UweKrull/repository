angular.module('appointmentplannerangularjs').factory('GeneralAvailabilityResource', function($resource){
    var resource = $resource('rest/generalavailabilitys/:GeneralAvailabilityId',{GeneralAvailabilityId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});