angular.module('appointmentplannerangularjs').factory('AvailabilityTypeResource', function($resource){
    var resource = $resource('rest/availabilitytypes/:AvailabilityTypeId',{AvailabilityTypeId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});