'use strict';

angular.module('appointmentplannerangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Appointments',{templateUrl:'views/Appointment/search.html',controller:'SearchAppointmentController'})
      .when('/Appointments/new',{templateUrl:'views/Appointment/detail.html',controller:'NewAppointmentController'})
      .when('/Appointments/edit/:AppointmentId',{templateUrl:'views/Appointment/detail.html',controller:'EditAppointmentController'})
      .when('/AppointmentCategorys',{templateUrl:'views/AppointmentCategory/search.html',controller:'SearchAppointmentCategoryController'})
      .when('/AppointmentCategorys/new',{templateUrl:'views/AppointmentCategory/detail.html',controller:'NewAppointmentCategoryController'})
      .when('/AppointmentCategorys/edit/:AppointmentCategoryId',{templateUrl:'views/AppointmentCategory/detail.html',controller:'EditAppointmentCategoryController'})
      .when('/Availabilitys',{templateUrl:'views/Availability/search.html',controller:'SearchAvailabilityController'})
      .when('/Availabilitys/new',{templateUrl:'views/Availability/detail.html',controller:'NewAvailabilityController'})
      .when('/Availabilitys/edit/:AvailabilityId',{templateUrl:'views/Availability/detail.html',controller:'EditAvailabilityController'})
      .when('/AvailabilityTypes',{templateUrl:'views/AvailabilityType/search.html',controller:'SearchAvailabilityTypeController'})
      .when('/AvailabilityTypes/new',{templateUrl:'views/AvailabilityType/detail.html',controller:'NewAvailabilityTypeController'})
      .when('/AvailabilityTypes/edit/:AvailabilityTypeId',{templateUrl:'views/AvailabilityType/detail.html',controller:'EditAvailabilityTypeController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Customers',{templateUrl:'views/Customer/search.html',controller:'SearchCustomerController'})
      .when('/Customers/new',{templateUrl:'views/Customer/detail.html',controller:'NewCustomerController'})
      .when('/Customers/edit/:CustomerId',{templateUrl:'views/Customer/detail.html',controller:'EditCustomerController'})
      .when('/GeneralAvailabilitys',{templateUrl:'views/GeneralAvailability/search.html',controller:'SearchGeneralAvailabilityController'})
      .when('/GeneralAvailabilitys/new',{templateUrl:'views/GeneralAvailability/detail.html',controller:'NewGeneralAvailabilityController'})
      .when('/GeneralAvailabilitys/edit/:GeneralAvailabilityId',{templateUrl:'views/GeneralAvailability/detail.html',controller:'EditGeneralAvailabilityController'})
      .when('/Participants',{templateUrl:'views/Participant/search.html',controller:'SearchParticipantController'})
      .when('/Participants/new',{templateUrl:'views/Participant/detail.html',controller:'NewParticipantController'})
      .when('/Participants/edit/:ParticipantId',{templateUrl:'views/Participant/detail.html',controller:'EditParticipantController'})
      .when('/ParticipantLists',{templateUrl:'views/ParticipantList/search.html',controller:'SearchParticipantListController'})
      .when('/ParticipantLists/new',{templateUrl:'views/ParticipantList/detail.html',controller:'NewParticipantListController'})
      .when('/ParticipantLists/edit/:ParticipantListId',{templateUrl:'views/ParticipantList/detail.html',controller:'EditParticipantListController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
