package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;

import de.binaris.appointmentplanner.model.Availability;
import de.binaris.appointmentplanner.rest.dto.NestedAvailabilityTypeDTO;
import de.binaris.appointmentplanner.rest.dto.NestedGeneralAvailabilityDTO;

import javax.persistence.EntityManager;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AvailabilityDTO implements Serializable
{

   private Date startDateTime;
   private NestedAvailabilityTypeDTO availabilityDay14;
   private NestedAvailabilityTypeDTO availabilityDay12;
   private NestedAvailabilityTypeDTO availabilityDay13;
   private Date endDateTime;
   private NestedAvailabilityTypeDTO availabilityDay10;
   private NestedAvailabilityTypeDTO availabilityDay11;
   private Long id;
   private NestedAvailabilityTypeDTO availabilityDay6;
   private NestedAvailabilityTypeDTO availabilityDay5;
   private NestedAvailabilityTypeDTO availabilityDay8;
   private NestedAvailabilityTypeDTO availabilityDay7;
   private NestedAvailabilityTypeDTO availabilityDay2;
   private NestedAvailabilityTypeDTO availabilityDay1;
   private NestedAvailabilityTypeDTO availabilityDay4;
   private NestedAvailabilityTypeDTO availabilityDay3;
   private NestedGeneralAvailabilityDTO generalAvailability;
   private NestedAvailabilityTypeDTO availabilityDay9;

   public AvailabilityDTO()
   {
   }

   public AvailabilityDTO(final Availability entity)
   {
      if (entity != null)
      {
         this.startDateTime = entity.getStartDateTime();
         this.availabilityDay14 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay14());
         this.availabilityDay12 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay12());
         this.availabilityDay13 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay13());
         this.endDateTime = entity.getEndDateTime();
         this.availabilityDay10 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay10());
         this.availabilityDay11 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay11());
         this.id = entity.getId();
         this.availabilityDay6 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay6());
         this.availabilityDay5 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay5());
         this.availabilityDay8 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay8());
         this.availabilityDay7 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay7());
         this.availabilityDay2 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay2());
         this.availabilityDay1 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay1());
         this.availabilityDay4 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay4());
         this.availabilityDay3 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay3());
         this.generalAvailability = new NestedGeneralAvailabilityDTO(
               entity.getGeneralAvailability());
         this.availabilityDay9 = new NestedAvailabilityTypeDTO(
               entity.getAvailabilityDay9());
      }
   }

   public Availability fromDTO(Availability entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Availability();
      }
      entity.setStartDateTime(this.startDateTime);
      if (this.availabilityDay14 != null)
      {
         entity.setAvailabilityDay14(this.availabilityDay14.fromDTO(
               entity.getAvailabilityDay14(), em));
      }
      if (this.availabilityDay12 != null)
      {
         entity.setAvailabilityDay12(this.availabilityDay12.fromDTO(
               entity.getAvailabilityDay12(), em));
      }
      if (this.availabilityDay13 != null)
      {
         entity.setAvailabilityDay13(this.availabilityDay13.fromDTO(
               entity.getAvailabilityDay13(), em));
      }
      entity.setEndDateTime(this.endDateTime);
      if (this.availabilityDay10 != null)
      {
         entity.setAvailabilityDay10(this.availabilityDay10.fromDTO(
               entity.getAvailabilityDay10(), em));
      }
      if (this.availabilityDay11 != null)
      {
         entity.setAvailabilityDay11(this.availabilityDay11.fromDTO(
               entity.getAvailabilityDay11(), em));
      }
      if (this.availabilityDay6 != null)
      {
         entity.setAvailabilityDay6(this.availabilityDay6.fromDTO(
               entity.getAvailabilityDay6(), em));
      }
      if (this.availabilityDay5 != null)
      {
         entity.setAvailabilityDay5(this.availabilityDay5.fromDTO(
               entity.getAvailabilityDay5(), em));
      }
      if (this.availabilityDay8 != null)
      {
         entity.setAvailabilityDay8(this.availabilityDay8.fromDTO(
               entity.getAvailabilityDay8(), em));
      }
      if (this.availabilityDay7 != null)
      {
         entity.setAvailabilityDay7(this.availabilityDay7.fromDTO(
               entity.getAvailabilityDay7(), em));
      }
      if (this.availabilityDay2 != null)
      {
         entity.setAvailabilityDay2(this.availabilityDay2.fromDTO(
               entity.getAvailabilityDay2(), em));
      }
      if (this.availabilityDay1 != null)
      {
         entity.setAvailabilityDay1(this.availabilityDay1.fromDTO(
               entity.getAvailabilityDay1(), em));
      }
      if (this.availabilityDay4 != null)
      {
         entity.setAvailabilityDay4(this.availabilityDay4.fromDTO(
               entity.getAvailabilityDay4(), em));
      }
      if (this.availabilityDay3 != null)
      {
         entity.setAvailabilityDay3(this.availabilityDay3.fromDTO(
               entity.getAvailabilityDay3(), em));
      }
      if (this.generalAvailability != null)
      {
         entity.setGeneralAvailability(this.generalAvailability.fromDTO(
               entity.getGeneralAvailability(), em));
      }
      if (this.availabilityDay9 != null)
      {
         entity.setAvailabilityDay9(this.availabilityDay9.fromDTO(
               entity.getAvailabilityDay9(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartDateTime()
   {
      return this.startDateTime;
   }

   public void setStartDateTime(final Date startDateTime)
   {
      this.startDateTime = startDateTime;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay14()
   {
      return this.availabilityDay14;
   }

   public void setAvailabilityDay14(
         final NestedAvailabilityTypeDTO availabilityDay14)
   {
      this.availabilityDay14 = availabilityDay14;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay12()
   {
      return this.availabilityDay12;
   }

   public void setAvailabilityDay12(
         final NestedAvailabilityTypeDTO availabilityDay12)
   {
      this.availabilityDay12 = availabilityDay12;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay13()
   {
      return this.availabilityDay13;
   }

   public void setAvailabilityDay13(
         final NestedAvailabilityTypeDTO availabilityDay13)
   {
      this.availabilityDay13 = availabilityDay13;
   }

   public Date getEndDateTime()
   {
      return this.endDateTime;
   }

   public void setEndDateTime(final Date endDateTime)
   {
      this.endDateTime = endDateTime;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay10()
   {
      return this.availabilityDay10;
   }

   public void setAvailabilityDay10(
         final NestedAvailabilityTypeDTO availabilityDay10)
   {
      this.availabilityDay10 = availabilityDay10;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay11()
   {
      return this.availabilityDay11;
   }

   public void setAvailabilityDay11(
         final NestedAvailabilityTypeDTO availabilityDay11)
   {
      this.availabilityDay11 = availabilityDay11;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay6()
   {
      return this.availabilityDay6;
   }

   public void setAvailabilityDay6(
         final NestedAvailabilityTypeDTO availabilityDay6)
   {
      this.availabilityDay6 = availabilityDay6;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay5()
   {
      return this.availabilityDay5;
   }

   public void setAvailabilityDay5(
         final NestedAvailabilityTypeDTO availabilityDay5)
   {
      this.availabilityDay5 = availabilityDay5;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay8()
   {
      return this.availabilityDay8;
   }

   public void setAvailabilityDay8(
         final NestedAvailabilityTypeDTO availabilityDay8)
   {
      this.availabilityDay8 = availabilityDay8;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay7()
   {
      return this.availabilityDay7;
   }

   public void setAvailabilityDay7(
         final NestedAvailabilityTypeDTO availabilityDay7)
   {
      this.availabilityDay7 = availabilityDay7;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay2()
   {
      return this.availabilityDay2;
   }

   public void setAvailabilityDay2(
         final NestedAvailabilityTypeDTO availabilityDay2)
   {
      this.availabilityDay2 = availabilityDay2;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay1()
   {
      return this.availabilityDay1;
   }

   public void setAvailabilityDay1(
         final NestedAvailabilityTypeDTO availabilityDay1)
   {
      this.availabilityDay1 = availabilityDay1;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay4()
   {
      return this.availabilityDay4;
   }

   public void setAvailabilityDay4(
         final NestedAvailabilityTypeDTO availabilityDay4)
   {
      this.availabilityDay4 = availabilityDay4;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay3()
   {
      return this.availabilityDay3;
   }

   public void setAvailabilityDay3(
         final NestedAvailabilityTypeDTO availabilityDay3)
   {
      this.availabilityDay3 = availabilityDay3;
   }

   public NestedGeneralAvailabilityDTO getGeneralAvailability()
   {
      return this.generalAvailability;
   }

   public void setGeneralAvailability(
         final NestedGeneralAvailabilityDTO generalAvailability)
   {
      this.generalAvailability = generalAvailability;
   }

   public NestedAvailabilityTypeDTO getAvailabilityDay9()
   {
      return this.availabilityDay9;
   }

   public void setAvailabilityDay9(
         final NestedAvailabilityTypeDTO availabilityDay9)
   {
      this.availabilityDay9 = availabilityDay9;
   }
}