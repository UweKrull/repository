package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;

import de.binaris.appointmentplanner.model.Appointment;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.appointmentplanner.model.ParticipantList;
import de.binaris.appointmentplanner.rest.dto.NestedAppointmentCategoryDTO;
import de.binaris.appointmentplanner.rest.dto.NestedParticipantListDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AppointmentDTO implements Serializable
{

   private Long id;
   private String timeRangeAsString;
   private Set<NestedParticipantListDTO> participantList = new HashSet<NestedParticipantListDTO>();
   private NestedAppointmentCategoryDTO appointmentCategory;
   private String name;

   public AppointmentDTO()
   {
   }

   public AppointmentDTO(final Appointment entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.timeRangeAsString = entity.getTimeRangeAsString();
         Iterator<ParticipantList> iterParticipantList = entity
               .getParticipantList().iterator();
         for (; iterParticipantList.hasNext();)
         {
            ParticipantList element = iterParticipantList.next();
            this.participantList.add(new NestedParticipantListDTO(element));
         }
         this.appointmentCategory = new NestedAppointmentCategoryDTO(
               entity.getAppointmentCategory());
         this.name = entity.getName();
      }
   }

   public Appointment fromDTO(Appointment entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Appointment();
      }
      entity.setTimeRangeAsString(this.timeRangeAsString);
      Iterator<ParticipantList> iterParticipantList = entity
            .getParticipantList().iterator();
      for (; iterParticipantList.hasNext();)
      {
         boolean found = false;
         ParticipantList participantList = iterParticipantList.next();
         Iterator<NestedParticipantListDTO> iterDtoParticipantList = this
               .getParticipantList().iterator();
         for (; iterDtoParticipantList.hasNext();)
         {
            NestedParticipantListDTO dtoParticipantList = iterDtoParticipantList
                  .next();
            if (dtoParticipantList.getId().equals(participantList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterParticipantList.remove();
         }
      }
      Iterator<NestedParticipantListDTO> iterDtoParticipantList = this
            .getParticipantList().iterator();
      for (; iterDtoParticipantList.hasNext();)
      {
         boolean found = false;
         NestedParticipantListDTO dtoParticipantList = iterDtoParticipantList
               .next();
         iterParticipantList = entity.getParticipantList().iterator();
         for (; iterParticipantList.hasNext();)
         {
            ParticipantList participantList = iterParticipantList.next();
            if (dtoParticipantList.getId().equals(participantList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<ParticipantList> resultIter = em
                  .createQuery(
                        "SELECT DISTINCT p FROM ParticipantList p",
                        ParticipantList.class).getResultList()
                  .iterator();
            for (; resultIter.hasNext();)
            {
               ParticipantList result = resultIter.next();
               if (result.getId().equals(dtoParticipantList.getId()))
               {
                  entity.getParticipantList().add(result);
                  break;
               }
            }
         }
      }
      if (this.appointmentCategory != null)
      {
         entity.setAppointmentCategory(this.appointmentCategory.fromDTO(
               entity.getAppointmentCategory(), em));
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTimeRangeAsString()
   {
      return this.timeRangeAsString;
   }

   public void setTimeRangeAsString(final String timeRangeAsString)
   {
      this.timeRangeAsString = timeRangeAsString;
   }

   public Set<NestedParticipantListDTO> getParticipantList()
   {
      return this.participantList;
   }

   public void setParticipantList(
         final Set<NestedParticipantListDTO> participantList)
   {
      this.participantList = participantList;
   }

   public NestedAppointmentCategoryDTO getAppointmentCategory()
   {
      return this.appointmentCategory;
   }

   public void setAppointmentCategory(
         final NestedAppointmentCategoryDTO appointmentCategory)
   {
      this.appointmentCategory = appointmentCategory;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}