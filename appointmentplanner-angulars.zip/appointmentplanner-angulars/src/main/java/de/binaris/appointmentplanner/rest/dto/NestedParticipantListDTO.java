package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;
import de.binaris.appointmentplanner.model.ParticipantList;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedParticipantListDTO implements Serializable
{

   private Long id;
   private String name;

   public NestedParticipantListDTO()
   {
   }

   public NestedParticipantListDTO(final ParticipantList entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public ParticipantList fromDTO(ParticipantList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ParticipantList();
      }
      if (this.id != null)
      {
         TypedQuery<ParticipantList> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT p FROM ParticipantList p WHERE p.id = :entityId",
                     ParticipantList.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}