package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;

import de.binaris.appointmentplanner.model.ParticipantList;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.appointmentplanner.model.Participant;
import de.binaris.appointmentplanner.rest.dto.NestedAppointmentDTO;
import de.binaris.appointmentplanner.rest.dto.NestedParticipantDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ParticipantListDTO implements Serializable
{

   private Long id;
   private String name;
   private Set<NestedParticipantDTO> participants = new HashSet<NestedParticipantDTO>();
   private NestedAppointmentDTO appointment;

   public ParticipantListDTO()
   {
   }

   public ParticipantListDTO(final ParticipantList entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
         Iterator<Participant> iterParticipants = entity.getParticipants()
               .iterator();
         for (; iterParticipants.hasNext();)
         {
            Participant element = iterParticipants.next();
            this.participants.add(new NestedParticipantDTO(element));
         }
         this.appointment = new NestedAppointmentDTO(entity.getAppointment());
      }
   }

   public ParticipantList fromDTO(ParticipantList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ParticipantList();
      }
      entity.setName(this.name);
      Iterator<Participant> iterParticipants = entity.getParticipants()
            .iterator();
      for (; iterParticipants.hasNext();)
      {
         boolean found = false;
         Participant participant = iterParticipants.next();
         Iterator<NestedParticipantDTO> iterDtoParticipants = this
               .getParticipants().iterator();
         for (; iterDtoParticipants.hasNext();)
         {
            NestedParticipantDTO dtoParticipant = iterDtoParticipants
                  .next();
            if (dtoParticipant.getId().equals(participant.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterParticipants.remove();
         }
      }
      Iterator<NestedParticipantDTO> iterDtoParticipants = this
            .getParticipants().iterator();
      for (; iterDtoParticipants.hasNext();)
      {
         boolean found = false;
         NestedParticipantDTO dtoParticipant = iterDtoParticipants.next();
         iterParticipants = entity.getParticipants().iterator();
         for (; iterParticipants.hasNext();)
         {
            Participant participant = iterParticipants.next();
            if (dtoParticipant.getId().equals(participant.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Participant> resultIter = em
                  .createQuery("SELECT DISTINCT p FROM Participant p",
                        Participant.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Participant result = resultIter.next();
               if (result.getId().equals(dtoParticipant.getId()))
               {
                  entity.getParticipants().add(result);
                  break;
               }
            }
         }
      }
      if (this.appointment != null)
      {
         entity.setAppointment(this.appointment.fromDTO(
               entity.getAppointment(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Set<NestedParticipantDTO> getParticipants()
   {
      return this.participants;
   }

   public void setParticipants(final Set<NestedParticipantDTO> participants)
   {
      this.participants = participants;
   }

   public NestedAppointmentDTO getAppointment()
   {
      return this.appointment;
   }

   public void setAppointment(final NestedAppointmentDTO appointment)
   {
      this.appointment = appointment;
   }
}