package de.binaris.appointmentplanner.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "participant_list")
public class ParticipantList implements Serializable {

	private static final long serialVersionUID = 7979792629255525349L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_participant_list")
	@SequenceGenerator(name = "my_entity_seq_gen_participant_list", sequenceName = "sequence_participant_list", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String name;
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "participantList")
	private Set<Participant> participants = new HashSet<Participant>();
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Appointment appointment;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Appointment getAppointment() {
		return appointment;
	}

	public void setAppointment(Appointment appointment) {
		this.appointment = appointment;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Participant> getParticipants() {
		return participants;
	}

	public void setParticipants(Set<Participant> participants) {
		this.participants = participants;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof ParticipantList)) {
			return false;
		}
		ParticipantList castOther = (ParticipantList) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		if (name.length() > 20) {
			sb.append(name.substring(0, 20));
			sb.append("...");
		} else {
			sb.append(name);
		}
		return sb.toString();
	}
}
