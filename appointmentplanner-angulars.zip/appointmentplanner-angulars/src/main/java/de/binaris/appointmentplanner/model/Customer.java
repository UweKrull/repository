package de.binaris.appointmentplanner.model;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Cacheable
@Entity
@NamedQueries({
    @NamedQuery(name = "findByLogin", query = "SELECT c FROM Customer c WHERE c.login = :login"),
    @NamedQuery(name = "findByLoginAndPassword", query = "SELECT c FROM Customer c WHERE c.login = :login AND c.password = :password")
})
@Table(name = "customer")
public class Customer implements Serializable {

	private static final long serialVersionUID = 5572737729659297239L;

    public static final String FIND_BY_LOGIN = "findByLogin";
    public static final String FIND_BY_LOGIN_PASSWORD = "findByLoginAndPassword";
    
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_customer")
	@SequenceGenerator(name = "my_entity_seq_gen_customer", sequenceName = "sequence_customer", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String name;
	
	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String familyName;
	
	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String login;
	
	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String password;
	
	@NotNull
	@NotEmpty
	@Email(message = "invalid email format")
	private String email;
	
	@ManyToOne
	private Country country;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFamilyName() {
		return familyName;
	}
	
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}
	
	public String getLogin() {
		return login;
	}
	
	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Customer)) {
			return false;
		}
		Customer castOther = (Customer) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(familyName).append(", ");
		sb.append(name);
		return sb.toString();
	}
}
