package de.binaris.appointmentplanner.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.appointmentplanner.model.Participant;
import de.binaris.appointmentplanner.rest.dto.ParticipantDTO;

/**
 * 
 */
@Stateless
@Path("/participants")
public class ParticipantEndpoint
{
   @PersistenceContext(unitName = "AppointmentplannerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(ParticipantDTO dto)
   {
      Participant entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(ParticipantEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Participant entity = em.find(Participant.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Participant> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM Participant p LEFT JOIN FETCH p.participantList LEFT JOIN FETCH p.availability LEFT JOIN FETCH p.customer WHERE p.id = :entityId ORDER BY p.id", Participant.class);
      findByIdQuery.setParameter("entityId", id);
      Participant entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      ParticipantDTO dto = new ParticipantDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<ParticipantDTO> listAll()
   {
      final List<Participant> searchResults = em.createQuery("SELECT DISTINCT p FROM Participant p LEFT JOIN FETCH p.participantList LEFT JOIN FETCH p.availability LEFT JOIN FETCH p.customer ORDER BY p.id", Participant.class).getResultList();
      final List<ParticipantDTO> results = new ArrayList<ParticipantDTO>();
      for (Participant searchResult : searchResults)
      {
         ParticipantDTO dto = new ParticipantDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, ParticipantDTO dto)
   {
      TypedQuery<Participant> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM Participant p LEFT JOIN FETCH p.participantList LEFT JOIN FETCH p.availability LEFT JOIN FETCH p.customer WHERE p.id = :entityId ORDER BY p.id", Participant.class);
      findByIdQuery.setParameter("entityId", id);
      Participant entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}