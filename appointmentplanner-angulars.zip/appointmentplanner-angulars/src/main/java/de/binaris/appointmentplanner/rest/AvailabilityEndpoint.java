package de.binaris.appointmentplanner.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.appointmentplanner.model.Availability;
import de.binaris.appointmentplanner.rest.dto.AvailabilityDTO;

/**
 * 
 */
@Stateless
@Path("/availabilitys")
public class AvailabilityEndpoint
{
   @PersistenceContext(unitName = "AppointmentplannerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(AvailabilityDTO dto)
   {
      Availability entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(AvailabilityEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Availability entity = em.find(Availability.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Availability> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM Availability a LEFT JOIN FETCH a.generalAvailability LEFT JOIN FETCH a.availabilityDay1 LEFT JOIN FETCH a.availabilityDay2 LEFT JOIN FETCH a.availabilityDay3 LEFT JOIN FETCH a.availabilityDay4 LEFT JOIN FETCH a.availabilityDay5 LEFT JOIN FETCH a.availabilityDay6 LEFT JOIN FETCH a.availabilityDay7 LEFT JOIN FETCH a.availabilityDay8 LEFT JOIN FETCH a.availabilityDay9 LEFT JOIN FETCH a.availabilityDay10 LEFT JOIN FETCH a.availabilityDay11 LEFT JOIN FETCH a.availabilityDay12 LEFT JOIN FETCH a.availabilityDay13 LEFT JOIN FETCH a.availabilityDay14 WHERE a.id = :entityId ORDER BY a.id", Availability.class);
      findByIdQuery.setParameter("entityId", id);
      Availability entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      AvailabilityDTO dto = new AvailabilityDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<AvailabilityDTO> listAll()
   {
      final List<Availability> searchResults = em.createQuery("SELECT DISTINCT a FROM Availability a LEFT JOIN FETCH a.generalAvailability LEFT JOIN FETCH a.availabilityDay1 LEFT JOIN FETCH a.availabilityDay2 LEFT JOIN FETCH a.availabilityDay3 LEFT JOIN FETCH a.availabilityDay4 LEFT JOIN FETCH a.availabilityDay5 LEFT JOIN FETCH a.availabilityDay6 LEFT JOIN FETCH a.availabilityDay7 LEFT JOIN FETCH a.availabilityDay8 LEFT JOIN FETCH a.availabilityDay9 LEFT JOIN FETCH a.availabilityDay10 LEFT JOIN FETCH a.availabilityDay11 LEFT JOIN FETCH a.availabilityDay12 LEFT JOIN FETCH a.availabilityDay13 LEFT JOIN FETCH a.availabilityDay14 ORDER BY a.id", Availability.class).getResultList();
      final List<AvailabilityDTO> results = new ArrayList<AvailabilityDTO>();
      for (Availability searchResult : searchResults)
      {
         AvailabilityDTO dto = new AvailabilityDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, AvailabilityDTO dto)
   {
      TypedQuery<Availability> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM Availability a LEFT JOIN FETCH a.generalAvailability LEFT JOIN FETCH a.availabilityDay1 LEFT JOIN FETCH a.availabilityDay2 LEFT JOIN FETCH a.availabilityDay3 LEFT JOIN FETCH a.availabilityDay4 LEFT JOIN FETCH a.availabilityDay5 LEFT JOIN FETCH a.availabilityDay6 LEFT JOIN FETCH a.availabilityDay7 LEFT JOIN FETCH a.availabilityDay8 LEFT JOIN FETCH a.availabilityDay9 LEFT JOIN FETCH a.availabilityDay10 LEFT JOIN FETCH a.availabilityDay11 LEFT JOIN FETCH a.availabilityDay12 LEFT JOIN FETCH a.availabilityDay13 LEFT JOIN FETCH a.availabilityDay14 WHERE a.id = :entityId ORDER BY a.id", Availability.class);
      findByIdQuery.setParameter("entityId", id);
      Availability entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}