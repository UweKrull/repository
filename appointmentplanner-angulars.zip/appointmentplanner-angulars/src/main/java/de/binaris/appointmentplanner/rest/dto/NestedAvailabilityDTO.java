package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;
import de.binaris.appointmentplanner.model.Availability;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Date;

public class NestedAvailabilityDTO implements Serializable
{

   private Date startDateTime;
   private Date endDateTime;
   private Long id;

   public NestedAvailabilityDTO()
   {
   }

   public NestedAvailabilityDTO(final Availability entity)
   {
      if (entity != null)
      {
         this.startDateTime = entity.getStartDateTime();
         this.endDateTime = entity.getEndDateTime();
         this.id = entity.getId();
      }
   }

   public Availability fromDTO(Availability entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Availability();
      }
      if (this.id != null)
      {
         TypedQuery<Availability> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT a FROM Availability a WHERE a.id = :entityId",
                     Availability.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setStartDateTime(this.startDateTime);
      entity.setEndDateTime(this.endDateTime);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartDateTime()
   {
      return this.startDateTime;
   }

   public void setStartDateTime(final Date startDateTime)
   {
      this.startDateTime = startDateTime;
   }

   public Date getEndDateTime()
   {
      return this.endDateTime;
   }

   public void setEndDateTime(final Date endDateTime)
   {
      this.endDateTime = endDateTime;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }
}