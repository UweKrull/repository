package de.binaris.appointmentplanner.model;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "participant")
public class Participant implements Serializable {

	private static final long serialVersionUID = 353255522579292125L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_participant")
	@SequenceGenerator(name = "my_entity_seq_gen_participant", sequenceName = "sequence_participant", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String aliasName;

	@ManyToOne
	private ParticipantList participantList;

	@ManyToOne
	private Availability availability;
	
    @ManyToOne
    private Customer customer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAliasName() {
		return aliasName;
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}
	
	public ParticipantList getParticipantList() {
		return participantList;
	}

	public void setParticipantList(ParticipantList participantList) {
		this.participantList = participantList;
	}

	public Availability getAvailability() {
		return availability;
	}
	
	public void setAvailability(Availability availability) {
		this.availability = availability;
	}
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Participant)) {
			return false;
		}
		Participant castOther = (Participant) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return aliasName;
	}
}
