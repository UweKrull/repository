package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.fridge.model.Article;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Date;

public class NestedArticleDTO implements Serializable
{

   private Long id;
   private String title;
   private Date expiryDateTime;
   private Date boughtDateTime;

   public NestedArticleDTO()
   {
   }

   public NestedArticleDTO(final Article entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.expiryDateTime = entity.getExpiryDateTime();
         this.boughtDateTime = entity.getBoughtDateTime();
      }
   }

   public Article fromDTO(Article entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Article();
      }
      if (this.id != null)
      {
         TypedQuery<Article> findByIdQuery = em.createQuery(
               "SELECT DISTINCT a FROM Article a WHERE a.id = :entityId",
               Article.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity.setExpiryDateTime(this.expiryDateTime);
      entity.setBoughtDateTime(this.boughtDateTime);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public Date getExpiryDateTime()
   {
      return this.expiryDateTime;
   }

   public void setExpiryDateTime(final Date expiryDateTime)
   {
      this.expiryDateTime = expiryDateTime;
   }

   public Date getBoughtDateTime()
   {
      return this.boughtDateTime;
   }

   public void setBoughtDateTime(final Date boughtDateTime)
   {
      this.boughtDateTime = boughtDateTime;
   }
}