package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.fridge.model.Article;
import de.binaris.rest.dto.ArticleDTO;

/**
 * 
 */
@Stateless
@Path("/articles")
public class ArticleEndpoint
{
   @PersistenceContext(unitName = "FridgecontentPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(ArticleDTO dto)
   {
      Article entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(ArticleEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Article entity = em.find(Article.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Article> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM Article a LEFT JOIN FETCH a.category LEFT JOIN FETCH a.refridgerator LEFT JOIN FETCH a.ingredient WHERE a.id = :entityId ORDER BY a.id", Article.class);
      findByIdQuery.setParameter("entityId", id);
      Article entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      ArticleDTO dto = new ArticleDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<ArticleDTO> listAll()
   {
      final List<Article> searchResults = em.createQuery("SELECT DISTINCT a FROM Article a LEFT JOIN FETCH a.category LEFT JOIN FETCH a.refridgerator LEFT JOIN FETCH a.ingredient ORDER BY a.id", Article.class).getResultList();
      final List<ArticleDTO> results = new ArrayList<ArticleDTO>();
      for (Article searchResult : searchResults)
      {
         ArticleDTO dto = new ArticleDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, ArticleDTO dto)
   {
      TypedQuery<Article> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM Article a LEFT JOIN FETCH a.category LEFT JOIN FETCH a.refridgerator LEFT JOIN FETCH a.ingredient WHERE a.id = :entityId ORDER BY a.id", Article.class);
      findByIdQuery.setParameter("entityId", id);
      Article entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}