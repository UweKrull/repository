package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.fridge.model.Ingredient;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.fridge.model.IngredientType;

public class NestedIngredientDTO implements Serializable
{

   private Long id;
   private String name;
   private IngredientType type;

   public NestedIngredientDTO()
   {
   }

   public NestedIngredientDTO(final Ingredient entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
         this.type = entity.getType();
      }
   }

   public Ingredient fromDTO(Ingredient entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Ingredient();
      }
      if (this.id != null)
      {
         TypedQuery<Ingredient> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT i FROM Ingredient i WHERE i.id = :entityId",
                     Ingredient.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity.setType(this.type);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public IngredientType getType()
   {
      return this.type;
   }

   public void setType(final IngredientType type)
   {
      this.type = type;
   }
}