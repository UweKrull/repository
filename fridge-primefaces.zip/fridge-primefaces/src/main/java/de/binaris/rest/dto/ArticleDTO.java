package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.fridge.model.Article;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedRefridgeratorDTO;
import de.binaris.rest.dto.NestedCategoryDTO;
import java.util.Date;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedIngredientDTO;
import de.binaris.fridge.model.Ingredient;
import java.util.Iterator;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ArticleDTO implements Serializable
{

   private NestedRefridgeratorDTO refridgerator;
   private Long id;
   private NestedCategoryDTO category;
   private String title;
   private Date expiryDateTime;
   private Set<NestedIngredientDTO> ingredient = new HashSet<NestedIngredientDTO>();
   private Date boughtDateTime;

   public ArticleDTO()
   {
   }

   public ArticleDTO(final Article entity)
   {
      if (entity != null)
      {
         this.refridgerator = new NestedRefridgeratorDTO(
               entity.getRefridgerator());
         this.id = entity.getId();
         this.category = new NestedCategoryDTO(entity.getCategory());
         this.title = entity.getTitle();
         this.expiryDateTime = entity.getExpiryDateTime();
         Iterator<Ingredient> iterIngredient = entity.getIngredient()
               .iterator();
         for (; iterIngredient.hasNext();)
         {
            Ingredient element = iterIngredient.next();
            this.ingredient.add(new NestedIngredientDTO(element));
         }
         this.boughtDateTime = entity.getBoughtDateTime();
      }
   }

   public Article fromDTO(Article entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Article();
      }
      if (this.refridgerator != null)
      {
         entity.setRefridgerator(this.refridgerator.fromDTO(
               entity.getRefridgerator(), em));
      }
      if (this.category != null)
      {
         entity.setCategory(this.category.fromDTO(entity.getCategory(), em));
      }
      entity.setTitle(this.title);
      entity.setExpiryDateTime(this.expiryDateTime);
      Iterator<Ingredient> iterIngredient = entity.getIngredient().iterator();
      for (; iterIngredient.hasNext();)
      {
         boolean found = false;
         Ingredient ingredient = iterIngredient.next();
         Iterator<NestedIngredientDTO> iterDtoIngredient = this
               .getIngredient().iterator();
         for (; iterDtoIngredient.hasNext();)
         {
            NestedIngredientDTO dtoIngredient = iterDtoIngredient.next();
            if (dtoIngredient.getId().equals(ingredient.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterIngredient.remove();
         }
      }
      Iterator<NestedIngredientDTO> iterDtoIngredient = this.getIngredient()
            .iterator();
      for (; iterDtoIngredient.hasNext();)
      {
         boolean found = false;
         NestedIngredientDTO dtoIngredient = iterDtoIngredient.next();
         iterIngredient = entity.getIngredient().iterator();
         for (; iterIngredient.hasNext();)
         {
            Ingredient ingredient = iterIngredient.next();
            if (dtoIngredient.getId().equals(ingredient.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Ingredient> resultIter = em
                  .createQuery("SELECT DISTINCT i FROM Ingredient i",
                        Ingredient.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Ingredient result = resultIter.next();
               if (result.getId().equals(dtoIngredient.getId()))
               {
                  entity.getIngredient().add(result);
                  break;
               }
            }
         }
      }
      entity.setBoughtDateTime(this.boughtDateTime);
      entity = em.merge(entity);
      return entity;
   }

   public NestedRefridgeratorDTO getRefridgerator()
   {
      return this.refridgerator;
   }

   public void setRefridgerator(final NestedRefridgeratorDTO refridgerator)
   {
      this.refridgerator = refridgerator;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedCategoryDTO getCategory()
   {
      return this.category;
   }

   public void setCategory(final NestedCategoryDTO category)
   {
      this.category = category;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public Date getExpiryDateTime()
   {
      return this.expiryDateTime;
   }

   public void setExpiryDateTime(final Date expiryDateTime)
   {
      this.expiryDateTime = expiryDateTime;
   }

   public Set<NestedIngredientDTO> getIngredient()
   {
      return this.ingredient;
   }

   public void setIngredient(final Set<NestedIngredientDTO> ingredient)
   {
      this.ingredient = ingredient;
   }

   public Date getBoughtDateTime()
   {
      return this.boughtDateTime;
   }

   public void setBoughtDateTime(final Date boughtDateTime)
   {
      this.boughtDateTime = boughtDateTime;
   }
}