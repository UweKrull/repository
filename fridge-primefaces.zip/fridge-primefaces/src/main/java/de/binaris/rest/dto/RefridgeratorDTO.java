package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.fridge.model.Refridgerator;
import javax.persistence.EntityManager;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedArticleDTO;
import de.binaris.fridge.model.Article;
import java.util.Iterator;
import de.binaris.fridge.model.RefridgeratorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RefridgeratorDTO implements Serializable
{

   private Long id;
   private Set<NestedArticleDTO> article = new HashSet<NestedArticleDTO>();
   private String description;
   private String name;
   private RefridgeratorType type;

   public RefridgeratorDTO()
   {
   }

   public RefridgeratorDTO(final Refridgerator entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         Iterator<Article> iterArticle = entity.getArticle().iterator();
         for (; iterArticle.hasNext();)
         {
            Article element = iterArticle.next();
            this.article.add(new NestedArticleDTO(element));
         }
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.type = entity.getType();
      }
   }

   public Refridgerator fromDTO(Refridgerator entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Refridgerator();
      }
      Iterator<Article> iterArticle = entity.getArticle().iterator();
      for (; iterArticle.hasNext();)
      {
         boolean found = false;
         Article article = iterArticle.next();
         Iterator<NestedArticleDTO> iterDtoArticle = this.getArticle()
               .iterator();
         for (; iterDtoArticle.hasNext();)
         {
            NestedArticleDTO dtoArticle = iterDtoArticle.next();
            if (dtoArticle.getId().equals(article.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterArticle.remove();
         }
      }
      Iterator<NestedArticleDTO> iterDtoArticle = this.getArticle()
            .iterator();
      for (; iterDtoArticle.hasNext();)
      {
         boolean found = false;
         NestedArticleDTO dtoArticle = iterDtoArticle.next();
         iterArticle = entity.getArticle().iterator();
         for (; iterArticle.hasNext();)
         {
            Article article = iterArticle.next();
            if (dtoArticle.getId().equals(article.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Article> resultIter = em
                  .createQuery("SELECT DISTINCT a FROM Article a",
                        Article.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Article result = resultIter.next();
               if (result.getId().equals(dtoArticle.getId()))
               {
                  entity.getArticle().add(result);
                  break;
               }
            }
         }
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setType(this.type);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedArticleDTO> getArticle()
   {
      return this.article;
   }

   public void setArticle(final Set<NestedArticleDTO> article)
   {
      this.article = article;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public RefridgeratorType getType()
   {
      return this.type;
   }

   public void setType(final RefridgeratorType type)
   {
      this.type = type;
   }
}