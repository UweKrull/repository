package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.fridge.model.Ingredient;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedArticleDTO;
import de.binaris.fridge.model.IngredientType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class IngredientDTO implements Serializable
{

   private Long id;
   private NestedArticleDTO article;
   private String name;
   private IngredientType type;

   public IngredientDTO()
   {
   }

   public IngredientDTO(final Ingredient entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.article = new NestedArticleDTO(entity.getArticle());
         this.name = entity.getName();
         this.type = entity.getType();
      }
   }

   public Ingredient fromDTO(Ingredient entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Ingredient();
      }
      if (this.article != null)
      {
         entity.setArticle(this.article.fromDTO(entity.getArticle(), em));
      }
      entity.setName(this.name);
      entity.setType(this.type);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedArticleDTO getArticle()
   {
      return this.article;
   }

   public void setArticle(final NestedArticleDTO article)
   {
      this.article = article;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public IngredientType getType()
   {
      return this.type;
   }

   public void setType(final IngredientType type)
   {
      this.type = type;
   }
}