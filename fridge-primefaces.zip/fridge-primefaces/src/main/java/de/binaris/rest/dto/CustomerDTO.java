package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.fridge.model.Customer;
import javax.persistence.EntityManager;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedRefridgeratorDTO;
import de.binaris.fridge.model.Refridgerator;
import java.util.Iterator;
import java.util.Date;
import de.binaris.rest.dto.AddressDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerDTO implements Serializable
{

   private Set<NestedRefridgeratorDTO> refridgerator = new HashSet<NestedRefridgeratorDTO>();
   private Date dateOfBirth;
   private Long id;
   private String lastName;
   private String phone;
   private AddressDTO address;
   private String email;
   private String login;
   private String firstName;
   private String password;

   public CustomerDTO()
   {
   }

   public CustomerDTO(final Customer entity)
   {
      if (entity != null)
      {
         Iterator<Refridgerator> iterRefridgerator = entity
               .getRefridgerator().iterator();
         for (; iterRefridgerator.hasNext();)
         {
            Refridgerator element = iterRefridgerator.next();
            this.refridgerator.add(new NestedRefridgeratorDTO(element));
         }
         this.dateOfBirth = entity.getDateOfBirth();
         this.id = entity.getId();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         this.address = new AddressDTO(entity.getAddress());
         this.email = entity.getEmail();
         this.login = entity.getLogin();
         this.firstName = entity.getFirstName();
         this.password = entity.getPassword();
      }
   }

   public Customer fromDTO(Customer entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Customer();
      }
      Iterator<Refridgerator> iterRefridgerator = entity.getRefridgerator()
            .iterator();
      for (; iterRefridgerator.hasNext();)
      {
         boolean found = false;
         Refridgerator refridgerator = iterRefridgerator.next();
         Iterator<NestedRefridgeratorDTO> iterDtoRefridgerator = this
               .getRefridgerator().iterator();
         for (; iterDtoRefridgerator.hasNext();)
         {
            NestedRefridgeratorDTO dtoRefridgerator = iterDtoRefridgerator
                  .next();
            if (dtoRefridgerator.getId().equals(refridgerator.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterRefridgerator.remove();
         }
      }
      Iterator<NestedRefridgeratorDTO> iterDtoRefridgerator = this
            .getRefridgerator().iterator();
      for (; iterDtoRefridgerator.hasNext();)
      {
         boolean found = false;
         NestedRefridgeratorDTO dtoRefridgerator = iterDtoRefridgerator
               .next();
         iterRefridgerator = entity.getRefridgerator().iterator();
         for (; iterRefridgerator.hasNext();)
         {
            Refridgerator refridgerator = iterRefridgerator.next();
            if (dtoRefridgerator.getId().equals(refridgerator.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Refridgerator> resultIter = em
                  .createQuery("SELECT DISTINCT r FROM Refridgerator r",
                        Refridgerator.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Refridgerator result = resultIter.next();
               if (result.getId().equals(dtoRefridgerator.getId()))
               {
                  entity.getRefridgerator().add(result);
                  break;
               }
            }
         }
      }
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setEmail(this.email);
      entity.setLogin(this.login);
      entity.setFirstName(this.firstName);
      entity.setPassword(this.password);
      entity = em.merge(entity);
      return entity;
   }

   public Set<NestedRefridgeratorDTO> getRefridgerator()
   {
      return this.refridgerator;
   }

   public void setRefridgerator(final Set<NestedRefridgeratorDTO> refridgerator)
   {
      this.refridgerator = refridgerator;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }
}