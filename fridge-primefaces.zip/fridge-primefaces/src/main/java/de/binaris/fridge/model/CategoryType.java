package de.binaris.fridge.model;

/**
 * <p>
 * The {@link CategoryType} describes the category's types
 * Meat or Veggies, etc.
 * 
 * CategoryType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the category types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link CategoryType} describes the category's types (Meat,Veggies,etc.).
 * </p>
 */
public enum CategoryType {

    /**
     * The type of a food category.
     */
    Bread_Butter("Bread and Butter", true),
    Cheese("Cheese", true),
    Chips_Crackers("Chips and Crackers", true),
    Drinks("Drinks", true),
    Eggs("Eggs", true),
    Fruit("Fruit", true),
    Honey_Marmelade("Honey and Marmelade", true),
    Ice("Ice", true),
    Meat("Meat", true),
    Veggies("Veggies", true),
    Milk("Milk", true),
    Milk_Products("Milk Products", true),
    Nuts("Nuts", true),
    Sugars_Spices("Sugars and Spices", true),
    Sweets("Sweets", true);


    /**
     * A human readable description of the food category type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the activ type can be cached.
     */
    private final boolean cacheable;
    
    private CategoryType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}