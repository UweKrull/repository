package de.binaris.fridge.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "article")
public class Article implements Serializable {

	private static final long serialVersionUID = 7999777123627126329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_article")
	@SequenceGenerator(name = "my_entity_seq_gen_article", sequenceName = "sequence_article", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String title;

	@ManyToOne
	private Category category;

	@ManyToOne
	private Refridgerator refridgerator;
	
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "bought_date_time", updatable = true)
	private Date boughtDateTime;	
	
	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expiry_date_time", updatable = true)
	private Date expiryDateTime;	
	
	@Column(name = "deleted")
    @Enumerated(STRING)
    private DeletedType deleted;
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "article")
	private Set<Ingredient> ingredient = new HashSet<Ingredient>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Refridgerator getRefridgerator() {
		return refridgerator;
	}

	public void setRefridgerator(Refridgerator refridgerator) {
		this.refridgerator = refridgerator;
	}

	public Date getBoughtDateTime() {
		return boughtDateTime;
	}

	public void setBoughtDateTime(Date boughtDateTime) {
		this.boughtDateTime = boughtDateTime;
	}

	public Date getExpiryDateTime() {
		return expiryDateTime;
	}

	public void setExpiryDateTime(Date expiryDateTime) {
		this.expiryDateTime = expiryDateTime;
	}

	public DeletedType getDeleted() {
		return deleted;
	}

	public void setDeleted(DeletedType deleted) {
		this.deleted = deleted;
	}
	
	public Set<Ingredient> getIngredient() {
		return ingredient;
	}

	public void setIngredient(Set<Ingredient> ingredient) {
		this.ingredient = ingredient;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Article)) {
			return false;
		}
		Article castOther = (Article) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(title);
		sb.append(", ");
		sb.append(category.toString());
		return sb.toString();
	}
}