package de.binaris.fridge.model;

/**
 * <p>
 * The {@link RefridgeratorType} describes the refridgerator's type
 * Superfridge or Homefridge (or Minibar).
 * 
 * RefridgeratorType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the refridgerator types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link RefridgeratorType} describes the refridgerator's types (S,H,M).
 * </p>
 */
public enum RefridgeratorType {

    /**
     * The type of refridgerator.
     */
    Superfridge("S", true),
    Homefridge("H", true),  
    Minibar("M", true);

    /**
     * A human readable description of the refridgerator type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the refridgerator type can be cached.
     */
    private final boolean cacheable;
    
    private RefridgeratorType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
