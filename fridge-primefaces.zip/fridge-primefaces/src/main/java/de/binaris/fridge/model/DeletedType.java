package de.binaris.fridge.model;

/**
 * <p>
 * The {@link DeletedType} describes, whether or not an article 
 * has been finally removed from the fridge.
 * 
 * DeletedType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the Deleted types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link DeletedType} describes the ingredient types (Y,N).
 * </p>
 */
public enum DeletedType {

    /**
     * Whether or not an article has been finally removed.
     */
    Deleted("D", true),
    Not_Deleted("N", true);

    /**
     * A human readable description of the deleted type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the deleted type can be cached.
     */
    private final boolean cacheable;
    
    private DeletedType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}