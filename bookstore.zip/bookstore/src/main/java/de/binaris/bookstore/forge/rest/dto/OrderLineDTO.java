package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import de.binaris.bookstore.forge.model.OrderLine;
import de.binaris.bookstore.forge.rest.dto.NestedItemDTO;
import de.binaris.bookstore.forge.rest.dto.NestedPurchaseOrderDTO;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class OrderLineDTO implements Serializable {

	private static final long serialVersionUID = 7117778910111233391L;

	private Long id;
	private Float subTotal;
	private NestedItemDTO item;
	private NestedPurchaseOrderDTO purchaseOrder;
	private Integer quantity;

	public OrderLineDTO() {
	}

	public OrderLineDTO(final OrderLine entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.subTotal = entity.getSubTotal();
			this.item = new NestedItemDTO(entity.getItem());
			this.purchaseOrder = new NestedPurchaseOrderDTO(
					entity.getPurchaseOrder());
			this.quantity = entity.getQuantity();
		}
	}

	public OrderLine fromDTO(OrderLine entity, EntityManager em) {
		if (entity == null) {
			entity = new OrderLine();
		}
		if (this.item != null) {
			entity.setItem(this.item.fromDTO(entity.getItem(), em));
		}
		if (this.purchaseOrder != null) {
			entity.setPurchaseOrder(this.purchaseOrder.fromDTO(
					entity.getPurchaseOrder(), em));
		}
		entity.setQuantity(this.quantity);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Float getSubTotal() {
		return this.subTotal;
	}

	public void setSubTotal(final Float subTotal) {
		this.subTotal = subTotal;
	}

	public NestedItemDTO getItem() {
		return this.item;
	}

	public void setItem(final NestedItemDTO item) {
		this.item = item;
	}

	public NestedPurchaseOrderDTO getPurchaseOrder() {
		return this.purchaseOrder;
	}

	public void setPurchaseOrder(final NestedPurchaseOrderDTO purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(final Integer quantity) {
		this.quantity = quantity;
	}
}