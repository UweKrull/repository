package de.binaris.bookstore.forge.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.bookstore.forge.model.PurchaseOrder;
import de.binaris.bookstore.forge.rest.dto.PurchaseOrderDTO;

/**
 * 
 */
@Stateless
@Path("/purchaseorders")
public class PurchaseOrderEndpoint
{
   @PersistenceContext(unitName = "BookstorePU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(PurchaseOrderDTO dto)
   {
      PurchaseOrder entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(PurchaseOrderEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      PurchaseOrder entity = em.find(PurchaseOrder.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<PurchaseOrder> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM PurchaseOrder p LEFT JOIN FETCH p.customer LEFT JOIN FETCH p.orderLines WHERE p.id = :entityId ORDER BY p.id", PurchaseOrder.class);
      findByIdQuery.setParameter("entityId", id);
      PurchaseOrder entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      PurchaseOrderDTO dto = new PurchaseOrderDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<PurchaseOrderDTO> listAll()
   {
      final List<PurchaseOrder> searchResults = em.createQuery("SELECT DISTINCT p FROM PurchaseOrder p LEFT JOIN FETCH p.customer LEFT JOIN FETCH p.orderLines ORDER BY p.id", PurchaseOrder.class).getResultList();
      final List<PurchaseOrderDTO> results = new ArrayList<PurchaseOrderDTO>();
      for (PurchaseOrder searchResult : searchResults)
      {
         PurchaseOrderDTO dto = new PurchaseOrderDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, PurchaseOrderDTO dto)
   {
      TypedQuery<PurchaseOrder> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM PurchaseOrder p LEFT JOIN FETCH p.customer LEFT JOIN FETCH p.orderLines WHERE p.id = :entityId ORDER BY p.id", PurchaseOrder.class);
      findByIdQuery.setParameter("entityId", id);
      PurchaseOrder entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}