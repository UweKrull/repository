package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;

import de.binaris.bookstore.forge.model.Item;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedItemDTO implements Serializable {

	private static final long serialVersionUID = 7735678910111213170L;

	private Long id;
	private Float unitCost;
	private String imagePath;
	private String description;
	private String name;

	public NestedItemDTO() {
	}

	public NestedItemDTO(final Item entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.unitCost = entity.getUnitCost();
			this.imagePath = entity.getImagePath();
			this.description = entity.getDescription();
			this.name = entity.getName();
		}
	}

	public Item fromDTO(Item entity, EntityManager em) {
		if (entity == null) {
			entity = new Item();
		}
		if (this.id != null) {
			TypedQuery<Item> findByIdQuery = em.createQuery(
					"SELECT DISTINCT i FROM Item i WHERE i.id = :entityId",
					Item.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setUnitCost(this.unitCost);
		entity.setImagePath(this.imagePath);
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Float getUnitCost() {
		return this.unitCost;
	}

	public void setUnitCost(final Float unitCost) {
		this.unitCost = unitCost;
	}

	public String getImagePath() {
		return this.imagePath;
	}

	public void setImagePath(final String imagePath) {
		this.imagePath = imagePath;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}
}