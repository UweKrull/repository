package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.Ingredient;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedIngredientDTO implements Serializable
{

   private Long id;
   private Float quantity;

   public NestedIngredientDTO()
   {
   }

   public NestedIngredientDTO(final Ingredient entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.quantity = entity.getQuantity();
      }
   }

   public Ingredient fromDTO(Ingredient entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Ingredient();
      }
      if (this.id != null)
      {
         TypedQuery<Ingredient> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT i FROM Ingredient i WHERE i.id = :entityId",
                     Ingredient.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setQuantity(this.quantity);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Float getQuantity()
   {
      return this.quantity;
   }

   public void setQuantity(final Float quantity)
   {
      this.quantity = quantity;
   }
}