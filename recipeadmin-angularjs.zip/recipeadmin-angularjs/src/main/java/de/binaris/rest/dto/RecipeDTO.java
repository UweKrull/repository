package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.Recipe;
import javax.persistence.EntityManager;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedPreparationDirectionDTO;
import de.binaris.recipeadmin.model.PreparationDirection;
import java.util.Iterator;
import de.binaris.rest.dto.NestedCategoryDTO;
import de.binaris.recipeadmin.model.Category;
import de.binaris.rest.dto.NestedServingDirectionDTO;
import de.binaris.recipeadmin.model.ServingDirection;
import de.binaris.rest.dto.NestedIngredientDTO;
import de.binaris.recipeadmin.model.Ingredient;
import de.binaris.rest.dto.NestedUserDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RecipeDTO implements Serializable
{

   private Long id;
   private Set<NestedPreparationDirectionDTO> preparationDirection = new HashSet<NestedPreparationDirectionDTO>();
   private Set<NestedCategoryDTO> category = new HashSet<NestedCategoryDTO>();
   private String title;
   private Set<NestedServingDirectionDTO> servingDirection = new HashSet<NestedServingDirectionDTO>();
   private Set<NestedIngredientDTO> ingredient = new HashSet<NestedIngredientDTO>();
   private NestedUserDTO user;

   public RecipeDTO()
   {
   }

   public RecipeDTO(final Recipe entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         Iterator<PreparationDirection> iterPreparationDirection = entity
               .getPreparationDirection().iterator();
         for (; iterPreparationDirection.hasNext();)
         {
            PreparationDirection element = iterPreparationDirection.next();
            this.preparationDirection
                  .add(new NestedPreparationDirectionDTO(element));
         }
         Iterator<Category> iterCategory = entity.getCategory().iterator();
         for (; iterCategory.hasNext();)
         {
            Category element = iterCategory.next();
            this.category.add(new NestedCategoryDTO(element));
         }
         this.title = entity.getTitle();
         Iterator<ServingDirection> iterServingDirection = entity
               .getServingDirection().iterator();
         for (; iterServingDirection.hasNext();)
         {
            ServingDirection element = iterServingDirection.next();
            this.servingDirection
                  .add(new NestedServingDirectionDTO(element));
         }
         Iterator<Ingredient> iterIngredient = entity.getIngredient()
               .iterator();
         for (; iterIngredient.hasNext();)
         {
            Ingredient element = iterIngredient.next();
            this.ingredient.add(new NestedIngredientDTO(element));
         }
         this.user = new NestedUserDTO(entity.getUser());
      }
   }

   public Recipe fromDTO(Recipe entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Recipe();
      }
      Iterator<PreparationDirection> iterPreparationDirection = entity
            .getPreparationDirection().iterator();
      for (; iterPreparationDirection.hasNext();)
      {
         boolean found = false;
         PreparationDirection preparationDirection = iterPreparationDirection
               .next();
         Iterator<NestedPreparationDirectionDTO> iterDtoPreparationDirection = this
               .getPreparationDirection().iterator();
         for (; iterDtoPreparationDirection.hasNext();)
         {
            NestedPreparationDirectionDTO dtoPreparationDirection = iterDtoPreparationDirection
                  .next();
            if (dtoPreparationDirection.getId().equals(
                  preparationDirection.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterPreparationDirection.remove();
         }
      }
      Iterator<NestedPreparationDirectionDTO> iterDtoPreparationDirection = this
            .getPreparationDirection().iterator();
      for (; iterDtoPreparationDirection.hasNext();)
      {
         boolean found = false;
         NestedPreparationDirectionDTO dtoPreparationDirection = iterDtoPreparationDirection
               .next();
         iterPreparationDirection = entity.getPreparationDirection()
               .iterator();
         for (; iterPreparationDirection.hasNext();)
         {
            PreparationDirection preparationDirection = iterPreparationDirection
                  .next();
            if (dtoPreparationDirection.getId().equals(
                  preparationDirection.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<PreparationDirection> resultIter = em
                  .createQuery(
                        "SELECT DISTINCT p FROM PreparationDirection p",
                        PreparationDirection.class).getResultList()
                  .iterator();
            for (; resultIter.hasNext();)
            {
               PreparationDirection result = resultIter.next();
               if (result.getId().equals(dtoPreparationDirection.getId()))
               {
                  entity.getPreparationDirection().add(result);
                  break;
               }
            }
         }
      }
      Iterator<Category> iterCategory = entity.getCategory().iterator();
      for (; iterCategory.hasNext();)
      {
         boolean found = false;
         Category category = iterCategory.next();
         Iterator<NestedCategoryDTO> iterDtoCategory = this.getCategory()
               .iterator();
         for (; iterDtoCategory.hasNext();)
         {
            NestedCategoryDTO dtoCategory = iterDtoCategory.next();
            if (dtoCategory.getId().equals(category.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterCategory.remove();
         }
      }
      Iterator<NestedCategoryDTO> iterDtoCategory = this.getCategory()
            .iterator();
      for (; iterDtoCategory.hasNext();)
      {
         boolean found = false;
         NestedCategoryDTO dtoCategory = iterDtoCategory.next();
         iterCategory = entity.getCategory().iterator();
         for (; iterCategory.hasNext();)
         {
            Category category = iterCategory.next();
            if (dtoCategory.getId().equals(category.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Category> resultIter = em
                  .createQuery("SELECT DISTINCT c FROM Category c",
                        Category.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Category result = resultIter.next();
               if (result.getId().equals(dtoCategory.getId()))
               {
                  entity.getCategory().add(result);
                  break;
               }
            }
         }
      }
      entity.setTitle(this.title);
      Iterator<ServingDirection> iterServingDirection = entity
            .getServingDirection().iterator();
      for (; iterServingDirection.hasNext();)
      {
         boolean found = false;
         ServingDirection servingDirection = iterServingDirection.next();
         Iterator<NestedServingDirectionDTO> iterDtoServingDirection = this
               .getServingDirection().iterator();
         for (; iterDtoServingDirection.hasNext();)
         {
            NestedServingDirectionDTO dtoServingDirection = iterDtoServingDirection
                  .next();
            if (dtoServingDirection.getId()
                  .equals(servingDirection.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterServingDirection.remove();
         }
      }
      Iterator<NestedServingDirectionDTO> iterDtoServingDirection = this
            .getServingDirection().iterator();
      for (; iterDtoServingDirection.hasNext();)
      {
         boolean found = false;
         NestedServingDirectionDTO dtoServingDirection = iterDtoServingDirection
               .next();
         iterServingDirection = entity.getServingDirection().iterator();
         for (; iterServingDirection.hasNext();)
         {
            ServingDirection servingDirection = iterServingDirection.next();
            if (dtoServingDirection.getId()
                  .equals(servingDirection.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<ServingDirection> resultIter = em
                  .createQuery(
                        "SELECT DISTINCT s FROM ServingDirection s",
                        ServingDirection.class).getResultList()
                  .iterator();
            for (; resultIter.hasNext();)
            {
               ServingDirection result = resultIter.next();
               if (result.getId().equals(dtoServingDirection.getId()))
               {
                  entity.getServingDirection().add(result);
                  break;
               }
            }
         }
      }
      Iterator<Ingredient> iterIngredient = entity.getIngredient().iterator();
      for (; iterIngredient.hasNext();)
      {
         boolean found = false;
         Ingredient ingredient = iterIngredient.next();
         Iterator<NestedIngredientDTO> iterDtoIngredient = this
               .getIngredient().iterator();
         for (; iterDtoIngredient.hasNext();)
         {
            NestedIngredientDTO dtoIngredient = iterDtoIngredient.next();
            if (dtoIngredient.getId().equals(ingredient.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterIngredient.remove();
         }
      }
      Iterator<NestedIngredientDTO> iterDtoIngredient = this.getIngredient()
            .iterator();
      for (; iterDtoIngredient.hasNext();)
      {
         boolean found = false;
         NestedIngredientDTO dtoIngredient = iterDtoIngredient.next();
         iterIngredient = entity.getIngredient().iterator();
         for (; iterIngredient.hasNext();)
         {
            Ingredient ingredient = iterIngredient.next();
            if (dtoIngredient.getId().equals(ingredient.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Ingredient> resultIter = em
                  .createQuery("SELECT DISTINCT i FROM Ingredient i",
                        Ingredient.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Ingredient result = resultIter.next();
               if (result.getId().equals(dtoIngredient.getId()))
               {
                  entity.getIngredient().add(result);
                  break;
               }
            }
         }
      }
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedPreparationDirectionDTO> getPreparationDirection()
   {
      return this.preparationDirection;
   }

   public void setPreparationDirection(
         final Set<NestedPreparationDirectionDTO> preparationDirection)
   {
      this.preparationDirection = preparationDirection;
   }

   public Set<NestedCategoryDTO> getCategory()
   {
      return this.category;
   }

   public void setCategory(final Set<NestedCategoryDTO> category)
   {
      this.category = category;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public Set<NestedServingDirectionDTO> getServingDirection()
   {
      return this.servingDirection;
   }

   public void setServingDirection(
         final Set<NestedServingDirectionDTO> servingDirection)
   {
      this.servingDirection = servingDirection;
   }

   public Set<NestedIngredientDTO> getIngredient()
   {
      return this.ingredient;
   }

   public void setIngredient(final Set<NestedIngredientDTO> ingredient)
   {
      this.ingredient = ingredient;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }
}