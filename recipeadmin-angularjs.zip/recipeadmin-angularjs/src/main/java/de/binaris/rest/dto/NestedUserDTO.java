package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.User;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Date;
import de.binaris.rest.dto.AddressDTO;

public class NestedUserDTO implements Serializable
{

   private String middleName;
   private Date dateOfBirth;
   private String lastName;
   private String phone;
   private Date dateOfLeave;
   private String password;
   private Long id;
   private AddressDTO address;
   private String email;
   private Date dateOfEntry;
   private String login;
   private String firstName;
   private String jobTitle;

   public NestedUserDTO()
   {
   }

   public NestedUserDTO(final User entity)
   {
      if (entity != null)
      {
         this.middleName = entity.getMiddleName();
         this.dateOfBirth = entity.getDateOfBirth();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         this.dateOfLeave = entity.getDateOfLeave();
         this.password = entity.getPassword();
         this.id = entity.getId();
         this.address = new AddressDTO(entity.getAddress());
         this.email = entity.getEmail();
         this.dateOfEntry = entity.getDateOfEntry();
         this.login = entity.getLogin();
         this.firstName = entity.getFirstName();
         this.jobTitle = entity.getJobTitle();
      }
   }

   public User fromDTO(User entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new User();
      }
      if (this.id != null)
      {
         TypedQuery<User> findByIdQuery = em.createQuery(
               "SELECT DISTINCT u FROM User u WHERE u.id = :entityId",
               User.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setMiddleName(this.middleName);
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      entity.setDateOfLeave(this.dateOfLeave);
      entity.setPassword(this.password);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setEmail(this.email);
      entity.setDateOfEntry(this.dateOfEntry);
      entity.setLogin(this.login);
      entity.setFirstName(this.firstName);
      entity.setJobTitle(this.jobTitle);
      entity = em.merge(entity);
      return entity;
   }

   public String getMiddleName()
   {
      return this.middleName;
   }

   public void setMiddleName(final String middleName)
   {
      this.middleName = middleName;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public Date getDateOfLeave()
   {
      return this.dateOfLeave;
   }

   public void setDateOfLeave(final Date dateOfLeave)
   {
      this.dateOfLeave = dateOfLeave;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public Date getDateOfEntry()
   {
      return this.dateOfEntry;
   }

   public void setDateOfEntry(final Date dateOfEntry)
   {
      this.dateOfEntry = dateOfEntry;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }

   public String getJobTitle()
   {
      return this.jobTitle;
   }

   public void setJobTitle(final String jobTitle)
   {
      this.jobTitle = jobTitle;
   }
}