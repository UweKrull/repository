package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.recipeadmin.model.Ingredient;
import de.binaris.rest.dto.IngredientDTO;

/**
 * 
 */
@Stateless
@Path("/ingredients")
public class IngredientEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(IngredientDTO dto)
   {
      Ingredient entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(IngredientEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Ingredient entity = em.find(Ingredient.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Ingredient> findByIdQuery = em.createQuery("SELECT DISTINCT i FROM Ingredient i LEFT JOIN FETCH i.recipe LEFT JOIN FETCH i.foodItem LEFT JOIN FETCH i.unit WHERE i.id = :entityId ORDER BY i.id", Ingredient.class);
      findByIdQuery.setParameter("entityId", id);
      Ingredient entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      IngredientDTO dto = new IngredientDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<IngredientDTO> listAll()
   {
      final List<Ingredient> searchResults = em.createQuery("SELECT DISTINCT i FROM Ingredient i LEFT JOIN FETCH i.recipe LEFT JOIN FETCH i.foodItem LEFT JOIN FETCH i.unit ORDER BY i.id", Ingredient.class).getResultList();
      final List<IngredientDTO> results = new ArrayList<IngredientDTO>();
      for (Ingredient searchResult : searchResults)
      {
         IngredientDTO dto = new IngredientDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, IngredientDTO dto)
   {
      TypedQuery<Ingredient> findByIdQuery = em.createQuery("SELECT DISTINCT i FROM Ingredient i LEFT JOIN FETCH i.recipe LEFT JOIN FETCH i.foodItem LEFT JOIN FETCH i.unit WHERE i.id = :entityId ORDER BY i.id", Ingredient.class);
      findByIdQuery.setParameter("entityId", id);
      Ingredient entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}