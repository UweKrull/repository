package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.recipeadmin.model.FoodItem;
import de.binaris.rest.dto.FoodItemDTO;

/**
 * 
 */
@Stateless
@Path("/fooditems")
public class FoodItemEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(FoodItemDTO dto)
   {
      FoodItem entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(FoodItemEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      FoodItem entity = em.find(FoodItem.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<FoodItem> findByIdQuery = em.createQuery("SELECT DISTINCT f FROM FoodItem f WHERE f.id = :entityId ORDER BY f.id", FoodItem.class);
      findByIdQuery.setParameter("entityId", id);
      FoodItem entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      FoodItemDTO dto = new FoodItemDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<FoodItemDTO> listAll()
   {
      final List<FoodItem> searchResults = em.createQuery("SELECT DISTINCT f FROM FoodItem f ORDER BY f.id", FoodItem.class).getResultList();
      final List<FoodItemDTO> results = new ArrayList<FoodItemDTO>();
      for (FoodItem searchResult : searchResults)
      {
         FoodItemDTO dto = new FoodItemDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, FoodItemDTO dto)
   {
      TypedQuery<FoodItem> findByIdQuery = em.createQuery("SELECT DISTINCT f FROM FoodItem f WHERE f.id = :entityId ORDER BY f.id", FoodItem.class);
      findByIdQuery.setParameter("entityId", id);
      FoodItem entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}