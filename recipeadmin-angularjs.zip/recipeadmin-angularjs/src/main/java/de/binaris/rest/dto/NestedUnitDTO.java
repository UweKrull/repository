package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.Unit;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedUnitDTO implements Serializable
{

   private Long id;
   private String name;
   private String abbreviation;

   public NestedUnitDTO()
   {
   }

   public NestedUnitDTO(final Unit entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
         this.abbreviation = entity.getAbbreviation();
      }
   }

   public Unit fromDTO(Unit entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Unit();
      }
      if (this.id != null)
      {
         TypedQuery<Unit> findByIdQuery = em.createQuery(
               "SELECT DISTINCT u FROM Unit u WHERE u.id = :entityId",
               Unit.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity.setAbbreviation(this.abbreviation);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getAbbreviation()
   {
      return this.abbreviation;
   }

   public void setAbbreviation(final String abbreviation)
   {
      this.abbreviation = abbreviation;
   }
}