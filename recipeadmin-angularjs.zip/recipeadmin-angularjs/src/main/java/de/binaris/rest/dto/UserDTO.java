package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.User;
import javax.persistence.EntityManager;
import java.util.Date;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedRecipeDTO;
import de.binaris.recipeadmin.model.Recipe;
import java.util.Iterator;
import de.binaris.rest.dto.AddressDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserDTO implements Serializable
{

   private String middleName;
   private Date dateOfBirth;
   private String lastName;
   private String phone;
   private Set<NestedRecipeDTO> recipe = new HashSet<NestedRecipeDTO>();
   private Date dateOfLeave;
   private String password;
   private Long id;
   private AddressDTO address;
   private String email;
   private Date dateOfEntry;
   private String login;
   private String firstName;
   private String jobTitle;

   public UserDTO()
   {
   }

   public UserDTO(final User entity)
   {
      if (entity != null)
      {
         this.middleName = entity.getMiddleName();
         this.dateOfBirth = entity.getDateOfBirth();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         Iterator<Recipe> iterRecipe = entity.getRecipe().iterator();
         for (; iterRecipe.hasNext();)
         {
            Recipe element = iterRecipe.next();
            this.recipe.add(new NestedRecipeDTO(element));
         }
         this.dateOfLeave = entity.getDateOfLeave();
         this.password = entity.getPassword();
         this.id = entity.getId();
         this.address = new AddressDTO(entity.getAddress());
         this.email = entity.getEmail();
         this.dateOfEntry = entity.getDateOfEntry();
         this.login = entity.getLogin();
         this.firstName = entity.getFirstName();
         this.jobTitle = entity.getJobTitle();
      }
   }

   public User fromDTO(User entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new User();
      }
      entity.setMiddleName(this.middleName);
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      Iterator<Recipe> iterRecipe = entity.getRecipe().iterator();
      for (; iterRecipe.hasNext();)
      {
         boolean found = false;
         Recipe recipe = iterRecipe.next();
         Iterator<NestedRecipeDTO> iterDtoRecipe = this.getRecipe()
               .iterator();
         for (; iterDtoRecipe.hasNext();)
         {
            NestedRecipeDTO dtoRecipe = iterDtoRecipe.next();
            if (dtoRecipe.getId().equals(recipe.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterRecipe.remove();
         }
      }
      Iterator<NestedRecipeDTO> iterDtoRecipe = this.getRecipe().iterator();
      for (; iterDtoRecipe.hasNext();)
      {
         boolean found = false;
         NestedRecipeDTO dtoRecipe = iterDtoRecipe.next();
         iterRecipe = entity.getRecipe().iterator();
         for (; iterRecipe.hasNext();)
         {
            Recipe recipe = iterRecipe.next();
            if (dtoRecipe.getId().equals(recipe.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Recipe> resultIter = em
                  .createQuery("SELECT DISTINCT r FROM Recipe r",
                        Recipe.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Recipe result = resultIter.next();
               if (result.getId().equals(dtoRecipe.getId()))
               {
                  entity.getRecipe().add(result);
                  break;
               }
            }
         }
      }
      entity.setDateOfLeave(this.dateOfLeave);
      entity.setPassword(this.password);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setEmail(this.email);
      entity.setDateOfEntry(this.dateOfEntry);
      entity.setLogin(this.login);
      entity.setFirstName(this.firstName);
      entity.setJobTitle(this.jobTitle);
      entity = em.merge(entity);
      return entity;
   }

   public String getMiddleName()
   {
      return this.middleName;
   }

   public void setMiddleName(final String middleName)
   {
      this.middleName = middleName;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public Set<NestedRecipeDTO> getRecipe()
   {
      return this.recipe;
   }

   public void setRecipe(final Set<NestedRecipeDTO> recipe)
   {
      this.recipe = recipe;
   }

   public Date getDateOfLeave()
   {
      return this.dateOfLeave;
   }

   public void setDateOfLeave(final Date dateOfLeave)
   {
      this.dateOfLeave = dateOfLeave;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public Date getDateOfEntry()
   {
      return this.dateOfEntry;
   }

   public void setDateOfEntry(final Date dateOfEntry)
   {
      this.dateOfEntry = dateOfEntry;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }

   public String getJobTitle()
   {
      return this.jobTitle;
   }

   public void setJobTitle(final String jobTitle)
   {
      this.jobTitle = jobTitle;
   }
}