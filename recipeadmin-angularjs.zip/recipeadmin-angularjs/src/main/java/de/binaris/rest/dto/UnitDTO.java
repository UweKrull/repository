package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.Unit;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UnitDTO implements Serializable
{

   private Long id;
   private String name;
   private String abbreviation;

   public UnitDTO()
   {
   }

   public UnitDTO(final Unit entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
         this.abbreviation = entity.getAbbreviation();
      }
   }

   public Unit fromDTO(Unit entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Unit();
      }
      entity.setName(this.name);
      entity.setAbbreviation(this.abbreviation);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getAbbreviation()
   {
      return this.abbreviation;
   }

   public void setAbbreviation(final String abbreviation)
   {
      this.abbreviation = abbreviation;
   }
}