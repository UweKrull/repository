package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.Recipe;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedRecipeDTO implements Serializable
{

   private Long id;
   private String title;

   public NestedRecipeDTO()
   {
   }

   public NestedRecipeDTO(final Recipe entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
      }
   }

   public Recipe fromDTO(Recipe entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Recipe();
      }
      if (this.id != null)
      {
         TypedQuery<Recipe> findByIdQuery = em.createQuery(
               "SELECT DISTINCT r FROM Recipe r WHERE r.id = :entityId",
               Recipe.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
}