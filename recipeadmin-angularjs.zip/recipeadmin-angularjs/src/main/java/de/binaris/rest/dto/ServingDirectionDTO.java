package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.ServingDirection;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedRecipeDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ServingDirectionDTO implements Serializable
{

   private Long id;
   private String howToServe;
   private NestedRecipeDTO recipe;

   public ServingDirectionDTO()
   {
   }

   public ServingDirectionDTO(final ServingDirection entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.howToServe = entity.getHowToServe();
         this.recipe = new NestedRecipeDTO(entity.getRecipe());
      }
   }

   public ServingDirection fromDTO(ServingDirection entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ServingDirection();
      }
      entity.setHowToServe(this.howToServe);
      if (this.recipe != null)
      {
         entity.setRecipe(this.recipe.fromDTO(entity.getRecipe(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getHowToServe()
   {
      return this.howToServe;
   }

   public void setHowToServe(final String howToServe)
   {
      this.howToServe = howToServe;
   }

   public NestedRecipeDTO getRecipe()
   {
      return this.recipe;
   }

   public void setRecipe(final NestedRecipeDTO recipe)
   {
      this.recipe = recipe;
   }
}