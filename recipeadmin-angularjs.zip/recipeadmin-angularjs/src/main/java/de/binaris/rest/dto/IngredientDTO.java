package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.Ingredient;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedUnitDTO;
import de.binaris.rest.dto.NestedRecipeDTO;
import de.binaris.rest.dto.NestedFoodItemDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class IngredientDTO implements Serializable
{

   private Long id;
   private NestedUnitDTO unit;
   private NestedRecipeDTO recipe;
   private Float quantity;
   private NestedFoodItemDTO foodItem;

   public IngredientDTO()
   {
   }

   public IngredientDTO(final Ingredient entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.unit = new NestedUnitDTO(entity.getUnit());
         this.recipe = new NestedRecipeDTO(entity.getRecipe());
         this.quantity = entity.getQuantity();
         this.foodItem = new NestedFoodItemDTO(entity.getFoodItem());
      }
   }

   public Ingredient fromDTO(Ingredient entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Ingredient();
      }
      if (this.unit != null)
      {
         entity.setUnit(this.unit.fromDTO(entity.getUnit(), em));
      }
      if (this.recipe != null)
      {
         entity.setRecipe(this.recipe.fromDTO(entity.getRecipe(), em));
      }
      entity.setQuantity(this.quantity);
      if (this.foodItem != null)
      {
         entity.setFoodItem(this.foodItem.fromDTO(entity.getFoodItem(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedUnitDTO getUnit()
   {
      return this.unit;
   }

   public void setUnit(final NestedUnitDTO unit)
   {
      this.unit = unit;
   }

   public NestedRecipeDTO getRecipe()
   {
      return this.recipe;
   }

   public void setRecipe(final NestedRecipeDTO recipe)
   {
      this.recipe = recipe;
   }

   public Float getQuantity()
   {
      return this.quantity;
   }

   public void setQuantity(final Float quantity)
   {
      this.quantity = quantity;
   }

   public NestedFoodItemDTO getFoodItem()
   {
      return this.foodItem;
   }

   public void setFoodItem(final NestedFoodItemDTO foodItem)
   {
      this.foodItem = foodItem;
   }
}