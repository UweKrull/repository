package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.recipeadmin.model.ServingDirection;
import de.binaris.rest.dto.ServingDirectionDTO;

/**
 * 
 */
@Stateless
@Path("/servingdirections")
public class ServingDirectionEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(ServingDirectionDTO dto)
   {
      ServingDirection entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(ServingDirectionEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      ServingDirection entity = em.find(ServingDirection.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<ServingDirection> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM ServingDirection s LEFT JOIN FETCH s.recipe WHERE s.id = :entityId ORDER BY s.id", ServingDirection.class);
      findByIdQuery.setParameter("entityId", id);
      ServingDirection entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      ServingDirectionDTO dto = new ServingDirectionDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<ServingDirectionDTO> listAll()
   {
      final List<ServingDirection> searchResults = em.createQuery("SELECT DISTINCT s FROM ServingDirection s LEFT JOIN FETCH s.recipe ORDER BY s.id", ServingDirection.class).getResultList();
      final List<ServingDirectionDTO> results = new ArrayList<ServingDirectionDTO>();
      for (ServingDirection searchResult : searchResults)
      {
         ServingDirectionDTO dto = new ServingDirectionDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, ServingDirectionDTO dto)
   {
      TypedQuery<ServingDirection> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM ServingDirection s LEFT JOIN FETCH s.recipe WHERE s.id = :entityId ORDER BY s.id", ServingDirection.class);
      findByIdQuery.setParameter("entityId", id);
      ServingDirection entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}