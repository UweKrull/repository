'use strict';

angular.module('recipeadminangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/FoodItems',{templateUrl:'views/FoodItem/search.html',controller:'SearchFoodItemController'})
      .when('/FoodItems/new',{templateUrl:'views/FoodItem/detail.html',controller:'NewFoodItemController'})
      .when('/FoodItems/edit/:FoodItemId',{templateUrl:'views/FoodItem/detail.html',controller:'EditFoodItemController'})
      .when('/Ingredients',{templateUrl:'views/Ingredient/search.html',controller:'SearchIngredientController'})
      .when('/Ingredients/new',{templateUrl:'views/Ingredient/detail.html',controller:'NewIngredientController'})
      .when('/Ingredients/edit/:IngredientId',{templateUrl:'views/Ingredient/detail.html',controller:'EditIngredientController'})
      .when('/PreparationDirections',{templateUrl:'views/PreparationDirection/search.html',controller:'SearchPreparationDirectionController'})
      .when('/PreparationDirections/new',{templateUrl:'views/PreparationDirection/detail.html',controller:'NewPreparationDirectionController'})
      .when('/PreparationDirections/edit/:PreparationDirectionId',{templateUrl:'views/PreparationDirection/detail.html',controller:'EditPreparationDirectionController'})
      .when('/Recipes',{templateUrl:'views/Recipe/search.html',controller:'SearchRecipeController'})
      .when('/Recipes/new',{templateUrl:'views/Recipe/detail.html',controller:'NewRecipeController'})
      .when('/Recipes/edit/:RecipeId',{templateUrl:'views/Recipe/detail.html',controller:'EditRecipeController'})
      .when('/ServingDirections',{templateUrl:'views/ServingDirection/search.html',controller:'SearchServingDirectionController'})
      .when('/ServingDirections/new',{templateUrl:'views/ServingDirection/detail.html',controller:'NewServingDirectionController'})
      .when('/ServingDirections/edit/:ServingDirectionId',{templateUrl:'views/ServingDirection/detail.html',controller:'EditServingDirectionController'})
      .when('/Units',{templateUrl:'views/Unit/search.html',controller:'SearchUnitController'})
      .when('/Units/new',{templateUrl:'views/Unit/detail.html',controller:'NewUnitController'})
      .when('/Units/edit/:UnitId',{templateUrl:'views/Unit/detail.html',controller:'EditUnitController'})
      .when('/Users',{templateUrl:'views/User/search.html',controller:'SearchUserController'})
      .when('/Users/new',{templateUrl:'views/User/detail.html',controller:'NewUserController'})
      .when('/Users/edit/:UserId',{templateUrl:'views/User/detail.html',controller:'EditUserController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
