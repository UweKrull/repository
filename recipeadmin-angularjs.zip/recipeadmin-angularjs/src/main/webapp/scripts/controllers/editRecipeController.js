

angular.module('recipeadminangularjs').controller('EditRecipeController', function($scope, $routeParams, $location, RecipeResource , UserResource, CategoryResource, IngredientResource, PreparationDirectionResource, ServingDirectionResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.recipe = new RecipeResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.recipe.user && item.id == $scope.recipe.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.recipe.user = wrappedObject;
                        self.original.user = $scope.recipe.user;
                    }
                    return labelObject;
                });
            });
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.recipe.category){
                        $.each($scope.recipe.category, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.categorySelection.push(labelObject);
                                $scope.recipe.category.push(wrappedObject);
                            }
                        });
                        self.original.category = $scope.recipe.category;
                    }
                    return labelObject;
                });
            });
            IngredientResource.queryAll(function(items) {
                $scope.ingredientSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.foodItem.name+' '+item.quantity+' '+item.unit.name+' '+item.unit.abbreviation
                    };
                    if($scope.recipe.ingredient){
                        $.each($scope.recipe.ingredient, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.ingredientSelection.push(labelObject);
                                $scope.recipe.ingredient.push(wrappedObject);
                            }
                        });
                        self.original.ingredient = $scope.recipe.ingredient;
                    }
                    return labelObject;
                });
            });
            PreparationDirectionResource.queryAll(function(items) {
                $scope.preparationDirectionSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.howToPrepare
                    };
                    if($scope.recipe.preparationDirection){
                        $.each($scope.recipe.preparationDirection, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.preparationDirectionSelection.push(labelObject);
                                $scope.recipe.preparationDirection.push(wrappedObject);
                            }
                        });
                        self.original.preparationDirection = $scope.recipe.preparationDirection;
                    }
                    return labelObject;
                });
            });
            ServingDirectionResource.queryAll(function(items) {
                $scope.servingDirectionSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.howToServe
                    };
                    if($scope.recipe.servingDirection){
                        $.each($scope.recipe.servingDirection, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.servingDirectionSelection.push(labelObject);
                                $scope.recipe.servingDirection.push(wrappedObject);
                            }
                        });
                        self.original.servingDirection = $scope.recipe.servingDirection;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Recipes");
        };
        RecipeResource.get({RecipeId:$routeParams.RecipeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.recipe);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.recipe.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Recipes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Recipes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.recipe.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recipe.user = {};
            $scope.recipe.user.id = selection.value;
        }
    });
    $scope.categorySelection = $scope.categorySelection || [];
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.recipe) {
            $scope.recipe.category = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.recipe.category.push(collectionItem);
            });
        }
    });
    $scope.ingredientSelection = $scope.ingredientSelection || [];
    $scope.$watch("ingredientSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.recipe) {
            $scope.recipe.ingredient = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.recipe.ingredient.push(collectionItem);
            });
        }
    });
    $scope.preparationDirectionSelection = $scope.preparationDirectionSelection || [];
    $scope.$watch("preparationDirectionSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.recipe) {
            $scope.recipe.preparationDirection = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.recipe.preparationDirection.push(collectionItem);
            });
        }
    });
    $scope.servingDirectionSelection = $scope.servingDirectionSelection || [];
    $scope.$watch("servingDirectionSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.recipe) {
            $scope.recipe.servingDirection = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.recipe.servingDirection.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});