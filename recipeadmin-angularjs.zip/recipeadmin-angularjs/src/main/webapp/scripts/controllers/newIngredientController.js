
angular.module('recipeadminangularjs').controller('NewIngredientController', function ($scope, $location, locationParser, IngredientResource , RecipeResource, FoodItemResource, UnitResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.ingredient = $scope.ingredient || {};
    
    $scope.recipeList = RecipeResource.queryAll(function(items){
        $scope.recipeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("recipeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.ingredient.recipe = {};
            $scope.ingredient.recipe.id = selection.value;
        }
    });
    
    $scope.foodItemList = FoodItemResource.queryAll(function(items){
        $scope.foodItemSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("foodItemSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.ingredient.foodItem = {};
            $scope.ingredient.foodItem.id = selection.value;
        }
    });
    
    $scope.unitList = UnitResource.queryAll(function(items){
        $scope.unitSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("unitSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.ingredient.unit = {};
            $scope.ingredient.unit.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Ingredients/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        IngredientResource.save($scope.ingredient, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Ingredients");
    };
});