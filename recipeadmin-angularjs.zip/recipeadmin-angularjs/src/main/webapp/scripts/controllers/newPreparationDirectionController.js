
angular.module('recipeadminangularjs').controller('NewPreparationDirectionController', function ($scope, $location, locationParser, PreparationDirectionResource , RecipeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.preparationDirection = $scope.preparationDirection || {};
    
    $scope.recipeList = RecipeResource.queryAll(function(items){
        $scope.recipeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("recipeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.preparationDirection.recipe = {};
            $scope.preparationDirection.recipe.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/PreparationDirections/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PreparationDirectionResource.save($scope.preparationDirection, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/PreparationDirections");
    };
});