

angular.module('recipeadminangularjs').controller('EditServingDirectionController', function($scope, $routeParams, $location, ServingDirectionResource , RecipeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.servingDirection = new ServingDirectionResource(self.original);
            RecipeResource.queryAll(function(items) {
                $scope.recipeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.servingDirection.recipe && item.id == $scope.servingDirection.recipe.id) {
                        $scope.recipeSelection = labelObject;
                        $scope.servingDirection.recipe = wrappedObject;
                        self.original.recipe = $scope.servingDirection.recipe;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/ServingDirections");
        };
        ServingDirectionResource.get({ServingDirectionId:$routeParams.ServingDirectionId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.servingDirection);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.servingDirection.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/ServingDirections");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/ServingDirections");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.servingDirection.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("recipeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.servingDirection.recipe = {};
            $scope.servingDirection.recipe.id = selection.value;
        }
    });
    
    $scope.get();
});