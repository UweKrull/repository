
angular.module('recipeadminangularjs').controller('NewServingDirectionController', function ($scope, $location, locationParser, ServingDirectionResource , RecipeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.servingDirection = $scope.servingDirection || {};
    
    $scope.recipeList = RecipeResource.queryAll(function(items){
        $scope.recipeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("recipeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.servingDirection.recipe = {};
            $scope.servingDirection.recipe.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/ServingDirections/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ServingDirectionResource.save($scope.servingDirection, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/ServingDirections");
    };
});