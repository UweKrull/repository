
angular.module('recipeadminangularjs').controller('NewCategoryController', function ($scope, $location, locationParser, CategoryResource , RecipeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.category = $scope.category || {};
    
    $scope.recipeList = RecipeResource.queryAll(function(items){
        $scope.recipeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("recipeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.category.recipe = {};
            $scope.category.recipe.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Categorys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CategoryResource.save($scope.category, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Categorys");
    };
});