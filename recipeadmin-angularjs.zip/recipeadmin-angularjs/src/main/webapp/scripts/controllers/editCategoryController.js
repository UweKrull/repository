

angular.module('recipeadminangularjs').controller('EditCategoryController', function($scope, $routeParams, $location, CategoryResource , RecipeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.category = new CategoryResource(self.original);
            RecipeResource.queryAll(function(items) {
                $scope.recipeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.category.recipe && item.id == $scope.category.recipe.id) {
                        $scope.recipeSelection = labelObject;
                        $scope.category.recipe = wrappedObject;
                        self.original.recipe = $scope.category.recipe;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Categorys");
        };
        CategoryResource.get({CategoryId:$routeParams.CategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.category);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.category.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Categorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Categorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.category.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("recipeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.category.recipe = {};
            $scope.category.recipe.id = selection.value;
        }
    });
    
    $scope.get();
});