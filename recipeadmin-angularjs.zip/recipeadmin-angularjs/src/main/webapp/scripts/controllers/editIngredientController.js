

angular.module('recipeadminangularjs').controller('EditIngredientController', function($scope, $routeParams, $location, IngredientResource , RecipeResource, FoodItemResource, UnitResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.ingredient = new IngredientResource(self.original);
            RecipeResource.queryAll(function(items) {
                $scope.recipeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.ingredient.recipe && item.id == $scope.ingredient.recipe.id) {
                        $scope.recipeSelection = labelObject;
                        $scope.ingredient.recipe = wrappedObject;
                        self.original.recipe = $scope.ingredient.recipe;
                    }
                    return labelObject;
                });
            });
            FoodItemResource.queryAll(function(items) {
                $scope.foodItemSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.ingredient.foodItem && item.id == $scope.ingredient.foodItem.id) {
                        $scope.foodItemSelection = labelObject;
                        $scope.ingredient.foodItem = wrappedObject;
                        self.original.foodItem = $scope.ingredient.foodItem;
                    }
                    return labelObject;
                });
            });
            UnitResource.queryAll(function(items) {
                $scope.unitSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.ingredient.unit && item.id == $scope.ingredient.unit.id) {
                        $scope.unitSelection = labelObject;
                        $scope.ingredient.unit = wrappedObject;
                        self.original.unit = $scope.ingredient.unit;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Ingredients");
        };
        IngredientResource.get({IngredientId:$routeParams.IngredientId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.ingredient);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.ingredient.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Ingredients");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Ingredients");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.ingredient.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("recipeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.ingredient.recipe = {};
            $scope.ingredient.recipe.id = selection.value;
        }
    });
    $scope.$watch("foodItemSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.ingredient.foodItem = {};
            $scope.ingredient.foodItem.id = selection.value;
        }
    });
    $scope.$watch("unitSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.ingredient.unit = {};
            $scope.ingredient.unit.id = selection.value;
        }
    });
    
    $scope.get();
});