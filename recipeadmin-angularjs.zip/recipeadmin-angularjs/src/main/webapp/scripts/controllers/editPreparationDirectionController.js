

angular.module('recipeadminangularjs').controller('EditPreparationDirectionController', function($scope, $routeParams, $location, PreparationDirectionResource , RecipeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.preparationDirection = new PreparationDirectionResource(self.original);
            RecipeResource.queryAll(function(items) {
                $scope.recipeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.preparationDirection.recipe && item.id == $scope.preparationDirection.recipe.id) {
                        $scope.recipeSelection = labelObject;
                        $scope.preparationDirection.recipe = wrappedObject;
                        self.original.recipe = $scope.preparationDirection.recipe;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/PreparationDirections");
        };
        PreparationDirectionResource.get({PreparationDirectionId:$routeParams.PreparationDirectionId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.preparationDirection);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.preparationDirection.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PreparationDirections");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PreparationDirections");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.preparationDirection.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("recipeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.preparationDirection.recipe = {};
            $scope.preparationDirection.recipe.id = selection.value;
        }
    });
    
    $scope.get();
});