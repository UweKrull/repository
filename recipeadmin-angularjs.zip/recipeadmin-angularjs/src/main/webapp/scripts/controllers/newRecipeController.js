
angular.module('recipeadminangularjs').controller('NewRecipeController', function ($scope, $location, locationParser, RecipeResource , UserResource, CategoryResource, IngredientResource, PreparationDirectionResource, ServingDirectionResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.recipe = $scope.recipe || {};
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.recipe.user = {};
            $scope.recipe.user.id = selection.value;
        }
    });
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recipe.category = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.recipe.category.push(collectionItem);
            });
        }
    });
    
    $scope.ingredientList = IngredientResource.queryAll(function(items){
        $scope.ingredientSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.foodItem.name+' '+item.quantity+' '+item.unit.name+' '+item.unit.abbreviation
            });
        });
    });
    $scope.$watch("ingredientSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recipe.ingredient = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.recipe.ingredient.push(collectionItem);
            });
        }
    });
    
    $scope.preparationDirectionList = PreparationDirectionResource.queryAll(function(items){
        $scope.preparationDirectionSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.howToPrepare
            });
        });
    });
    $scope.$watch("preparationDirectionSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recipe.preparationDirection = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.recipe.preparationDirection.push(collectionItem);
            });
        }
    });
    
    $scope.servingDirectionList = ServingDirectionResource.queryAll(function(items){
        $scope.servingDirectionSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.howToServe
            });
        });
    });
    $scope.$watch("servingDirectionSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recipe.servingDirection = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.recipe.servingDirection.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Recipes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        RecipeResource.save($scope.recipe, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Recipes");
    };
});