

angular.module('recipeadminangularjs').controller('EditFoodItemController', function($scope, $routeParams, $location, FoodItemResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.foodItem = new FoodItemResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/FoodItems");
        };
        FoodItemResource.get({FoodItemId:$routeParams.FoodItemId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.foodItem);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.foodItem.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/FoodItems");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/FoodItems");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.foodItem.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});