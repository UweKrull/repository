
angular.module('recipeadminangularjs').controller('NewUnitController', function ($scope, $location, locationParser, UnitResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.unit = $scope.unit || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Units/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        UnitResource.save($scope.unit, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Units");
    };
});