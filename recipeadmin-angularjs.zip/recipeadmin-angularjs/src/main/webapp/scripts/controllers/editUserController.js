

angular.module('recipeadminangularjs').controller('EditUserController', function($scope, $routeParams, $location, UserResource , RecipeResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.user = new UserResource(self.original);
            RecipeResource.queryAll(function(items) {
                $scope.recipeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.user.recipe){
                        $.each($scope.user.recipe, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.recipeSelection.push(labelObject);
                                $scope.user.recipe.push(wrappedObject);
                            }
                        });
                        self.original.recipe = $scope.user.recipe;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.user.address.country && item.id == $scope.user.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.user.address.country = wrappedObject;
                        self.original.address.country = $scope.user.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Users");
        };
        UserResource.get({UserId:$routeParams.UserId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.user);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.user.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Users");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Users");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.user.$remove(successCallback, errorCallback);
    };
    
    $scope.recipeSelection = $scope.recipeSelection || [];
    $scope.$watch("recipeSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.user) {
            $scope.user.recipe = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.recipe.push(collectionItem);
            });
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.user.address.country = {};
            $scope.user.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});