
angular.module('recipeadminangularjs').controller('NewFoodItemController', function ($scope, $location, locationParser, FoodItemResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.foodItem = $scope.foodItem || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/FoodItems/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        FoodItemResource.save($scope.foodItem, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/FoodItems");
    };
});