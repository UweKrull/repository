angular.module('recipeadminangularjs').factory('PreparationDirectionResource', function($resource){
    var resource = $resource('rest/preparationdirections/:PreparationDirectionId',{PreparationDirectionId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});