angular.module('recipeadminangularjs').factory('ServingDirectionResource', function($resource){
    var resource = $resource('rest/servingdirections/:ServingDirectionId',{ServingDirectionId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});