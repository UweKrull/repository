package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;
import de.binaris.appointmentplanner.model.Participant;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedParticipantDTO implements Serializable
{

   private String aliasName;
   private Long id;

   public NestedParticipantDTO()
   {
   }

   public NestedParticipantDTO(final Participant entity)
   {
      if (entity != null)
      {
         this.aliasName = entity.getAliasName();
         this.id = entity.getId();
      }
   }

   public Participant fromDTO(Participant entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Participant();
      }
      if (this.id != null)
      {
         TypedQuery<Participant> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT p FROM Participant p WHERE p.id = :entityId",
                     Participant.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setAliasName(this.aliasName);
      entity = em.merge(entity);
      return entity;
   }

   public String getAliasName()
   {
      return this.aliasName;
   }

   public void setAliasName(final String aliasName)
   {
      this.aliasName = aliasName;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }
}