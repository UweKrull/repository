package de.binaris.appointmentplanner.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "appointment")
public class Appointment implements Serializable {

	private static final long serialVersionUID = 5567452931679823322L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_appointment")
	@SequenceGenerator(name = "my_entity_seq_gen_appointment", sequenceName = "sequence_appointment", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
	private String timeRangeAsString;
	
	@ManyToOne
	private AppointmentCategory appointmentCategory;
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "appointment")
	private Set<ParticipantList> participantList = new HashSet<ParticipantList>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTimeRangeAsString() {
		return timeRangeAsString;
	}

	public void setTimeRangeAsString(String timeRangeAsString) {
		this.timeRangeAsString = timeRangeAsString;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public AppointmentCategory getAppointmentCategory() {
		return appointmentCategory;
	}
	
	public void setAppointmentCategory(AppointmentCategory appointmentCategory) {
		this.appointmentCategory = appointmentCategory;
	}
	
	public Set<ParticipantList> getParticipantList() {
		return participantList;
	}
	
	public void setParticipantList(Set<ParticipantList> participantList) {
		this.participantList = participantList;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Appointment)) {
			return false;
		}
		Appointment castOther = (Appointment) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(appointmentCategory.getName());
		sb.append(", ");
		sb.append(name);
		return sb.toString();
	}
}
