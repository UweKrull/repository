package de.binaris.appointmentplanner.login;

import java.util.Map;

import javax.enterprise.context.spi.CreationalContext;
import javax.enterprise.inject.spi.Bean;
import javax.enterprise.inject.spi.BeanManager;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import de.binaris.appointmentplanner.model.Customer;
import de.binaris.appointmentplanner.view.CustomerBean;

public class SimpleLoginModule implements LoginModule {

    private CallbackHandler callbackHandler;

    private CustomerBean customerService;

    private BeanManager beanManager;

    @SuppressWarnings("rawtypes")
    private CustomerBean getCustomerService() {
        if (customerService != null) {
            return customerService;
        }
        try {
            Context context = new InitialContext();
            beanManager = (BeanManager) context.lookup("java:comp/BeanManager");
            Bean<?> bean = beanManager.getBeans(CustomerBean.class).iterator().next();
			CreationalContext cc = beanManager.createCreationalContext(bean);
            customerService = (CustomerBean) beanManager.getReference(bean, CustomerBean.class, cc);

        } catch (NamingException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        return customerService;
    }

    @Override
    public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> stringMap, Map<String, ?> stringMap1) {
        this.callbackHandler = callbackHandler;
        getCustomerService();
    }

    @Override
    public boolean login() throws LoginException {

        NameCallback nameCallback = new NameCallback("Name : ");
        PasswordCallback passwordCallback = new PasswordCallback("Password : ", false);
        try {
            callbackHandler.handle(new Callback[]{nameCallback, passwordCallback});
            String username = nameCallback.getName();
            String password = new String(passwordCallback.getPassword());
            nameCallback.setName("");
            passwordCallback.clearPassword();
            Customer customer = customerService.findCustomer(username, password);

            if (customer == null) {
                throw new LoginException("Authentication failed");
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            throw new LoginException(e.getMessage());
        }
    }

    @Override
    public boolean commit() throws LoginException {
        return true;
    }

    @Override
    public boolean abort() throws LoginException {
        return true;
    }

    @Override
    public boolean logout() throws LoginException {
        return true;
    }
}