package de.binaris.appointmentplanner.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.appointmentplanner.model.GeneralAvailability;
import de.binaris.appointmentplanner.rest.dto.GeneralAvailabilityDTO;

/**
 * 
 */
@Stateless
@Path("/generalavailabilitys")
public class GeneralAvailabilityEndpoint
{
   @PersistenceContext(unitName = "AppointmentplannerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(GeneralAvailabilityDTO dto)
   {
      GeneralAvailability entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(GeneralAvailabilityEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      GeneralAvailability entity = em.find(GeneralAvailability.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<GeneralAvailability> findByIdQuery = em.createQuery("SELECT DISTINCT g FROM GeneralAvailability g WHERE g.id = :entityId ORDER BY g.id", GeneralAvailability.class);
      findByIdQuery.setParameter("entityId", id);
      GeneralAvailability entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      GeneralAvailabilityDTO dto = new GeneralAvailabilityDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<GeneralAvailabilityDTO> listAll()
   {
      final List<GeneralAvailability> searchResults = em.createQuery("SELECT DISTINCT g FROM GeneralAvailability g ORDER BY g.id", GeneralAvailability.class).getResultList();
      final List<GeneralAvailabilityDTO> results = new ArrayList<GeneralAvailabilityDTO>();
      for (GeneralAvailability searchResult : searchResults)
      {
         GeneralAvailabilityDTO dto = new GeneralAvailabilityDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, GeneralAvailabilityDTO dto)
   {
      TypedQuery<GeneralAvailability> findByIdQuery = em.createQuery("SELECT DISTINCT g FROM GeneralAvailability g WHERE g.id = :entityId ORDER BY g.id", GeneralAvailability.class);
      findByIdQuery.setParameter("entityId", id);
      GeneralAvailability entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}