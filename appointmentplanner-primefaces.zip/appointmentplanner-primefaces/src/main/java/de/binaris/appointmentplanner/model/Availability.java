package de.binaris.appointmentplanner.model;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

@Cacheable
@Entity
@Table(name = "availability")
public class Availability implements Serializable {

	private static final long serialVersionUID = 2177552237175529555L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_availability")
	@SequenceGenerator(name = "my_entity_seq_gen_availability", sequenceName = "sequence_availability", allocationSize = 1)
	private Long id;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_date_time", updatable = true)
	private Date startDateTime;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_date_time", updatable = true)
	private Date endDateTime;
	
	@ManyToOne
	private GeneralAvailability generalAvailability;

	@ManyToOne
	private AvailabilityType availabilityDay1;
	
	@ManyToOne
	private AvailabilityType availabilityDay2;
	
	@ManyToOne
	private AvailabilityType availabilityDay3;
	
	@ManyToOne
	private AvailabilityType availabilityDay4;
	
	@ManyToOne
	private AvailabilityType availabilityDay5;
	
	@ManyToOne
	private AvailabilityType availabilityDay6;
	
	@ManyToOne
	private AvailabilityType availabilityDay7;
	
	@ManyToOne
	private AvailabilityType availabilityDay8;
	
	@ManyToOne
	private AvailabilityType availabilityDay9;
	
	@ManyToOne
	private AvailabilityType availabilityDay10;
	
	@ManyToOne
	private AvailabilityType availabilityDay11;
	
	@ManyToOne
	private AvailabilityType availabilityDay12;
	
	@ManyToOne
	private AvailabilityType availabilityDay13;
	
	@ManyToOne
	private AvailabilityType availabilityDay14;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	public Date getEndDateTime() {
		return endDateTime;
	}

	public void setEndDateTime(Date endDateTime) {
		this.endDateTime = endDateTime;
	}

	public GeneralAvailability getGeneralAvailability() {
		return generalAvailability;
	}

	public void setGeneralAvailability(GeneralAvailability generalAvailability) {
		this.generalAvailability = generalAvailability;
	}

	public AvailabilityType getAvailabilityDay1() {
		return availabilityDay1;
	}

	public void setAvailabilityDay1(AvailabilityType availabilityDay1) {
		this.availabilityDay1 = availabilityDay1;
	}

	public AvailabilityType getAvailabilityDay2() {
		return availabilityDay2;
	}

	public void setAvailabilityDay2(AvailabilityType availabilityDay2) {
		this.availabilityDay2 = availabilityDay2;
	}

	public AvailabilityType getAvailabilityDay3() {
		return availabilityDay3;
	}

	public void setAvailabilityDay3(AvailabilityType availabilityDay3) {
		this.availabilityDay3 = availabilityDay3;
	}

	public AvailabilityType getAvailabilityDay4() {
		return availabilityDay4;
	}

	public void setAvailabilityDay4(AvailabilityType availabilityDay4) {
		this.availabilityDay4 = availabilityDay4;
	}

	public AvailabilityType getAvailabilityDay5() {
		return availabilityDay5;
	}

	public void setAvailabilityDay5(AvailabilityType availabilityDay5) {
		this.availabilityDay5 = availabilityDay5;
	}

	public AvailabilityType getAvailabilityDay6() {
		return availabilityDay6;
	}

	public void setAvailabilityDay6(AvailabilityType availabilityDay6) {
		this.availabilityDay6 = availabilityDay6;
	}

	public AvailabilityType getAvailabilityDay7() {
		return availabilityDay7;
	}

	public void setAvailabilityDay7(AvailabilityType availabilityDay7) {
		this.availabilityDay7 = availabilityDay7;
	}

	public AvailabilityType getAvailabilityDay8() {
		return availabilityDay8;
	}

	public void setAvailabilityDay8(AvailabilityType availabilityDay8) {
		this.availabilityDay8 = availabilityDay8;
	}

	public AvailabilityType getAvailabilityDay9() {
		return availabilityDay9;
	}

	public void setAvailabilityDay9(AvailabilityType availabilityDay9) {
		this.availabilityDay9 = availabilityDay9;
	}

	public AvailabilityType getAvailabilityDay10() {
		return availabilityDay10;
	}

	public void setAvailabilityDay10(AvailabilityType availabilityDay10) {
		this.availabilityDay10 = availabilityDay10;
	}

	public AvailabilityType getAvailabilityDay11() {
		return availabilityDay11;
	}

	public void setAvailabilityDay11(AvailabilityType availabilityDay11) {
		this.availabilityDay11 = availabilityDay11;
	}

	public AvailabilityType getAvailabilityDay12() {
		return availabilityDay12;
	}

	public void setAvailabilityDay12(AvailabilityType availabilityDay12) {
		this.availabilityDay12 = availabilityDay12;
	}

	public AvailabilityType getAvailabilityDay13() {
		return availabilityDay13;
	}

	public void setAvailabilityDay13(AvailabilityType availabilityDay13) {
		this.availabilityDay13 = availabilityDay13;
	}

	public AvailabilityType getAvailabilityDay14() {
		return availabilityDay14;
	}

	public void setAvailabilityDay14(AvailabilityType availabilityDay14) {
		this.availabilityDay14 = availabilityDay14;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Availability)) {
			return false;
		}
		Availability castOther = (Availability) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final DateFormat df = new SimpleDateFormat("dd.MM.yyyy HH:mm");
		final StringBuilder sb = new StringBuilder();
		sb.append(df.format(startDateTime));
		sb.append(" - ");
		sb.append(df.format(endDateTime));
		return sb.toString();
	}
}
