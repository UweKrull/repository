package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;
import de.binaris.appointmentplanner.model.GeneralAvailability;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class GeneralAvailabilityDTO implements Serializable
{

   private Long id;
   private String name;

   public GeneralAvailabilityDTO()
   {
   }

   public GeneralAvailabilityDTO(final GeneralAvailability entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public GeneralAvailability fromDTO(GeneralAvailability entity,
         EntityManager em)
   {
      if (entity == null)
      {
         entity = new GeneralAvailability();
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}