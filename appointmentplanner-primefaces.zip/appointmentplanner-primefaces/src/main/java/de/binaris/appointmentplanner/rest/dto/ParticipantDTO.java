package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;

import de.binaris.appointmentplanner.model.Participant;
import de.binaris.appointmentplanner.rest.dto.NestedAvailabilityDTO;
import de.binaris.appointmentplanner.rest.dto.NestedCustomerDTO;
import de.binaris.appointmentplanner.rest.dto.NestedParticipantListDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ParticipantDTO implements Serializable
{

   private String aliasName;
   private Long id;
   private NestedParticipantListDTO participantList;
   private NestedCustomerDTO customer;
   private NestedAvailabilityDTO availability;

   public ParticipantDTO()
   {
   }

   public ParticipantDTO(final Participant entity)
   {
      if (entity != null)
      {
         this.aliasName = entity.getAliasName();
         this.id = entity.getId();
         this.participantList = new NestedParticipantListDTO(
               entity.getParticipantList());
         this.customer = new NestedCustomerDTO(entity.getCustomer());
         this.availability = new NestedAvailabilityDTO(
               entity.getAvailability());
      }
   }

   public Participant fromDTO(Participant entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Participant();
      }
      entity.setAliasName(this.aliasName);
      if (this.participantList != null)
      {
         entity.setParticipantList(this.participantList.fromDTO(
               entity.getParticipantList(), em));
      }
      if (this.customer != null)
      {
         entity.setCustomer(this.customer.fromDTO(entity.getCustomer(), em));
      }
      if (this.availability != null)
      {
         entity.setAvailability(this.availability.fromDTO(
               entity.getAvailability(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public String getAliasName()
   {
      return this.aliasName;
   }

   public void setAliasName(final String aliasName)
   {
      this.aliasName = aliasName;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedParticipantListDTO getParticipantList()
   {
      return this.participantList;
   }

   public void setParticipantList(
         final NestedParticipantListDTO participantList)
   {
      this.participantList = participantList;
   }

   public NestedCustomerDTO getCustomer()
   {
      return this.customer;
   }

   public void setCustomer(final NestedCustomerDTO customer)
   {
      this.customer = customer;
   }

   public NestedAvailabilityDTO getAvailability()
   {
      return this.availability;
   }

   public void setAvailability(final NestedAvailabilityDTO availability)
   {
      this.availability = availability;
   }
}