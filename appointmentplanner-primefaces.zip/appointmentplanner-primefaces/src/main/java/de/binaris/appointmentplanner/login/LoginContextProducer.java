package de.binaris.appointmentplanner.login;

import java.net.URISyntaxException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import de.binaris.appointmentplanner.annotations.ConfigProperty;

public class LoginContextProducer {

    @Inject
    private SimpleCallbackHandler callbackHandler;

    @Produces
    public LoginContext produceLoginContext(@ConfigProperty("loginConfigFile") String loginConfigFileName,
                                            @ConfigProperty("loginModuleName") String loginModuleName) throws LoginException, URISyntaxException {

    	Logger.getAnonymousLogger().log(Level.INFO, "loginConfigFileName: " + loginConfigFileName);
    	Logger.getAnonymousLogger().log(Level.INFO, "loginModuleName:     " + loginModuleName);
    	Logger.getAnonymousLogger().log(Level.INFO, "file URI:            " + loginConfigFileName);
    	
        System.setProperty("java.security.auth.login.config", loginConfigFileName);
//      System.setProperty("java.security.auth.login.config", new File(LoginContextProducer.class.getResource(loginConfigFileName).toURI()).getPath());

        try {
            return new LoginContext(loginModuleName, callbackHandler);
        } catch (Exception e) {
            System.out.println("ouch!!!");
            return null;
        }
    }
}