package de.binaris.appointmentplanner.rest.dto;

import java.io.Serializable;
import de.binaris.appointmentplanner.model.Appointment;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedAppointmentDTO implements Serializable
{

   private Long id;
   private String timeRangeAsString;
   private String name;

   public NestedAppointmentDTO()
   {
   }

   public NestedAppointmentDTO(final Appointment entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.timeRangeAsString = entity.getTimeRangeAsString();
         this.name = entity.getName();
      }
   }

   public Appointment fromDTO(Appointment entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Appointment();
      }
      if (this.id != null)
      {
         TypedQuery<Appointment> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT a FROM Appointment a WHERE a.id = :entityId",
                     Appointment.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTimeRangeAsString(this.timeRangeAsString);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTimeRangeAsString()
   {
      return this.timeRangeAsString;
   }

   public void setTimeRangeAsString(final String timeRangeAsString)
   {
      this.timeRangeAsString = timeRangeAsString;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}