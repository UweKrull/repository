package de.binaris.restaurantguide.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.restaurantguide.model.Recommendation;
import de.binaris.restaurantguide.rest.dto.RecommendationDTO;

/**
 * The Recommendation REST service endpoint
 */
@Stateless
@Path("/recommendations")
public class RecommendationEndpoint
{
   @PersistenceContext(unitName = "RestaurantguidePU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(RecommendationDTO dto)
   {
      Recommendation entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(RecommendationEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Recommendation entity = em.find(Recommendation.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Recommendation> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM Recommendation r LEFT JOIN FETCH r.guest LEFT JOIN FETCH r.restaurant WHERE r.id = :entityId ORDER BY r.id", Recommendation.class);
      findByIdQuery.setParameter("entityId", id);
      Recommendation entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      RecommendationDTO dto = new RecommendationDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<RecommendationDTO> listAll()
   {
      final List<Recommendation> searchResults = em.createQuery("SELECT DISTINCT r FROM Recommendation r LEFT JOIN FETCH r.guest LEFT JOIN FETCH r.restaurant ORDER BY r.id", Recommendation.class).getResultList();
      final List<RecommendationDTO> results = new ArrayList<RecommendationDTO>();
      for (Recommendation searchResult : searchResults)
      {
         RecommendationDTO dto = new RecommendationDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, RecommendationDTO dto)
   {
      TypedQuery<Recommendation> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM Recommendation r LEFT JOIN FETCH r.guest LEFT JOIN FETCH r.restaurant WHERE r.id = :entityId ORDER BY r.id", Recommendation.class);
      findByIdQuery.setParameter("entityId", id);
      Recommendation entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}