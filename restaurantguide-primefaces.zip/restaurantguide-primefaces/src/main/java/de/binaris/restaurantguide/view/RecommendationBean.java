package de.binaris.restaurantguide.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import de.binaris.restaurantguide.model.Recommendation;
import de.binaris.restaurantguide.model.Customer;
import de.binaris.restaurantguide.model.RankingType;
import de.binaris.restaurantguide.model.Restaurant;
import de.binaris.restaurantguide.view.RecommendationBean;

/**
 * Backing bean for Recommendation entities.
 * <p>
 * This class provides CRUD functionality for all Recommendation entities. It focuses
 * purely on Java EE 6 standards (e.g. <tt>&#64;ConversationScoped</tt> for
 * state management, <tt>PersistenceContext</tt> for persistence,
 * <tt>CriteriaBuilder</tt> for searches) rather than introducing a CRUD framework or
 * custom base class.
 */

@Named
@Stateful
@ConversationScoped
public class RecommendationBean implements Serializable
{
   private static final long serialVersionUID = 1L;

   /*
    * Support creating and retrieving Recommendation entities
    */

   private Long id;

   public Long getId()
   {
      return this.id;
   }

   public void setId(Long id)
   {
      this.id = id;
   }

   private Recommendation recommendation;

   public Recommendation getRecommendation()
   {
      return this.recommendation;
   }

   @Inject
   private Conversation conversation;

   @PersistenceContext(type = PersistenceContextType.EXTENDED)
   private EntityManager entityManager;

   public String create()
   {

      this.conversation.begin();
      return "create?faces-redirect=true";
   }

   public void retrieve()
   {
      if (FacesContext.getCurrentInstance().isPostback())
      {
         return;
      }

      if (this.conversation.isTransient())
      {
         this.conversation.begin();
      }

      if (this.id == null)
      {
         this.recommendation = this.example;
      }
      else
      {
         this.recommendation = findById(getId());
      }
   }

   public Recommendation findById(Long id)
   {
      return this.entityManager.find(Recommendation.class, id);
   }

   /*
    * Support updating and deleting Recommendation entities
    */
   public String update()
   {
      this.conversation.end();

      try
      {
         if (this.id == null)
         {
            this.entityManager.persist(this.recommendation);
            return "search?faces-redirect=true";
         }
         else
         {
            this.entityManager.merge(this.recommendation);
            return "view?faces-redirect=true&id=" + this.recommendation.getId();
         }
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   public String delete()
   {
      this.conversation.end();

      try
      {
         Recommendation deletableEntity = findById(getId());
         Restaurant restaurant = deletableEntity.getRestaurant();
         restaurant.getRecommendation().remove(deletableEntity);
         deletableEntity.setRestaurant(null);
         this.entityManager.merge(restaurant);
         this.entityManager.remove(deletableEntity);
         this.entityManager.flush();
         return "search?faces-redirect=true";
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   /*
    * Support searching Recommendation entities with pagination
    */

   private int page;
   private long count;
   private List<Recommendation> pageItems;

   private Recommendation example = new Recommendation();

   public int getPage()
   {
      return this.page;
   }

   public void setPage(int page)
   {
      this.page = page;
   }

   public int getPageSize()
   {
      return 10;
   }

   public Recommendation getExample()
   {
      return this.example;
   }

   public void setExample(Recommendation example)
   {
      this.example = example;
   }

   public void search()
   {
      this.page = 0;
   }

   public void paginate()
   {
      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

      // Populate this.count

      CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
      Root<Recommendation> root = countCriteria.from(Recommendation.class);
      countCriteria = countCriteria.select(builder.count(root)).where(
            getSearchPredicates(root));
      this.count = this.entityManager.createQuery(countCriteria)
            .getSingleResult();

      // Populate this.pageItems

      CriteriaQuery<Recommendation> criteria = builder.createQuery(Recommendation.class);
      root = criteria.from(Recommendation.class);
      TypedQuery<Recommendation> query = this.entityManager.createQuery(criteria
            .select(root).where(getSearchPredicates(root)));
      query.setFirstResult(this.page * getPageSize()).setMaxResults(
            getPageSize());
      this.pageItems = query.getResultList();
   }

   private Predicate[] getSearchPredicates(Root<Recommendation> root)
   {
      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
      List<Predicate> predicatesList = new ArrayList<Predicate>();

      String name = this.example.getName();
      if (name != null && !"".equals(name))
      {
         predicatesList.add(builder.like(root.<String> get("name"), '%' + name + '%'));
      }
      Restaurant restaurant = this.example.getRestaurant();
      if (restaurant != null)
      {
         predicatesList.add(builder.equal(root.get("restaurant"), restaurant));
      }
      Customer guest = this.example.getGuest();
      if (guest != null)
      {
         predicatesList.add(builder.equal(root.get("guest"), guest));
      }
      String description = this.example.getDescription();
      if (description != null && !"".equals(description))
      {
         predicatesList.add(builder.like(root.<String> get("description"), '%' + description + '%'));
      }
      RankingType rankingType = this.example.getRankingType();
      if (rankingType != null)
      {
         predicatesList.add(builder.equal(root.get("rankingType"), rankingType));
      }

      return predicatesList.toArray(new Predicate[predicatesList.size()]);
   }

   public List<Recommendation> getPageItems()
   {
      return this.pageItems;
   }

   public long getCount()
   {
      return this.count;
   }

   /*
    * Support listing and POSTing back Recommendation entities (e.g. from inside an
    * HtmlSelectOneMenu)
    */

   public List<Recommendation> getAll()
   {
      CriteriaQuery<Recommendation> criteria = this.entityManager
            .getCriteriaBuilder().createQuery(Recommendation.class);
      return this.entityManager.createQuery(
            criteria.select(criteria.from(Recommendation.class))).getResultList();
   }

   @Resource
   private SessionContext sessionContext;

   public Converter getConverter()
   {
      final RecommendationBean ejbProxy = this.sessionContext.getBusinessObject(RecommendationBean.class);

      return new Converter()
      {
         @Override
         public Object getAsObject(FacesContext context,
               UIComponent component, String value)
         {

            return ejbProxy.findById(Long.valueOf(value));
         }

         @Override
         public String getAsString(FacesContext context,
               UIComponent component, Object value)
         {
            if (value == null)
            {
               return "";
            }

            return String.valueOf(((Recommendation) value).getId());
         }
      };
   }

   /*
    * Support adding children to bidirectional, one-to-many tables
    */
   private Recommendation add = new Recommendation();

   public Recommendation getAdd()
   {
      return this.add;
   }

   public Recommendation getAdded()
   {
      Recommendation added = this.add;
      this.add = new Recommendation();
      return added;
   }
}