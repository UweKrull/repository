package de.binaris.restaurantguide.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.restaurantguide.model.Restaurant;
import de.binaris.restaurantguide.rest.dto.RestaurantDTO;

/**
 * The Restaurant REST service endpoint
 */
@Stateless
@Path("/restaurants")
public class RestaurantEndpoint
{
   @PersistenceContext(unitName = "RestaurantguidePU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(RestaurantDTO dto)
   {
      Restaurant entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(RestaurantEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Restaurant entity = em.find(Restaurant.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Restaurant> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM Restaurant r LEFT JOIN FETCH r.category LEFT JOIN FETCH r.recommendation LEFT JOIN FETCH r.phoneContact LEFT JOIN FETCH r.timesOfService WHERE r.id = :entityId ORDER BY r.id", Restaurant.class);
      findByIdQuery.setParameter("entityId", id);
      Restaurant entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      RestaurantDTO dto = new RestaurantDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<RestaurantDTO> listAll()
   {
      final List<Restaurant> searchResults = em.createQuery("SELECT DISTINCT r FROM Restaurant r LEFT JOIN FETCH r.category LEFT JOIN FETCH r.recommendation LEFT JOIN FETCH r.phoneContact LEFT JOIN FETCH r.timesOfService ORDER BY r.id", Restaurant.class).getResultList();
      final List<RestaurantDTO> results = new ArrayList<RestaurantDTO>();
      for (Restaurant searchResult : searchResults)
      {
         RestaurantDTO dto = new RestaurantDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, RestaurantDTO dto)
   {
      TypedQuery<Restaurant> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM Restaurant r LEFT JOIN FETCH r.category LEFT JOIN FETCH r.recommendation LEFT JOIN FETCH r.phoneContact LEFT JOIN FETCH r.timesOfService WHERE r.id = :entityId ORDER BY r.id", Restaurant.class);
      findByIdQuery.setParameter("entityId", id);
      Restaurant entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}