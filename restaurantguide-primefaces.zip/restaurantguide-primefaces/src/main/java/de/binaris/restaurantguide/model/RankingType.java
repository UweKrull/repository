package de.binaris.restaurantguide.model;

/**
 * <p>
 * The {@link RankingType} describes the ranking types
 * 
 * Ranking is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the partner types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link RankingType} describes whether or not the
 * restaurant is outstanding.
 * </p>
 */
public enum RankingType {

    /**
     * The RankingType of the recommendation.
     */
	OUTSTANDING("outstanding", true, 5),
	EXCELLENT("excellent", true, 4),
	GOOD("good", true, 3),
	AVERAGE("average", true, 2),
	POOR("poor", true, 1),
	DREADFUL("dreadful", true, 0);

    /**
     * A human readable description of the ranking type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the adult-only type can be cached.
     */
    private final boolean cacheable;
    
    private final int orderseq;
    
    private RankingType(String description, boolean cacheable, int orderseq) {
        this.description = description;
        this.cacheable = cacheable;
        this.orderseq = orderseq;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
    
    public int getOrderseq() {
    	return orderseq;
    }
    
    @Override
    public String toString() {
    	return description;
    }
}
