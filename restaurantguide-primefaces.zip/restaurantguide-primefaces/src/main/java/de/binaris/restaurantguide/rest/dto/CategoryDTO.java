package de.binaris.restaurantguide.rest.dto;

import java.io.Serializable;

import de.binaris.restaurantguide.model.Category;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.restaurantguide.model.Restaurant;
import de.binaris.restaurantguide.rest.dto.NestedRestaurantDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable
{

   private Long id;
   private String description;
   private String name;
   private Set<NestedRestaurantDTO> restaurant = new HashSet<NestedRestaurantDTO>();

   public CategoryDTO()
   {
   }

   public CategoryDTO(final Category entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         Iterator<Restaurant> iterRestaurant = entity.getRestaurant()
               .iterator();
         for (; iterRestaurant.hasNext();)
         {
            Restaurant element = iterRestaurant.next();
            this.restaurant.add(new NestedRestaurantDTO(element));
         }
      }
   }

   public Category fromDTO(Category entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Category();
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      Iterator<Restaurant> iterRestaurant = entity.getRestaurant().iterator();
      for (; iterRestaurant.hasNext();)
      {
         boolean found = false;
         Restaurant restaurant = iterRestaurant.next();
         Iterator<NestedRestaurantDTO> iterDtoRestaurant = this
               .getRestaurant().iterator();
         for (; iterDtoRestaurant.hasNext();)
         {
            NestedRestaurantDTO dtoRestaurant = iterDtoRestaurant.next();
            if (dtoRestaurant.getId().equals(restaurant.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterRestaurant.remove();
         }
      }
      Iterator<NestedRestaurantDTO> iterDtoRestaurant = this.getRestaurant()
            .iterator();
      for (; iterDtoRestaurant.hasNext();)
      {
         boolean found = false;
         NestedRestaurantDTO dtoRestaurant = iterDtoRestaurant.next();
         iterRestaurant = entity.getRestaurant().iterator();
         for (; iterRestaurant.hasNext();)
         {
            Restaurant restaurant = iterRestaurant.next();
            if (dtoRestaurant.getId().equals(restaurant.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Restaurant> resultIter = em
                  .createQuery("SELECT DISTINCT r FROM Restaurant r",
                        Restaurant.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Restaurant result = resultIter.next();
               if (result.getId().equals(dtoRestaurant.getId()))
               {
                  entity.getRestaurant().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Set<NestedRestaurantDTO> getRestaurant()
   {
      return this.restaurant;
   }

   public void setRestaurant(final Set<NestedRestaurantDTO> restaurant)
   {
      this.restaurant = restaurant;
   }
}