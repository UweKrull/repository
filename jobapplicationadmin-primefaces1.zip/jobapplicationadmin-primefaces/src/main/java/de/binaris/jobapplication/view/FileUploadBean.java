package de.binaris.jobapplication.view;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.event.ValueChangeEvent;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;
import org.primefaces.model.UploadedFile;
import org.primefaces.webapp.filter.FileUploadFilter;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.itextpdf.text.pdf.parser.SimpleTextExtractionStrategy;
import com.itextpdf.text.pdf.parser.TextExtractionStrategy;

import de.binaris.jobapplication.controller.AccountController;
import de.binaris.jobapplication.model.Customer;
import de.binaris.jobapplication.model.FileUpload;

/**
 * Backing bean for FileUpload entities.
 */
@Named
@Stateful
@ConversationScoped
public class FileUploadBean extends FileUploadFilter implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final String PREFIX = "<br/>";
	public static final String MSG_COVER_LETTER_UPLOAD_FINISHED = PREFIX
			+ "Cover Letter Upload completed.";
	public static final String MSG_CV_UPLOAD_FINISHED = PREFIX
			+ "CV Upload completed.";
	public static final String MSG_TESTIMONIAL1_UPLOAD_FINISHED = PREFIX
			+ "Testimonial 1 Upload completed.";
	public static final String MSG_TESTIMONIAL2_UPLOAD_FINISHED = PREFIX
			+ "Testimonial 2 Upload completed.";
	public static final String MSG_TESTIMONIAL3_UPLOAD_FINISHED = PREFIX
			+ "Testimonial 3 Upload completed.";
	public static final String MSG_TESTIMONIAL4_UPLOAD_FINISHED = PREFIX
			+ "Testimonial 4 Upload completed.";
	public static final String MSG_TESTIMONIAL5_UPLOAD_FINISHED = PREFIX
			+ "Testimonial 5 Upload completed.";
	public static final String MSG_PROFILE_PIC_UPLOAD_FINISHED = PREFIX
			+ "Profile Picture Upload completed.";

	@Inject
	private Conversation conversation;

	@Inject
	private AccountController accController;

	@PersistenceContext(type = PersistenceContextType.EXTENDED)
	private EntityManager entityManager;

	@Resource
	private SessionContext sessionContext;

	/*
	 * pagination
	 */
	private int page;
	private long count;
	private List<FileUpload> pageItems;
	private List<FileUpload> foundPageItems = new ArrayList<FileUpload>();


	private FileUpload example = new FileUpload();
	private FileUpload add = new FileUpload();

	/*
	 * Support creating and retrieving FileUpload entities
	 */
	private Long id;

	private String customerId;
	private FileUpload fileUpload;

	public final String UPLOAD_DIRECTORY_COVER_LETTER = "D:" + File.separator
			+ "Temp" + File.separator + "cover_letters" + File.separator
			+ "cid_";
	public final String UPLOAD_DIRECTORY_CV = "D:" + File.separator + "Temp"
			+ File.separator + "cvs" + File.separator + "cid_";
	public final String UPLOAD_DIRECTORY_TESTIMONIALS = "D:" + File.separator
			+ "Temp" + File.separator + "testimonials" + File.separator
			+ "cid_";
	public final String UPLOAD_DIRECTORY_PROFILE_PIC = "D:" + File.separator
			+ "Temp" + File.separator + "profile_pics" + File.separator
			+ "cid_";

	private boolean coverLetterFinished;
	private boolean coverLetterStopped;
	private boolean cvFinished;
	private boolean cvStopped;
	private boolean profilePicFinished;
	private boolean profilePicStopped;

	private boolean testimonial1Finished;
	private boolean testimonial1Stopped;
	private boolean testimonial2Finished;
	private boolean testimonial2Stopped;
	private boolean testimonial3Finished;
	private boolean testimonial3Stopped;
	private boolean testimonial4Finished;
	private boolean testimonial4Stopped;
	private boolean testimonial5Finished;
	private boolean testimonial5Stopped;

	private UploadedFile coverLetterPdf;
	private UploadedFile cvPdf;
	private UploadedFile profilePicImage;
	private UploadedFile testimonial1Pdf;
	private UploadedFile testimonial2Pdf;
	private UploadedFile testimonial3Pdf;
	private UploadedFile testimonial4Pdf;
	private UploadedFile testimonial5Pdf;

	private StreamedContent coverLetterStream;
	private StreamedContent cvStream;
	private StreamedContent imageStream;
	private StreamedContent testimonial1Stream;
	private StreamedContent testimonial2Stream;
	private StreamedContent testimonial3Stream;
	private StreamedContent testimonial4Stream;
	private StreamedContent testimonial5Stream;

	@Override
	public void init(FilterConfig config) throws ServletException {
		super.init(config);
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws ServletException, IOException {
		super.doFilter(request, response, chain);
	}

	// Cover Letter Upload
	public void handleCoverLetterUpload(FileUploadEvent event) {
		Logger.getAnonymousLogger().info("in handleCoverLetterUpload");

		coverLetterPdf = event.getFile();
		Logger.getAnonymousLogger().info(
				"fileName: " + coverLetterPdf.getFileName());

		String coverLetterPath = storeUploadFile(coverLetterPdf,
				UPLOAD_DIRECTORY_COVER_LETTER + customerId);
		Logger.getAnonymousLogger().info("coverLetterPath: " + coverLetterPath);

		fileUpload.setCoverLetterPath(coverLetterPath);
		fileUpload.setCoverLetter(coverLetterPdf.getContents());

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("uploadCoverFinished", new FacesMessage(
				MSG_COVER_LETTER_UPLOAD_FINISHED));
		resetCoverLetterUpload();

		streamCoverLetter();
		Logger.getAnonymousLogger().info("coverLetter upload finished...");
	}

	public void cancelCoverLetterUpload() {
		coverLetterStopped = true;
		Logger.getAnonymousLogger().info("in cancelCoverLetterUpload");
	}

	public void coverLetterUploadFinished() {
		if (coverLetterStopped) {
			String name = fileUpload.getCoverLetterPath();
			File file = new File(name);
			file.delete();
			fileUpload.setCoverLetterPath(null);
		} else {
			coverLetterFinished = true;
		}
		Logger.getAnonymousLogger().info("in coverLetterUploadFinished");
	}

	public void resetCoverLetterUpload() {
		Logger.getAnonymousLogger().info("in resetCoverLetterUpload");
		coverLetterStopped = false;
		coverLetterFinished = false;
	}

	// CV Upload
	public void handleCVUpload(FileUploadEvent event) {
		Logger.getAnonymousLogger().info("in handleCVUpload");

		cvPdf = event.getFile();
		Logger.getAnonymousLogger().info("fileName: " + cvPdf.getFileName());

		String cvPath = storeUploadFile(cvPdf, UPLOAD_DIRECTORY_CV + customerId);
		Logger.getAnonymousLogger().info("cvPath: " + cvPath);

		fileUpload.setCvPath(cvPath);
		fileUpload.setCv(cvPdf.getContents());

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("uploadCVFinished", new FacesMessage(
				MSG_CV_UPLOAD_FINISHED));
		resetCVUpload();

		streamCv();
		Logger.getAnonymousLogger().info("cv upload finished...");
	}

	public void cancelCVUpload() {
		cvStopped = true;
		Logger.getAnonymousLogger().info("in cancelCVUpload");
	}

	public void cvUploadFinished() {
		if (cvStopped) {
			String name = fileUpload.getCvPath();
			File file = new File(name);
			file.delete();
			fileUpload.setCvPath(null);
		} else {
			cvFinished = true;
		}
		Logger.getAnonymousLogger().info("in cvUploadFinished");
	}

	public void resetCVUpload() {
		Logger.getAnonymousLogger().info("in resetCVUpload");
		cvStopped = false;
		cvFinished = false;
	}

	// Testimonial1 Upload
	public void handleTestimonial1Upload(FileUploadEvent event) {
		Logger.getAnonymousLogger().info("in handleTestimonial1Upload");

		testimonial1Pdf = event.getFile();
		Logger.getAnonymousLogger().info(
				"fileName: " + testimonial1Pdf.getFileName());

		String testimonial1Path = storeUploadFile(testimonial1Pdf,
				UPLOAD_DIRECTORY_TESTIMONIALS + customerId);
		Logger.getAnonymousLogger().info(
				"testimonial1Path: " + testimonial1Path);

		fileUpload.setTestimonial1Path(testimonial1Path);
		fileUpload.setTestimonial1(testimonial1Pdf.getContents());

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("uploadTestimonial1Finished", new FacesMessage(
				MSG_TESTIMONIAL1_UPLOAD_FINISHED));
		resetTestimonial1Upload();

		streamTestimonial1();
		Logger.getAnonymousLogger().info("testimonial upload finished...");
	}

	public void cancelTestimonial1Upload() {
		testimonial1Stopped = true;
		Logger.getAnonymousLogger().info("in cancelTestimonial1Upload");
	}

	public void testimonial1UploadFinished() {
		if (testimonial1Stopped) {
			String name = fileUpload.getTestimonial1Path();
			File file = new File(name);
			file.delete();
			fileUpload.setTestimonial1Path(null);
		} else {
			testimonial1Finished = true;
		}
		Logger.getAnonymousLogger().info("in testimonial1UploadFinished");
	}

	public void resetTestimonial1Upload() {
		Logger.getAnonymousLogger().info("in resetTestimonial1Upload");
		testimonial1Stopped = false;
		testimonial1Finished = false;
	}

	// Testimonial2 Upload
	public void handleTestimonial2Upload(FileUploadEvent event) {
		Logger.getAnonymousLogger().info("in handleTestimonial2Upload");

		testimonial2Pdf = event.getFile();
		Logger.getAnonymousLogger().info(
				"fileName: " + testimonial2Pdf.getFileName());

		String testimonial2Path = storeUploadFile(testimonial2Pdf,
				UPLOAD_DIRECTORY_TESTIMONIALS + customerId);
		Logger.getAnonymousLogger().info(
				"testimonial2Path: " + testimonial2Path);

		fileUpload.setTestimonial2Path(testimonial2Path);
		fileUpload.setTestimonial2(testimonial2Pdf.getContents());

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("uploadTestimonial2Finished", new FacesMessage(
				MSG_TESTIMONIAL2_UPLOAD_FINISHED));
		resetTestimonial2Upload();

		streamTestimonial2();
		Logger.getAnonymousLogger().info("testimonial2 upload finished...");
	}

	public void cancelTestimonial2Upload() {
		testimonial2Stopped = true;
		Logger.getAnonymousLogger().info("in cancelTestimonial2Upload");
	}

	public void testimonial2UploadFinished() {
		if (testimonial2Stopped) {
			String name = fileUpload.getTestimonial2Path();
			File file = new File(name);
			file.delete();
			fileUpload.setTestimonial2Path(null);
		} else {
			testimonial2Finished = true;
		}
		Logger.getAnonymousLogger().info("in testimonial2UploadFinished");
	}

	public void resetTestimonial2Upload() {
		Logger.getAnonymousLogger().info("in resetTestimonial2Upload");
		testimonial2Stopped = false;
		testimonial2Finished = false;
	}

	// Testimonial3 Upload
	public void handleTestimonial3Upload(FileUploadEvent event) {
		Logger.getAnonymousLogger().info("in handleTestimonial3Upload");

		testimonial3Pdf = event.getFile();
		Logger.getAnonymousLogger().info(
				"fileName: " + testimonial3Pdf.getFileName());

		String testimonial3Path = storeUploadFile(testimonial3Pdf,
				UPLOAD_DIRECTORY_TESTIMONIALS + customerId);
		Logger.getAnonymousLogger().info(
				"testimonial3Path: " + testimonial3Path);

		fileUpload.setTestimonial3Path(testimonial3Path);
		fileUpload.setTestimonial3(testimonial3Pdf.getContents());

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("uploadTestimonial3Finished", new FacesMessage(
				MSG_TESTIMONIAL3_UPLOAD_FINISHED));
		resetTestimonial3Upload();

		streamTestimonial3();
		Logger.getAnonymousLogger().info("testimonial3 upload finished...");
	}

	public void cancelTestimonial3Upload() {
		testimonial3Stopped = true;
		Logger.getAnonymousLogger().info("in cancelTestimonial3Upload");
	}

	public void testimonial3UploadFinished() {
		if (testimonial3Stopped) {
			String name = fileUpload.getTestimonial3Path();
			File file = new File(name);
			file.delete();
			fileUpload.setTestimonial3Path(null);
		} else {
			testimonial3Finished = true;
		}
		Logger.getAnonymousLogger().info("in testimonial3UploadFinished");
	}

	public void resetTestimonial3Upload() {
		Logger.getAnonymousLogger().info("in resetTestimonial3Upload");
		testimonial3Stopped = false;
		testimonial3Finished = false;
	}

	// Testimonial4 Upload
	public void handleTestimonial4Upload(FileUploadEvent event) {
		Logger.getAnonymousLogger().info("in handleTestimonial4Upload");

		testimonial4Pdf = event.getFile();
		Logger.getAnonymousLogger().info(
				"fileName: " + testimonial4Pdf.getFileName());

		String testimonial4Path = storeUploadFile(testimonial4Pdf,
				UPLOAD_DIRECTORY_TESTIMONIALS + customerId);
		Logger.getAnonymousLogger().info(
				"testimonial4Path: " + testimonial4Path);

		fileUpload.setTestimonial4Path(testimonial4Path);
		fileUpload.setTestimonial4(testimonial4Pdf.getContents());

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("uploadTestimonial4Finished", new FacesMessage(
				MSG_TESTIMONIAL4_UPLOAD_FINISHED));
		resetTestimonial4Upload();

		streamTestimonial4();
		Logger.getAnonymousLogger().info("testimonial4 upload finished...");
	}

	public void cancelTestimonial4Upload() {
		testimonial4Stopped = true;
		Logger.getAnonymousLogger().info("in cancelTestimonial4Upload");
	}

	public void testimonial4UploadFinished() {
		if (testimonial4Stopped) {
			String name = fileUpload.getTestimonial4Path();
			File file = new File(name);
			file.delete();
			fileUpload.setTestimonial4Path(null);
		} else {
			testimonial4Finished = true;
		}
		Logger.getAnonymousLogger().info("in testimonial4UploadFinished");
	}

	public void resetTestimonial4Upload() {
		Logger.getAnonymousLogger().info("in resetTestimonial4Upload");
		testimonial4Stopped = false;
		testimonial4Finished = false;
	}

	// Testimonial5 Upload
	public void handleTestimonial5Upload(FileUploadEvent event) {
		Logger.getAnonymousLogger().info("in handleTestimonial5Upload");

		testimonial5Pdf = event.getFile();
		Logger.getAnonymousLogger().info(
				"fileName: " + testimonial5Pdf.getFileName());

		String testimonial5Path = storeUploadFile(testimonial5Pdf,
				UPLOAD_DIRECTORY_TESTIMONIALS + customerId);
		Logger.getAnonymousLogger().info(
				"testimonial5Path: " + testimonial5Path);

		fileUpload.setTestimonial5Path(testimonial5Path);
		fileUpload.setTestimonial5(testimonial5Pdf.getContents());

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("uploadTestimonial5Finished", new FacesMessage(
				MSG_TESTIMONIAL5_UPLOAD_FINISHED));
		resetTestimonial5Upload();

		streamTestimonial5();
		Logger.getAnonymousLogger().info("testimonial5 upload finished...");
	}

	public void cancelTestimonial5Upload() {
		testimonial5Stopped = true;
		Logger.getAnonymousLogger().info("in cancelTestimonial5Upload");
	}

	public void testimonial5UploadFinished() {
		if (testimonial5Stopped) {
			String name = fileUpload.getTestimonial5Path();
			File file = new File(name);
			file.delete();
			fileUpload.setTestimonial5Path(null);
		} else {
			testimonial5Finished = true;
		}
		Logger.getAnonymousLogger().info("in testimonial5UploadFinished");
	}

	public void resetTestimonial5Upload() {
		Logger.getAnonymousLogger().info("in resetTestimonial5Upload");
		testimonial5Stopped = false;
		testimonial5Finished = false;
	}

	// Profile Pic Upload
	public void handleProfilePicUpload(FileUploadEvent event) {
		Logger.getAnonymousLogger().info("in handleProfilePicUpload");

		profilePicImage = event.getFile();
		Logger.getAnonymousLogger().info(
				"fileName: " + profilePicImage.getFileName());

		String profilePicPath = storeUploadFile(profilePicImage,
				UPLOAD_DIRECTORY_PROFILE_PIC + customerId);
		Logger.getAnonymousLogger().info("profilePicPath: " + profilePicPath);

		fileUpload.setProfilePicPath(profilePicPath);
		fileUpload.setProfilePic(profilePicImage.getContents());

		FacesContext context = FacesContext.getCurrentInstance();
		context.addMessage("uploadProfilePicFinished", new FacesMessage(
				MSG_PROFILE_PIC_UPLOAD_FINISHED));
		resetProfilePicUpload();

		streamProfilePic();
		Logger.getAnonymousLogger().info("profilePic upload finished...");
	}

	public void cancelProfilePicUpload() {
		profilePicStopped = true;
		Logger.getAnonymousLogger().info("in cancelProfilePicUpload");
	}

	public void profilePicUploadFinished() {
		if (profilePicStopped) {
			String name = fileUpload.getProfilePicPath();
//			File file = new File(name);
//			file.delete();
			fileUpload.setProfilePicPath(null);
		} else {
			profilePicFinished = true;
		}
		Logger.getAnonymousLogger().info("in profilePicUploadFinished");
	}

	public void resetProfilePicUpload() {
		Logger.getAnonymousLogger().info("in resetProfilePicUpload");
		profilePicStopped = false;
		profilePicFinished = false;
	}

	private String storeUploadFile(UploadedFile file, String uploadDir) {
		String fileNamePath = "";
		// try {
		long pathName = (new Date()).getTime();
		File directory = new File(uploadDir + File.separator + pathName);
		if (!directory.exists()) {
			directory.mkdirs();
		}
		fileNamePath = file.getFileName();
		// fileNamePath = directory+File.separator+file.getFileName();
		// Logger.getAnonymousLogger().info("fileNamePath: " + fileNamePath);
		//
		// BufferedInputStream bufInStream = new
		// BufferedInputStream(file.getInputstream());
		// BufferedReader reader = new BufferedReader(new
		// InputStreamReader(bufInStream),
		// Long.valueOf(file.getSize()).intValue());
		//
		// int i=0;
		// FileWriter fWriter = new FileWriter(new File(fileNamePath));
		// while ((i = reader. read()) != -1) {
		// fWriter.write(i);
		// }
		// fWriter.close();
		// bufInStream.close();
		return fileNamePath;
		// } catch (IOException e) {
		// // handle exception
		// Logger.getAnonymousLogger().info("Exception with file write in storeUploadFile"
		// + e.getMessage());
		// }
		// return fileNamePath;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCustomerId() {
		return this.customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public void setCustomerValue(ValueChangeEvent event) {
		customerId = (String) event.getNewValue();
	}

	public FileUpload getFileUpload() {
		return this.fileUpload;
	}

	public String create() {
		this.conversation.begin();
		return "create?faces-redirect=true";
	}

	public void retrieve() {
		if (FacesContext.getCurrentInstance().isPostback()) {
			return;
		}

		if (this.conversation.isTransient()) {
			this.conversation.begin();
		}

		if (this.customerId != null) {
			paginate();
			for (FileUpload info : this.pageItems) {
				if (info.getCustomer().getId().longValue() == Long.valueOf(
						this.customerId).longValue()) {
					this.example = info;
					this.id = info.getId().longValue();
				}
			}
		}

		if (this.id == null) {
			this.fileUpload = this.example;
		} else {
			this.fileUpload = findById(getId());
		}
        if (this.customerId == null || this.customerId.isEmpty()) {
      	    this.customerId = this.fileUpload.getCustomer().getId().toString();
        }

		streamProfilePic();
		streamCoverLetter();
		streamCv();
		streamTestimonial1();
		streamTestimonial2();
		streamTestimonial3();
		streamTestimonial4();
		streamTestimonial5();
	}

	protected void streamProfilePic() {
		if (fileUpload.getProfilePicPath() != null && !fileUpload.getProfilePicPath().isEmpty()) {
			int length = fileUpload.getProfilePicPath().split("['.']").length;
			String type = fileUpload.getProfilePicPath().split("['.']")[length - 1];
			
			String contentType = "image/png";
			if (type.startsWith("jp")) {
				contentType = "image/jpeg";
			} else if (type.startsWith("gif")) {
				contentType = "image/gif";
			}
			imageStream = new DefaultStreamedContent(new ByteArrayInputStream(
					fileUpload.getProfilePic()), contentType,
					fileUpload.getProfilePicPath());
		}
	}

	protected void streamCoverLetter() {
		if (fileUpload.getCoverLetterPath() != null && !fileUpload.getCoverLetterPath().isEmpty()) {
			int length = fileUpload.getCoverLetterPath().split("['.']").length;
			String type = fileUpload.getCoverLetterPath().split("['.']")[length - 1];
			
			String contentType = "application/pdf";
			if (!type.startsWith("pdf")) {
				contentType = "application/" + type;
			}
			coverLetterStream = new DefaultStreamedContent(new ByteArrayInputStream(
										fileUpload.getCoverLetter()), contentType,
										fileUpload.getCoverLetterPath());
		}
	}
	
	protected void streamCv() {
		if (fileUpload.getCvPath() != null && !fileUpload.getCvPath().isEmpty()) {
			int length = fileUpload.getCvPath().split("['.']").length;
			String type = fileUpload.getCvPath().split("['.']")[length - 1];
			
			String contentType = "application/pdf";
			if (!type.startsWith("pdf")) {
				contentType = "application/" + type;
			}
			cvStream = new DefaultStreamedContent(new ByteArrayInputStream(
					fileUpload.getCv()), contentType,
					fileUpload.getCvPath());
		}
	}
	
	protected void streamTestimonial1() {
		if (fileUpload.getTestimonial1Path() != null && !fileUpload.getTestimonial1Path().isEmpty()) {
			int length = fileUpload.getTestimonial1Path().split("['.']").length;
			String type = fileUpload.getTestimonial1Path().split("['.']")[length - 1];
			
			String contentType = "application/pdf";
			if (!type.startsWith("pdf")) {
				contentType = "application/" + type;
			}
			testimonial1Stream = new DefaultStreamedContent(new ByteArrayInputStream(
					fileUpload.getTestimonial1()), contentType,
					fileUpload.getTestimonial1Path());
		}
	}
	
	protected void streamTestimonial2() {
		if (fileUpload.getTestimonial2Path() != null && !fileUpload.getTestimonial2Path().isEmpty()) {
			int length = fileUpload.getTestimonial2Path().split("['.']").length;
			String type = fileUpload.getTestimonial2Path().split("['.']")[length - 1];
			
			String contentType = "application/pdf";
			if (!type.startsWith("pdf")) {
				contentType = "application/" + type;
			}
			testimonial2Stream = new DefaultStreamedContent(new ByteArrayInputStream(
					fileUpload.getTestimonial2()), contentType,
					fileUpload.getTestimonial2Path());
		}
	}
	
	protected void streamTestimonial3() {
		if (fileUpload.getTestimonial3Path() != null && !fileUpload.getTestimonial3Path().isEmpty()) {
			int length = fileUpload.getTestimonial3Path().split("['.']").length;
			String type = fileUpload.getTestimonial3Path().split("['.']")[length - 1];
			
			String contentType = "application/pdf";
			if (!type.startsWith("pdf")) {
				contentType = "application/" + type;
			}
			testimonial3Stream = new DefaultStreamedContent(new ByteArrayInputStream(
					fileUpload.getTestimonial3()), contentType,
					fileUpload.getTestimonial3Path());
		}
	}
	
	protected void streamTestimonial4() {
		if (fileUpload.getTestimonial4Path() != null && !fileUpload.getTestimonial4Path().isEmpty()) {
			int length = fileUpload.getTestimonial4Path().split("['.']").length;
			String type = fileUpload.getTestimonial4Path().split("['.']")[length - 1];
			
			String contentType = "application/pdf";
			if (!type.startsWith("pdf")) {
				contentType = "application/" + type;
			}
			testimonial4Stream = new DefaultStreamedContent(new ByteArrayInputStream(
					fileUpload.getTestimonial4()), contentType,
					fileUpload.getTestimonial4Path());
		}
	}
	
	protected void streamTestimonial5() {
		if (fileUpload.getTestimonial5Path() != null && !fileUpload.getTestimonial5Path().isEmpty()) {
			int length = fileUpload.getTestimonial5Path().split("['.']").length;
			String type = fileUpload.getTestimonial5Path().split("['.']")[length - 1];
			
			String contentType = "application/pdf";
			if (!type.startsWith("pdf")) {
				contentType = "application/" + type;
			}
			testimonial5Stream = new DefaultStreamedContent(new ByteArrayInputStream(
					fileUpload.getTestimonial5()), contentType,
					fileUpload.getTestimonial5Path());
		}
	}
	
	public FileUpload findById(Long id) {
		return this.entityManager.find(FileUpload.class, id);
	}

	/*
	 * Support updating and deleting FileUpload entities
	 */
	public String update() {
		this.conversation.end();
		this.fileUpload.setCustomer(this.accController.getLoggedinCustomer());
		try {
			if (this.id == null) {
				this.entityManager.persist(this.fileUpload);
				return "search?faces-redirect=true";
			} else {
				this.entityManager.merge(this.fileUpload);
				return "view?faces-redirect=true&id=" + this.fileUpload.getId();
			}
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
			return null;
		}
	}

	public String delete() {
		this.conversation.end();

		try {
			FileUpload deletableEntity = findById(getId());

			this.entityManager.remove(deletableEntity);
			this.entityManager.flush();
			return "search?faces-redirect=true";
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}

	public int getPage() {
		return this.page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getPageSize() {
		return 10;
	}

	public FileUpload getExample() {
		return this.example;
	}

	public void setExample(FileUpload example) {
		this.example = example;
	}

	public void search() {
		this.page = 0;
	}

	public void paginate() {
		CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

		// Populate this.count
		CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
		Root<FileUpload> root = countCriteria.from(FileUpload.class);
		countCriteria = countCriteria.select(builder.count(root)).where(
				getSearchPredicates(root));
		this.count = this.entityManager.createQuery(countCriteria)
				.getSingleResult();

		// Populate this.pageItems
		CriteriaQuery<FileUpload> criteria = builder
				.createQuery(FileUpload.class);
		root = criteria.from(FileUpload.class);
		TypedQuery<FileUpload> query = this.entityManager.createQuery(criteria
				.select(root).where(getSearchPredicates(root)));
		query.setFirstResult(this.page * getPageSize()).setMaxResults(
				getPageSize());
		this.pageItems = query.getResultList();
	}

	private Predicate[] getSearchPredicates(Root<FileUpload> root) {
		CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
		List<Predicate> predicatesList = new ArrayList<Predicate>();

		Customer customer = this.example.getCustomer();
		if (customer != null) {
			predicatesList.add(builder.equal(root.get("customer"), customer));
		}
		String coverLetterPath = this.example.getCoverLetterPath();
		if (coverLetterPath != null && !"".equals(coverLetterPath)) {
			predicatesList.add(builder.like(
					root.<String> get("coverLetterPath"),
					'%' + coverLetterPath + '%'));
		}
		String cvPath = this.example.getCvPath();
		if (cvPath != null && !"".equals(cvPath)) {
			predicatesList.add(builder.like(root.<String> get("cvPath"),
					'%' + cvPath + '%'));
		}
		String testimonial1Path = this.example.getTestimonial1Path();
		if (testimonial1Path != null && !"".equals(testimonial1Path)) {
			predicatesList.add(builder.like(
					root.<String> get("testimonial1Path"),
					'%' + testimonial1Path + '%'));
		}
		String testimonial2Path = this.example.getTestimonial2Path();
		if (testimonial2Path != null && !"".equals(testimonial2Path)) {
			predicatesList.add(builder.like(
					root.<String> get("testimonial2Path"),
					'%' + testimonial2Path + '%'));
		}
		String testimonial3Path = this.example.getTestimonial3Path();
		if (testimonial3Path != null && !"".equals(testimonial3Path)) {
			predicatesList.add(builder.like(
					root.<String> get("testimonial3Path"),
					'%' + testimonial3Path + '%'));
		}
		String testimonial4Path = this.example.getTestimonial4Path();
		if (testimonial4Path != null && !"".equals(testimonial4Path)) {
			predicatesList.add(builder.like(
					root.<String> get("testimonial4Path"),
					'%' + testimonial4Path + '%'));
		}
		String testimonial5Path = this.example.getTestimonial5Path();
		if (testimonial5Path != null && !"".equals(testimonial5Path)) {
			predicatesList.add(builder.like(
					root.<String> get("testimonial5Path"),
					'%' + testimonial5Path + '%'));
		}
		return predicatesList.toArray(new Predicate[predicatesList.size()]);
	}

	public StreamedContent getImageStream() throws IOException {
		return imageStream;
	}

	public StreamedContent getCoverLetterStream() throws IOException {
		return coverLetterStream;
	}
	
	public StreamedContent getCvStream() throws IOException {
		return cvStream;
	}
	
	public StreamedContent getTestimonial1Stream() throws IOException {
		return testimonial1Stream;
	}
	
	public StreamedContent getTestimonial2Stream() throws IOException {
		return testimonial2Stream;
	}
	
	public StreamedContent getTestimonial3Stream() throws IOException {
		return testimonial3Stream;
	}
	
	public StreamedContent getTestimonial4Stream() throws IOException {
		return testimonial4Stream;
	}
	
	public StreamedContent getTestimonial5Stream() throws IOException {
		return testimonial5Stream;
	}
	
	public List<FileUpload> getPageItems() {
		return this.pageItems;
	}

	public List<FileUpload> getFoundPageItems() {
		return this.foundPageItems;
	}
	
	public long getCount() {
		return (!foundPageItems.isEmpty())? foundPageItems.size() : this.count;
	}

	/*
	 * Support listing and POSTing back FileUpload entities (e.g. from inside an
	 * HtmlSelectOneMenu)
	 */
	public List<FileUpload> getAll() {
		CriteriaQuery<FileUpload> criteria = this.entityManager
				.getCriteriaBuilder().createQuery(FileUpload.class);
		return this.entityManager.createQuery(
				criteria.select(criteria.from(FileUpload.class)))
				.getResultList();
	}

	private String searchText;
	
	public String getSearchText() {
		return searchText;
	}
	
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}
	
	public void searchForText() {
		paginate();
		foundPageItems.clear();
		if (searchText == null || searchText.trim().isEmpty()) {
			foundPageItems.addAll(pageItems);
			return;
		}
		for (FileUpload oneUpload : pageItems) {
			byte[] cv = oneUpload.getCv();
			byte[] coverLetter = oneUpload.getCoverLetter();
			byte[] testimonial1 = oneUpload.getTestimonial1();
			byte[] testimonial2 = oneUpload.getTestimonial2();
			byte[] testimonial3 = oneUpload.getTestimonial3();
			byte[] testimonial4 = oneUpload.getTestimonial4();
			byte[] testimonial5 = oneUpload.getTestimonial5();
			
			try {
				String extractCoverLetter = "";
				if (coverLetter != null) {
					String textCoverLetter = parsePDF(coverLetter);
					extractCoverLetter = extractContent(textCoverLetter, "Sehr");
					String content = replaceLineBreaks(extractCoverLetter);
					if (content.indexOf(searchText) >= 0) {
						foundPageItems.add(oneUpload);
						continue;
					}
				}
				String extractCv = "";
				if (cv != null) {
					String textCv = parsePDF(cv);
					extractCv = extractContent(textCv, new String[] {"Lebenslauf","CV","C.V."} );
					String content = replaceLineBreaks(extractCv);
					if (content.indexOf(searchText) >= 0) {
						foundPageItems.add(oneUpload);
						continue;
					}
				}
				String extractTestimonial1 = "";
				if (testimonial1 != null) {
					String textTestimonial1 = parsePDF(testimonial1);
					extractTestimonial1 = extractContent(textTestimonial1, "eugnis");
					String content = replaceLineBreaks(extractTestimonial1);
					if (content.indexOf(searchText) >= 0) {
						foundPageItems.add(oneUpload);
						continue;
					}
				}
				String extractTestimonial2 = "";
				if (testimonial2 != null) {
					String textTestimonial2 = parsePDF(testimonial2);
					extractTestimonial2 = extractContent(textTestimonial2, "eugnis");
					String content = replaceLineBreaks(extractTestimonial2);
					if (content.indexOf(searchText) >= 0) {
						foundPageItems.add(oneUpload);
						continue;
					}
				}
				String extractTestimonial3 = "";
				if (testimonial3 != null) {
					String textTestimonial3 = parsePDF(testimonial3);
					extractTestimonial3 = extractContent(textTestimonial3, "eugnis");
					String content = replaceLineBreaks(extractTestimonial3);
					if (content.indexOf(searchText) >= 0) {
						foundPageItems.add(oneUpload);
						continue;
					}
				}
				String extractTestimonial4 = "";
				if (testimonial4 != null) {
					String textTestimonial4 = parsePDF(testimonial4);
					extractTestimonial4 = extractContent(textTestimonial4, "eugnis");
					String content = replaceLineBreaks(extractTestimonial4);
					if (content.indexOf(searchText) >= 0) {
						foundPageItems.add(oneUpload);
						continue;
					}
				}
				String extractTestimonial5 = "";
				if (testimonial5 != null) {
					String textTestimonial5 = parsePDF(testimonial5);
					extractTestimonial5 = extractContent(textTestimonial5, "eugnis");
					String content = replaceLineBreaks(extractTestimonial5);
					if (content.indexOf(searchText) >= 0) {
						foundPageItems.add(oneUpload);
						continue;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private String extractContent(String txt, String[] starts) {
		String result = "";
		for (String s : starts) {
			result = extractContent(txt, s);
			if (result != null && !result.isEmpty()) {
				break;
			}
		}
        return result;
	}
	
	private String extractContent(String txt, String start) {
		if (txt == null || txt.isEmpty()) {
			return txt;
		}
		String result = "";
		String[] split1 = txt.split(start);
		if (split1 != null && split1.length > 1 && split1[1] != null) {
			result = split1[1];
		} else if (split1 != null && split1.length == 1) {
			result = split1[0];
		}
		return result;
	}
	
    private String parsePDF(byte[] pdfIn) throws IOException {
        PdfReader pdfReader = new PdfReader(pdfIn);
        StringBuilder builder = new StringBuilder();
        for (int counter = 1; counter <= pdfReader.getNumberOfPages(); ++counter) {
            TextExtractionStrategy tExtractStrategy = new SimpleTextExtractionStrategy();
            builder.append(PdfTextExtractor.getTextFromPage(pdfReader, counter, tExtractStrategy));
        }
        pdfReader.close();
        return builder.toString();
    }
	
    private String replaceLineBreaks(String input) {
    	String result = "";
        String[] lines = input.split("\n");
        for (String line : lines) {
        	if (result.isEmpty()) {
        		result = line;
        	} else {
        		result += ", " + line;
        	}
        }
        return result;
    }
    
	public Converter getConverter() {
		final FileUploadBean ejbProxy = this.sessionContext
				.getBusinessObject(FileUploadBean.class);

		return new Converter() {
			@Override
			public Object getAsObject(FacesContext context,
					UIComponent component, String value) {
				return ejbProxy.findById(Long.valueOf(value));
			}

			@Override
			public String getAsString(FacesContext context,
					UIComponent component, Object value) {
				if (value == null) {
					return "";
				}
				return String.valueOf(((FileUpload) value).getId());
			}
		};
	}

	public FileUpload getAdd() {
		return this.add;
	}

	public FileUpload getAdded() {
		FileUpload added = this.add;
		this.add = new FileUpload();
		return added;
	}
}