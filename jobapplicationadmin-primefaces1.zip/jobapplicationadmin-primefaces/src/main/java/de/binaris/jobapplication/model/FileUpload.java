package de.binaris.jobapplication.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "file_upload")
public class FileUpload implements Serializable {

	private static final long serialVersionUID = 7975779629657126329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_file_upload")
	@SequenceGenerator(name = "my_entity_seq_gen_file_upload", sequenceName = "sequence_file_upload", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	private Customer customer;
	
	@NotNull
	@Size(min = 1, max = 1000, message = "must be 1-1000 letters and spaces")
	@Column(name="cover_letter_path")
	private String coverLetterPath;

	@NotNull
	@Size(min = 1, max = 1000, message = "must be 1-1000 letters and spaces")
	@Column(name="cv_path")
	private String cvPath;
	
	@NotNull
	@Size(min = 1, max = 1000, message = "must be 1-1000 letters and spaces")
	@Column(name="profile_pic_path")
	private String profilePicPath;
	
	@Size(min = 0, max = 1000, message = "must be 0-1000 letters and spaces")
	@Column(name="testimonial_1_path")
	private String testimonial1Path;
	
	@Size(min = 0, max = 1000, message = "must be 0-1000 letters and spaces")
	@Column(name="testimonial_2_path")
	private String testimonial2Path;
	
	@Size(min = 0, max = 1000, message = "must be 0-1000 letters and spaces")
	@Column(name="testimonial_3_path")
	private String testimonial3Path;
	
	@Size(min = 0, max = 1000, message = "must be 0-1000 letters and spaces")
	@Column(name="testimonial_4_path")
	private String testimonial4Path;
	
	@Size(min = 0, max = 1000, message = "must be 0-1000 letters and spaces")
	@Column(name="testimonial_5_path")
	private String testimonial5Path;

	@NotNull
	@Lob
	@Column(name="cover_letter")
	private byte[] coverLetter;
	
	@NotNull
	@Lob
	@Column(name="cv")
	private byte[] cv;
	
	@NotNull
	@Lob
	@Column(name="profile_pic")
	private byte[] profilePic;
	
	@Lob
	@Column(name="testimonial1")
	private byte[] testimonial1;
	
	@Lob
	@Column(name="testimonial2")
	private byte[] testimonial2;
	
	@Lob
	@Column(name="testimonial3")
	private byte[] testimonial3;
	
	@Lob
	@Column(name="testimonial4")
	private byte[] testimonial4;
	
	@Lob
	@Column(name="testimonial5")
	private byte[] testimonial5;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getCoverLetterPath() {
		return coverLetterPath;
	}

	public void setCoverLetterPath(String coverLetterPath) {
		this.coverLetterPath = coverLetterPath;
	}

	public String getCvPath() {
		return cvPath;
	}

	public void setCvPath(String cvPath) {
		this.cvPath = cvPath;
	}

	public String getTestimonial1Path() {
		return testimonial1Path;
	}

	public void setTestimonial1Path(String testimonial1Path) {
		this.testimonial1Path = testimonial1Path;
	}

	public String getTestimonial2Path() {
		return testimonial2Path;
	}

	public void setTestimonial2Path(String testimonial2Path) {
		this.testimonial2Path = testimonial2Path;
	}

	public String getTestimonial3Path() {
		return testimonial3Path;
	}

	public void setTestimonial3Path(String testimonial3Path) {
		this.testimonial3Path = testimonial3Path;
	}

	public String getTestimonial4Path() {
		return testimonial4Path;
	}

	public void setTestimonial4Path(String testimonial4Path) {
		this.testimonial4Path = testimonial4Path;
	}

	public String getTestimonial5Path() {
		return testimonial5Path;
	}

	public void setTestimonial5Path(String testimonial5Path) {
		this.testimonial5Path = testimonial5Path;
	}

	public String getProfilePicPath() {
		return profilePicPath;
	}

	public void setProfilePicPath(String profilePicPath) {
		this.profilePicPath = profilePicPath;
	}

	public byte[] getCoverLetter() {
		return coverLetter;
	}

	public void setCoverLetter(byte[] coverLetter) {
		this.coverLetter = coverLetter;
	}

	public byte[] getCv() {
		return cv;
	}

	public void setCv(byte[] cv) {
		this.cv = cv;
	}

	public byte[] getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(byte[] profilePic) {
		this.profilePic = profilePic;
	}

	public byte[] getTestimonial1() {
		return testimonial1;
	}

	public void setTestimonial1(byte[] testimonial1) {
		this.testimonial1 = testimonial1;
	}

	public byte[] getTestimonial2() {
		return testimonial2;
	}

	public void setTestimonial2(byte[] testimonial2) {
		this.testimonial2 = testimonial2;
	}

	public byte[] getTestimonial3() {
		return testimonial3;
	}

	public void setTestimonial3(byte[] testimonial3) {
		this.testimonial3 = testimonial3;
	}

	public byte[] getTestimonial4() {
		return testimonial4;
	}

	public void setTestimonial4(byte[] testimonial4) {
		this.testimonial4 = testimonial4;
	}

	public byte[] getTestimonial5() {
		return testimonial5;
	}

	public void setTestimonial5(byte[] testimonial5) {
		this.testimonial5 = testimonial5;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof FileUpload)) {
			return false;
		}
		FileUpload castOther = (FileUpload) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(customer.getFamilyName()).append(", ");
		sb.append(customer.getFirstName());
		sb.append(", ");
		sb.append(customer.getEmail());
		return sb.toString();
	}
}
