package de.binaris.jobapplication.model;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//import de.binaris.jobapplication.annotations.Login;

@Cacheable
@Entity
@Table(name = "additional_info")
public class AdditionalInfo implements Serializable {

	private static final long serialVersionUID = 1525589723659122329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_additional_info")
	@SequenceGenerator(name = "my_entity_seq_gen_additional_info", sequenceName = "sequence_additional_info", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String salary;

	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
	@Column(name = "former_employer")
	private String formerEmployer;
	
	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
	@Column(name = "quitting_option_time")
	private String quittingOptionTime;

	@NotNull
	@Column(name = "date_of_entry")
	@Temporal(TemporalType.DATE)
	private Date dateOfEntry;
	
    @ManyToOne
    private Customer customer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getDateOfEntry() {
		return dateOfEntry;
	}
	
	public void setDateOfEntry(Date dateOfEntry) {
		this.dateOfEntry = dateOfEntry;
	}
	
	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getFormerEmployer() {
		return formerEmployer;
	}

	public void setFormerEmployer(String formerEmployer) {
		this.formerEmployer = formerEmployer;
	}

	public String getQuittingOptionTime() {
		return quittingOptionTime;
	}

	public void setQuittingOptionTime(String quittingOptionTime) {
		this.quittingOptionTime = quittingOptionTime;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof AdditionalInfo)) {
			return false;
		}
		AdditionalInfo castOther = (AdditionalInfo) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		DateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
		final StringBuilder sb = new StringBuilder();
		sb.append(formerEmployer);
		sb.append(", ");
		sb.append(formatter.format(dateOfEntry));
		return sb.toString();
	}
}
