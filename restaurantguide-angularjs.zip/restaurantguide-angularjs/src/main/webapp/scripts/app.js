'use strict';

angular.module('restaurantguideangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Customers',{templateUrl:'views/Customer/search.html',controller:'SearchCustomerController'})
      .when('/Customers/new',{templateUrl:'views/Customer/detail.html',controller:'NewCustomerController'})
      .when('/Customers/edit/:CustomerId',{templateUrl:'views/Customer/detail.html',controller:'EditCustomerController'})
      .when('/PhoneContacts',{templateUrl:'views/PhoneContact/search.html',controller:'SearchPhoneContactController'})
      .when('/PhoneContacts/new',{templateUrl:'views/PhoneContact/detail.html',controller:'NewPhoneContactController'})
      .when('/PhoneContacts/edit/:PhoneContactId',{templateUrl:'views/PhoneContact/detail.html',controller:'EditPhoneContactController'})
      .when('/Recommendations',{templateUrl:'views/Recommendation/search.html',controller:'SearchRecommendationController'})
      .when('/Recommendations/new',{templateUrl:'views/Recommendation/detail.html',controller:'NewRecommendationController'})
      .when('/Recommendations/edit/:RecommendationId',{templateUrl:'views/Recommendation/detail.html',controller:'EditRecommendationController'})
      .when('/Restaurants',{templateUrl:'views/Restaurant/search.html',controller:'SearchRestaurantController'})
      .when('/Restaurants/new',{templateUrl:'views/Restaurant/detail.html',controller:'NewRestaurantController'})
      .when('/Restaurants/edit/:RestaurantId',{templateUrl:'views/Restaurant/detail.html',controller:'EditRestaurantController'})
      .when('/TimesOfServices',{templateUrl:'views/TimesOfService/search.html',controller:'SearchTimesOfServiceController'})
      .when('/TimesOfServices/new',{templateUrl:'views/TimesOfService/detail.html',controller:'NewTimesOfServiceController'})
      .when('/TimesOfServices/edit/:TimesOfServiceId',{templateUrl:'views/TimesOfService/detail.html',controller:'EditTimesOfServiceController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
