
angular.module('restaurantguideangularjs').controller('NewTimesOfServiceController', function ($scope, $location, locationParser, TimesOfServiceResource , RestaurantResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.timesOfService = $scope.timesOfService || {};
    
    $scope.restaurantList = RestaurantResource.queryAll(function(items){
        $scope.restaurantSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("restaurantSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.timesOfService.restaurant = {};
            $scope.timesOfService.restaurant.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/TimesOfServices/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TimesOfServiceResource.save($scope.timesOfService, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/TimesOfServices");
    };
});