
angular.module('restaurantguideangularjs').controller('NewRestaurantController', function ($scope, $location, locationParser, RestaurantResource , RecommendationResource, CategoryResource, PhoneContactResource, TimesOfServiceResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.restaurant = $scope.restaurant || {};
    
    $scope.recommendationList = RecommendationResource.queryAll(function(items){
        $scope.recommendationSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("recommendationSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.restaurant.recommendation = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.restaurant.recommendation.push(collectionItem);
            });
        }
    });
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.restaurant.category = {};
            $scope.restaurant.category.id = selection.value;
        }
    });
    
    $scope.phoneContactList = PhoneContactResource.queryAll(function(items){
        $scope.phoneContactSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.phoneNumber
            });
        });
    });
    $scope.$watch("phoneContactSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.restaurant.phoneContact = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.restaurant.phoneContact.push(collectionItem);
            });
        }
    });
    
    $scope.timesOfServiceList = TimesOfServiceResource.queryAll(function(items){
        $scope.timesOfServiceSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.days
            });
        });
    });
    $scope.$watch("timesOfServiceSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.restaurant.timesOfService = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.restaurant.timesOfService.push(collectionItem);
            });
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.restaurant.address.country = {};
            $scope.restaurant.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Restaurants/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        RestaurantResource.save($scope.restaurant, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Restaurants");
    };
});