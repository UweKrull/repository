
angular.module('restaurantguideangularjs').controller('NewCategoryController', function ($scope, $location, locationParser, CategoryResource , RestaurantResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.category = $scope.category || {};
    
    $scope.restaurantList = RestaurantResource.queryAll(function(items){
        $scope.restaurantSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("restaurantSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.category.restaurant = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.category.restaurant.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Categorys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CategoryResource.save($scope.category, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Categorys");
    };
});