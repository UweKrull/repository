

angular.module('restaurantguideangularjs').controller('EditRestaurantController', function($scope, $routeParams, $location, RestaurantResource , RecommendationResource, CategoryResource, PhoneContactResource, TimesOfServiceResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.restaurant = new RestaurantResource(self.original);
            RecommendationResource.queryAll(function(items) {
                $scope.recommendationSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.restaurant.recommendation){
                        $.each($scope.restaurant.recommendation, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.recommendationSelection.push(labelObject);
                                $scope.restaurant.recommendation.push(wrappedObject);
                            }
                        });
                        self.original.recommendation = $scope.restaurant.recommendation;
                    }
                    return labelObject;
                });
            });
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.restaurant.category && item.id == $scope.restaurant.category.id) {
                        $scope.categorySelection = labelObject;
                        $scope.restaurant.category = wrappedObject;
                        self.original.category = $scope.restaurant.category;
                    }
                    return labelObject;
                });
            });
            PhoneContactResource.queryAll(function(items) {
                $scope.phoneContactSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.phoneNumber
                    };
                    if($scope.restaurant.phoneContact){
                        $.each($scope.restaurant.phoneContact, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.phoneContactSelection.push(labelObject);
                                $scope.restaurant.phoneContact.push(wrappedObject);
                            }
                        });
                        self.original.phoneContact = $scope.restaurant.phoneContact;
                    }
                    return labelObject;
                });
            });
            TimesOfServiceResource.queryAll(function(items) {
                $scope.timesOfServiceSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.days
                    };
                    if($scope.restaurant.timesOfService){
                        $.each($scope.restaurant.timesOfService, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.timesOfServiceSelection.push(labelObject);
                                $scope.restaurant.timesOfService.push(wrappedObject);
                            }
                        });
                        self.original.timesOfService = $scope.restaurant.timesOfService;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.restaurant.address.country && item.id == $scope.restaurant.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.restaurant.address.country = wrappedObject;
                        self.original.address.country = $scope.restaurant.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Restaurants");
        };
        RestaurantResource.get({RestaurantId:$routeParams.RestaurantId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.restaurant);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.restaurant.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Restaurants");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Restaurants");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.restaurant.$remove(successCallback, errorCallback);
    };
    
    $scope.recommendationSelection = $scope.recommendationSelection || [];
    $scope.$watch("recommendationSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.restaurant) {
            $scope.restaurant.recommendation = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.restaurant.recommendation.push(collectionItem);
            });
        }
    });
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.restaurant.category = {};
            $scope.restaurant.category.id = selection.value;
        }
    });
    $scope.phoneContactSelection = $scope.phoneContactSelection || [];
    $scope.$watch("phoneContactSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.restaurant) {
            $scope.restaurant.phoneContact = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.restaurant.phoneContact.push(collectionItem);
            });
        }
    });
    $scope.timesOfServiceSelection = $scope.timesOfServiceSelection || [];
    $scope.$watch("timesOfServiceSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.restaurant) {
            $scope.restaurant.timesOfService = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.restaurant.timesOfService.push(collectionItem);
            });
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.restaurant.address.country = {};
            $scope.restaurant.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});