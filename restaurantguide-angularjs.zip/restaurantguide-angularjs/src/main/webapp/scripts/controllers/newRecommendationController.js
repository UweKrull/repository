
angular.module('restaurantguideangularjs').controller('NewRecommendationController', function ($scope, $location, locationParser, RecommendationResource , RestaurantResource, CustomerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.recommendation = $scope.recommendation || {};
    
    $scope.restaurantList = RestaurantResource.queryAll(function(items){
        $scope.restaurantSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("restaurantSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.recommendation.restaurant = {};
            $scope.recommendation.restaurant.id = selection.value;
        }
    });
    
    $scope.guestList = CustomerResource.queryAll(function(items){
        $scope.guestSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.aliasName
            });
        });
    });
    $scope.$watch("guestSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.recommendation.guest = {};
            $scope.recommendation.guest.id = selection.value;
        }
    });
    
    $scope.rankingTypeList = [
        "OUTSTANDING",
        "EXCELLENT",
        "GOOD",
        "AVERAGE",
        "POOR",
        "DREADFUL"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Recommendations/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        RecommendationResource.save($scope.recommendation, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Recommendations");
    };
});