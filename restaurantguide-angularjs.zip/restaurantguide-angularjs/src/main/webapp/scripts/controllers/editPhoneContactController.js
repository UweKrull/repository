

angular.module('restaurantguideangularjs').controller('EditPhoneContactController', function($scope, $routeParams, $location, PhoneContactResource , RestaurantResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.phoneContact = new PhoneContactResource(self.original);
            RestaurantResource.queryAll(function(items) {
                $scope.restaurantSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.phoneContact.restaurant && item.id == $scope.phoneContact.restaurant.id) {
                        $scope.restaurantSelection = labelObject;
                        $scope.phoneContact.restaurant = wrappedObject;
                        self.original.restaurant = $scope.phoneContact.restaurant;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/PhoneContacts");
        };
        PhoneContactResource.get({PhoneContactId:$routeParams.PhoneContactId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.phoneContact);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.phoneContact.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PhoneContacts");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PhoneContacts");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.phoneContact.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("restaurantSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.phoneContact.restaurant = {};
            $scope.phoneContact.restaurant.id = selection.value;
        }
    });
    
    $scope.get();
});