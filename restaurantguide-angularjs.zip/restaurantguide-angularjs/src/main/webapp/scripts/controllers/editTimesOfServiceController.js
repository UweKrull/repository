

angular.module('restaurantguideangularjs').controller('EditTimesOfServiceController', function($scope, $routeParams, $location, TimesOfServiceResource , RestaurantResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.timesOfService = new TimesOfServiceResource(self.original);
            RestaurantResource.queryAll(function(items) {
                $scope.restaurantSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.timesOfService.restaurant && item.id == $scope.timesOfService.restaurant.id) {
                        $scope.restaurantSelection = labelObject;
                        $scope.timesOfService.restaurant = wrappedObject;
                        self.original.restaurant = $scope.timesOfService.restaurant;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/TimesOfServices");
        };
        TimesOfServiceResource.get({TimesOfServiceId:$routeParams.TimesOfServiceId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.timesOfService);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.timesOfService.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/TimesOfServices");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/TimesOfServices");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.timesOfService.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("restaurantSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timesOfService.restaurant = {};
            $scope.timesOfService.restaurant.id = selection.value;
        }
    });
    
    $scope.get();
});