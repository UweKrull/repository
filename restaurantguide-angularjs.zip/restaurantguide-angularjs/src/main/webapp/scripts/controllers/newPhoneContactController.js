
angular.module('restaurantguideangularjs').controller('NewPhoneContactController', function ($scope, $location, locationParser, PhoneContactResource , RestaurantResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.phoneContact = $scope.phoneContact || {};
    
    $scope.restaurantList = RestaurantResource.queryAll(function(items){
        $scope.restaurantSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("restaurantSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.phoneContact.restaurant = {};
            $scope.phoneContact.restaurant.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/PhoneContacts/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PhoneContactResource.save($scope.phoneContact, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/PhoneContacts");
    };
});