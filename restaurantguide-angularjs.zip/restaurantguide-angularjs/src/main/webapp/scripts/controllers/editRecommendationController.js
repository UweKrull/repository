

angular.module('restaurantguideangularjs').controller('EditRecommendationController', function($scope, $routeParams, $location, RecommendationResource , RestaurantResource, CustomerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.recommendation = new RecommendationResource(self.original);
            RestaurantResource.queryAll(function(items) {
                $scope.restaurantSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.recommendation.restaurant && item.id == $scope.recommendation.restaurant.id) {
                        $scope.restaurantSelection = labelObject;
                        $scope.recommendation.restaurant = wrappedObject;
                        self.original.restaurant = $scope.recommendation.restaurant;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.guestSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.aliasName
                    };
                    if($scope.recommendation.guest && item.id == $scope.recommendation.guest.id) {
                        $scope.guestSelection = labelObject;
                        $scope.recommendation.guest = wrappedObject;
                        self.original.guest = $scope.recommendation.guest;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Recommendations");
        };
        RecommendationResource.get({RecommendationId:$routeParams.RecommendationId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.recommendation);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.recommendation.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Recommendations");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Recommendations");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.recommendation.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("restaurantSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recommendation.restaurant = {};
            $scope.recommendation.restaurant.id = selection.value;
        }
    });
    $scope.$watch("guestSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recommendation.guest = {};
            $scope.recommendation.guest.id = selection.value;
        }
    });
    $scope.rankingTypeList = [
        "OUTSTANDING",  
        "EXCELLENT",  
        "GOOD",  
        "AVERAGE",  
        "POOR",  
        "DREADFUL"  
    ];
    
    $scope.get();
});