angular.module('restaurantguideangularjs').factory('RecommendationResource', function($resource){
    var resource = $resource('rest/recommendations/:RecommendationId',{RecommendationId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});