package de.binaris.restaurantguide.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import de.binaris.restaurantguide.model.Restaurant;

/**
 * <p>
 * A restaurant's times of service .
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "times_of_service")
public class TimesOfService implements Serializable {

	private static final long serialVersionUID = 7278971756722267965L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_times_of_service")
	@SequenceGenerator(name = "my_entity_seq_gen_times_of_service", sequenceName = "sequence_times_of_service", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
	private String days;
	
	@NotNull
	@Size(min = 4, max = 10, message = "must be 4-10 letters and spaces")
	private String startTime;
	
	@NotNull
	@Size(min = 4, max = 10, message = "must be 4-10 letters and spaces")
	private String endTime;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Restaurant restaurant;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String days) {
		this.days = days;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}
	
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public Restaurant getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	
	/*
	 * toString(), equals() and hashCode() for TimeAndCharge, using the natural
	 * identity of the object
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof TimesOfService)) {
			return false;
		}
		TimesOfService castOther = (TimesOfService) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(days).append(", ");
		sb.append(startTime);
		if (endTime != null) {
			sb.append(", ");
			sb.append(endTime);
		}
		return sb.toString();
	}
}
