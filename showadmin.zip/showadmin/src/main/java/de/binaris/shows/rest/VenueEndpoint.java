package de.binaris.shows.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.shows.model.Venue;
import de.binaris.shows.rest.dto.VenueDTO;

@Stateless
@Path("/venues")
public class VenueEndpoint
{
   @PersistenceContext(unitName = "ShowfinderPU")
   private EntityManager em;

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Venue> findByIdQuery = em.createQuery("SELECT DISTINCT v FROM Venue v LEFT JOIN FETCH v.show WHERE v.id = :entityId ORDER BY v.id", Venue.class);
      findByIdQuery.setParameter("entityId", id);
      Venue entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      VenueDTO dto = new VenueDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<VenueDTO> listAll()
   {
      final List<Venue> searchResults = em.createQuery("SELECT DISTINCT v FROM Venue v LEFT JOIN FETCH v.show ORDER BY v.id", Venue.class).getResultList();
      final List<VenueDTO> results = new ArrayList<VenueDTO>();
      for (Venue searchResult : searchResults)
      {
         VenueDTO dto = new VenueDTO(searchResult);
         results.add(dto);
      }
      return results;
   }
}