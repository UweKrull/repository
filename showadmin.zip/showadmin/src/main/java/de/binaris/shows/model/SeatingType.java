package de.binaris.shows.model;

/**
 * <p>
 * The {@link SeatingType} describes the seating types (VIP, Premium,...)
 * 
 * Seating is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the partner types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link SeatingType} describes the type
 * of seating in the showroom.
 * </p>
 */
public enum SeatingType {

    /**
     * The SeatingType in the showroom.
     */
    vip("vip", true),
    premium("premium", true),
    general_admission("general_admission", true),
    no_reservation("no_reservation", true),
    unknown("unknown", true);

    /**
     * A human readable description of the seating type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the seating type can be cached.
     */
    private final boolean cacheable;
    
    private SeatingType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
