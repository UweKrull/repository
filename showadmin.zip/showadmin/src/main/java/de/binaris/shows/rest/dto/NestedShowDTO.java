package de.binaris.shows.rest.dto;

import java.io.Serializable;
import de.binaris.shows.model.Show;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.shows.model.AdultOnlyType;

public class NestedShowDTO implements Serializable
{

   private String priceRangeMin;
   private String linkBookOnlineAtVenue;
   private String dressCode;
   private Long id;
   private String linkBookOnlineAtProvider2;
   private String schedule;
   private AdultOnlyType adultOnly;
   private String linkBookOnlineAtProvider1;
   private String description;
   private String priceRangeMax;
   private String name;
   private String linkDetails;
   private String linkSeatingChart;
   private String linkBookOnlineLocally;

   public NestedShowDTO()
   {
   }

   public NestedShowDTO(final Show entity)
   {
      if (entity != null)
      {
         this.priceRangeMin = entity.getPriceRangeMin();
         this.linkBookOnlineAtVenue = entity.getLinkBookOnlineAtVenue();
         this.dressCode = entity.getDressCode();
         this.id = entity.getId();
         this.linkBookOnlineAtProvider2 = entity
               .getLinkBookOnlineAtProvider2();
         this.schedule = entity.getSchedule();
         this.adultOnly = entity.getAdultOnly();
         this.linkBookOnlineAtProvider1 = entity
               .getLinkBookOnlineAtProvider1();
         this.description = entity.getDescription();
         this.priceRangeMax = entity.getPriceRangeMax();
         this.name = entity.getName();
         this.linkDetails = entity.getLinkDetails();
         this.linkSeatingChart = entity.getLinkSeatingChart();
         this.linkBookOnlineLocally = entity.getLinkBookOnlineLocally();
      }
   }

   public Show fromDTO(Show entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Show();
      }
      if (this.id != null)
      {
         TypedQuery<Show> findByIdQuery = em.createQuery(
               "SELECT DISTINCT s FROM Show s WHERE s.id = :entityId",
               Show.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setPriceRangeMin(this.priceRangeMin);
      entity.setLinkBookOnlineAtVenue(this.linkBookOnlineAtVenue);
      entity.setDressCode(this.dressCode);
      entity.setLinkBookOnlineAtProvider2(this.linkBookOnlineAtProvider2);
      entity.setSchedule(this.schedule);
      entity.setAdultOnly(this.adultOnly);
      entity.setLinkBookOnlineAtProvider1(this.linkBookOnlineAtProvider1);
      entity.setDescription(this.description);
      entity.setPriceRangeMax(this.priceRangeMax);
      entity.setName(this.name);
      entity.setLinkDetails(this.linkDetails);
      entity.setLinkSeatingChart(this.linkSeatingChart);
      entity.setLinkBookOnlineLocally(this.linkBookOnlineLocally);
      entity = em.merge(entity);
      return entity;
   }

   public String getPriceRangeMin()
   {
      return this.priceRangeMin;
   }

   public void setPriceRangeMin(final String priceRangeMin)
   {
      this.priceRangeMin = priceRangeMin;
   }

   public String getLinkBookOnlineAtVenue()
   {
      return this.linkBookOnlineAtVenue;
   }

   public void setLinkBookOnlineAtVenue(final String linkBookOnlineAtVenue)
   {
      this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
   }

   public String getDressCode()
   {
      return this.dressCode;
   }

   public void setDressCode(final String dressCode)
   {
      this.dressCode = dressCode;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getLinkBookOnlineAtProvider2()
   {
      return this.linkBookOnlineAtProvider2;
   }

   public void setLinkBookOnlineAtProvider2(
         final String linkBookOnlineAtProvider2)
   {
      this.linkBookOnlineAtProvider2 = linkBookOnlineAtProvider2;
   }

   public String getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final String schedule)
   {
      this.schedule = schedule;
   }

   public AdultOnlyType getAdultOnly()
   {
      return this.adultOnly;
   }

   public void setAdultOnly(final AdultOnlyType adultOnly)
   {
      this.adultOnly = adultOnly;
   }

   public String getLinkBookOnlineAtProvider1()
   {
      return this.linkBookOnlineAtProvider1;
   }

   public void setLinkBookOnlineAtProvider1(
         final String linkBookOnlineAtProvider1)
   {
      this.linkBookOnlineAtProvider1 = linkBookOnlineAtProvider1;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getPriceRangeMax()
   {
      return this.priceRangeMax;
   }

   public void setPriceRangeMax(final String priceRangeMax)
   {
      this.priceRangeMax = priceRangeMax;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLinkDetails()
   {
      return this.linkDetails;
   }

   public void setLinkDetails(final String linkDetails)
   {
      this.linkDetails = linkDetails;
   }

   public String getLinkSeatingChart()
   {
      return this.linkSeatingChart;
   }

   public void setLinkSeatingChart(final String linkSeatingChart)
   {
      this.linkSeatingChart = linkSeatingChart;
   }

   public String getLinkBookOnlineLocally()
   {
      return this.linkBookOnlineLocally;
   }

   public void setLinkBookOnlineLocally(final String linkBookOnlineLocally)
   {
      this.linkBookOnlineLocally = linkBookOnlineLocally;
   }
}