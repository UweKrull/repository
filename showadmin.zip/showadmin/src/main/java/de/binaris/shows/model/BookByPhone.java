package de.binaris.shows.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>
 * A phone number to use for booking an offered show.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "book_by_phone")
public class BookByPhone implements Serializable {

	private static final long serialVersionUID = 127797175632679629L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_book_by_phone")
	@SequenceGenerator(name = "my_entity_seq_gen_book_by_phone", sequenceName = "sequence_book_by_phone", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 3, max = 20, message = "must be 3-20 letters and spaces")
	private String phoneNumber;
	
    @NotNull
    @Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
    private String name;
    
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Show show;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Show getShow() {
		return show;
	}

	public void setShow(Show show) {
		this.show = show;
	}
	
	/*
	 * toString(), equals() and hashCode() for Ingredient, using the natural
	 * identity of the object
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof BookByPhone)) {
			return false;
		}
		BookByPhone castOther = (BookByPhone) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(phoneNumber).append(", ");
		sb.append(name);
		return sb.toString();
	}
}
