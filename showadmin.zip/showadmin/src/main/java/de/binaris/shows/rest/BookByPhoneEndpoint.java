package de.binaris.shows.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.shows.model.BookByPhone;
import de.binaris.shows.rest.dto.BookByPhoneDTO;

@Stateless
@Path("/bookbyphones")
public class BookByPhoneEndpoint
{
   @PersistenceContext(unitName = "ShowfinderPU")
   private EntityManager em;

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<BookByPhone> findByIdQuery = em.createQuery("SELECT DISTINCT b FROM BookByPhone b LEFT JOIN FETCH b.show WHERE b.id = :entityId ORDER BY b.id", BookByPhone.class);
      findByIdQuery.setParameter("entityId", id);
      BookByPhone entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      BookByPhoneDTO dto = new BookByPhoneDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<BookByPhoneDTO> listAll()
   {
      final List<BookByPhone> searchResults = em.createQuery("SELECT DISTINCT b FROM BookByPhone b LEFT JOIN FETCH b.show ORDER BY b.id", BookByPhone.class).getResultList();
      final List<BookByPhoneDTO> results = new ArrayList<BookByPhoneDTO>();
      for (BookByPhone searchResult : searchResults)
      {
         BookByPhoneDTO dto = new BookByPhoneDTO(searchResult);
         results.add(dto);
      }
      return results;
   }
}