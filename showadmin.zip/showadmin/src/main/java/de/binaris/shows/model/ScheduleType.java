package de.binaris.shows.model;

/**
 * <p>
 * The {@link ScheduleType} describes the types of schedule (6 days a week, 1 day a month, ...)
 * 
 * Schedule is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the partner types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link ScheduleType} describes the show's type of schedule.
 * </p>
 */
public enum ScheduleType {

    /**
     * The ScheduleType of the show.
     */
    seven_days_a_week("7 days a week", true),
    six_days_a_week("6 days a week", true),
    five_days_a_week("5 days a week", true),
    four_days_a_week("4 days a week", true),
    three_days_a_week("3 days a week", true),
    two_days_a_week("2 days a week", true),
    one_day_a_week("1 day a week", true),
    once_a_month("1 day a month", true),
    twice_a_month("2 days a month", true),
    three_days_a_month("3 days a month", true),
    four_days_a_month("4 days a month", true),
    five_days_a_month("5 days a month", true),
    six_days_a_month("6 days a month", true),
    one_week_a_month("1 week a month", true),
    eight_days_a_month("8 days a month", true),
    nine_days_a_month("9 days a month", true),
    ten_days_a_month("10 days a month", true),
    eleven_days_a_month("11 days a month", true),
    twelve_days_a_month("12 days a month", true),
    thirteen_days_a_month("13 days a month", true),
    two_weeks_a_month("2 weeks a month", true),
    three_weeks_a_month("3 weeks a month", true),
    unknown("unknown", true);

    /**
     * A human readable description of the schedule type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the schedule type can be cached.
     */
    private final boolean cacheable;
    
    private ScheduleType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
