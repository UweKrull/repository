package de.binaris.shows.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.shows.model.TimeAndPrice;
import de.binaris.shows.rest.dto.TimeAndPriceDTO;

@Stateless
@Path("/timeandprices")
public class TimeAndPriceEndpoint
{
   @PersistenceContext(unitName = "ShowfinderPU")
   private EntityManager em;

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<TimeAndPrice> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TimeAndPrice t LEFT JOIN FETCH t.show WHERE t.id = :entityId ORDER BY t.id", TimeAndPrice.class);
      findByIdQuery.setParameter("entityId", id);
      TimeAndPrice entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      TimeAndPriceDTO dto = new TimeAndPriceDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<TimeAndPriceDTO> listAll()
   {
      final List<TimeAndPrice> searchResults = em.createQuery("SELECT DISTINCT t FROM TimeAndPrice t LEFT JOIN FETCH t.show ORDER BY t.id", TimeAndPrice.class).getResultList();
      final List<TimeAndPriceDTO> results = new ArrayList<TimeAndPriceDTO>();
      for (TimeAndPrice searchResult : searchResults)
      {
         TimeAndPriceDTO dto = new TimeAndPriceDTO(searchResult);
         results.add(dto);
      }
      return results;
   }
}