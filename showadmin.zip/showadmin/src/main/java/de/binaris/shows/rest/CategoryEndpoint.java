package de.binaris.shows.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.shows.model.Category;
import de.binaris.shows.rest.dto.CategoryDTO;

@Stateless
@Path("/categorys")
public class CategoryEndpoint
{
   @PersistenceContext(unitName = "ShowfinderPU")
   private EntityManager em;

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Category> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM Category c LEFT JOIN FETCH c.show WHERE c.id = :entityId ORDER BY c.id", Category.class);
      findByIdQuery.setParameter("entityId", id);
      Category entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      CategoryDTO dto = new CategoryDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<CategoryDTO> listAll()
   {
      final List<Category> searchResults = em.createQuery("SELECT DISTINCT c FROM Category c LEFT JOIN FETCH c.show ORDER BY c.id", Category.class).getResultList();
      final List<CategoryDTO> results = new ArrayList<CategoryDTO>();
      for (Category searchResult : searchResults)
      {
         CategoryDTO dto = new CategoryDTO(searchResult);
         results.add(dto);
      }
      return results;
   }
}