angular.module('showadmin').factory('BookByPhoneResource', function($resource){
    var resource = $resource('rest/bookbyphones/:BookByPhoneId',{BookByPhoneId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});