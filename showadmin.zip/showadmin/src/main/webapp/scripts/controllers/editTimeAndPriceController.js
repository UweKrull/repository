

angular.module('showadmin').controller('EditTimeAndPriceController', function($scope, $routeParams, $location, TimeAndPriceResource , ShowResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.timeAndPrice = new TimeAndPriceResource(self.original);
            ShowResource.queryAll(function(items) {
                $scope.showSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.timeAndPrice.show && item.id == $scope.timeAndPrice.show.id) {
                        $scope.showSelection = labelObject;
                        $scope.timeAndPrice.show = wrappedObject;
                        self.original.show = $scope.timeAndPrice.show;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/TimeAndPrices");
        };
        TimeAndPriceResource.get({TimeAndPriceId:$routeParams.TimeAndPriceId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.timeAndPrice);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.timeAndPrice.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/TimeAndPrices");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/TimeAndPrices");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.timeAndPrice.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("showSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timeAndPrice.show = {};
            $scope.timeAndPrice.show.id = selection.value;
        }
    });
    
    $scope.get();
});