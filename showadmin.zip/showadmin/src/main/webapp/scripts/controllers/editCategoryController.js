

angular.module('showadmin').controller('EditCategoryController', function($scope, $routeParams, $location, CategoryResource , ShowResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.category = new CategoryResource(self.original);
            ShowResource.queryAll(function(items) {
                $scope.showSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.category.show){
                        $.each($scope.category.show, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.showSelection.push(labelObject);
                                $scope.category.show.push(wrappedObject);
                            }
                        });
                        self.original.show = $scope.category.show;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Categorys");
        };
        CategoryResource.get({CategoryId:$routeParams.CategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.category);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.category.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Categorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Categorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.category.$remove(successCallback, errorCallback);
    };
    
    $scope.showSelection = $scope.showSelection || [];
    $scope.$watch("showSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.category) {
            $scope.category.show = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.category.show.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});