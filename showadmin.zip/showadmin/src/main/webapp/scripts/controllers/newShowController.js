
angular.module('showadmin').controller('NewShowController', function ($scope, $location, locationParser, ShowResource , VenueResource, CategoryResource, TimeAndPriceResource, BookByPhoneResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.show = $scope.show || {};
    
    $scope.venueList = VenueResource.queryAll(function(items){
        $scope.venueSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("venueSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.show.venue = {};
            $scope.show.venue.id = selection.value;
        }
    });
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.show.category = {};
            $scope.show.category.id = selection.value;
        }
    });
    
    $scope.timeAndPriceList = TimeAndPriceResource.queryAll(function(items){
        $scope.timeAndPriceSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.days
            });
        });
    });
    $scope.$watch("timeAndPriceSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.show.timeAndPrice = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.show.timeAndPrice.push(collectionItem);
            });
        }
    });
    
    $scope.bookByPhoneList = BookByPhoneResource.queryAll(function(items){
        $scope.bookByPhoneSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.phoneNumber
            });
        });
    });
    $scope.$watch("bookByPhoneSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.show.bookByPhone = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.show.bookByPhone.push(collectionItem);
            });
        }
    });
    
    $scope.adultOnlyList = [
        "yes",
        "no"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Shows/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ShowResource.save($scope.show, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Shows");
    };
});