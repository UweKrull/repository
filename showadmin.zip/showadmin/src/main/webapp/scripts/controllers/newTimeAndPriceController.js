
angular.module('showadmin').controller('NewTimeAndPriceController', function ($scope, $location, locationParser, TimeAndPriceResource , ShowResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.timeAndPrice = $scope.timeAndPrice || {};
    
    $scope.showList = ShowResource.queryAll(function(items){
        $scope.showSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("showSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.timeAndPrice.show = {};
            $scope.timeAndPrice.show.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/TimeAndPrices/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TimeAndPriceResource.save($scope.timeAndPrice, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/TimeAndPrices");
    };
});