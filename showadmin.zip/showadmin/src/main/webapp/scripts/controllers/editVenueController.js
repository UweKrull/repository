

angular.module('showadmin').controller('EditVenueController', function($scope, $routeParams, $location, VenueResource , ShowResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.venue = new VenueResource(self.original);
            ShowResource.queryAll(function(items) {
                $scope.showSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.venue.show){
                        $.each($scope.venue.show, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.showSelection.push(labelObject);
                                $scope.venue.show.push(wrappedObject);
                            }
                        });
                        self.original.show = $scope.venue.show;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.venue.address.country && item.id == $scope.venue.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.venue.address.country = wrappedObject;
                        self.original.address.country = $scope.venue.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Venues");
        };
        VenueResource.get({VenueId:$routeParams.VenueId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.venue);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.venue.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Venues");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Venues");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.venue.$remove(successCallback, errorCallback);
    };
    
    $scope.showSelection = $scope.showSelection || [];
    $scope.$watch("showSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.venue) {
            $scope.venue.show = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.venue.show.push(collectionItem);
            });
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.venue.address.country = {};
            $scope.venue.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});