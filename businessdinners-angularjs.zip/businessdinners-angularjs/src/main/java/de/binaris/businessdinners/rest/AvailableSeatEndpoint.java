package de.binaris.businessdinners.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.businessdinners.model.AvailableSeat;
import de.binaris.businessdinners.rest.dto.AvailableSeatDTO;

/**
 * 
 */
@Stateless
@Path("/availableseats")
public class AvailableSeatEndpoint
{
   @PersistenceContext(unitName = "BusinessdinnersPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(AvailableSeatDTO dto)
   {
      AvailableSeat entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(AvailableSeatEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      AvailableSeat entity = em.find(AvailableSeat.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<AvailableSeat> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM AvailableSeat a LEFT JOIN FETCH a.seatsList LEFT JOIN FETCH a.seat LEFT JOIN FETCH a.user WHERE a.id = :entityId ORDER BY a.id", AvailableSeat.class);
      findByIdQuery.setParameter("entityId", id);
      AvailableSeat entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      AvailableSeatDTO dto = new AvailableSeatDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<AvailableSeatDTO> listAll()
   {
      final List<AvailableSeat> searchResults = em.createQuery("SELECT DISTINCT a FROM AvailableSeat a LEFT JOIN FETCH a.seatsList LEFT JOIN FETCH a.seat LEFT JOIN FETCH a.user ORDER BY a.id", AvailableSeat.class).getResultList();
      final List<AvailableSeatDTO> results = new ArrayList<AvailableSeatDTO>();
      for (AvailableSeat searchResult : searchResults)
      {
         AvailableSeatDTO dto = new AvailableSeatDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, AvailableSeatDTO dto)
   {
      TypedQuery<AvailableSeat> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM AvailableSeat a LEFT JOIN FETCH a.seatsList LEFT JOIN FETCH a.seat LEFT JOIN FETCH a.user WHERE a.id = :entityId ORDER BY a.id", AvailableSeat.class);
      findByIdQuery.setParameter("entityId", id);
      AvailableSeat entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}