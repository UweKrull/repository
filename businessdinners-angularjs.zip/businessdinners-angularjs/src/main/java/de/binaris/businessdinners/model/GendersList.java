package de.binaris.businessdinners.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "genders_list")
public class GendersList implements Serializable {

	private static final long serialVersionUID = 7975779629657127325L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_genders_list")
	@SequenceGenerator(name = "my_entity_seq_gen_genders_list", sequenceName = "sequence_genders_list", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Dinner dinner;
	
	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String title;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "gendersList")
	private Set<AvailableGender> availableGender = new HashSet<AvailableGender>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Dinner getDinner() {
		return dinner;
	}

	public void setDinner(Dinner dinner) {
		this.dinner = dinner;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Set<AvailableGender> getAvailableGender() {
		return availableGender;
	}

	public void setAvailableGender(Set<AvailableGender> availableGender) {
		this.availableGender = availableGender;
	}

	public String getDisplayItems() {
		StringBuilder sb = new StringBuilder();
		for (AvailableGender ag : availableGender) {
			sb.append(ag.getUser().getLastName());
			sb.append(" ");
			sb.append(ag.getUser().getFirstName());
			sb.append(", ");
			sb.append(ag.getGender().toString());
			sb.append(";");
		}
		return sb.toString();
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof GendersList)) {
			return false;
		}
		GendersList castOther = (GendersList) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		if (title.length() > 20) {
			sb.append(title.substring(0, 20));
			sb.append("...");
		} else {
			sb.append(title);
		}
		return sb.toString();
	}
}
