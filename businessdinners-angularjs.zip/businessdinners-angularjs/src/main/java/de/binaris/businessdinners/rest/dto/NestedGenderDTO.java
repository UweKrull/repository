package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;
import de.binaris.businessdinners.model.Gender;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedGenderDTO implements Serializable
{

   private Long id;
   private String name;

   public NestedGenderDTO()
   {
   }

   public NestedGenderDTO(final Gender entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public Gender fromDTO(Gender entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Gender();
      }
      if (this.id != null)
      {
         TypedQuery<Gender> findByIdQuery = em.createQuery(
               "SELECT DISTINCT g FROM Gender g WHERE g.id = :entityId",
               Gender.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}