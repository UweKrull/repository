package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.SeatsList;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedSeatsListDTO implements Serializable
{

   private Long id;
   private String title;
   private String displayItems;

   public NestedSeatsListDTO()
   {
   }

   public NestedSeatsListDTO(final SeatsList entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.displayItems = entity.getDisplayItems();
      }
   }

   public SeatsList fromDTO(SeatsList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new SeatsList();
      }
      if (this.id != null)
      {
         TypedQuery<SeatsList> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT s FROM SeatsList s WHERE s.id = :entityId",
                     SeatsList.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
   
   public String getDisplayItems()
   {
	   return this.displayItems;
   }
   
   public void setDisplayItems(final String displayItems)
   {
	   this.displayItems = displayItems;
   }
}