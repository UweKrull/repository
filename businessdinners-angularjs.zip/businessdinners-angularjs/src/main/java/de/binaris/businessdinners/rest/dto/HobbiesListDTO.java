package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.HobbiesList;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessdinners.model.AvailableHobby;
import de.binaris.businessdinners.rest.dto.NestedAvailableHobbyDTO;
import de.binaris.businessdinners.rest.dto.NestedDinnerDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class HobbiesListDTO implements Serializable
{

   private NestedDinnerDTO dinner;
   private Long id;
   private Set<NestedAvailableHobbyDTO> availableHobby = new HashSet<NestedAvailableHobbyDTO>();
   private String title;
   private String displayItems;

   public HobbiesListDTO()
   {
   }

   public HobbiesListDTO(final HobbiesList entity)
   {
      if (entity != null)
      {
         this.dinner = new NestedDinnerDTO(entity.getDinner());
         this.id = entity.getId();
         Iterator<AvailableHobby> iterAvailableHobby = entity
               .getAvailableHobby().iterator();
         for (; iterAvailableHobby.hasNext();)
         {
            AvailableHobby element = iterAvailableHobby.next();
            this.availableHobby.add(new NestedAvailableHobbyDTO(element));
         }
         this.title = entity.getTitle();
         this.displayItems = entity.getDisplayItems();
      }
   }

   public HobbiesList fromDTO(HobbiesList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new HobbiesList();
      }
      if (this.dinner != null)
      {
         entity.setDinner(this.dinner.fromDTO(entity.getDinner(), em));
      }
      Iterator<AvailableHobby> iterAvailableHobby = entity
            .getAvailableHobby().iterator();
      for (; iterAvailableHobby.hasNext();)
      {
         boolean found = false;
         AvailableHobby availableHobby = iterAvailableHobby.next();
         Iterator<NestedAvailableHobbyDTO> iterDtoAvailableHobby = this
               .getAvailableHobby().iterator();
         for (; iterDtoAvailableHobby.hasNext();)
         {
            NestedAvailableHobbyDTO dtoAvailableHobby = iterDtoAvailableHobby
                  .next();
            if (dtoAvailableHobby.getId().equals(availableHobby.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterAvailableHobby.remove();
         }
      }
      Iterator<NestedAvailableHobbyDTO> iterDtoAvailableHobby = this
            .getAvailableHobby().iterator();
      for (; iterDtoAvailableHobby.hasNext();)
      {
         boolean found = false;
         NestedAvailableHobbyDTO dtoAvailableHobby = iterDtoAvailableHobby
               .next();
         iterAvailableHobby = entity.getAvailableHobby().iterator();
         for (; iterAvailableHobby.hasNext();)
         {
            AvailableHobby availableHobby = iterAvailableHobby.next();
            if (dtoAvailableHobby.getId().equals(availableHobby.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<AvailableHobby> resultIter = em
                  .createQuery("SELECT DISTINCT a FROM AvailableHobby a",
                        AvailableHobby.class).getResultList()
                  .iterator();
            for (; resultIter.hasNext();)
            {
               AvailableHobby result = resultIter.next();
               if (result.getId().equals(dtoAvailableHobby.getId()))
               {
                  entity.getAvailableHobby().add(result);
                  break;
               }
            }
         }
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public NestedDinnerDTO getDinner()
   {
      return this.dinner;
   }

   public void setDinner(final NestedDinnerDTO dinner)
   {
      this.dinner = dinner;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedAvailableHobbyDTO> getAvailableHobby()
   {
      return this.availableHobby;
   }

   public void setAvailableHobby(
         final Set<NestedAvailableHobbyDTO> availableHobby)
   {
      this.availableHobby = availableHobby;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public String getDisplayItems()
   {
	   return this.displayItems;
   }
   
   public void setDisplayItems(final String displayItems)
   {
	   this.displayItems = displayItems;
   }
}