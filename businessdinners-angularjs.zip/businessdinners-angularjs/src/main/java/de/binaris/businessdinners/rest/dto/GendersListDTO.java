package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.GendersList;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessdinners.model.AvailableGender;
import de.binaris.businessdinners.rest.dto.NestedAvailableGenderDTO;
import de.binaris.businessdinners.rest.dto.NestedDinnerDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class GendersListDTO implements Serializable
{

   private NestedDinnerDTO dinner;
   private Long id;
   private String title;
   private Set<NestedAvailableGenderDTO> availableGender = new HashSet<NestedAvailableGenderDTO>();
   private String displayItems;
   
   public GendersListDTO()
   {
   }

   public GendersListDTO(final GendersList entity)
   {
      if (entity != null)
      {
         this.dinner = new NestedDinnerDTO(entity.getDinner());
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.displayItems = entity.getDisplayItems();
         Iterator<AvailableGender> iterAvailableGender = entity
               .getAvailableGender().iterator();
         for (; iterAvailableGender.hasNext();)
         {
            AvailableGender element = iterAvailableGender.next();
            this.availableGender.add(new NestedAvailableGenderDTO(element));
         }
      }
   }

   public GendersList fromDTO(GendersList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new GendersList();
      }
      if (this.dinner != null)
      {
         entity.setDinner(this.dinner.fromDTO(entity.getDinner(), em));
      }
      entity.setTitle(this.title);
      Iterator<AvailableGender> iterAvailableGender = entity
            .getAvailableGender().iterator();
      for (; iterAvailableGender.hasNext();)
      {
         boolean found = false;
         AvailableGender availableGender = iterAvailableGender.next();
         Iterator<NestedAvailableGenderDTO> iterDtoAvailableGender = this
               .getAvailableGender().iterator();
         for (; iterDtoAvailableGender.hasNext();)
         {
            NestedAvailableGenderDTO dtoAvailableGender = iterDtoAvailableGender
                  .next();
            if (dtoAvailableGender.getId().equals(availableGender.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterAvailableGender.remove();
         }
      }
      Iterator<NestedAvailableGenderDTO> iterDtoAvailableGender = this
            .getAvailableGender().iterator();
      for (; iterDtoAvailableGender.hasNext();)
      {
         boolean found = false;
         NestedAvailableGenderDTO dtoAvailableGender = iterDtoAvailableGender
               .next();
         iterAvailableGender = entity.getAvailableGender().iterator();
         for (; iterAvailableGender.hasNext();)
         {
            AvailableGender availableGender = iterAvailableGender.next();
            if (dtoAvailableGender.getId().equals(availableGender.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<AvailableGender> resultIter = em
                  .createQuery(
                        "SELECT DISTINCT a FROM AvailableGender a",
                        AvailableGender.class).getResultList()
                  .iterator();
            for (; resultIter.hasNext();)
            {
               AvailableGender result = resultIter.next();
               if (result.getId().equals(dtoAvailableGender.getId()))
               {
                  entity.getAvailableGender().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public NestedDinnerDTO getDinner()
   {
      return this.dinner;
   }

   public void setDinner(final NestedDinnerDTO dinner)
   {
      this.dinner = dinner;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public Set<NestedAvailableGenderDTO> getAvailableGender()
   {
      return this.availableGender;
   }

   public void setAvailableGender(
         final Set<NestedAvailableGenderDTO> availableGender)
   {
      this.availableGender = availableGender;
   }
   
   public String getDisplayItems()
   {
	   return this.displayItems;
   }
   
   public void setDisplayItems(final String displayItems)
   {
	   this.displayItems = displayItems;
   }
}