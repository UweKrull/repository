package de.binaris.businessdinners.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.businessdinners.model.Dinner;
import de.binaris.businessdinners.rest.dto.DinnerDTO;

/**
 * 
 */
@Stateless
@Path("/dinners")
public class DinnerEndpoint
{
   @PersistenceContext(unitName = "BusinessdinnersPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(DinnerDTO dto)
   {
      Dinner entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(DinnerEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Dinner entity = em.find(Dinner.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Dinner> findByIdQuery = em.createQuery("SELECT DISTINCT d FROM Dinner d LEFT JOIN FETCH d.venue LEFT JOIN FETCH d.category LEFT JOIN FETCH d.seatingChart LEFT JOIN FETCH d.hobbiesList LEFT JOIN FETCH d.jobsList LEFT JOIN FETCH d.gendersList LEFT JOIN FETCH d.seatsList WHERE d.id = :entityId ORDER BY d.id", Dinner.class);
      findByIdQuery.setParameter("entityId", id);
      Dinner entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      DinnerDTO dto = new DinnerDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<DinnerDTO> listAll()
   {
      final List<Dinner> searchResults = em.createQuery("SELECT DISTINCT d FROM Dinner d LEFT JOIN FETCH d.venue LEFT JOIN FETCH d.category LEFT JOIN FETCH d.seatingChart LEFT JOIN FETCH d.hobbiesList LEFT JOIN FETCH d.jobsList LEFT JOIN FETCH d.gendersList LEFT JOIN FETCH d.seatsList ORDER BY d.id", Dinner.class).getResultList();
      final List<DinnerDTO> results = new ArrayList<DinnerDTO>();
      for (Dinner searchResult : searchResults)
      {
         DinnerDTO dto = new DinnerDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, DinnerDTO dto)
   {
      TypedQuery<Dinner> findByIdQuery = em.createQuery("SELECT DISTINCT d FROM Dinner d LEFT JOIN FETCH d.venue LEFT JOIN FETCH d.category LEFT JOIN FETCH d.seatingChart LEFT JOIN FETCH d.hobbiesList LEFT JOIN FETCH d.jobsList LEFT JOIN FETCH d.gendersList LEFT JOIN FETCH d.seatsList WHERE d.id = :entityId ORDER BY d.id", Dinner.class);
      findByIdQuery.setParameter("entityId", id);
      Dinner entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}