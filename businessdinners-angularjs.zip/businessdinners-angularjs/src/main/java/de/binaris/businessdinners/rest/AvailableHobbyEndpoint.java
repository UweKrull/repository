package de.binaris.businessdinners.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.businessdinners.model.AvailableHobby;
import de.binaris.businessdinners.rest.dto.AvailableHobbyDTO;

/**
 * 
 */
@Stateless
@Path("/availablehobbys")
public class AvailableHobbyEndpoint
{
   @PersistenceContext(unitName = "BusinessdinnersPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(AvailableHobbyDTO dto)
   {
      AvailableHobby entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(AvailableHobbyEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      AvailableHobby entity = em.find(AvailableHobby.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<AvailableHobby> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM AvailableHobby a LEFT JOIN FETCH a.hobbiesList LEFT JOIN FETCH a.hobby LEFT JOIN FETCH a.user WHERE a.id = :entityId ORDER BY a.id", AvailableHobby.class);
      findByIdQuery.setParameter("entityId", id);
      AvailableHobby entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      AvailableHobbyDTO dto = new AvailableHobbyDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<AvailableHobbyDTO> listAll()
   {
      final List<AvailableHobby> searchResults = em.createQuery("SELECT DISTINCT a FROM AvailableHobby a LEFT JOIN FETCH a.hobbiesList LEFT JOIN FETCH a.hobby LEFT JOIN FETCH a.user ORDER BY a.id", AvailableHobby.class).getResultList();
      final List<AvailableHobbyDTO> results = new ArrayList<AvailableHobbyDTO>();
      for (AvailableHobby searchResult : searchResults)
      {
         AvailableHobbyDTO dto = new AvailableHobbyDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, AvailableHobbyDTO dto)
   {
      TypedQuery<AvailableHobby> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM AvailableHobby a LEFT JOIN FETCH a.hobbiesList LEFT JOIN FETCH a.hobby LEFT JOIN FETCH a.user WHERE a.id = :entityId ORDER BY a.id", AvailableHobby.class);
      findByIdQuery.setParameter("entityId", id);
      AvailableHobby entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}