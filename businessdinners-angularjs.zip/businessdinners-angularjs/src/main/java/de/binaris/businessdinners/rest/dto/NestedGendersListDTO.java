package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.GendersList;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedGendersListDTO implements Serializable
{

   private Long id;
   private String title;
   private String displayItems;

   public NestedGendersListDTO()
   {
   }

   public NestedGendersListDTO(final GendersList entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.displayItems = entity.getDisplayItems();
      }
   }

   public GendersList fromDTO(GendersList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new GendersList();
      }
      if (this.id != null)
      {
         TypedQuery<GendersList> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT g FROM GendersList g WHERE g.id = :entityId",
                     GendersList.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
   
   public String getDisplayItems()
   {
	   return this.displayItems;
   }
   
   public void setDisplayItems(final String displayItems)
   {
	   this.displayItems = displayItems;
   }
}