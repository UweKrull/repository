package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;
import de.binaris.businessdinners.model.Seat;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SeatDTO implements Serializable
{

   private Long id;
   private String description;
   private String name;

   public SeatDTO()
   {
   }

   public SeatDTO(final Seat entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
      }
   }

   public Seat fromDTO(Seat entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Seat();
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}