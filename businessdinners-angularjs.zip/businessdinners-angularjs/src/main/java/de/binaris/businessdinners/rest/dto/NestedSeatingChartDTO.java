package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;
import de.binaris.businessdinners.model.SeatingChart;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedSeatingChartDTO implements Serializable
{

   private Long id;
   private String name;
   private String url;

   public NestedSeatingChartDTO()
   {
   }

   public NestedSeatingChartDTO(final SeatingChart entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
         this.url = entity.getUrl();
      }
   }

   public SeatingChart fromDTO(SeatingChart entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new SeatingChart();
      }
      if (this.id != null)
      {
         TypedQuery<SeatingChart> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT s FROM SeatingChart s WHERE s.id = :entityId",
                     SeatingChart.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity.setUrl(this.url);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getUrl()
   {
      return this.url;
   }

   public void setUrl(final String url)
   {
      this.url = url;
   }
}