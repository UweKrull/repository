package de.binaris.businessdinners.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "business_dinner")
public class Dinner implements Serializable {

	private static final long serialVersionUID = 7972379629657125327L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_business_dinner")
	@SequenceGenerator(name = "my_entity_seq_gen_business_dinner", sequenceName = "sequence_business_dinner", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String name;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Venue venue;
	
	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Category category;
	
	@NotNull
	@Size(min = 1, max = 200, message = "must be 1-200 letters and spaces")
	private String hostname;
	
	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
    private String schedule;
    
    @Column(name = "private_only")
    @Enumerated(STRING)
    private PrivateOnlyType privateOnly;
    
	@Size(min = 0, max = 100, message = "optional max. 100 letters and spaces")
	private String dressCode;
		
    @ManyToOne
    private SeatingChart seatingChart;

	@Size(min = 0, max = 200, message = "optional max. 200 letters and spaces")
    private String linkDetails;
	
	@Size(min = 0, max = 200, message = "optional max. 200 letters and spaces")
	private String linkDrinkMenu;
	
	@Size(min = 0, max = 500, message = "optional max. 500 letters and spaces")
	private String linkGooglemaps;
	
	@Size(min = 0, max = 500, message = "optional max. 2000 letters and spaces")
	private String dinnerWebsite;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "dinner")
	private Set<HobbiesList> hobbiesList = new HashSet<HobbiesList>();
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "dinner")
	private Set<JobsList> jobsList = new HashSet<JobsList>();
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "dinner")
	private Set<GendersList> gendersList = new HashSet<GendersList>();
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "dinner")
	private Set<SeatsList> seatsList = new HashSet<SeatsList>();	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Venue getVenue() {
		return venue;
	}
	
	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	
	public PrivateOnlyType getPrivateOnly() {
		return privateOnly;
	}

	public void setPrivateOnly(PrivateOnlyType privateOnly) {
		this.privateOnly = privateOnly;
	}

	public String getDressCode() {
		return dressCode;
	}

	public void setDressCode(String dressCode) {
		this.dressCode = dressCode;
	}

	public String getLinkDetails() {
		return linkDetails;
	}

	public void setLinkDetails(String linkDetails) {
		this.linkDetails = linkDetails;
	}

	public SeatingChart getSeatingChart() {
		return seatingChart;
	}
	
	public void setSeatingChart(SeatingChart seatingChart) {
		this.seatingChart = seatingChart;
	}
	
	public String getLinkDrinkMenu() {
		return linkDrinkMenu;
	}
	
	public void setLinkDrinkMenu(String linkDrinkMenu) {
		this.linkDrinkMenu = linkDrinkMenu;
	}
	
	public String getLinkGooglemaps() {
		return linkGooglemaps;
	}
	
	public void setLinkGooglemaps(String linkGooglemaps) {
		this.linkGooglemaps = linkGooglemaps;
	}
	
	public String getDinnerWebsite() {
		return dinnerWebsite;
	}

	public void setDinnerWebsite(String dinnerWebsite) {
		this.dinnerWebsite = dinnerWebsite;
	}
	
	public Set<HobbiesList> getHobbiesList() {
		return hobbiesList;
	}
	
	public void setHobbiesList(Set<HobbiesList> hobbiesList) {
		this.hobbiesList = hobbiesList;
	}
	
	public Set<JobsList> getJobsList() {
		return jobsList;
	}
	
	public void setJobsList(Set<JobsList> jobsList) {
		this.jobsList = jobsList;
	}
	
	public Set<GendersList> getGendersList() {
		return gendersList;
	}
	
	public void setGendersList(Set<GendersList> gendersList) {
		this.gendersList = gendersList;
	}
	
	public Set<SeatsList> getSeatsList() {
		return seatsList;
	}
	
	public void setSeatsList(Set<SeatsList> seatsList) {
		this.seatsList = seatsList;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Dinner)) {
			return false;
		}
		Dinner castOther = (Dinner) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name);
		return sb.toString();
	}
}
