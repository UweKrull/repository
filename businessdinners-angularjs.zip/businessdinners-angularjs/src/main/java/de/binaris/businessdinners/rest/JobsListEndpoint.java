package de.binaris.businessdinners.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.businessdinners.model.JobsList;
import de.binaris.businessdinners.rest.dto.JobsListDTO;

/**
 * 
 */
@Stateless
@Path("/jobslists")
public class JobsListEndpoint
{
   @PersistenceContext(unitName = "BusinessdinnersPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(JobsListDTO dto)
   {
      JobsList entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(JobsListEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      JobsList entity = em.find(JobsList.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<JobsList> findByIdQuery = em.createQuery("SELECT DISTINCT j FROM JobsList j LEFT JOIN FETCH j.dinner LEFT JOIN FETCH j.availableJob WHERE j.id = :entityId ORDER BY j.id", JobsList.class);
      findByIdQuery.setParameter("entityId", id);
      JobsList entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      JobsListDTO dto = new JobsListDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<JobsListDTO> listAll()
   {
      final List<JobsList> searchResults = em.createQuery("SELECT DISTINCT j FROM JobsList j LEFT JOIN FETCH j.dinner LEFT JOIN FETCH j.availableJob ORDER BY j.id", JobsList.class).getResultList();
      final List<JobsListDTO> results = new ArrayList<JobsListDTO>();
      for (JobsList searchResult : searchResults)
      {
         JobsListDTO dto = new JobsListDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, JobsListDTO dto)
   {
      TypedQuery<JobsList> findByIdQuery = em.createQuery("SELECT DISTINCT j FROM JobsList j LEFT JOIN FETCH j.dinner LEFT JOIN FETCH j.availableJob WHERE j.id = :entityId ORDER BY j.id", JobsList.class);
      findByIdQuery.setParameter("entityId", id);
      JobsList entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}