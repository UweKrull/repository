package de.binaris.businessdinners.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.businessdinners.model.GendersList;
import de.binaris.businessdinners.rest.dto.GendersListDTO;

/**
 * 
 */
@Stateless
@Path("/genderslists")
public class GendersListEndpoint
{
   @PersistenceContext(unitName = "BusinessdinnersPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(GendersListDTO dto)
   {
      GendersList entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(GendersListEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      GendersList entity = em.find(GendersList.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<GendersList> findByIdQuery = em.createQuery("SELECT DISTINCT g FROM GendersList g LEFT JOIN FETCH g.dinner LEFT JOIN FETCH g.availableGender WHERE g.id = :entityId ORDER BY g.id", GendersList.class);
      findByIdQuery.setParameter("entityId", id);
      GendersList entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      GendersListDTO dto = new GendersListDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<GendersListDTO> listAll()
   {
      final List<GendersList> searchResults = em.createQuery("SELECT DISTINCT g FROM GendersList g LEFT JOIN FETCH g.dinner LEFT JOIN FETCH g.availableGender ORDER BY g.id", GendersList.class).getResultList();
      final List<GendersListDTO> results = new ArrayList<GendersListDTO>();
      for (GendersList searchResult : searchResults)
      {
         GendersListDTO dto = new GendersListDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, GendersListDTO dto)
   {
      TypedQuery<GendersList> findByIdQuery = em.createQuery("SELECT DISTINCT g FROM GendersList g LEFT JOIN FETCH g.dinner LEFT JOIN FETCH g.availableGender WHERE g.id = :entityId ORDER BY g.id", GendersList.class);
      findByIdQuery.setParameter("entityId", id);
      GendersList entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}