package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.AvailableGender;
import de.binaris.businessdinners.rest.dto.NestedGenderDTO;
import de.binaris.businessdinners.rest.dto.NestedGendersListDTO;
import de.binaris.businessdinners.rest.dto.NestedUserDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AvailableGenderDTO implements Serializable
{

   private Long id;
   private String title;
   private NestedGendersListDTO gendersList;
   private NestedGenderDTO gender;
   private NestedUserDTO user;

   public AvailableGenderDTO()
   {
   }

   public AvailableGenderDTO(final AvailableGender entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.gendersList = new NestedGendersListDTO(entity.getGendersList());
         this.gender = new NestedGenderDTO(entity.getGender());
         this.user = new NestedUserDTO(entity.getUser());
      }
   }

   public AvailableGender fromDTO(AvailableGender entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new AvailableGender();
      }
      entity.setTitle(this.title);
      if (this.gendersList != null)
      {
         entity.setGendersList(this.gendersList.fromDTO(
               entity.getGendersList(), em));
      }
      if (this.gender != null)
      {
         entity.setGender(this.gender.fromDTO(entity.getGender(), em));
      }
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public NestedGendersListDTO getGendersList()
   {
      return this.gendersList;
   }

   public void setGendersList(final NestedGendersListDTO gendersList)
   {
      this.gendersList = gendersList;
   }

   public NestedGenderDTO getGender()
   {
      return this.gender;
   }

   public void setGender(final NestedGenderDTO gender)
   {
      this.gender = gender;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }
}