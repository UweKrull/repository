package de.binaris.businessdinners.rest.dto;

import java.io.Serializable;

import de.binaris.businessdinners.model.AvailableJob;
import de.binaris.businessdinners.rest.dto.NestedJobDTO;
import de.binaris.businessdinners.rest.dto.NestedJobsListDTO;
import de.binaris.businessdinners.rest.dto.NestedUserDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AvailableJobDTO implements Serializable
{

   private Long id;
   private String title;
   private NestedJobsListDTO jobsList;
   private NestedJobDTO job;
   private NestedUserDTO user;

   public AvailableJobDTO()
   {
   }

   public AvailableJobDTO(final AvailableJob entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.jobsList = new NestedJobsListDTO(entity.getJobsList());
         this.job = new NestedJobDTO(entity.getJob());
         this.user = new NestedUserDTO(entity.getUser());
      }
   }

   public AvailableJob fromDTO(AvailableJob entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new AvailableJob();
      }
      entity.setTitle(this.title);
      if (this.jobsList != null)
      {
         entity.setJobsList(this.jobsList.fromDTO(entity.getJobsList(), em));
      }
      if (this.job != null)
      {
         entity.setJob(this.job.fromDTO(entity.getJob(), em));
      }
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public NestedJobsListDTO getJobsList()
   {
      return this.jobsList;
   }

   public void setJobsList(final NestedJobsListDTO jobsList)
   {
      this.jobsList = jobsList;
   }

   public NestedJobDTO getJob()
   {
      return this.job;
   }

   public void setJob(final NestedJobDTO job)
   {
      this.job = job;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }
}