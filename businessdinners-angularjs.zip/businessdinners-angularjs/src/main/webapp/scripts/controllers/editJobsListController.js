

angular.module('businessdinnersangularjs').controller('EditJobsListController', function($scope, $routeParams, $location, JobsListResource , DinnerResource, AvailableJobResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.jobsList = new JobsListResource(self.original);
            DinnerResource.queryAll(function(items) {
                $scope.dinnerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.jobsList.dinner && item.id == $scope.jobsList.dinner.id) {
                        $scope.dinnerSelection = labelObject;
                        $scope.jobsList.dinner = wrappedObject;
                        self.original.dinner = $scope.jobsList.dinner;
                    }
                    return labelObject;
                });
            });
            AvailableJobResource.queryAll(function(items) {
                $scope.availableJobSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.jobsList.availableJob){
                        $.each($scope.jobsList.availableJob, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.availableJobSelection.push(labelObject);
                                $scope.jobsList.availableJob.push(wrappedObject);
                            }
                        });
                        self.original.availableJob = $scope.jobsList.availableJob;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/JobsLists");
        };
        JobsListResource.get({JobsListId:$routeParams.JobsListId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.jobsList);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.jobsList.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/JobsLists");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/JobsLists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.jobsList.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("dinnerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.jobsList.dinner = {};
            $scope.jobsList.dinner.id = selection.value;
        }
    });
    $scope.availableJobSelection = $scope.availableJobSelection || [];
    $scope.$watch("availableJobSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.jobsList) {
            $scope.jobsList.availableJob = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.jobsList.availableJob.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});