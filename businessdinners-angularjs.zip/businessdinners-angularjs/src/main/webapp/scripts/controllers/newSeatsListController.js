
angular.module('businessdinnersangularjs').controller('NewSeatsListController', function ($scope, $location, locationParser, SeatsListResource , DinnerResource, AvailableSeatResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.seatsList = $scope.seatsList || {};
    
    $scope.dinnerList = DinnerResource.queryAll(function(items){
        $scope.dinnerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("dinnerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.seatsList.dinner = {};
            $scope.seatsList.dinner.id = selection.value;
        }
    });
    
    $scope.availableSeatList = AvailableSeatResource.queryAll(function(items){
        $scope.availableSeatSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("availableSeatSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.seatsList.availableSeat = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.seatsList.availableSeat.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/SeatsLists/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SeatsListResource.save($scope.seatsList, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/SeatsLists");
    };
});