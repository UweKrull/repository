

angular.module('businessdinnersangularjs').controller('EditCategoryController', function($scope, $routeParams, $location, CategoryResource , DinnerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.category = new CategoryResource(self.original);
            DinnerResource.queryAll(function(items) {
                $scope.appointmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.category.appointment){
                        $.each($scope.category.appointment, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.appointmentSelection.push(labelObject);
                                $scope.category.appointment.push(wrappedObject);
                            }
                        });
                        self.original.appointment = $scope.category.appointment;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Categorys");
        };
        CategoryResource.get({CategoryId:$routeParams.CategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.category);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.category.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Categorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Categorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.category.$remove(successCallback, errorCallback);
    };
    
    $scope.appointmentSelection = $scope.appointmentSelection || [];
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.category) {
            $scope.category.appointment = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.category.appointment.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});