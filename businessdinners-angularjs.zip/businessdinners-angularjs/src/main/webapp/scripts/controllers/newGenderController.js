
angular.module('businessdinnersangularjs').controller('NewGenderController', function ($scope, $location, locationParser, GenderResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.gender = $scope.gender || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Genders/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        GenderResource.save($scope.gender, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Genders");
    };
});