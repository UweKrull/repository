

angular.module('businessdinnersangularjs').controller('EditDinnerController', function($scope, $routeParams, $location, DinnerResource , VenueResource, CategoryResource, SeatingChartResource, HobbiesListResource, JobsListResource, GendersListResource, SeatsListResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.dinner = new DinnerResource(self.original);
            VenueResource.queryAll(function(items) {
                $scope.venueSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.dinner.venue && item.id == $scope.dinner.venue.id) {
                        $scope.venueSelection = labelObject;
                        $scope.dinner.venue = wrappedObject;
                        self.original.venue = $scope.dinner.venue;
                    }
                    return labelObject;
                });
            });
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.dinner.category && item.id == $scope.dinner.category.id) {
                        $scope.categorySelection = labelObject;
                        $scope.dinner.category = wrappedObject;
                        self.original.category = $scope.dinner.category;
                    }
                    return labelObject;
                });
            });
            SeatingChartResource.queryAll(function(items) {
                $scope.seatingChartSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        seatingChartPdf : item.url,
                        text : item.name
                    };
                    if($scope.dinner.seatingChart && item.id == $scope.dinner.seatingChart.id) {
                        $scope.seatingChartSelection = labelObject;
                        $scope.dinner.seatingChart = wrappedObject;
                        self.original.seatingChart = $scope.dinner.seatingChart;
                    }
                    return labelObject;
                });
            });
            HobbiesListResource.queryAll(function(items) {
                $scope.hobbiesListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.displayItems
                    };
                    var id_ = 0;
                    if($scope.dinner.hobbiesList){
                        $.each($scope.dinner.hobbiesList, function(idx, element) {
                            if(item.id == element.id) {
                            	$.each(labelObject.text.split(";"), function(idx, subElement) {
                            		id_ = id_ + 1;
                                    var wrappedObjectSub = {
                                        id : id_
                                    };
                                    var labelObjectSub = {
                                        value : id_,
                                        text : subElement
                                    };
                                    if (labelObjectSub.text.length > 0) {
                                    	$scope.hobbiesListSelection.push(labelObjectSub);
                                    	$scope.dinner.hobbiesList.push(wrappedObjectSub);
                                    }
                            	});
                            }
                        });
                        self.original.hobbiesList = $scope.hobbiesListSelection;
                    }
                    return labelObjectSub;
                });
            });
            JobsListResource.queryAll(function(items) {
                $scope.jobsListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.displayItems
                    };
                    var id_ = 0;
                    if($scope.dinner.jobsList){
                        $.each($scope.dinner.jobsList, function(idx, element) {
                            if(item.id == element.id) {
                            	$.each(labelObject.text.split(";"), function(idx, subElement) {
                            		id_ = id_ + 1;
                                    var wrappedObjectSub = {
                                        id : id_
                                    };
                                    var labelObjectSub = {
                                        value : id_,
                                        text : subElement
                                    };
                                    if (labelObjectSub.text.length > 0) {
                                    	$scope.jobsListSelection.push(labelObjectSub);
                                    	$scope.dinner.jobsList.push(wrappedObjectSub);
                                    }
                            	});
                            }
                        });
                        self.original.jobsList = $scope.jobsListSelection;
                    }
                    return labelObjectSub;
                });
            });
            GendersListResource.queryAll(function(items) {
                $scope.gendersListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.displayItems
                    };
                    var id_ = 0;
                    if($scope.dinner.gendersList){
                        $.each($scope.dinner.gendersList, function(idx, element) {
                            if(item.id == element.id) {
                            	$.each(labelObject.text.split(";"), function(idx, subElement) {
                            		id_ = id_ + 1;
                                    var wrappedObjectSub = {
                                        id : id_
                                    };
                                    var labelObjectSub = {
                                        value : id_,
                                        text : subElement
                                    };
                                    if (labelObjectSub.text.length > 0) {
                                    	$scope.gendersListSelection.push(labelObjectSub);
                                    	$scope.dinner.gendersList.push(wrappedObjectSub);
                                    }
                            	});
                            }
                        });
                        self.original.gendersList = $scope.gendersListSelection;
                    }
                    return labelObjectSub;
                });
            });
            SeatsListResource.queryAll(function(items) {
                $scope.seatsListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.displayItems
                    };
                    var id_ = 0;
                    if($scope.dinner.seatsList){
                        $.each($scope.dinner.seatsList, function(idx, element) {
                            if(item.id == element.id) {
                            	$.each(labelObject.text.split(";"), function(idx, subElement) {
                            		id_ = id_ + 1;
                                    var wrappedObjectSub = {
                                        id : id_
                                    };
                                    var labelObjectSub = {
                                        value : id_,
                                        text : subElement
                                    };
                                    if (labelObjectSub.text.length > 0) {
                                    	$scope.seatsListSelection.push(labelObjectSub);
                                    	$scope.dinner.seatsList.push(wrappedObjectSub);
                                    }
                            	});
                            }
                        });
                        self.original.seatsList = $scope.seatsListSelection;
                    }
                    return labelObjectSub;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Dinners");
        };
        DinnerResource.get({DinnerId:$routeParams.DinnerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.dinner);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.dinner.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Dinners");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Dinners");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.dinner.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("venueSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dinner.venue = {};
            $scope.dinner.venue.id = selection.value;
        }
    });
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dinner.category = {};
            $scope.dinner.category.id = selection.value;
        }
    });
    $scope.privateOnlyList = [
        "yes",  
        "no"  
    ];
    $scope.$watch("seatingChartSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dinner.seatingChart = {};
            $scope.dinner.seatingChart.id = selection.value;
        }
    });
    $scope.hobbiesListSelection = $scope.hobbiesListSelection || [];
    $scope.$watch("hobbiesListSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.dinner) {
            $scope.dinner.hobbiesList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.dinner.hobbiesList.push(collectionItem);
            });
        }
    });
    $scope.jobsListSelection = $scope.jobsListSelection || [];
    $scope.$watch("jobsListSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.dinner) {
            $scope.dinner.jobsList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.dinner.jobsList.push(collectionItem);
            });
        }
    });
    $scope.gendersListSelection = $scope.gendersListSelection || [];
    $scope.$watch("gendersListSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.dinner) {
            $scope.dinner.gendersList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.dinner.gendersList.push(collectionItem);
            });
        }
    });
    $scope.seatsListSelection = $scope.seatsListSelection || [];
    $scope.$watch("seatsListSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.dinner) {
            $scope.dinner.seatsList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.dinner.seatsList.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});