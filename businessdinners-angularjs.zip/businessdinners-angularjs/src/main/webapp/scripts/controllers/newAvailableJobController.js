
angular.module('businessdinnersangularjs').controller('NewAvailableJobController', function ($scope, $location, locationParser, AvailableJobResource , JobsListResource, JobResource, UserResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.availableJob = $scope.availableJob || {};
    
    $scope.jobsListList = JobsListResource.queryAll(function(items){
        $scope.jobsListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("jobsListSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableJob.jobsList = {};
            $scope.availableJob.jobsList.id = selection.value;
        }
    });
    
    $scope.jobList = JobResource.queryAll(function(items){
        $scope.jobSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("jobSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableJob.job = {};
            $scope.availableJob.job.id = selection.value;
        }
    });
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableJob.user = {};
            $scope.availableJob.user.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/AvailableJobs/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AvailableJobResource.save($scope.availableJob, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/AvailableJobs");
    };
});