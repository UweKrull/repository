

angular.module('businessdinnersangularjs').controller('EditGendersListController', function($scope, $routeParams, $location, GendersListResource , DinnerResource, AvailableGenderResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.gendersList = new GendersListResource(self.original);
            DinnerResource.queryAll(function(items) {
                $scope.dinnerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.gendersList.dinner && item.id == $scope.gendersList.dinner.id) {
                        $scope.dinnerSelection = labelObject;
                        $scope.gendersList.dinner = wrappedObject;
                        self.original.dinner = $scope.gendersList.dinner;
                    }
                    return labelObject;
                });
            });
            AvailableGenderResource.queryAll(function(items) {
                $scope.availableGenderSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.gendersList.availableGender){
                        $.each($scope.gendersList.availableGender, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.availableGenderSelection.push(labelObject);
                                $scope.gendersList.availableGender.push(wrappedObject);
                            }
                        });
                        self.original.availableGender = $scope.gendersList.availableGender;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/GendersLists");
        };
        GendersListResource.get({GendersListId:$routeParams.GendersListId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.gendersList);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.gendersList.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/GendersLists");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/GendersLists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.gendersList.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("dinnerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.gendersList.dinner = {};
            $scope.gendersList.dinner.id = selection.value;
        }
    });
    $scope.availableGenderSelection = $scope.availableGenderSelection || [];
    $scope.$watch("availableGenderSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.gendersList) {
            $scope.gendersList.availableGender = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.gendersList.availableGender.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});