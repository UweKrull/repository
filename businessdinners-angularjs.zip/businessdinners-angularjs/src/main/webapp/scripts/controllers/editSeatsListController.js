

angular.module('businessdinnersangularjs').controller('EditSeatsListController', function($scope, $routeParams, $location, SeatsListResource , DinnerResource, AvailableSeatResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.seatsList = new SeatsListResource(self.original);
            DinnerResource.queryAll(function(items) {
                $scope.dinnerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.seatsList.dinner && item.id == $scope.seatsList.dinner.id) {
                        $scope.dinnerSelection = labelObject;
                        $scope.seatsList.dinner = wrappedObject;
                        self.original.dinner = $scope.seatsList.dinner;
                    }
                    return labelObject;
                });
            });
            AvailableSeatResource.queryAll(function(items) {
                $scope.availableSeatSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.seatsList.availableSeat){
                        $.each($scope.seatsList.availableSeat, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.availableSeatSelection.push(labelObject);
                                $scope.seatsList.availableSeat.push(wrappedObject);
                            }
                        });
                        self.original.availableSeat = $scope.seatsList.availableSeat;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/SeatsLists");
        };
        SeatsListResource.get({SeatsListId:$routeParams.SeatsListId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.seatsList);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.seatsList.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/SeatsLists");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/SeatsLists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.seatsList.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("dinnerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.seatsList.dinner = {};
            $scope.seatsList.dinner.id = selection.value;
        }
    });
    $scope.availableSeatSelection = $scope.availableSeatSelection || [];
    $scope.$watch("availableSeatSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.seatsList) {
            $scope.seatsList.availableSeat = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.seatsList.availableSeat.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});