
angular.module('businessdinnersangularjs').controller('NewAvailableGenderController', function ($scope, $location, locationParser, AvailableGenderResource , GendersListResource, GenderResource, UserResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.availableGender = $scope.availableGender || {};
    
    $scope.gendersListList = GendersListResource.queryAll(function(items){
        $scope.gendersListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("gendersListSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableGender.gendersList = {};
            $scope.availableGender.gendersList.id = selection.value;
        }
    });
    
    $scope.genderList = GenderResource.queryAll(function(items){
        $scope.genderSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("genderSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableGender.gender = {};
            $scope.availableGender.gender.id = selection.value;
        }
    });
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableGender.user = {};
            $scope.availableGender.user.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/AvailableGenders/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AvailableGenderResource.save($scope.availableGender, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/AvailableGenders");
    };
});