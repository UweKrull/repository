

angular.module('businessdinnersangularjs').controller('EditAvailableGenderController', function($scope, $routeParams, $location, AvailableGenderResource , GendersListResource, GenderResource, UserResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.availableGender = new AvailableGenderResource(self.original);
            GendersListResource.queryAll(function(items) {
                $scope.gendersListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.availableGender.gendersList && item.id == $scope.availableGender.gendersList.id) {
                        $scope.gendersListSelection = labelObject;
                        $scope.availableGender.gendersList = wrappedObject;
                        self.original.gendersList = $scope.availableGender.gendersList;
                    }
                    return labelObject;
                });
            });
            GenderResource.queryAll(function(items) {
                $scope.genderSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.availableGender.gender && item.id == $scope.availableGender.gender.id) {
                        $scope.genderSelection = labelObject;
                        $scope.availableGender.gender = wrappedObject;
                        self.original.gender = $scope.availableGender.gender;
                    }
                    return labelObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.availableGender.user && item.id == $scope.availableGender.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.availableGender.user = wrappedObject;
                        self.original.user = $scope.availableGender.user;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/AvailableGenders");
        };
        AvailableGenderResource.get({AvailableGenderId:$routeParams.AvailableGenderId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.availableGender);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.availableGender.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/AvailableGenders");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/AvailableGenders");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.availableGender.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("gendersListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableGender.gendersList = {};
            $scope.availableGender.gendersList.id = selection.value;
        }
    });
    $scope.$watch("genderSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableGender.gender = {};
            $scope.availableGender.gender.id = selection.value;
        }
    });
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableGender.user = {};
            $scope.availableGender.user.id = selection.value;
        }
    });
    
    $scope.get();
});