
angular.module('businessdinnersangularjs').controller('NewAvailableHobbyController', function ($scope, $location, locationParser, AvailableHobbyResource , HobbiesListResource, HobbyResource, UserResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.availableHobby = $scope.availableHobby || {};
    
    $scope.hobbiesListList = HobbiesListResource.queryAll(function(items){
        $scope.hobbiesListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("hobbiesListSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableHobby.hobbiesList = {};
            $scope.availableHobby.hobbiesList.id = selection.value;
        }
    });
    
    $scope.hobbyList = HobbyResource.queryAll(function(items){
        $scope.hobbySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("hobbySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableHobby.hobby = {};
            $scope.availableHobby.hobby.id = selection.value;
        }
    });
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableHobby.user = {};
            $scope.availableHobby.user.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/AvailableHobbys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AvailableHobbyResource.save($scope.availableHobby, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/AvailableHobbys");
    };
});