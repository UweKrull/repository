
angular.module('businessdinnersangularjs').controller('NewJobsListController', function ($scope, $location, locationParser, JobsListResource , DinnerResource, AvailableJobResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.jobsList = $scope.jobsList || {};
    
    $scope.dinnerList = DinnerResource.queryAll(function(items){
        $scope.dinnerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("dinnerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.jobsList.dinner = {};
            $scope.jobsList.dinner.id = selection.value;
        }
    });
    
    $scope.availableJobList = AvailableJobResource.queryAll(function(items){
        $scope.availableJobSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("availableJobSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.jobsList.availableJob = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.jobsList.availableJob.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/JobsLists/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        JobsListResource.save($scope.jobsList, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/JobsLists");
    };
});