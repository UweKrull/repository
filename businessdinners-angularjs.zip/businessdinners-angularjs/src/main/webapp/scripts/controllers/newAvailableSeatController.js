
angular.module('businessdinnersangularjs').controller('NewAvailableSeatController', function ($scope, $location, locationParser, AvailableSeatResource , SeatsListResource, SeatResource, UserResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.availableSeat = $scope.availableSeat || {};
    
    $scope.seatsListList = SeatsListResource.queryAll(function(items){
        $scope.seatsListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("seatsListSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableSeat.seatsList = {};
            $scope.availableSeat.seatsList.id = selection.value;
        }
    });
    
    $scope.seatList = SeatResource.queryAll(function(items){
        $scope.seatSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("seatSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableSeat.seat = {};
            $scope.availableSeat.seat.id = selection.value;
        }
    });
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.availableSeat.user = {};
            $scope.availableSeat.user.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/AvailableSeats/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AvailableSeatResource.save($scope.availableSeat, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/AvailableSeats");
    };
});