
angular.module('businessdinnersangularjs').controller('NewDinnerController', function ($scope, $location, locationParser, DinnerResource , VenueResource, CategoryResource, SeatingChartResource, HobbiesListResource, JobsListResource, GendersListResource, SeatsListResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.dinner = $scope.dinner || {};
    
    $scope.venueList = VenueResource.queryAll(function(items){
        $scope.venueSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("venueSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.dinner.venue = {};
            $scope.dinner.venue.id = selection.value;
        }
    });
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.dinner.category = {};
            $scope.dinner.category.id = selection.value;
        }
    });
    
    $scope.privateOnlyList = [
        "yes",
        "no"
    ];
    
    $scope.seatingChartList = SeatingChartResource.queryAll(function(items){
        $scope.seatingChartSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("seatingChartSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.dinner.seatingChart = {};
            $scope.dinner.seatingChart.id = selection.value;
        }
    });
    
    $scope.hobbiesListList = HobbiesListResource.queryAll(function(items){
        $scope.hobbiesListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("hobbiesListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dinner.hobbiesList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.dinner.hobbiesList.push(collectionItem);
            });
        }
    });
    
    $scope.jobsListList = JobsListResource.queryAll(function(items){
        $scope.jobsListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("jobsListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dinner.jobsList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.dinner.jobsList.push(collectionItem);
            });
        }
    });
    
    $scope.gendersListList = GendersListResource.queryAll(function(items){
        $scope.gendersListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("gendersListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dinner.gendersList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.dinner.gendersList.push(collectionItem);
            });
        }
    });
    
    $scope.seatsListList = SeatsListResource.queryAll(function(items){
        $scope.seatsListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("seatsListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dinner.seatsList = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.dinner.seatsList.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Dinners/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        DinnerResource.save($scope.dinner, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Dinners");
    };
});