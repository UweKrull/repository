
angular.module('businessdinnersangularjs').controller('NewSeatController', function ($scope, $location, locationParser, SeatResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.seat = $scope.seat || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Seats/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SeatResource.save($scope.seat, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Seats");
    };
});