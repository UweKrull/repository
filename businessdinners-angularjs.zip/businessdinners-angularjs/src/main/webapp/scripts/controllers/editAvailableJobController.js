

angular.module('businessdinnersangularjs').controller('EditAvailableJobController', function($scope, $routeParams, $location, AvailableJobResource , JobsListResource, JobResource, UserResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.availableJob = new AvailableJobResource(self.original);
            JobsListResource.queryAll(function(items) {
                $scope.jobsListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.availableJob.jobsList && item.id == $scope.availableJob.jobsList.id) {
                        $scope.jobsListSelection = labelObject;
                        $scope.availableJob.jobsList = wrappedObject;
                        self.original.jobsList = $scope.availableJob.jobsList;
                    }
                    return labelObject;
                });
            });
            JobResource.queryAll(function(items) {
                $scope.jobSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.availableJob.job && item.id == $scope.availableJob.job.id) {
                        $scope.jobSelection = labelObject;
                        $scope.availableJob.job = wrappedObject;
                        self.original.job = $scope.availableJob.job;
                    }
                    return labelObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName
                    };
                    if($scope.availableJob.user && item.id == $scope.availableJob.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.availableJob.user = wrappedObject;
                        self.original.user = $scope.availableJob.user;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/AvailableJobs");
        };
        AvailableJobResource.get({AvailableJobId:$routeParams.AvailableJobId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.availableJob);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.availableJob.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/AvailableJobs");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/AvailableJobs");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.availableJob.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("jobsListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableJob.jobsList = {};
            $scope.availableJob.jobsList.id = selection.value;
        }
    });
    $scope.$watch("jobSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableJob.job = {};
            $scope.availableJob.job.id = selection.value;
        }
    });
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableJob.user = {};
            $scope.availableJob.user.id = selection.value;
        }
    });
    
    $scope.get();
});