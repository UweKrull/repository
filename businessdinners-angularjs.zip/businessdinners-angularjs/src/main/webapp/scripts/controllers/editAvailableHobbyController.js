

angular.module('businessdinnersangularjs').controller('EditAvailableHobbyController', function($scope, $routeParams, $location, AvailableHobbyResource , HobbiesListResource, HobbyResource, UserResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.availableHobby = new AvailableHobbyResource(self.original);
            HobbiesListResource.queryAll(function(items) {
                $scope.hobbiesListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.availableHobby.hobbiesList && item.id == $scope.availableHobby.hobbiesList.id) {
                        $scope.hobbiesListSelection = labelObject;
                        $scope.availableHobby.hobbiesList = wrappedObject;
                        self.original.hobbiesList = $scope.availableHobby.hobbiesList;
                    }
                    return labelObject;
                });
            });
            HobbyResource.queryAll(function(items) {
                $scope.hobbySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.availableHobby.hobby && item.id == $scope.availableHobby.hobby.id) {
                        $scope.hobbySelection = labelObject;
                        $scope.availableHobby.hobby = wrappedObject;
                        self.original.hobby = $scope.availableHobby.hobby;
                    }
                    return labelObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName
                    };
                    if($scope.availableHobby.user && item.id == $scope.availableHobby.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.availableHobby.user = wrappedObject;
                        self.original.user = $scope.availableHobby.user;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/AvailableHobbys");
        };
        AvailableHobbyResource.get({AvailableHobbyId:$routeParams.AvailableHobbyId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.availableHobby);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.availableHobby.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/AvailableHobbys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/AvailableHobbys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.availableHobby.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("hobbiesListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableHobby.hobbiesList = {};
            $scope.availableHobby.hobbiesList.id = selection.value;
        }
    });
    $scope.$watch("hobbySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableHobby.hobby = {};
            $scope.availableHobby.hobby.id = selection.value;
        }
    });
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableHobby.user = {};
            $scope.availableHobby.user.id = selection.value;
        }
    });
    
    $scope.get();
});