

angular.module('businessdinnersangularjs').controller('EditHobbiesListController', function($scope, $routeParams, $location, HobbiesListResource , DinnerResource, AvailableHobbyResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.hobbiesList = new HobbiesListResource(self.original);
            DinnerResource.queryAll(function(items) {
                $scope.dinnerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.hobbiesList.dinner && item.id == $scope.hobbiesList.dinner.id) {
                        $scope.dinnerSelection = labelObject;
                        $scope.hobbiesList.dinner = wrappedObject;
                        self.original.dinner = $scope.hobbiesList.dinner;
                    }
                    return labelObject;
                });
            });
            AvailableHobbyResource.queryAll(function(items) {
                $scope.availableHobbySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.hobbiesList.availableHobby){
                        $.each($scope.hobbiesList.availableHobby, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.availableHobbySelection.push(labelObject);
                                $scope.hobbiesList.availableHobby.push(wrappedObject);
                            }
                        });
                        self.original.availableHobby = $scope.hobbiesList.availableHobby;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/HobbiesLists");
        };
        HobbiesListResource.get({HobbiesListId:$routeParams.HobbiesListId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.hobbiesList);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.hobbiesList.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/HobbiesLists");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/HobbiesLists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.hobbiesList.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("dinnerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.hobbiesList.dinner = {};
            $scope.hobbiesList.dinner.id = selection.value;
        }
    });
    $scope.availableHobbySelection = $scope.availableHobbySelection || [];
    $scope.$watch("availableHobbySelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.hobbiesList) {
            $scope.hobbiesList.availableHobby = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.hobbiesList.availableHobby.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});