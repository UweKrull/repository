
angular.module('businessdinnersangularjs').controller('NewJobController', function ($scope, $location, locationParser, JobResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.job = $scope.job || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Jobs/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        JobResource.save($scope.job, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Jobs");
    };
});