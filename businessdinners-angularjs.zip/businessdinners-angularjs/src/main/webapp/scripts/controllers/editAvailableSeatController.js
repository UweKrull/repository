

angular.module('businessdinnersangularjs').controller('EditAvailableSeatController', function($scope, $routeParams, $location, AvailableSeatResource , SeatsListResource, SeatResource, UserResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.availableSeat = new AvailableSeatResource(self.original);
            SeatsListResource.queryAll(function(items) {
                $scope.seatsListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.availableSeat.seatsList && item.id == $scope.availableSeat.seatsList.id) {
                        $scope.seatsListSelection = labelObject;
                        $scope.availableSeat.seatsList = wrappedObject;
                        self.original.seatsList = $scope.availableSeat.seatsList;
                    }
                    return labelObject;
                });
            });
            SeatResource.queryAll(function(items) {
                $scope.seatSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.availableSeat.seat && item.id == $scope.availableSeat.seat.id) {
                        $scope.seatSelection = labelObject;
                        $scope.availableSeat.seat = wrappedObject;
                        self.original.seat = $scope.availableSeat.seat;
                    }
                    return labelObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName
                    };
                    if($scope.availableSeat.user && item.id == $scope.availableSeat.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.availableSeat.user = wrappedObject;
                        self.original.user = $scope.availableSeat.user;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/AvailableSeats");
        };
        AvailableSeatResource.get({AvailableSeatId:$routeParams.AvailableSeatId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.availableSeat);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.availableSeat.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/AvailableSeats");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/AvailableSeats");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.availableSeat.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("seatsListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableSeat.seatsList = {};
            $scope.availableSeat.seatsList.id = selection.value;
        }
    });
    $scope.$watch("seatSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableSeat.seat = {};
            $scope.availableSeat.seat.id = selection.value;
        }
    });
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.availableSeat.user = {};
            $scope.availableSeat.user.id = selection.value;
        }
    });
    
    $scope.get();
});