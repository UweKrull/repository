

angular.module('businessdinnersangularjs').controller('EditSeatingChartController', function($scope, $routeParams, $location, SeatingChartResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.seatingChart = new SeatingChartResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/SeatingCharts");
        };
        SeatingChartResource.get({SeatingChartId:$routeParams.SeatingChartId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.seatingChart);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.seatingChart.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/SeatingCharts");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/SeatingCharts");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.seatingChart.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});