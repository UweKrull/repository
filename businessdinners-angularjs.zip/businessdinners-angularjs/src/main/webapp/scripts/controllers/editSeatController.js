

angular.module('businessdinnersangularjs').controller('EditSeatController', function($scope, $routeParams, $location, SeatResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.seat = new SeatResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Seats");
        };
        SeatResource.get({SeatId:$routeParams.SeatId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.seat);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.seat.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Seats");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Seats");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.seat.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});