
angular.module('businessdinnersangularjs').controller('NewGendersListController', function ($scope, $location, locationParser, GendersListResource , DinnerResource, AvailableGenderResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.gendersList = $scope.gendersList || {};
    
    $scope.dinnerList = DinnerResource.queryAll(function(items){
        $scope.dinnerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("dinnerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.gendersList.dinner = {};
            $scope.gendersList.dinner.id = selection.value;
        }
    });
    
    $scope.availableGenderList = AvailableGenderResource.queryAll(function(items){
        $scope.availableGenderSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("availableGenderSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.gendersList.availableGender = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.gendersList.availableGender.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/GendersLists/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        GendersListResource.save($scope.gendersList, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/GendersLists");
    };
});