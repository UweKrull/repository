
angular.module('businessdinnersangularjs').controller('NewHobbyController', function ($scope, $location, locationParser, HobbyResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.hobby = $scope.hobby || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Hobbys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        HobbyResource.save($scope.hobby, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Hobbys");
    };
});