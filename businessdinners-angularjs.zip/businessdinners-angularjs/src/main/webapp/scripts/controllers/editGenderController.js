

angular.module('businessdinnersangularjs').controller('EditGenderController', function($scope, $routeParams, $location, GenderResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.gender = new GenderResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Genders");
        };
        GenderResource.get({GenderId:$routeParams.GenderId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.gender);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.gender.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Genders");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Genders");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.gender.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});