
angular.module('businessdinnersangularjs').controller('NewHobbiesListController', function ($scope, $location, locationParser, HobbiesListResource , DinnerResource, AvailableHobbyResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.hobbiesList = $scope.hobbiesList || {};
    
    $scope.dinnerList = DinnerResource.queryAll(function(items){
        $scope.dinnerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("dinnerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.hobbiesList.dinner = {};
            $scope.hobbiesList.dinner.id = selection.value;
        }
    });
    
    $scope.availableHobbyList = AvailableHobbyResource.queryAll(function(items){
        $scope.availableHobbySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("availableHobbySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.hobbiesList.availableHobby = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.hobbiesList.availableHobby.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/HobbiesLists/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        HobbiesListResource.save($scope.hobbiesList, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/HobbiesLists");
    };
});