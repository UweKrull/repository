
angular.module('businessdinnersangularjs').controller('NewVenueController', function ($scope, $location, locationParser, VenueResource , DinnerResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.venue = $scope.venue || {};
    
    $scope.appointmentList = DinnerResource.queryAll(function(items){
        $scope.appointmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.venue.appointment = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.venue.appointment.push(collectionItem);
            });
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.venue.address.country = {};
            $scope.venue.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Venues/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        VenueResource.save($scope.venue, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Venues");
    };
});