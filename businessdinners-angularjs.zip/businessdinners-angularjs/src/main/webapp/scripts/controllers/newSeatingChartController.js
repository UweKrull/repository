
angular.module('businessdinnersangularjs').controller('NewSeatingChartController', function ($scope, $location, locationParser, SeatingChartResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.seatingChart = $scope.seatingChart || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/SeatingCharts/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SeatingChartResource.save($scope.seatingChart, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/SeatingCharts");
    };
});