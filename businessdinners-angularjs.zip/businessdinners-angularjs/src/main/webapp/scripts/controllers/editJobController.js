

angular.module('businessdinnersangularjs').controller('EditJobController', function($scope, $routeParams, $location, JobResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.job = new JobResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Jobs");
        };
        JobResource.get({JobId:$routeParams.JobId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.job);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.job.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Jobs");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Jobs");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.job.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});