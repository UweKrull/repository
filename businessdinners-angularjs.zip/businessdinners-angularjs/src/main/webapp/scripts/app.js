'use strict';

angular.module('businessdinnersangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/AvailableGenders',{templateUrl:'views/AvailableGender/search.html',controller:'SearchAvailableGenderController'})
      .when('/AvailableGenders/new',{templateUrl:'views/AvailableGender/detail.html',controller:'NewAvailableGenderController'})
      .when('/AvailableGenders/edit/:AvailableGenderId',{templateUrl:'views/AvailableGender/detail.html',controller:'EditAvailableGenderController'})
      .when('/AvailableHobbys',{templateUrl:'views/AvailableHobby/search.html',controller:'SearchAvailableHobbyController'})
      .when('/AvailableHobbys/new',{templateUrl:'views/AvailableHobby/detail.html',controller:'NewAvailableHobbyController'})
      .when('/AvailableHobbys/edit/:AvailableHobbyId',{templateUrl:'views/AvailableHobby/detail.html',controller:'EditAvailableHobbyController'})
      .when('/AvailableJobs',{templateUrl:'views/AvailableJob/search.html',controller:'SearchAvailableJobController'})
      .when('/AvailableJobs/new',{templateUrl:'views/AvailableJob/detail.html',controller:'NewAvailableJobController'})
      .when('/AvailableJobs/edit/:AvailableJobId',{templateUrl:'views/AvailableJob/detail.html',controller:'EditAvailableJobController'})
      .when('/AvailableSeats',{templateUrl:'views/AvailableSeat/search.html',controller:'SearchAvailableSeatController'})
      .when('/AvailableSeats/new',{templateUrl:'views/AvailableSeat/detail.html',controller:'NewAvailableSeatController'})
      .when('/AvailableSeats/edit/:AvailableSeatId',{templateUrl:'views/AvailableSeat/detail.html',controller:'EditAvailableSeatController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Dinners',{templateUrl:'views/Dinner/search.html',controller:'SearchDinnerController'})
      .when('/Dinners/new',{templateUrl:'views/Dinner/detail.html',controller:'NewDinnerController'})
      .when('/Dinners/edit/:DinnerId',{templateUrl:'views/Dinner/detail.html',controller:'EditDinnerController'})
      .when('/Genders',{templateUrl:'views/Gender/search.html',controller:'SearchGenderController'})
      .when('/Genders/new',{templateUrl:'views/Gender/detail.html',controller:'NewGenderController'})
      .when('/Genders/edit/:GenderId',{templateUrl:'views/Gender/detail.html',controller:'EditGenderController'})
      .when('/GendersLists',{templateUrl:'views/GendersList/search.html',controller:'SearchGendersListController'})
      .when('/GendersLists/new',{templateUrl:'views/GendersList/detail.html',controller:'NewGendersListController'})
      .when('/GendersLists/edit/:GendersListId',{templateUrl:'views/GendersList/detail.html',controller:'EditGendersListController'})
      .when('/HobbiesLists',{templateUrl:'views/HobbiesList/search.html',controller:'SearchHobbiesListController'})
      .when('/HobbiesLists/new',{templateUrl:'views/HobbiesList/detail.html',controller:'NewHobbiesListController'})
      .when('/HobbiesLists/edit/:HobbiesListId',{templateUrl:'views/HobbiesList/detail.html',controller:'EditHobbiesListController'})
      .when('/Hobbys',{templateUrl:'views/Hobby/search.html',controller:'SearchHobbyController'})
      .when('/Hobbys/new',{templateUrl:'views/Hobby/detail.html',controller:'NewHobbyController'})
      .when('/Hobbys/edit/:HobbyId',{templateUrl:'views/Hobby/detail.html',controller:'EditHobbyController'})
      .when('/Jobs',{templateUrl:'views/Job/search.html',controller:'SearchJobController'})
      .when('/Jobs/new',{templateUrl:'views/Job/detail.html',controller:'NewJobController'})
      .when('/Jobs/edit/:JobId',{templateUrl:'views/Job/detail.html',controller:'EditJobController'})
      .when('/JobsLists',{templateUrl:'views/JobsList/search.html',controller:'SearchJobsListController'})
      .when('/JobsLists/new',{templateUrl:'views/JobsList/detail.html',controller:'NewJobsListController'})
      .when('/JobsLists/edit/:JobsListId',{templateUrl:'views/JobsList/detail.html',controller:'EditJobsListController'})
      .when('/Seats',{templateUrl:'views/Seat/search.html',controller:'SearchSeatController'})
      .when('/Seats/new',{templateUrl:'views/Seat/detail.html',controller:'NewSeatController'})
      .when('/Seats/edit/:SeatId',{templateUrl:'views/Seat/detail.html',controller:'EditSeatController'})
      .when('/SeatingCharts',{templateUrl:'views/SeatingChart/search.html',controller:'SearchSeatingChartController'})
      .when('/SeatingCharts/new',{templateUrl:'views/SeatingChart/detail.html',controller:'NewSeatingChartController'})
      .when('/SeatingCharts/edit/:SeatingChartId',{templateUrl:'views/SeatingChart/detail.html',controller:'EditSeatingChartController'})
      .when('/SeatsLists',{templateUrl:'views/SeatsList/search.html',controller:'SearchSeatsListController'})
      .when('/SeatsLists/new',{templateUrl:'views/SeatsList/detail.html',controller:'NewSeatsListController'})
      .when('/SeatsLists/edit/:SeatsListId',{templateUrl:'views/SeatsList/detail.html',controller:'EditSeatsListController'})
      .when('/Users',{templateUrl:'views/User/search.html',controller:'SearchUserController'})
      .when('/Users/new',{templateUrl:'views/User/detail.html',controller:'NewUserController'})
      .when('/Users/edit/:UserId',{templateUrl:'views/User/detail.html',controller:'EditUserController'})
      .when('/Venues',{templateUrl:'views/Venue/search.html',controller:'SearchVenueController'})
      .when('/Venues/new',{templateUrl:'views/Venue/detail.html',controller:'NewVenueController'})
      .when('/Venues/edit/:VenueId',{templateUrl:'views/Venue/detail.html',controller:'EditVenueController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
