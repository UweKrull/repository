angular.module('businessdinnersangularjs').factory('JobsListResource', function($resource){
    var resource = $resource('rest/jobslists/:JobsListId',{JobsListId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});