angular.module('businessdinnersangularjs').factory('HobbyResource', function($resource){
    var resource = $resource('rest/hobbys/:HobbyId',{HobbyId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});