angular.module('businessdinnersangularjs').factory('AvailableGenderResource', function($resource){
    var resource = $resource('rest/availablegenders/:AvailableGenderId',{AvailableGenderId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});