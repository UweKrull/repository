angular.module('businessdinnersangularjs').factory('AvailableSeatResource', function($resource){
    var resource = $resource('rest/availableseats/:AvailableSeatId',{AvailableSeatId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});