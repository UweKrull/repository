angular.module('businessdinnersangularjs').factory('DinnerResource', function($resource){
    var resource = $resource('rest/dinners/:DinnerId',{DinnerId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});