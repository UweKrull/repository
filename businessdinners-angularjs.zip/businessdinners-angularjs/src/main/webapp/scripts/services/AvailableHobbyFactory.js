angular.module('businessdinnersangularjs').factory('AvailableHobbyResource', function($resource){
    var resource = $resource('rest/availablehobbys/:AvailableHobbyId',{AvailableHobbyId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});