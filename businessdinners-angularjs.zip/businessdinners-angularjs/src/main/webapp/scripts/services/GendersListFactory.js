angular.module('businessdinnersangularjs').factory('GendersListResource', function($resource){
    var resource = $resource('rest/genderslists/:GendersListId',{GendersListId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});