angular.module('businessdinnersangularjs').factory('AvailableJobResource', function($resource){
    var resource = $resource('rest/availablejobs/:AvailableJobId',{AvailableJobId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});