angular.module('businessdinnersangularjs').factory('SeatResource', function($resource){
    var resource = $resource('rest/seats/:SeatId',{SeatId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});