
angular.module('logisticsadminangularjs').controller('NewArticleController', function ($scope, $location, locationParser, ArticleResource , WarengruppeResource, ArticleDataResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.article = $scope.article || {};
    
    $scope.activList = [
        "Activ",
        "Inactiv"
    ];
    
    $scope.warengruppeList = WarengruppeResource.queryAll(function(items){
        $scope.warengruppeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.type
            });
        });
    });
    $scope.$watch("warengruppeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.article.warengruppe = {};
            $scope.article.warengruppe.id = selection.value;
        }
    });
    
    $scope.orderAmountUnitList = [
        "KG",
        "KGG",
        "L",
        "M",
        "QM",
        "STK"
    ];
    
    $scope.articleDataList = ArticleDataResource.queryAll(function(items){
        $scope.articleDataSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.minAmounPerPackageUnit
            });
        });
    });
    $scope.$watch("articleDataSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.article.articleData = {};
            $scope.article.articleData.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Articles/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ArticleResource.save($scope.article, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Articles");
    };
});