

angular.module('logisticsadminangularjs').controller('EditDepartmentController', function($scope, $routeParams, $location, DepartmentResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.department = new DepartmentResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Departments");
        };
        DepartmentResource.get({DepartmentId:$routeParams.DepartmentId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.department);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.department.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Departments");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Departments");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.department.$remove(successCallback, errorCallback);
    };
    
    $scope.articleRelatedList = [
        "Article",  
        "No_Article"  
    ];
    
    $scope.get();
});