

angular.module('logisticsadminangularjs').controller('EditLagerController', function($scope, $routeParams, $location, LagerResource , CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.lager = new LagerResource(self.original);
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.lager.address.country && item.id == $scope.lager.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.lager.address.country = wrappedObject;
                        self.original.address.country = $scope.lager.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Lagers");
        };
        LagerResource.get({LagerId:$routeParams.LagerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.lager);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.lager.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Lagers");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Lagers");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.lager.$remove(successCallback, errorCallback);
    };
    
    $scope.typeList = [
        "Baecker",  
        "Food",  
        "Kolonialwaren",  
        "Obst_und_Gemuese",  
        "Zentrallager"  
    ];
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.lager.address.country = {};
            $scope.lager.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});