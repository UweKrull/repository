
angular.module('logisticsadminangularjs').controller('NewBezugswegController', function ($scope, $location, locationParser, BezugswegResource , DepartmentResource, LagerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.bezugsweg = $scope.bezugsweg || {};
    
    $scope.departmentList = DepartmentResource.queryAll(function(items){
        $scope.departmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.articleRelated
            });
        });
    });
    $scope.$watch("departmentSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.bezugsweg.department = {};
            $scope.bezugsweg.department.id = selection.value;
        }
    });
    
    $scope.lagerList = LagerResource.queryAll(function(items){
        $scope.lagerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.lagerNo
            });
        });
    });
    $scope.$watch("lagerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.bezugsweg.lager = {};
            $scope.bezugsweg.lager.id = selection.value;
        }
    });
    
    $scope.aktionList = [
        "Aktion",
        "Keine_Aktion"
    ];
    
    $scope.ausnahmeList = [
        "Ausnahme",
        "Ausnahme2",
        "Keine_Ausnahme"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Bezugswegs/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        BezugswegResource.save($scope.bezugsweg, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Bezugswegs");
    };
});