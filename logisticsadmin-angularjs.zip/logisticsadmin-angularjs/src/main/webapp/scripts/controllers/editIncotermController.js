

angular.module('logisticsadminangularjs').controller('EditIncotermController', function($scope, $routeParams, $location, IncotermResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.incoterm = new IncotermResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Incoterms");
        };
        IncotermResource.get({IncotermId:$routeParams.IncotermId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.incoterm);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.incoterm.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Incoterms");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Incoterms");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.incoterm.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});