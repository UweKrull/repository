

angular.module('logisticsadminangularjs').controller('EditArticleDataController', function($scope, $routeParams, $location, ArticleDataResource , LagerResource, ArticleResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.articleData = new ArticleDataResource(self.original);
            LagerResource.queryAll(function(items) {
                $scope.lagerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.lagerNo
                    };
                    if($scope.articleData.lager && item.id == $scope.articleData.lager.id) {
                        $scope.lagerSelection = labelObject;
                        $scope.articleData.lager = wrappedObject;
                        self.original.lager = $scope.articleData.lager;
                    }
                    return labelObject;
                });
            });
            ArticleResource.queryAll(function(items) {
                $scope.articleSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.ean+' '+item.description
                    };
                    if($scope.articleData.article){
                        $.each($scope.articleData.article, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.articleSelection.push(labelObject);
                                $scope.articleData.article.push(wrappedObject);
                            }
                        });
                        self.original.article = $scope.articleData.article;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/ArticleDatas");
        };
        ArticleDataResource.get({ArticleDataId:$routeParams.ArticleDataId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.articleData);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.articleData.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/ArticleDatas");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/ArticleDatas");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.articleData.$remove(successCallback, errorCallback);
    };
    
    $scope.packageUnitList = [
        "GL",  
        "FL",  
        "ST",  
        "KG"  
    ];
    $scope.$watch("lagerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.articleData.lager = {};
            $scope.articleData.lager.id = selection.value;
        }
    });
    $scope.articleSelection = $scope.articleSelection || [];
    $scope.$watch("articleSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.articleData) {
            $scope.articleData.article = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.articleData.article.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});