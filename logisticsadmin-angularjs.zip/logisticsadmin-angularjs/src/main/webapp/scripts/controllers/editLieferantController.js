

angular.module('logisticsadminangularjs').controller('EditLieferantController', function($scope, $routeParams, $location, LieferantResource , CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.lieferant = new LieferantResource(self.original);
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.lieferant.address.country && item.id == $scope.lieferant.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.lieferant.address.country = wrappedObject;
                        self.original.address.country = $scope.lieferant.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Lieferants");
        };
        LieferantResource.get({LieferantId:$routeParams.LieferantId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.lieferant);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.lieferant.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Lieferants");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Lieferants");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.lieferant.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.lieferant.address.country = {};
            $scope.lieferant.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});