

angular.module('logisticsadminangularjs').controller('EditArticleController', function($scope, $routeParams, $location, ArticleResource , WarengruppeResource, ArticleDataResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.article = new ArticleResource(self.original);
            WarengruppeResource.queryAll(function(items) {
                $scope.warengruppeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.type
                    };
                    if($scope.article.warengruppe && item.id == $scope.article.warengruppe.id) {
                        $scope.warengruppeSelection = labelObject;
                        $scope.article.warengruppe = wrappedObject;
                        self.original.warengruppe = $scope.article.warengruppe;
                    }
                    return labelObject;
                });
            });
            ArticleDataResource.queryAll(function(items) {
                $scope.articleDataSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.minAmounPerPackageUnit
                    };
                    if($scope.article.articleData && item.id == $scope.article.articleData.id) {
                        $scope.articleDataSelection = labelObject;
                        $scope.article.articleData = wrappedObject;
                        self.original.articleData = $scope.article.articleData;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Articles");
        };
        ArticleResource.get({ArticleId:$routeParams.ArticleId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.article);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.article.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Articles");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Articles");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.article.$remove(successCallback, errorCallback);
    };
    
    $scope.activList = [
        "Activ",  
        "Inactiv"  
    ];
    $scope.$watch("warengruppeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.article.warengruppe = {};
            $scope.article.warengruppe.id = selection.value;
        }
    });
    $scope.orderAmountUnitList = [
        "KG",  
        "KGG",  
        "L",  
        "M",  
        "QM",  
        "STK"  
    ];
    $scope.$watch("articleDataSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.article.articleData = {};
            $scope.article.articleData.id = selection.value;
        }
    });
    
    $scope.get();
});