
angular.module('logisticsadminangularjs').controller('NewArticleDataController', function ($scope, $location, locationParser, ArticleDataResource , LagerResource, ArticleResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.articleData = $scope.articleData || {};
    
    $scope.packageUnitList = [
        "GL",
        "FL",
        "ST",
        "KG"
    ];
    
    $scope.lagerList = LagerResource.queryAll(function(items){
        $scope.lagerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.lagerNo
            });
        });
    });
    $scope.$watch("lagerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.articleData.lager = {};
            $scope.articleData.lager.id = selection.value;
        }
    });
    
    $scope.articleList = ArticleResource.queryAll(function(items){
        $scope.articleSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.ean+' '+item.decription
            });
        });
    });
    $scope.$watch("articleSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.articleData.article = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.articleData.article.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/ArticleDatas/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ArticleDataResource.save($scope.articleData, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/ArticleDatas");
    };
});