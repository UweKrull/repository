

angular.module('logisticsadminangularjs').controller('EditWarengruppeController', function($scope, $routeParams, $location, WarengruppeResource , ArticleResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.warengruppe = new WarengruppeResource(self.original);
            ArticleResource.queryAll(function(items) {
                $scope.articleSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.activ
                    };
                    if($scope.warengruppe.article){
                        $.each($scope.warengruppe.article, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.articleSelection.push(labelObject);
                                $scope.warengruppe.article.push(wrappedObject);
                            }
                        });
                        self.original.article = $scope.warengruppe.article;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Warengruppes");
        };
        WarengruppeResource.get({WarengruppeId:$routeParams.WarengruppeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.warengruppe);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.warengruppe.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Warengruppes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Warengruppes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.warengruppe.$remove(successCallback, errorCallback);
    };
    
    $scope.articleSelection = $scope.articleSelection || [];
    $scope.$watch("articleSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.warengruppe) {
            $scope.warengruppe.article = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.warengruppe.article.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});