

angular.module('logisticsadminangularjs').controller('EditBezugswegController', function($scope, $routeParams, $location, BezugswegResource , DepartmentResource, LagerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.bezugsweg = new BezugswegResource(self.original);
            DepartmentResource.queryAll(function(items) {
                $scope.departmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.articleRelated
                    };
                    if($scope.bezugsweg.department && item.id == $scope.bezugsweg.department.id) {
                        $scope.departmentSelection = labelObject;
                        $scope.bezugsweg.department = wrappedObject;
                        self.original.department = $scope.bezugsweg.department;
                    }
                    return labelObject;
                });
            });
            LagerResource.queryAll(function(items) {
                $scope.lagerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.lagerNo
                    };
                    if($scope.bezugsweg.lager && item.id == $scope.bezugsweg.lager.id) {
                        $scope.lagerSelection = labelObject;
                        $scope.bezugsweg.lager = wrappedObject;
                        self.original.lager = $scope.bezugsweg.lager;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Bezugswegs");
        };
        BezugswegResource.get({BezugswegId:$routeParams.BezugswegId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.bezugsweg);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.bezugsweg.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Bezugswegs");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Bezugswegs");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.bezugsweg.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("departmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.bezugsweg.department = {};
            $scope.bezugsweg.department.id = selection.value;
        }
    });
    $scope.$watch("lagerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.bezugsweg.lager = {};
            $scope.bezugsweg.lager.id = selection.value;
        }
    });
    $scope.aktionList = [
        "Aktion",  
        "Keine_Aktion"  
    ];
    $scope.ausnahmeList = [
        "Ausnahme",  
        "Ausnahme2",  
        "Keine_Ausnahme"  
    ];
    
    $scope.get();
});