
angular.module('logisticsadminangularjs').controller('NewIncotermController', function ($scope, $location, locationParser, IncotermResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.incoterm = $scope.incoterm || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Incoterms/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        IncotermResource.save($scope.incoterm, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Incoterms");
    };
});