
angular.module('logisticsadminangularjs').controller('NewLieferantController', function ($scope, $location, locationParser, LieferantResource , CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.lieferant = $scope.lieferant || {};
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.lieferant.address.country = {};
            $scope.lieferant.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Lieferants/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        LieferantResource.save($scope.lieferant, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Lieferants");
    };
});