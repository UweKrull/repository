

angular.module('logisticsadminangularjs').controller('EditLieferartController', function($scope, $routeParams, $location, LieferartResource , LagerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.lieferart = new LieferartResource(self.original);
            LagerResource.queryAll(function(items) {
                $scope.lagerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.lagerNo
                    };
                    if($scope.lieferart.lager && item.id == $scope.lieferart.lager.id) {
                        $scope.lagerSelection = labelObject;
                        $scope.lieferart.lager = wrappedObject;
                        self.original.lager = $scope.lieferart.lager;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Lieferarts");
        };
        LieferartResource.get({LieferartId:$routeParams.LieferartId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.lieferart);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.lieferart.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Lieferarts");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Lieferarts");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.lieferart.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("lagerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.lieferart.lager = {};
            $scope.lieferart.lager.id = selection.value;
        }
    });
    $scope.partieAppList = [
        "BEDARF",  
        "ELVS",  
        "BUCHUNG",  
        "PARTIE",  
        "RUECKSTELLUNG",  
        "STRECKE",  
        "UMSATZ",  
        "WALAGER",  
        "WELAGER"  
    ];
    $scope.statusList = [
        "Activ",  
        "Inactiv"  
    ];
    $scope.deliveryList = [
        "Lagerart_Lagernr",  
        "Manuelle_Buchung",  
        "Strecken_Basislager",  
        "Baumarkt_WE"  
    ];
    $scope.articleOrBetragList = [
        "Article",  
        "Betrag",  
        "Both"  
    ];
    $scope.amountKeyList = [
        "Einheiten",  
        "Stueck_oder_KG",  
        "Keine_Menge"  
    ];
    $scope.rechnungOrGutschriftList = [
        "Rechnung",  
        "Gutschrift",  
        "Keine"  
    ];
    $scope.rueckstellungRegelList = [
        "Betrag_aus_Menge",  
        "Prozent_aus_Wert",  
        "Keine"  
    ];
    $scope.lieferartTypeList = [
        "Eigengeschaeft",  
        "Filialbuchhaltung",  
        "Lagerbuchung",  
        "Partner_Agrenzung",  
        "Partner",  
        "Warenwirtschaft",  
        "Zentrale_Abbildung_Maerkte"  
    ];
    $scope.bezugartList = [
        "Lager",  
        "Buchung_Strecke",  
        "Abschrift",  
        "Aktionsanschrift",  
        "Pauschalabschrift"  
    ];
    
    $scope.get();
});