
angular.module('logisticsadminangularjs').controller('NewLagerController', function ($scope, $location, locationParser, LagerResource , CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.lager = $scope.lager || {};
    
    $scope.typeList = [
        "Baecker",
        "Food",
        "Kolonialwaren",
        "Obst_und_Gemuese",
        "Zentrallager"
    ];
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.lager.address.country = {};
            $scope.lager.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Lagers/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        LagerResource.save($scope.lager, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Lagers");
    };
});