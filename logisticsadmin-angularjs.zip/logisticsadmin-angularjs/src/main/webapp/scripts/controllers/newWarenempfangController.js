
angular.module('logisticsadminangularjs').controller('NewWarenempfangController', function ($scope, $location, locationParser, WarenempfangResource , LagerResource, LieferantResource, UserResource, UserResource, UserResource, UserResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.warenempfang = $scope.warenempfang || {};
    
    $scope.lagerList = LagerResource.queryAll(function(items){
        $scope.lagerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.lagerNo
            });
        });
    });
    $scope.$watch("lagerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.warenempfang.lager = {};
            $scope.warenempfang.lager.id = selection.value;
        }
    });
    
    $scope.lieferantList = LieferantResource.queryAll(function(items){
        $scope.lieferantSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.lieferantNo
            });
        });
    });
    $scope.$watch("lieferantSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.warenempfang.lieferant = {};
            $scope.warenempfang.lieferant.id = selection.value;
        }
    });
    
    $scope.geandertBisVerbuchenUserList = UserResource.queryAll(function(items){
        $scope.geandertBisVerbuchenUserSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("geandertBisVerbuchenUserSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.warenempfang.geandertBisVerbuchenUser = {};
            $scope.warenempfang.geandertBisVerbuchenUser.id = selection.value;
        }
    });
    
    $scope.geandertBisBelegUserList = UserResource.queryAll(function(items){
        $scope.geandertBisBelegUserSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("geandertBisBelegUserSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.warenempfang.geandertBisBelegUser = {};
            $scope.warenempfang.geandertBisBelegUser.id = selection.value;
        }
    });
    
    $scope.rechnungEmpfangGeprueftUserList = UserResource.queryAll(function(items){
        $scope.rechnungEmpfangGeprueftUserSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("rechnungEmpfangGeprueftUserSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.warenempfang.rechnungEmpfangGeprueftUser = {};
            $scope.warenempfang.rechnungEmpfangGeprueftUser.id = selection.value;
        }
    });
    
    $scope.geandertBisEmpfaengerUserList = UserResource.queryAll(function(items){
        $scope.geandertBisEmpfaengerUserSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("geandertBisEmpfaengerUserSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.warenempfang.geandertBisEmpfaengerUser = {};
            $scope.warenempfang.geandertBisEmpfaengerUser.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Warenempfangs/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        WarenempfangResource.save($scope.warenempfang, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Warenempfangs");
    };
});