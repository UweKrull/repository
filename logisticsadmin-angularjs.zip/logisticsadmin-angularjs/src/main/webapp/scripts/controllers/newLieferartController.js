
angular.module('logisticsadminangularjs').controller('NewLieferartController', function ($scope, $location, locationParser, LieferartResource , LagerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.lieferart = $scope.lieferart || {};
    
    $scope.lagerList = LagerResource.queryAll(function(items){
        $scope.lagerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.lagerNo
            });
        });
    });
    $scope.$watch("lagerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.lieferart.lager = {};
            $scope.lieferart.lager.id = selection.value;
        }
    });
    
    $scope.partieAppList = [
        "BEDARF",
        "ELVS",
        "BUCHUNG",
        "PARTIE",
        "RUECKSTELLUNG",
        "STRECKE",
        "UMSATZ",
        "WALAGER",
        "WELAGER"
    ];
    
    $scope.statusList = [
        "Activ",
        "Inactiv"
    ];
    
    $scope.deliveryList = [
        "Lagerart_Lagernr",
        "Manuelle_Buchung",
        "Strecken_Basislager",
        "Baumarkt_WE"
    ];
    
    $scope.articleOrBetragList = [
        "Article",
        "Betrag",
        "Both"
    ];
    
    $scope.amountKeyList = [
        "Einheiten",
        "Stueck_oder_KG",
        "Keine_Menge"
    ];
    
    $scope.rechnungOrGutschriftList = [
        "Rechnung",
        "Gutschrift",
        "Keine"
    ];
    
    $scope.rueckstellungRegelList = [
        "Betrag_aus_Menge",
        "Prozent_aus_Wert",
        "Keine"
    ];
    
    $scope.lieferartTypeList = [
        "Eigengeschaeft",
        "Filialbuchhaltung",
        "Lagerbuchung",
        "Partner_Agrenzung",
        "Partner",
        "Warenwirtschaft",
        "Zentrale_Abbildung_Maerkte"
    ];
    
    $scope.bezugartList = [
        "Lager",
        "Buchung_Strecke",
        "Abschrift",
        "Aktionsanschrift",
        "Pauschalabschrift"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Lieferarts/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        LieferartResource.save($scope.lieferart, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Lieferarts");
    };
});