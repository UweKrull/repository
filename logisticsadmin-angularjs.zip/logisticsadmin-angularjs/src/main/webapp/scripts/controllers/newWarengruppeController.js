
angular.module('logisticsadminangularjs').controller('NewWarengruppeController', function ($scope, $location, locationParser, WarengruppeResource , ArticleResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.warengruppe = $scope.warengruppe || {};
    
    $scope.articleList = ArticleResource.queryAll(function(items){
        $scope.articleSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.activ
            });
        });
    });
    $scope.$watch("articleSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.warengruppe.article = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.warengruppe.article.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Warengruppes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        WarengruppeResource.save($scope.warengruppe, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Warengruppes");
    };
});