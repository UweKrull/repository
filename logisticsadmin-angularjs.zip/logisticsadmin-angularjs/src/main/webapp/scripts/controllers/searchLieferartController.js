

angular.module('logisticsadminangularjs').controller('SearchLieferartController', function($scope, $http, LieferartResource , LagerResource) {

    $scope.search={};
    $scope.currentPage = 0;
    $scope.pageSize= 10;
    $scope.searchResults = [];
    $scope.filteredResults = [];
    $scope.pageRange = [];
    $scope.numberOfPages = function() {
        var result = Math.ceil($scope.filteredResults.length/$scope.pageSize);
        var max = (result == 0) ? 1 : result;
        $scope.pageRange = [];
        for(var ctr=0;ctr<max;ctr++) {
            $scope.pageRange.push(ctr);
        }
        return max;
    };
    $scope.lagerList = LagerResource.queryAll();
    $scope.partieAppList = [
        "BEDARF",
        "ELVS",
        "BUCHUNG",
        "PARTIE",
        "RUECKSTELLUNG",
        "STRECKE",
        "UMSATZ",
        "WALAGER",
        "WELAGER"
    ];
    $scope.statusList = [
        "Activ",
        "Inactiv"
    ];
    $scope.deliveryList = [
        "Lagerart_Lagernr",
        "Manuelle_Buchung",
        "Strecken_Basislager",
        "Baumarkt_WE"
    ];
    $scope.articleOrBetragList = [
        "Article",
        "Betrag",
        "Both"
    ];
    $scope.amountKeyList = [
        "Einheiten",
        "Stueck_oder_KG",
        "Keine_Menge"
    ];
    $scope.rechnungOrGutschriftList = [
        "Rechnung",
        "Gutschrift",
        "Keine"
    ];
    $scope.rueckstellungRegelList = [
        "Betrag_aus_Menge",
        "Prozent_aus_Wert",
        "Keine"
    ];
    $scope.lieferartTypeList = [
        "Eigengeschaeft",
        "Filialbuchhaltung",
        "Lagerbuchung",
        "Partner_Agrenzung",
        "Partner",
        "Warenwirtschaft",
        "Zentrale_Abbildung_Maerkte"
    ];
    $scope.bezugartList = [
        "Lager",
        "Buchung_Strecke",
        "Abschrift",
        "Aktionsanschrift",
        "Pauschalabschrift"
    ];

    $scope.performSearch = function() {
        $scope.searchResults = LieferartResource.queryAll(function(){
            $scope.numberOfPages();
        });
    };
    
    $scope.previous = function() {
       if($scope.currentPage > 0) {
           $scope.currentPage--;
       }
    };
    
    $scope.next = function() {
       if($scope.currentPage < ($scope.numberOfPages() - 1) ) {
           $scope.currentPage++;
       }
    };
    
    $scope.setPage = function(n) {
       $scope.currentPage = n;
    };

    $scope.performSearch();
});