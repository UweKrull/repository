

angular.module('logisticsadminangularjs').controller('EditWarenempfangController', function($scope, $routeParams, $location, WarenempfangResource , LagerResource, LieferantResource, UserResource, UserResource, UserResource, UserResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.warenempfang = new WarenempfangResource(self.original);
            LagerResource.queryAll(function(items) {
                $scope.lagerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.lagerNo
                    };
                    if($scope.warenempfang.lager && item.id == $scope.warenempfang.lager.id) {
                        $scope.lagerSelection = labelObject;
                        $scope.warenempfang.lager = wrappedObject;
                        self.original.lager = $scope.warenempfang.lager;
                    }
                    return labelObject;
                });
            });
            LieferantResource.queryAll(function(items) {
                $scope.lieferantSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.lieferantNo
                    };
                    if($scope.warenempfang.lieferant && item.id == $scope.warenempfang.lieferant.id) {
                        $scope.lieferantSelection = labelObject;
                        $scope.warenempfang.lieferant = wrappedObject;
                        self.original.lieferant = $scope.warenempfang.lieferant;
                    }
                    return labelObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.geandertBisVerbuchenUserSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.warenempfang.geandertBisVerbuchenUser && item.id == $scope.warenempfang.geandertBisVerbuchenUser.id) {
                        $scope.geandertBisVerbuchenUserSelection = labelObject;
                        $scope.warenempfang.geandertBisVerbuchenUser = wrappedObject;
                        self.original.geandertBisVerbuchenUser = $scope.warenempfang.geandertBisVerbuchenUser;
                    }
                    return labelObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.geandertBisBelegUserSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.warenempfang.geandertBisBelegUser && item.id == $scope.warenempfang.geandertBisBelegUser.id) {
                        $scope.geandertBisBelegUserSelection = labelObject;
                        $scope.warenempfang.geandertBisBelegUser = wrappedObject;
                        self.original.geandertBisBelegUser = $scope.warenempfang.geandertBisBelegUser;
                    }
                    return labelObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.rechnungEmpfangGeprueftUserSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.warenempfang.rechnungEmpfangGeprueftUser && item.id == $scope.warenempfang.rechnungEmpfangGeprueftUser.id) {
                        $scope.rechnungEmpfangGeprueftUserSelection = labelObject;
                        $scope.warenempfang.rechnungEmpfangGeprueftUser = wrappedObject;
                        self.original.rechnungEmpfangGeprueftUser = $scope.warenempfang.rechnungEmpfangGeprueftUser;
                    }
                    return labelObject;
                });
            });
            UserResource.queryAll(function(items) {
                $scope.geandertBisEmpfaengerUserSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.warenempfang.geandertBisEmpfaengerUser && item.id == $scope.warenempfang.geandertBisEmpfaengerUser.id) {
                        $scope.geandertBisEmpfaengerUserSelection = labelObject;
                        $scope.warenempfang.geandertBisEmpfaengerUser = wrappedObject;
                        self.original.geandertBisEmpfaengerUser = $scope.warenempfang.geandertBisEmpfaengerUser;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Warenempfangs");
        };
        WarenempfangResource.get({WarenempfangId:$routeParams.WarenempfangId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.warenempfang);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.warenempfang.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Warenempfangs");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Warenempfangs");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.warenempfang.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("lagerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.warenempfang.lager = {};
            $scope.warenempfang.lager.id = selection.value;
        }
    });
    $scope.$watch("lieferantSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.warenempfang.lieferant = {};
            $scope.warenempfang.lieferant.id = selection.value;
        }
    });
    $scope.$watch("geandertBisVerbuchenUserSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.warenempfang.geandertBisVerbuchenUser = {};
            $scope.warenempfang.geandertBisVerbuchenUser.id = selection.value;
        }
    });
    $scope.$watch("geandertBisBelegUserSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.warenempfang.geandertBisBelegUser = {};
            $scope.warenempfang.geandertBisBelegUser.id = selection.value;
        }
    });
    $scope.$watch("rechnungEmpfangGeprueftUserSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.warenempfang.rechnungEmpfangGeprueftUser = {};
            $scope.warenempfang.rechnungEmpfangGeprueftUser.id = selection.value;
        }
    });
    $scope.$watch("geandertBisEmpfaengerUserSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.warenempfang.geandertBisEmpfaengerUser = {};
            $scope.warenempfang.geandertBisEmpfaengerUser.id = selection.value;
        }
    });
    
    $scope.get();
});