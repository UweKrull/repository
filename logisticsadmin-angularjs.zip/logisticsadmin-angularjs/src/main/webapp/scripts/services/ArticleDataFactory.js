angular.module('logisticsadminangularjs').factory('ArticleDataResource', function($resource){
    var resource = $resource('rest/articledatas/:ArticleDataId',{ArticleDataId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});