angular.module('logisticsadminangularjs').factory('BezugswegResource', function($resource){
    var resource = $resource('rest/bezugswegs/:BezugswegId',{BezugswegId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});