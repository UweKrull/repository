angular.module('logisticsadminangularjs').factory('LagerResource', function($resource){
    var resource = $resource('rest/lagers/:LagerId',{LagerId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});