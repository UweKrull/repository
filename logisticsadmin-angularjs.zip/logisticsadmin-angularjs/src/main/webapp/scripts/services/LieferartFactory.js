angular.module('logisticsadminangularjs').factory('LieferartResource', function($resource){
    var resource = $resource('rest/lieferarts/:LieferartId',{LieferartId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});