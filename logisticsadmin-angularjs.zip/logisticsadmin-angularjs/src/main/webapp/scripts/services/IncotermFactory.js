angular.module('logisticsadminangularjs').factory('IncotermResource', function($resource){
    var resource = $resource('rest/incoterms/:IncotermId',{IncotermId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});