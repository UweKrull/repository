'use strict';

angular.module('logisticsadminangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Articles',{templateUrl:'views/Article/search.html',controller:'SearchArticleController'})
      .when('/Articles/new',{templateUrl:'views/Article/detail.html',controller:'NewArticleController'})
      .when('/Articles/edit/:ArticleId',{templateUrl:'views/Article/detail.html',controller:'EditArticleController'})
      .when('/ArticleDatas',{templateUrl:'views/ArticleData/search.html',controller:'SearchArticleDataController'})
      .when('/ArticleDatas/new',{templateUrl:'views/ArticleData/detail.html',controller:'NewArticleDataController'})
      .when('/ArticleDatas/edit/:ArticleDataId',{templateUrl:'views/ArticleData/detail.html',controller:'EditArticleDataController'})
      .when('/Bezugswegs',{templateUrl:'views/Bezugsweg/search.html',controller:'SearchBezugswegController'})
      .when('/Bezugswegs/new',{templateUrl:'views/Bezugsweg/detail.html',controller:'NewBezugswegController'})
      .when('/Bezugswegs/edit/:BezugswegId',{templateUrl:'views/Bezugsweg/detail.html',controller:'EditBezugswegController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Departments',{templateUrl:'views/Department/search.html',controller:'SearchDepartmentController'})
      .when('/Departments/new',{templateUrl:'views/Department/detail.html',controller:'NewDepartmentController'})
      .when('/Departments/edit/:DepartmentId',{templateUrl:'views/Department/detail.html',controller:'EditDepartmentController'})
      .when('/Incoterms',{templateUrl:'views/Incoterm/search.html',controller:'SearchIncotermController'})
      .when('/Incoterms/new',{templateUrl:'views/Incoterm/detail.html',controller:'NewIncotermController'})
      .when('/Incoterms/edit/:IncotermId',{templateUrl:'views/Incoterm/detail.html',controller:'EditIncotermController'})
      .when('/Lagers',{templateUrl:'views/Lager/search.html',controller:'SearchLagerController'})
      .when('/Lagers/new',{templateUrl:'views/Lager/detail.html',controller:'NewLagerController'})
      .when('/Lagers/edit/:LagerId',{templateUrl:'views/Lager/detail.html',controller:'EditLagerController'})
      .when('/Lieferants',{templateUrl:'views/Lieferant/search.html',controller:'SearchLieferantController'})
      .when('/Lieferants/new',{templateUrl:'views/Lieferant/detail.html',controller:'NewLieferantController'})
      .when('/Lieferants/edit/:LieferantId',{templateUrl:'views/Lieferant/detail.html',controller:'EditLieferantController'})
      .when('/Lieferarts',{templateUrl:'views/Lieferart/search.html',controller:'SearchLieferartController'})
      .when('/Lieferarts/new',{templateUrl:'views/Lieferart/detail.html',controller:'NewLieferartController'})
      .when('/Lieferarts/edit/:LieferartId',{templateUrl:'views/Lieferart/detail.html',controller:'EditLieferartController'})
      .when('/Users',{templateUrl:'views/User/search.html',controller:'SearchUserController'})
      .when('/Users/new',{templateUrl:'views/User/detail.html',controller:'NewUserController'})
      .when('/Users/edit/:UserId',{templateUrl:'views/User/detail.html',controller:'EditUserController'})
      .when('/Warenempfangs',{templateUrl:'views/Warenempfang/search.html',controller:'SearchWarenempfangController'})
      .when('/Warenempfangs/new',{templateUrl:'views/Warenempfang/detail.html',controller:'NewWarenempfangController'})
      .when('/Warenempfangs/edit/:WarenempfangId',{templateUrl:'views/Warenempfang/detail.html',controller:'EditWarenempfangController'})
      .when('/Warengruppes',{templateUrl:'views/Warengruppe/search.html',controller:'SearchWarengruppeController'})
      .when('/Warengruppes/new',{templateUrl:'views/Warengruppe/detail.html',controller:'NewWarengruppeController'})
      .when('/Warengruppes/edit/:WarengruppeId',{templateUrl:'views/Warengruppe/detail.html',controller:'EditWarengruppeController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
