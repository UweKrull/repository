package de.binaris.logisticsadmin.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
/**
 * <p>
 * A reusable representation of the Fachbereich.
 * 
 * Fachbereich can be used in many places in the logistics application, 
 * so to observe the DRY principle, Fachbereich is an embeddable
 * entity. An embeddable entity appears as a child in the object model, 
 * but no relationship is established in the RDBMS.
 * </p>
 */
@SuppressWarnings("serial")
@Embeddable
public class Fachbereich implements Serializable {

	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "fachbereich_bilanzstelle")
	private String fachbereichBilanzstelle;
    
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "fachbereich_bereich")
	private String fachbereichBereich;
	
	@NotNull
	@Digits(integer = 3, fraction = 0)
	@Size(min = 3, max = 3, message = "must be 000-999 digits")
	@Column(name = "fachbereich_kostenstelle")
	private String fachbereichKostenstelle;
	
	@NotNull
	@Min(0)
	@Max(9)
	@Column(name = "fachbereich_pruefziffer")
	private Integer verificationCode;
	
	public String getFachbereichBilanzstelle() {
		return fachbereichBilanzstelle;
	}

	public void setFachbereichBilanzstelle(String fachbereichBilanzstelle) {
		this.fachbereichBilanzstelle = fachbereichBilanzstelle;
	}

	public String getFachbereichBereich() {
		return fachbereichBereich;
	}

	public void setFachbereichBereich(String fachbereichBereich) {
		this.fachbereichBereich = fachbereichBereich;
	}

	public String getFachbereichKostenstelle() {
		return fachbereichKostenstelle;
	}

	public void setFachbereichKostenstelle(String fachbereichKostenstelle) {
		this.fachbereichKostenstelle = fachbereichKostenstelle;
	}

	public Integer getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(Integer verificationCode) {
		this.verificationCode = verificationCode;
	}

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        Fachbereich fachbereich = (Fachbereich) o;

        if (fachbereichBilanzstelle != null ? !fachbereichBilanzstelle.equals(fachbereich.fachbereichBilanzstelle) : fachbereich.fachbereichBilanzstelle != null)
            return false;
        if (fachbereichBereich != null ? !fachbereichBereich.equals(fachbereich.fachbereichBereich) : fachbereich.fachbereichBereich != null)
        	return false;
        if (fachbereichKostenstelle != null ? !fachbereichKostenstelle.equals(fachbereich.fachbereichKostenstelle) : fachbereich.fachbereichKostenstelle != null)
        	return false;
        if (verificationCode != null ? !verificationCode.equals(fachbereich.verificationCode) : fachbereich.verificationCode != null)
        	return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = fachbereichBilanzstelle != null ? fachbereichBilanzstelle.hashCode() : 0;
        result = 31 * result + (fachbereichBereich != null ? fachbereichBereich.hashCode() : 0);
        result = 31 * result + (fachbereichKostenstelle != null ? fachbereichKostenstelle.hashCode() : 0);
        result = 31 * result + (verificationCode != null ? verificationCode.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(fachbereichBilanzstelle);
       	sb.append(", ").append(fachbereichBereich);
        sb.append(", ").append(fachbereichKostenstelle);
        sb.append(", ").append(verificationCode.toString());
        return sb.toString();
    }
}
