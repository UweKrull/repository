package de.binaris.logisticsadmin.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Cacheable
@Entity
@Table(name = "lieferant")
public class Lieferant implements Serializable {

	private static final long serialVersionUID = 111332255569765321L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_lieferant")
	@SequenceGenerator(name = "my_entity_seq_gen_lieferant", sequenceName = "sequence_lieferant", allocationSize = 1)
	private Long id;

	@NotNull
	@NotEmpty
	@Column(name = "lieferant_nr")
	private String lieferantNo;

	@NotNull
	@NotEmpty
	@Column(name = "name")
	private String name;
	
	private Address address = new Address();

	@Digits(integer = 9, fraction = 0)
	@Size(min = 9, max = 9, message = "must be 000000000-999999999 digits")
	@Column(name = "sap_nr")
	private String sapNo;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLieferantNo() {
		return lieferantNo;
	}

	public void setLieferantNo(String lieferantNo) {
		this.lieferantNo = lieferantNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getSapNo() {
		return sapNo;
	}

	public void setSapNo(String sapNo) {
		this.sapNo = sapNo;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Lieferant)) {
			return false;
		}
		Lieferant castOther = (Lieferant) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(lieferantNo);
		sb.append(", ");
		sb.append(name);
		if (sapNo != null) {
			sb.append(", ");
			sb.append(sapNo);
		}
		return sb.toString();
	}
}
