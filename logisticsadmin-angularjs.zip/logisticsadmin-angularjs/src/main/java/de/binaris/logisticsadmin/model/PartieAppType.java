package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link PartieAppType} describes the types of Partie-Anwendungen.
 * 
 * PartieApp is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the PartieApp types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link PartieAppType} describes the PartieApp types of a Lieferart (delivery type).
 * </p>
 */
public enum PartieAppType {

    /**
     * The PartieApps of Lieferarten.
     */
	BEDARF("Bedarf", true),
    ELVS("Elektron. Lagerverw. System", true),
    BUCHUNG("Buchung", true),
    PARTIE("Partie", true),
    RUECKSTELLUNG("Rueckstellung", true),
    STRECKE("Strecke", true),
    UMSATZ("Umsatz", true),
    WALAGER("Warenausgangslager", true),
    WELAGER("Warenempfangslager", true);   

    /**
     * A human readable description of the PartieApp type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the PartieApp type can be cached.
     */
    private final boolean cacheable;
    
    private PartieAppType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
