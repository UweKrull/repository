package de.binaris.logisticsadmin.model;

import static javax.persistence.EnumType.STRING;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "abteilung")
public class Department implements Serializable {

	private static final long serialVersionUID = 5954321989657257321L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_abteilung")
	@SequenceGenerator(name = "my_entity_seq_gen_abteilung", sequenceName = "sequence_abteilung", allocationSize = 1)
	private Long id;

	private Kostenstellenbasis kostenstellenbasis = new Kostenstellenbasis();
	
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "abt_kennung")
	private String deptNo;
	
    @Column(name = "artikel_kennzeichen")
    @NotNull
    @Enumerated(STRING)
    private DepartmentType articleRelated;
    
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public DepartmentType getArticleRelated() {
		return articleRelated;
	}

	public void setArticleRelated(DepartmentType articleRelated) {
		this.articleRelated = articleRelated;
	}

	public String getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}

	public Kostenstellenbasis getKostenstellenbasis() {
		return kostenstellenbasis;
	}

	public void setKostenstellenbasis(Kostenstellenbasis kostenstellenbasis) {
		this.kostenstellenbasis = kostenstellenbasis;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Department)) {
			return false;
		}
		Department castOther = (Department) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(deptNo);
		sb.append(", ");
		sb.append(articleRelated);
		sb.append(", ");
		sb.append(kostenstellenbasis);
		return sb.toString();
	}
}
