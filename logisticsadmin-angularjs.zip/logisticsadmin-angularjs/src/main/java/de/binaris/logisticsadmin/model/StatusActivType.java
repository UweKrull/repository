package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link StatusActivType} describes the (non-)activ status types (A, N)
 * 
 * StatusActiv is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the StatusActiv types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link StatusActivType} describes the StatusActiv.
 * </p>
 */
public enum StatusActivType {

    /**
     * The StatusActiv types.
     */
    Activ("AKTIV", true),
    Inactiv("DEAKTIV", true);   

    /**
     * A human readable description of the StatusActiv type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the StatusActiv type can be cached.
     */
    private final boolean cacheable;
    
    private StatusActivType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
