package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link DeliveryType} describes how the delivery is to happen.
 * 
 * DeliveryType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the DeliveryType types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link DeliveryType} describes how the delivery is to happen.
 * </p>
 */
public enum DeliveryType {

    /**
     * The DeliveryType how to deliver the goods.
     */
    Lagerart_Lagernr("Lnnn", true),
    Manuelle_Buchung("MAN", true),   
    Strecken_Basislager("SBL", true),
    Baumarkt_WE("WE", true);

    /**
     * A human readable description of the Delivery type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the Delivery type can be cached.
     */
    private final boolean cacheable;
    
    private DeliveryType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
