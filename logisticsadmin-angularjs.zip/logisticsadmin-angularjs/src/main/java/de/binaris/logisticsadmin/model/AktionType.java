package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link AktionType} describes the Aktion types (A, N)
 * 
 * Aktion is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the Aktion types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link AktionType} describes whether or not the article is an Aktions-article.
 * </p>
 */
public enum AktionType {

    /**
     * The Aktion types of articles.
     */
    Aktion("A", true),
    Keine_Aktion("N", true);   

    /**
     * A human readable description of the Aktion type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the Aktion type can be cached.
     */
    private final boolean cacheable;
    
    private AktionType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
