package de.binaris.logisticsadmin.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "artikel_daten")
public class ArticleData implements Serializable {

	private static final long serialVersionUID = 2925219619657113312L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_article_daten")
	@SequenceGenerator(name = "my_entity_seq_gen_article_daten", sequenceName = "sequence_article_daten", allocationSize = 1)
	private Long id;

	@NotNull
	@Digits(integer = 4, fraction = 0)
	@Size(min = 4, max = 4, message = "must be 0000-9999 digits")
	@Column(name = "gebinde_einheit")
	private String minAmountPerPackageUnit;

	@NotNull
	@Column(name = "laenge_mm")
	private Long length;

	@NotNull
	@Column(name = "breite_mm")
	private Long width;
	
	@NotNull
	@Column(name = "hoehe_mm")
	private Long height;
	
	@NotNull
	@Column(name = "gewicht_kg")
	private Float weight;
	
    @Column(name = "verpackungs_einheit")
    @Enumerated(STRING)
    private PackageUnitType packageUnit;

	@ManyToOne
	private Lager lager;
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "articleData")
	private Set<Article> article = new HashSet<Article>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMinAmounPerPackageUnit() {
		return minAmountPerPackageUnit;
	}

	public void setMinAmounPerPackageUnit(String minAmountPerPackageUnit) {
		this.minAmountPerPackageUnit = minAmountPerPackageUnit;
	}

	public Long getLength() {
		return length;
	}

	public void setLength(Long length) {
		this.length = length;
	}

	public Long getWidth() {
		return width;
	}

	public void setWidth(Long width) {
		this.width = width;
	}

	public Long getHeight() {
		return height;
	}

	public void setHeight(Long height) {
		this.height = height;
	}

	public Float getWeight() {
		return weight;
	}

	public void setWeight(Float weight) {
		this.weight = weight;
	}

	public PackageUnitType getPackageUnit() {
		return packageUnit;
	}

	public void setPackageUnit(PackageUnitType packageUnit) {
		this.packageUnit = packageUnit;
	}

	public Lager getLager() {
		return lager;
	}

	public void setLager(Lager lager) {
		this.lager = lager;
	}

	public Set<Article> getArticle() {
		return article;
	}

	public void setArticle(Set<Article> article) {
		this.article = article;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof ArticleData)) {
			return false;
		}
		ArticleData castOther = (ArticleData) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		if (!article.isEmpty()) {
			sb.append(article.iterator().next().getCurrentArticleNo());
			sb.append(", ");
		}
		sb.append(minAmountPerPackageUnit);
		sb.append(", ");
		sb.append(packageUnit);
		sb.append(", ");
		sb.append(length);
		sb.append("x");
		sb.append(height);
		sb.append("x");
		sb.append(width);
		sb.append(", ");
		sb.append(lager);
		return sb.toString();
	}
}
