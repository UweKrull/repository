package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link RueckstellungRegelType} describes the rule 
 * to be applied for the Rueckstellung
 * 
 * RueckstellungRegelType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the RueckstellungRegel types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link RueckstellungRegelType} describes the rule 
 * to be applied for the Rueckstellung
 * </p>
 */
public enum RueckstellungRegelType {

    /**
     * The RueckstellungRegelType.
     */
    Betrag_aus_Menge("BM", true),
    Prozent_aus_Wert("PR", true),
    Keine(" ", true);   

    /**
     * A human readable description of the RueckstellungRegel type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the RueckstellungRegel type can be cached.
     */
    private final boolean cacheable;
    
    private RueckstellungRegelType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
