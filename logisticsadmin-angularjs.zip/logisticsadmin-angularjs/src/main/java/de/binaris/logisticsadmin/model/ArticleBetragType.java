package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link ArticleBetragType} describes the article delivery's types
 * Article or Betrag (or both).
 * 
 * ArticleBetragType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the ArticleBetrag types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link ArticleBetragType} describes the article delivery's types (A,B,X).
 * </p>
 */
public enum ArticleBetragType {

    /**
     * The ArticleOrBetrag type of a delivery.
     */
    Article("A", true),
    Betrag("B", true),  
    Both("X", true);

    /**
     * A human readable description of the ArticleOrBetrag type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the activ type can be cached.
     */
    private final boolean cacheable;
    
    private ArticleBetragType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
