package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link DepartmentType} describes the types (J, N) whether it's article-related or not.
 * 
 * departmentType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the department types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link DepartmentType} describes whether or not the department is article-related.
 * </p>
 */
public enum DepartmentType {

    /**
     * The department type.
     */
    Article("J", true),
    No_Article("N", true);

    /**
     * A human readable description of the department type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the department type can be cached.
     */
    private final boolean cacheable;
    
    private DepartmentType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
