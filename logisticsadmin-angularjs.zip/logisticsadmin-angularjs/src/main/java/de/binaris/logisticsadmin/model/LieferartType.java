package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link LieferartType} describes the Lieferart types.
 * 
 * Lieferart type is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the Lieferart types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link LieferartType} describes the types of an Lieferart.
 * </p>
 */
public enum LieferartType {

    /**
     * The Lieferart types.
     */	
	Eigengeschaeft("EG",true),
	Filialbuchhaltung("FL",true),
	Lagerbuchung("LG",true),
	Partner_Agrenzung("PB",true),
	Partner("WB",true),
	Warenwirtschaft("WW",true),
	Zentrale_Abbildung_Maerkte("ZM",true);   
	
    /**
     * A human readable description of the Lieferart type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the Lieferart type can be cached.
     */
    private final boolean cacheable;
    
    private LieferartType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
