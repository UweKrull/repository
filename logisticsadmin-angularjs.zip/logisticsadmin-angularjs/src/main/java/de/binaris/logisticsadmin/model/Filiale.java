package de.binaris.logisticsadmin.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
/**
 * <p>
 * A reusable representation of the Filiale.
 * 
 * Filiale can be used in many places in the logistics application, 
 * so to observe the DRY principle, Filiale is an embeddable
 * entity. An embeddable entity appears as a child in the object model, 
 * but no relationship is established in the RDBMS.
 * </p>
 */
@SuppressWarnings("serial")
@Embeddable
public class Filiale implements Serializable {

	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "filial_bilanzstelle")
	private String filialBilanzstelle;
    
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "filial_bereich")
	private String filialBereich;
	
	@NotNull
	@Digits(integer = 3, fraction = 0)
	@Size(min = 3, max = 3, message = "must be 000-999 digits")
	@Column(name = "filial_kostenstelle")
	private String filialKostenstelle;
	
	@NotNull
	@Min(0)
	@Max(9)
	@Column(name = "filial_pruefziffer")
	private Integer verificationCode;
	
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "filial_niederlassung")
	private String filialNiederlassung;
	
	public String getFilialBilanzstelle() {
		return filialBilanzstelle;
	}

	public void setFilialBilanzstelle(String filialBilanzstelle) {
		this.filialBilanzstelle = filialBilanzstelle;
	}

	public String getFilialBereich() {
		return filialBereich;
	}

	public void setFilialBereich(String filialBereich) {
		this.filialBereich = filialBereich;
	}

	public String getFilialKostenstelle() {
		return filialKostenstelle;
	}

	public void setFilialKostenstelle(String filialKostenstelle) {
		this.filialKostenstelle = filialKostenstelle;
	}

	public Integer getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(Integer verificationCode) {
		this.verificationCode = verificationCode;
	}

	public String getFilialNiederlassung() {
		return filialNiederlassung;
	}
	
	public void setFilialNiederlassung(String filialNiederlassung) {
		this.filialNiederlassung = filialNiederlassung;
	}
	
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        Filiale filiale = (Filiale) o;

        if (filialBilanzstelle != null ? !filialBilanzstelle.equals(filiale.filialBilanzstelle) : filiale.filialBilanzstelle != null)
            return false;
        if (filialBereich != null ? !filialBereich.equals(filiale.filialBereich) : filiale.filialBereich != null)
        	return false;
        if (filialKostenstelle != null ? !filialKostenstelle.equals(filiale.filialKostenstelle) : filiale.filialKostenstelle != null)
        	return false;
        if (verificationCode != null ? !verificationCode.equals(filiale.verificationCode) : filiale.verificationCode != null)
        	return false;
        if (filialNiederlassung != null ? !filialNiederlassung.equals(filiale.filialNiederlassung) : filiale.filialNiederlassung != null)
        	return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = filialBilanzstelle != null ? filialBilanzstelle.hashCode() : 0;
        result = 31 * result + (filialBereich != null ? filialBereich.hashCode() : 0);
        result = 31 * result + (filialKostenstelle != null ? filialKostenstelle.hashCode() : 0);
        result = 31 * result + (verificationCode != null ? verificationCode.hashCode() : 0);
        result = 31 * result + (filialNiederlassung != null ? filialNiederlassung.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(filialBilanzstelle);
       	sb.append(", ").append(filialBereich);
        sb.append(", ").append(filialKostenstelle);
        sb.append(", ").append(verificationCode.toString());
        sb.append(", ").append(filialNiederlassung);
        return sb.toString();
    }
}
