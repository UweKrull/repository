package de.binaris.logisticsadmin.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "warengruppe")
public class Warengruppe implements Serializable {

	private static final long serialVersionUID = 3471759629797123727L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_warengruppe")
	@SequenceGenerator(name = "my_entity_seq_gen_warengruppe", sequenceName = "sequence_warengruppe", allocationSize = 1)
	private Long id;

	@NotNull
	@Digits(integer = 4, fraction = 0)
	@Size(min = 4, max = 4, message = "must be between 0000 and 9999 digits")
	private String wgru;

	@NotNull
	@Min(0)
	@Max(9)
	@Column(name = "typ")
	private Integer type;
	
	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	@Column(name = "beschreibung")
	private String description;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "warengruppe")
	private Set<Article> article = new HashSet<Article>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getWgru() {
		return wgru;
	}

	public void setWgru(String wgru) {
		this.wgru = wgru;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<Article> getArticle() {
		return article;
	}

	public void setArticle(Set<Article> article) {
		this.article = article;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Warengruppe)) {
			return false;
		}
		Warengruppe castOther = (Warengruppe) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return wgru;
	}
}
