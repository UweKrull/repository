package de.binaris.logisticsadmin.model;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "artikel")
public class Article implements Serializable {

	private static final long serialVersionUID = 1915129629657226325L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_article")
	@SequenceGenerator(name = "my_entity_seq_gen_article", sequenceName = "sequence_article", allocationSize = 1)
	private Long id;

	@NotNull
	@Digits(integer = 7, fraction = 0)
	@Size(min = 7, max = 7, message = "must be 0000000-9999999 digits")
	@Column(name = "original_nan")
	private String originalArticleNo;

	@NotNull
	@Digits(integer = 7, fraction = 0)
	@Size(min = 7, max = 7, message = "must be 0000000-9999999 digits")
	@Column(name = "aktuelle_nan")
	private String currentArticleNo;
	
	@NotNull
	@Digits(integer = 13, fraction = 0)
	@Size(min = 13, max = 13, message = "must be 0000000000000-9999999999999 digits")
	@Column(name = "ean")
	private String ean;
	
	@NotNull
	@Min(1)
	@Max(6)
	@Column(name = "ean_typ")
	private Integer eanType;
	
    @Column(name = "aktiv")
    @Enumerated(STRING)
    private ActivType activ;
    
    @Column(name = "bestell_mengen_einheit")
    @Enumerated(STRING)
    private OrderAmountUnitType orderAmountUnit;
    
	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	@Column(name = "beschreibung")
	private String description;
	
	@ManyToOne
	private Warengruppe warengruppe;
	
	@ManyToOne
	private ArticleData articleData;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ActivType getActiv() {
		return activ;
	}

	public void setActiv(ActivType activ) {
		this.activ = activ;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Warengruppe getWarengruppe() {
		return warengruppe;
	}

	public void setWarengruppe(Warengruppe warengruppe) {
		this.warengruppe = warengruppe;
	}

	public String getOriginalArticleNo() {
		return originalArticleNo;
	}

	public void setOriginalArticleNo(String originalArticleNo) {
		this.originalArticleNo = originalArticleNo;
	}

	public String getCurrentArticleNo() {
		return currentArticleNo;
	}

	public void setCurrentArticleNo(String currentArticleNo) {
		this.currentArticleNo = currentArticleNo;
	}

	public String getEan() {
		return ean;
	}

	public void setEan(String ean) {
		this.ean = ean;
	}

	public Integer getEanType() {
		return eanType;
	}

	public void setEanType(Integer eanType) {
		this.eanType = eanType;
	}

	public OrderAmountUnitType getOrderAmountUnit() {
		return orderAmountUnit;
	}

	public void setOrderAmountUnit(OrderAmountUnitType orderAmountUnit) {
		this.orderAmountUnit = orderAmountUnit;
	}

	public ArticleData getArticleData() {
		return articleData;
	}

	public void setArticleData(ArticleData articleData) {
		this.articleData = articleData;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Article)) {
			return false;
		}
		Article castOther = (Article) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(currentArticleNo);
		sb.append(", ");
		sb.append(ean);
		sb.append(", ");
		sb.append(description);
		return sb.toString();
	}
}
