package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link BezugArtType} describes the delivery-related Bezugart.
 * 
 * BezugArtType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the BezugArt types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link BezugArtType} describes the delivery-related Bezugart.
 * </p>
 */
public enum BezugArtType {

    /**
     * The BezugArt type.
     */
    Lager("L", true),
    Buchung_Strecke("B", true),
    Abschrift("A", true),
    Aktionsanschrift("C", true),
    Pauschalabschrift("P", true);

    /**
     * A human readable description of the BezugArt type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the BezugArt type can be cached.
     */
    private final boolean cacheable;
    
    private BezugArtType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
