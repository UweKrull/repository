package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link PackageUnitType} describes the order unit types
 * 
 * orderAmountUnit is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the order unit types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link PackageUnitType} describes the package unit 
 * the article will be at sale.
 * </p>
 */
public enum PackageUnitType {

    /**
     * The package unit types of articles.
     */
	GL("Glas", true),
	FL("Flasche", true),
	ST("Stueck", true),
	KG("Kilogramm", true);   

    /**
     * A human readable description of the package unit type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the package unit type can be cached.
     */
    private final boolean cacheable;
    
    private PackageUnitType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
