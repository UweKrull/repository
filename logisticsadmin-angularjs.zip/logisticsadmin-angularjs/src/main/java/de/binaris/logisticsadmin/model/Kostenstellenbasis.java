package de.binaris.logisticsadmin.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;
/**
 * <p>
 * A reusable representation of the kostenstelle base.
 * 
 * kostenstelle base is used in many places in the logistics application, 
 * so to observe the DRY principle, Kostenstellen base is an embeddable
 * entity. An embeddable entity appears as a child in the object model, 
 * but no relationship is established in the RDBMS.
 * Department and Kostenstelle do embed this Embeddable.
 * </p>
 */
@SuppressWarnings("serial")
@Embeddable
public class Kostenstellenbasis implements Serializable {

	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "bilanzstelle")
	private String bs;
    
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "bereich")
	private String ber;
	
	@NotNull
	@Digits(integer = 3, fraction = 0)
	@Size(min = 3, max = 3, message = "must be 000-999 digits")
	@Column(name = "kst")
	private String kst;
	
	@NotNull
	@Min(1)
	@Max(6)
	@Column(name = "pruefziffer")
	private Integer verificationCode;
    
	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	@Column(name = "bezeichnung")
	private String description;
    
	@NotNull
	@Column(name = "umsatz_von")
	@Past
	@Temporal(TemporalType.DATE)
	private Date umsatzVon;
    
	@NotNull
	@Column(name = "umsatz_bis")
	@Temporal(TemporalType.DATE)
	private Date umsatzBis;
    
	@NotNull
	@Column(name = "buchen_von")
	@Past
	@Temporal(TemporalType.DATE)
	private Date buchenVon;
	
	@NotNull
	@Column(name = "buchen_bis")
	@Temporal(TemporalType.DATE)
	private Date buchenBis;
	
	@NotNull
	@Digits(integer = 8, fraction = 0)
	@Size(min = 8, max = 8, message = "must be 00000000-99999999 digits")
	@Column(name = "kst8")
	private String kst8;
	
	public String getBs() {
		return bs;
	}

	public void setBs(String bs) {
		this.bs = bs;
	}

	public String getBer() {
		return ber;
	}

	public void setBer(String ber) {
		this.ber = ber;
	}

	public String getKst() {
		return kst;
	}

	public void setKst(String kst) {
		this.kst = kst;
	}

	public Integer getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(Integer verificationCode) {
		this.verificationCode = verificationCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getUmsatzVon() {
		return umsatzVon;
	}

	public void setUmsatzVon(Date umsatzVon) {
		this.umsatzVon = umsatzVon;
	}

	public Date getUmsatzBis() {
		return umsatzBis;
	}

	public void setUmsatzBis(Date umsatzBis) {
		this.umsatzBis = umsatzBis;
	}

	public Date getBuchenVon() {
		return buchenVon;
	}

	public void setBuchenVon(Date buchenVon) {
		this.buchenVon = buchenVon;
	}

	public Date getBuchenBis() {
		return buchenBis;
	}

	public void setBuchenBis(Date buchenBis) {
		this.buchenBis = buchenBis;
	}

	public String getKst8() {
		return kst8;
	}

	public void setKst8(String kst8) {
		this.kst8 = kst8;
	}
	
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        Kostenstellenbasis kostenstellenbasis = (Kostenstellenbasis) o;

        if (bs != null ? !bs.equals(kostenstellenbasis.bs) : kostenstellenbasis.bs != null)
            return false;
        if (ber != null ? !ber.equals(kostenstellenbasis.ber) : kostenstellenbasis.ber != null)
            return false;
        if (kst != null ? !kst.equals(kostenstellenbasis.kst) : kostenstellenbasis.kst != null)
        	return false;
        if (kst8 != null ? !kst8.equals(kostenstellenbasis.kst8) : kostenstellenbasis.kst8 != null)
        	return false;
        if (verificationCode != null ? !verificationCode.equals(kostenstellenbasis.verificationCode) : kostenstellenbasis.verificationCode != null)
        	return false;
        if (description != null ? !description.equals(kostenstellenbasis.description) : kostenstellenbasis.description != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = bs != null ? bs.hashCode() : 0;
        result = 31 * result + (ber != null ? ber.hashCode() : 0);
        result = 31 * result + (kst != null ? kst.hashCode() : 0);
        result = 31 * result + (kst8 != null ? kst8.hashCode() : 0);
        result = 31 * result + (verificationCode != null ? verificationCode.hashCode() : 0);
        result = 31 * result + (description != null ? description.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(bs);
       	sb.append("_").append(ber);
        sb.append("_").append(kst);
        sb.append("_").append(kst8);
//      sb.append(", ").append(verificationCode);
//      sb.append(", ").append(description);
        return sb.toString();
    }
}
