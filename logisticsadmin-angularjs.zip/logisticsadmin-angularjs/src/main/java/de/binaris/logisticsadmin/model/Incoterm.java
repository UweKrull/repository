package de.binaris.logisticsadmin.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Cacheable
@Entity
@Table(name = "incoterm")
public class Incoterm implements Serializable {

	private static final long serialVersionUID = 332992251569761721L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_incoterm")
	@SequenceGenerator(name = "my_entity_seq_gen_incoterm", sequenceName = "sequence_incoterm", allocationSize = 1)
	private Long id;

	@NotNull
	@NotEmpty
	@Column(name = "iterm")
	private String iterm;

	@NotNull
	@NotEmpty
	@Column(name = "kurz_text")
	private String shortDescription;
	
	@NotNull
	@NotEmpty
	@Column(name = "beschreibung")
	private String description;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIterm() {
		return iterm;
	}

	public void setIterm(String iterm) {
		this.iterm = iterm;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Incoterm)) {
			return false;
		}
		Incoterm castOther = (Incoterm) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(iterm);
		sb.append(", ");
		sb.append(shortDescription);
		sb.append(", ");
		sb.append(description);
		return sb.toString();
	}
}
