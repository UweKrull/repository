package de.binaris.logisticsadmin.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
/**
 * <p>
 * A reusable representation of the Gebiet-Bezirk-Berater.
 * 
 * GebietBezirkBerater can be used in many places in the logistics application, 
 * so to observe the DRY principle, GebietBezirkBerater is an embeddable
 * entity. An embeddable entity appears as a child in the object model, 
 * but no relationship is established in the RDBMS.
 * </p>
 */
@SuppressWarnings("serial")
@Embeddable
public class GebietBezirkBerater implements Serializable {

	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "gebiet")
	private String gebiet;

	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "bezirk")
	private String bezirk;
	
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "fach_gebiet")
	private String fachGebiet;
	
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "fach_berater")
	private String fachBerater;
	
	public String getGebiet() {
		return gebiet;
	}

	public void setGebiet(String gebiet) {
		this.gebiet = gebiet;
	}

	public String getBezirk() {
		return bezirk;
	}

	public void setBezirk(String bezirk) {
		this.bezirk = bezirk;
	}

	public String getFachGebiet() {
		return fachGebiet;
	}

	public void setFachGebiet(String fachGebiet) {
		this.fachGebiet = fachGebiet;
	}

	public String getFachBerater() {
		return fachBerater;
	}

	public void setFachBerater(String fachBerater) {
		this.fachBerater = fachBerater;
	}
	
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        GebietBezirkBerater gebietBezirkBerater = (GebietBezirkBerater) o;

        if (gebiet != null ? !gebiet.equals(gebietBezirkBerater.gebiet) : gebietBezirkBerater.gebiet != null)
            return false;
        if (bezirk != null ? !bezirk.equals(gebietBezirkBerater.bezirk) : gebietBezirkBerater.bezirk != null)
            return false;
        if (fachGebiet != null ? !fachGebiet.equals(gebietBezirkBerater.fachGebiet) : gebietBezirkBerater.fachGebiet != null)
        	return false;
        if (fachBerater != null ? !fachBerater.equals(gebietBezirkBerater.fachBerater) : gebietBezirkBerater.fachBerater != null)
        	return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = gebiet != null ? gebiet.hashCode() : 0;
        result = 31 * result + (bezirk != null ? bezirk.hashCode() : 0);
        result = 31 * result + (fachGebiet != null ? fachGebiet.hashCode() : 0);
        result = 31 * result + (fachBerater != null ? fachBerater.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("GebietBezirkBerater: ");
        sb.append(gebiet).append('\'');
       	sb.append(", ").append(bezirk).append('\'');
        sb.append(", ").append(fachGebiet).append('\'');
        sb.append(" ").append(fachBerater).append('\'');
        return sb.toString();
    }
}
