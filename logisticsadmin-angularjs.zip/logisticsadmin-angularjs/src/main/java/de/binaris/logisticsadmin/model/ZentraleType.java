package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link ZentraleType} describes the kst types (000, 050, 051, 052)
 * 
 * Zentrale type is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the Zentrale types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link ZentraleType} describes which kind of Zentrale 
 * Kostenstelle this is: 000, 050, 051, 052.
 * </p>
 */
public enum ZentraleType {

    /**
     * The types of Zenrale kostenstelle.
     */
	_000("000", true),
	_050("050", true),
    _051("051", true),
	_052("052", true);

    /**
     * A human readable description of the Zenrale kst type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the Zenrale kst type can be cached.
     */
    private final boolean cacheable;
    
    private ZentraleType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
