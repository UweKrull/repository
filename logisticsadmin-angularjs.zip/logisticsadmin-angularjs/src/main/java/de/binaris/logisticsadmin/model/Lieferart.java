package de.binaris.logisticsadmin.model;

import static javax.persistence.EnumType.STRING;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "lieferart")
public class Lieferart implements Serializable {

	private static final long serialVersionUID = 7925219653227131317L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_lieferart")
	@SequenceGenerator(name = "my_entity_seq_gen_lieferart", sequenceName = "sequence_lieferart", allocationSize = 1)
	private Long id;

	@ManyToOne
	private Lager lager;
	
    @Column(name = "partie_app")
    @Enumerated(STRING)
    private PartieAppType partieApp;

    @Column(name = "status")
    @Enumerated(STRING)
    private StatusActivType status;
    
    @Column(name = "delivery")
    @Enumerated(STRING)
    private DeliveryType delivery;
    
    @Column(name = "artikel_oder_betrag")
    @Enumerated(STRING)
    private ArticleBetragType articleOrBetrag;
    
    @Column(name = "mengen_key")
    @Enumerated(STRING)
    private AmountKeyType amountKey;
    
    @Column(name = "rechnung_oder_gutschrift")
    @Enumerated(STRING)
    private RechnungGutschriftType rechnungOrGutschrift;
    
    @Column(name = "rueckstellung_regel")
    @Enumerated(STRING)
    private RueckstellungRegelType rueckstellungRegel;
    
    @Column(name = "typ")
    @Enumerated(STRING)
    private LieferartType lieferartType;
    
    @Column(name = "bezug_art")
    @Enumerated(STRING)
    private BezugArtType bezugart;
    
	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	@Column(name = "beschreibung")
	private String description;

	@NotNull
	@Min(0)
	@Max(999)
	@Column(name = "buchungssatz")
	private Integer buchungssatz;

	@NotNull
	@Column(name = "gueltig_von")
	@Past
	@Temporal(TemporalType.DATE)
	private Date gueltigVon;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Lager getLager() {
		return lager;
	}

	public void setLager(Lager lager) {
		this.lager = lager;
	}

	public PartieAppType getPartieApp() {
		return partieApp;
	}

	public void setPartieApp(PartieAppType partieApp) {
		this.partieApp = partieApp;
	}

	public StatusActivType getStatus() {
		return status;
	}

	public void setStatus(StatusActivType status) {
		this.status = status;
	}

	public DeliveryType getDelivery() {
		return delivery;
	}

	public void setDelivery(DeliveryType delivery) {
		this.delivery = delivery;
	}

	public ArticleBetragType getArticleOrBetrag() {
		return articleOrBetrag;
	}

	public void setArticleOrBetrag(ArticleBetragType articleOrBetrag) {
		this.articleOrBetrag = articleOrBetrag;
	}

	public AmountKeyType getAmountKey() {
		return amountKey;
	}

	public void setAmountKey(AmountKeyType amountKey) {
		this.amountKey = amountKey;
	}

	public RechnungGutschriftType getRechnungOrGutschrift() {
		return rechnungOrGutschrift;
	}

	public void setRechnungOrGutschrift(RechnungGutschriftType rechnungOrGutschrift) {
		this.rechnungOrGutschrift = rechnungOrGutschrift;
	}

	public RueckstellungRegelType getRueckstellungRegel() {
		return rueckstellungRegel;
	}

	public void setRueckstellungRegel(RueckstellungRegelType rueckstellungRegel) {
		this.rueckstellungRegel = rueckstellungRegel;
	}

	public LieferartType getLieferartType() {
		return lieferartType;
	}

	public void setLieferartType(LieferartType lieferartType) {
		this.lieferartType = lieferartType;
	}

	public BezugArtType getBezugart() {
		return bezugart;
	}

	public void setBezugart(BezugArtType bezugart) {
		this.bezugart = bezugart;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getBuchungssatz() {
		return buchungssatz;
	}

	public void setBuchungssatz(Integer buchungssatz) {
		this.buchungssatz = buchungssatz;
	}

	public Date getGueltigVon() {
		return gueltigVon;
	}

	public void setGueltigVon(Date gueltigVon) {
		this.gueltigVon = gueltigVon;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Lieferart)) {
			return false;
		}
		Lieferart castOther = (Lieferart) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(description.substring(0,10));
		sb.append("...");
		sb.append(", ");
		sb.append(lager.toString());
		sb.append(", ");
		sb.append(buchungssatz.toString());
		return sb.toString();
	}
}
