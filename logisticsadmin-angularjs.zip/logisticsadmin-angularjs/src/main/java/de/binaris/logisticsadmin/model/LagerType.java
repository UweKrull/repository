package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link LagerType} describes the Lager types.
 * 
 * Lager type is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the Lager types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link LagerType} describes which kind of Lager (B,F,K,O,Z)
 * </p>
 */
public enum LagerType {

    /**
     * The types of Lager.
     */
    Baecker("B", true),
    Food("F", true),
    Kolonialwaren("K", true),
    Obst_und_Gemuese("O", true),
    Zentrallager("Z", true);

    /**
     * A human readable description of the lager type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the lager type can be cached.
     */
    private final boolean cacheable;
    
    private LagerType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
