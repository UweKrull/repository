package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link LieferartWertArtType} describes the LieferartWertArt types (A, N)
 * 
 * LieferartWertArt types are represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the LieferartWertArt types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link LieferartWertArtType} describes the LieferartWertArt types.
 * </p>
 */
public enum LieferartWertArtType {

    /**
     * The LieferartWertArt types of a Lieferart.
     */
	Artikelzeilen_EK("AZ",true),
	Partie_Einstand("ES",true),
	GH_Kondition("KO",true),
	Lagerabgabe("LA",true),
	Listen_EK("LI",true),
	Ladenverkauf_GH("LV",true),
	Menge("ME",true),
	Netto_Netto_EK("NN",true),
	Partie_Abgabe("PA",true),
	Rechnungs_Pruefung_EK("RP",true),
	Verkauf_EH("VK",true),
	Weitergabe_GH("WG",true),
	Weitergabe_Info_GH("WI",true),
	Weitergabe_Netto_GH("WN",true);   

    /**
     * A human readable description of the LieferartWertArt type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the LieferartWertArt type can be cached.
     */
    private final boolean cacheable;
    
    private LieferartWertArtType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}