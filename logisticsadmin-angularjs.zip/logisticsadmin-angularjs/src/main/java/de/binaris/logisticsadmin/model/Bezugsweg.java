package de.binaris.logisticsadmin.model;

import static javax.persistence.EnumType.STRING;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "bezugsweg")
public class Bezugsweg implements Serializable {

	private static final long serialVersionUID = 6295212132257132312L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_bezugsweg")
	@SequenceGenerator(name = "my_entity_seq_gen_bezugsweg", sequenceName = "sequence_bezugsweg", allocationSize = 1)
	private Long id;

	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "bilanzstelle")
	private String bs;
    
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "bereich")
	private String ber;
	
	@NotNull
	@Digits(integer = 3, fraction = 0)
	@Size(min = 3, max = 3, message = "must be 000-999 digits")
	@Column(name = "kst")
	private String kst;
	
	@NotNull
	@Min(0)
	@Max(9)
	@Column(name = "pruefziffer")
	private Integer verificationCode;

	@ManyToOne
	private Department department;
	
	@ManyToOne
	private Lager lager;
	
	@Digits(integer = 1, fraction = 0)
	@Size(min = 1, max = 1, message = "must be 0-9 digits or empty")
	@Column(name = "lieferant_preisschiene")
	private String lieferantPreisschiene;
	
	@NotNull
	@Column(name = "gueltig_von")
	@Past
	@Temporal(TemporalType.DATE)
	private Date gueltigVon;
    
	@NotNull
	@Column(name = "gueltig_bis")
	@Temporal(TemporalType.DATE)
	private Date gueltigBis;
    
    @Column(name = "aktion_kennzeichen")
    @Enumerated(STRING)
    private AktionType aktion;
    
    @Column(name = "ausnahme_kennzeichen")
    @Enumerated(STRING)
    private AusnahmeType ausnahme;
    
	@NotNull
	@Digits(integer = 8, fraction = 0)
	@Size(min = 8, max = 8, message = "must be 00000000-99999999 digits")
	@Column(name = "kst8")
	private String kst8;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBs() {
		return bs;
	}

	public void setBs(String bs) {
		this.bs = bs;
	}

	public String getBer() {
		return ber;
	}

	public void setBer(String ber) {
		this.ber = ber;
	}

	public String getKst() {
		return kst;
	}

	public void setKst(String kst) {
		this.kst = kst;
	}

	public Integer getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(Integer verificationCode) {
		this.verificationCode = verificationCode;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Lager getLager() {
		return lager;
	}

	public void setLager(Lager lager) {
		this.lager = lager;
	}

	public String getLieferantPreisschiene() {
		return lieferantPreisschiene;
	}

	public void setLieferantPreisschiene(String lieferantPreisschiene) {
		this.lieferantPreisschiene = lieferantPreisschiene;
	}

	public Date getGueltigVon() {
		return gueltigVon;
	}

	public void setGueltigVon(Date gueltigVon) {
		this.gueltigVon = gueltigVon;
	}

	public Date getGueltigBis() {
		return gueltigBis;
	}

	public void setGueltigBis(Date gueltigBis) {
		this.gueltigBis = gueltigBis;
	}

	public AktionType getAktion() {
		return aktion;
	}

	public void setAktion(AktionType aktion) {
		this.aktion = aktion;
	}

	public AusnahmeType getAusnahme() {
		return ausnahme;
	}

	public void setAusnahme(AusnahmeType ausnahme) {
		this.ausnahme = ausnahme;
	}

	public String getKst8() {
		return kst8;
	}

	public void setKst8(String kst8) {
		this.kst8 = kst8;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Bezugsweg)) {
			return false;
		}
		Bezugsweg castOther = (Bezugsweg) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(lager);
		sb.append(", ");
		sb.append(aktion);
		sb.append(", ");
        sb.append(bs);
       	sb.append("_").append(ber);
        sb.append("_").append(kst);
        sb.append(", ");
		sb.append(kst8.toString());
		sb.append(", ");
		sb.append(department);
		return sb.toString().replace("Kostenstellenbasis","Abteilung");
	}
}
