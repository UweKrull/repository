package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link PartnerType} describes the (no-)partner types (P, N)
 * 
 * Partner is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the partner types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link PartnerType} describes whether or not 
 * the Kostenstelle belongs to a partner company.
 * </p>
 */
public enum PartnerType {

    /**
     * The (no-)partner types of kostenstelle.
     */
    Partner("P", true),
    No_Partner("N", true);   

    /**
     * A human readable description of the partner type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the partner type can be cached.
     */
    private final boolean cacheable;
    
    private PartnerType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
