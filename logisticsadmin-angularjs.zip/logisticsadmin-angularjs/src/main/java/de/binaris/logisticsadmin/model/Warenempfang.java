package de.binaris.logisticsadmin.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "warenempfang")
public class Warenempfang implements Serializable {

	private static final long serialVersionUID = 1323219713267931010L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_warenempfang")
	@SequenceGenerator(name = "my_entity_seq_gen_warenempfang", sequenceName = "sequence_warenempfang", allocationSize = 1)
	private Long id;
	
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "we_bs")
	private String weBs;
    
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "we_vb")
	private String weVb;
	
	@NotNull
	@Digits(integer = 3, fraction = 0)
	@Size(min = 3, max = 3, message = "must be 000-999 digits")
	@Column(name = "we_kst")
	private String weKst;

	@ManyToOne
	private Lager lager;
	
	@ManyToOne
	private Lieferant lieferant;
	
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "rechnung_steller_bs")
	private String kreditorenBs;

	@Column(name = "gilt_von_verbuchen")
	@Past
	@Temporal(TemporalType.DATE)
	private Date giltVonVerbuchen;
    
	@Column(name = "gilt_bis_verbuchen")
	@Temporal(TemporalType.DATE)
	private Date giltBisVerbuchen;

	@ManyToOne
	private User geandertBisVerbuchenUser;
	
	@Column(name = "geandert_bis_verbuchen_ts")
	@Past
	@Temporal(TemporalType.DATE)
	private Date geandertBisVerbuchenTimestamp;
	
	@Column(name = "gilt_von_beleg")
	@Past
	@Temporal(TemporalType.DATE)
	private Date giltVonBeleg;
	
	@Column(name = "gilt_bis_beleg")
	@Temporal(TemporalType.DATE)
	private Date giltBisBeleg;
	
	@ManyToOne
	private User geandertBisBelegUser;
	
	@Column(name = "geandert_bis_beleg_ts")
	@Past
	@Temporal(TemporalType.DATE)
	private Date geandertBisBelegTimestamp;
	
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "rechnung_empfang_bs")
	private String rechnungEmpfangBs;
    
	@NotNull
	@Digits(integer = 2, fraction = 0)
	@Size(min = 2, max = 2, message = "must be 00-99 digits")
	@Column(name = "rechnung_empfang_vb")
	private String rechnungEmpfangVb;
	
	@NotNull
	@Digits(integer = 3, fraction = 0)
	@Size(min = 3, max = 3, message = "must be 000-999 digits")
	@Column(name = "rechnung_empfang_kst")
	private String rechnungEmpfangKst;
	
	@NotNull
	@Min(0)
	@Max(1)
	@Column(name = "rechnung_empfang_pruefung")
	private Integer verificationCode;
    
	@ManyToOne
	private User rechnungEmpfangGeprueftUser;
	
	@Column(name = "rechnung_empfang_geprueft_ts")
	@Past
	@Temporal(TemporalType.DATE)
	private Date rechnungEmpfangGeprueftTimestamp;
	
	@Column(name = "gilt_bis_empfaenger")
	@Temporal(TemporalType.DATE)
	private Date giltBisEmpfaenger;
	
	@ManyToOne
	private User geandertBisEmpfaengerUser;
	
	@Column(name = "geandert_bis_empfaenger_ts")
	@Past
	@Temporal(TemporalType.DATE)
	private Date geaendertBisEmpfaengerTimestamp;
	
	@NotNull
	@Column(name = "zugangs_ts")
	@Past
	@Temporal(TemporalType.DATE)
	private Date zugangsTimestamp;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getWeBs() {
		return weBs;
	}

	public void setWeBs(String weBs) {
		this.weBs = weBs;
	}

	public String getWeVb() {
		return weVb;
	}

	public void setWeVb(String weVb) {
		this.weVb = weVb;
	}

	public String getWeKst() {
		return weKst;
	}

	public void setWeKst(String weKst) {
		this.weKst = weKst;
	}

	public Lager getLager() {
		return lager;
	}

	public void setLager(Lager lager) {
		this.lager = lager;
	}

	public Lieferant getLieferant() {
		return lieferant;
	}

	public void setLieferant(Lieferant lieferant) {
		this.lieferant = lieferant;
	}

	public String getKreditorenBs() {
		return kreditorenBs;
	}

	public void setKreditorenBs(String kreditorenBs) {
		this.kreditorenBs = kreditorenBs;
	}

	public Date getGiltVonVerbuchen() {
		return giltVonVerbuchen;
	}

	public void setGiltVonVerbuchen(Date giltVonVerbuchen) {
		this.giltVonVerbuchen = giltVonVerbuchen;
	}

	public Date getGiltBisVerbuchen() {
		return giltBisVerbuchen;
	}

	public void setGiltBisVerbuchen(Date giltBisVerbuchen) {
		this.giltBisVerbuchen = giltBisVerbuchen;
	}

	public User getGeandertBisVerbuchenUser() {
		return geandertBisVerbuchenUser;
	}

	public void setGeandertBisVerbuchenUser(User geandertBisVerbuchenUser) {
		this.geandertBisVerbuchenUser = geandertBisVerbuchenUser;
	}

	public Date getGeandertBisVerbuchenTimestamp() {
		return geandertBisVerbuchenTimestamp;
	}

	public void setGeandertBisVerbuchenTimestamp(Date geandertBisVerbuchenTimestamp) {
		this.geandertBisVerbuchenTimestamp = geandertBisVerbuchenTimestamp;
	}

	public Date getGiltVonBeleg() {
		return giltVonBeleg;
	}

	public void setGiltVonBeleg(Date giltVonBeleg) {
		this.giltVonBeleg = giltVonBeleg;
	}

	public Date getGiltBisBeleg() {
		return giltBisBeleg;
	}

	public void setGiltBisBeleg(Date giltBisBeleg) {
		this.giltBisBeleg = giltBisBeleg;
	}

	public User getGeandertBisBelegUser() {
		return geandertBisBelegUser;
	}

	public void setGeandertBisBelegUser(User geandertBisBelegUser) {
		this.geandertBisBelegUser = geandertBisBelegUser;
	}

	public Date getGeandertBisBelegTimestamp() {
		return geandertBisBelegTimestamp;
	}

	public void setGeandertBisBelegTimestamp(Date geandertBisBelegTimestamp) {
		this.geandertBisBelegTimestamp = geandertBisBelegTimestamp;
	}

	public String getRechnungEmpfangBs() {
		return rechnungEmpfangBs;
	}

	public void setRechnungEmpfangBs(String rechnungEmpfangBs) {
		this.rechnungEmpfangBs = rechnungEmpfangBs;
	}

	public String getRechnungEmpfangVb() {
		return rechnungEmpfangVb;
	}

	public void setRechnungEmpfangVb(String rechnungEmpfangVb) {
		this.rechnungEmpfangVb = rechnungEmpfangVb;
	}

	public String getRechnungEmpfangKst() {
		return rechnungEmpfangKst;
	}

	public void setRechnungEmpfangKst(String rechnungEmpfangKst) {
		this.rechnungEmpfangKst = rechnungEmpfangKst;
	}

	public Integer getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(Integer verificationCode) {
		this.verificationCode = verificationCode;
	}

	public User getRechnungEmpfangGeprueftUser() {
		return rechnungEmpfangGeprueftUser;
	}

	public void setRechnungEmpfangGeprueftUser(User rechnungEmpfangGeprueftUser) {
		this.rechnungEmpfangGeprueftUser = rechnungEmpfangGeprueftUser;
	}

	public Date getRechnungEmpfangGeprueftTimestamp() {
		return rechnungEmpfangGeprueftTimestamp;
	}

	public void setRechnungEmpfangGeprueftTimestamp(
			Date rechnungEmpfangGeprueftTimestamp) {
		this.rechnungEmpfangGeprueftTimestamp = rechnungEmpfangGeprueftTimestamp;
	}

	public Date getGiltBisEmpfaenger() {
		return giltBisEmpfaenger;
	}

	public void setGiltBisEmpfaenger(Date giltBisEmpfaenger) {
		this.giltBisEmpfaenger = giltBisEmpfaenger;
	}

	public User getGeandertBisEmpfaengerUser() {
		return geandertBisEmpfaengerUser;
	}

	public void setGeandertBisEmpfaengerUser(User geandertBisEmpfaengerUser) {
		this.geandertBisEmpfaengerUser = geandertBisEmpfaengerUser;
	}

	public Date getGeaendertBisEmpfaengerTimestamp() {
		return geaendertBisEmpfaengerTimestamp;
	}

	public void setGeaendertBisEmpfaengerTimestamp(
			Date geaendertBisEmpfaengerTimestamp) {
		this.geaendertBisEmpfaengerTimestamp = geaendertBisEmpfaengerTimestamp;
	}

	public Date getZugangsTimestamp() {
		return zugangsTimestamp;
	}

	public void setZugangsTimestamp(Date zugangsTimestamp) {
		this.zugangsTimestamp = zugangsTimestamp;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Warenempfang)) {
			return false;
		}
		Warenempfang castOther = (Warenempfang) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(weBs);
		sb.append("_");
		sb.append(weVb);
		sb.append("_");
		sb.append(weKst);
		sb.append(", ");
		sb.append(lager);
		sb.append(", ");
		sb.append(lieferant);
		return sb.toString();
	}
}
