package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link RechnungGutschriftType} describes whether it's Rechnung or Gutschrift.
 * 
 * Activ is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the activ types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link RechnungGutschriftType} describes whether it's Rechnung or Gutschrift.
 * </p>
 */
public enum RechnungGutschriftType {

    /**
     * The RechnungOrGutschrift type.
     */
    Rechnung("R", true),
    Gutschrift("G", true),
    Keine(" ", true);   

    /**
     * A human readable description of the RechnungOrGutschrift type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the RechnungOrGutschrift type can be cached.
     */
    private final boolean cacheable;
    
    private RechnungGutschriftType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
