package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link AusnahmeType} describes the Ausnahme types (2, A, N)
 * 
 * Ausnahme is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the Ausnahme types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link AusnahmeType} describes whether or not the Bezugsweg is an exceptional one.
 * </p>
 */
public enum AusnahmeType {

    /**
     * The Ausnahme types of Bezugsweg.
     */
    Ausnahme("A", true),
    Ausnahme2("2", true),
    Keine_Ausnahme("N", true);   

    /**
     * A human readable description of the Ausnahme type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the Ausnahme type can be cached.
     */
    private final boolean cacheable;
    
    private AusnahmeType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
