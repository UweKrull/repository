package de.binaris.logisticsadmin.model;

/**
 * <p>
 * The {@link AmountKeyType} describes the delivery types of the article.
 * 
 * DeliveryType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the AmountKey types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link AmountKeyType} describes the article-related delivery type (unit,..).
 * </p>
 */
public enum AmountKeyType {

    /**
     * The AmountKey type.
     */
	Einheiten("E", true),   
	Stueck_oder_KG("S", true),
	Keine_Menge(" ", true);

    /**
     * A human readable description of the AmountKey type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the department type can be cached.
     */
    private final boolean cacheable;
    
    private AmountKeyType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
