package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Department;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.rest.dto.KostenstellenbasisDTO;
import de.binaris.logisticsadmin.model.DepartmentType;

public class NestedDepartmentDTO implements Serializable
{

   private String deptNo;
   private Long id;
   private KostenstellenbasisDTO kostenstellenbasis;
   private DepartmentType articleRelated;

   public NestedDepartmentDTO()
   {
   }

   public NestedDepartmentDTO(final Department entity)
   {
      if (entity != null)
      {
         this.deptNo = entity.getDeptNo();
         this.id = entity.getId();
         this.kostenstellenbasis = new KostenstellenbasisDTO(
               entity.getKostenstellenbasis());
         this.articleRelated = entity.getArticleRelated();
      }
   }

   public Department fromDTO(Department entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Department();
      }
      if (this.id != null)
      {
         TypedQuery<Department> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT d FROM Department d WHERE d.id = :entityId",
                     Department.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setDeptNo(this.deptNo);
      if (this.kostenstellenbasis != null)
      {
         entity.setKostenstellenbasis(this.kostenstellenbasis.fromDTO(
               entity.getKostenstellenbasis(), em));
      }
      entity.setArticleRelated(this.articleRelated);
      entity = em.merge(entity);
      return entity;
   }

   public String getDeptNo()
   {
      return this.deptNo;
   }

   public void setDeptNo(final String deptNo)
   {
      this.deptNo = deptNo;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public KostenstellenbasisDTO getKostenstellenbasis()
   {
      return this.kostenstellenbasis;
   }

   public void setKostenstellenbasis(
         final KostenstellenbasisDTO kostenstellenbasis)
   {
      this.kostenstellenbasis = kostenstellenbasis;
   }

   public DepartmentType getArticleRelated()
   {
      return this.articleRelated;
   }

   public void setArticleRelated(final DepartmentType articleRelated)
   {
      this.articleRelated = articleRelated;
   }
}