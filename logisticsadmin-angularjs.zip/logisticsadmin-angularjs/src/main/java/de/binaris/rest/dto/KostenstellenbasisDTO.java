package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Kostenstellenbasis;
import javax.persistence.EntityManager;
import java.util.Date;

public class KostenstellenbasisDTO implements Serializable
{

   private Date umsatzVon;
   private String kst8;
   private String description;
   private String kst;
   private Date umsatzBis;
   private String ber;
   private Integer verificationCode;
   private Date buchenBis;
   private Date buchenVon;
   private String bs;

   public KostenstellenbasisDTO()
   {
   }

   public KostenstellenbasisDTO(final Kostenstellenbasis entity)
   {
      if (entity != null)
      {
         this.umsatzVon = entity.getUmsatzVon();
         this.kst8 = entity.getKst8();
         this.description = entity.getDescription();
         this.kst = entity.getKst();
         this.umsatzBis = entity.getUmsatzBis();
         this.ber = entity.getBer();
         this.verificationCode = entity.getVerificationCode();
         this.buchenBis = entity.getBuchenBis();
         this.buchenVon = entity.getBuchenVon();
         this.bs = entity.getBs();
      }
   }

   public Kostenstellenbasis fromDTO(Kostenstellenbasis entity,
         EntityManager em)
   {
      if (entity == null)
      {
         entity = new Kostenstellenbasis();
      }
      entity.setUmsatzVon(this.umsatzVon);
      entity.setKst8(this.kst8);
      entity.setDescription(this.description);
      entity.setKst(this.kst);
      entity.setUmsatzBis(this.umsatzBis);
      entity.setBer(this.ber);
      entity.setVerificationCode(this.verificationCode);
      entity.setBuchenBis(this.buchenBis);
      entity.setBuchenVon(this.buchenVon);
      entity.setBs(this.bs);
      return entity;
   }

   public Date getUmsatzVon()
   {
      return this.umsatzVon;
   }

   public void setUmsatzVon(final Date umsatzVon)
   {
      this.umsatzVon = umsatzVon;
   }

   public String getKst8()
   {
      return this.kst8;
   }

   public void setKst8(final String kst8)
   {
      this.kst8 = kst8;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getKst()
   {
      return this.kst;
   }

   public void setKst(final String kst)
   {
      this.kst = kst;
   }

   public Date getUmsatzBis()
   {
      return this.umsatzBis;
   }

   public void setUmsatzBis(final Date umsatzBis)
   {
      this.umsatzBis = umsatzBis;
   }

   public String getBer()
   {
      return this.ber;
   }

   public void setBer(final String ber)
   {
      this.ber = ber;
   }

   public Integer getVerificationCode()
   {
      return this.verificationCode;
   }

   public void setVerificationCode(final Integer verificationCode)
   {
      this.verificationCode = verificationCode;
   }

   public Date getBuchenBis()
   {
      return this.buchenBis;
   }

   public void setBuchenBis(final Date buchenBis)
   {
      this.buchenBis = buchenBis;
   }

   public Date getBuchenVon()
   {
      return this.buchenVon;
   }

   public void setBuchenVon(final Date buchenVon)
   {
      this.buchenVon = buchenVon;
   }

   public String getBs()
   {
      return this.bs;
   }

   public void setBs(final String bs)
   {
      this.bs = bs;
   }
}