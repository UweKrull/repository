package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Article;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.logisticsadmin.model.OrderAmountUnitType;
import de.binaris.logisticsadmin.model.ActivType;

public class NestedArticleDTO implements Serializable
{

   private String ean;
   private Long id;
   private OrderAmountUnitType orderAmountUnit;
   private String originalArticleNo;
   private String description;
   private ActivType activ;
   private Integer eanType;
   private String currentArticleNo;

   public NestedArticleDTO()
   {
   }

   public NestedArticleDTO(final Article entity)
   {
      if (entity != null)
      {
         this.ean = entity.getEan();
         this.id = entity.getId();
         this.orderAmountUnit = entity.getOrderAmountUnit();
         this.originalArticleNo = entity.getOriginalArticleNo();
         this.description = entity.getDescription();
         this.activ = entity.getActiv();
         this.eanType = entity.getEanType();
         this.currentArticleNo = entity.getCurrentArticleNo();
      }
   }

   public Article fromDTO(Article entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Article();
      }
      if (this.id != null)
      {
         TypedQuery<Article> findByIdQuery = em.createQuery(
               "SELECT DISTINCT a FROM Article a WHERE a.id = :entityId",
               Article.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setEan(this.ean);
      entity.setOrderAmountUnit(this.orderAmountUnit);
      entity.setOriginalArticleNo(this.originalArticleNo);
      entity.setDescription(this.description);
      entity.setActiv(this.activ);
      entity.setEanType(this.eanType);
      entity.setCurrentArticleNo(this.currentArticleNo);
      entity = em.merge(entity);
      return entity;
   }

   public String getEan()
   {
      return this.ean;
   }

   public void setEan(final String ean)
   {
      this.ean = ean;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public OrderAmountUnitType getOrderAmountUnit()
   {
      return this.orderAmountUnit;
   }

   public void setOrderAmountUnit(final OrderAmountUnitType orderAmountUnit)
   {
      this.orderAmountUnit = orderAmountUnit;
   }

   public String getOriginalArticleNo()
   {
      return this.originalArticleNo;
   }

   public void setOriginalArticleNo(final String originalArticleNo)
   {
      this.originalArticleNo = originalArticleNo;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public ActivType getActiv()
   {
      return this.activ;
   }

   public void setActiv(final ActivType activ)
   {
      this.activ = activ;
   }

   public Integer getEanType()
   {
      return this.eanType;
   }

   public void setEanType(final Integer eanType)
   {
      this.eanType = eanType;
   }

   public String getCurrentArticleNo()
   {
      return this.currentArticleNo;
   }

   public void setCurrentArticleNo(final String currentArticleNo)
   {
      this.currentArticleNo = currentArticleNo;
   }
}