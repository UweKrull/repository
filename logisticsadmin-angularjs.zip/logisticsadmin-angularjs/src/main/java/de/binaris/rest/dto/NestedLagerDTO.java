package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Lager;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.rest.dto.AddressDTO;
import de.binaris.logisticsadmin.model.LagerType;

public class NestedLagerDTO implements Serializable
{

   private Long id;
   private String kst8;
   private AddressDTO address;
   private String description;
   private String lagerNo;
   private LagerType type;

   public NestedLagerDTO()
   {
   }

   public NestedLagerDTO(final Lager entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.kst8 = entity.getKst8();
         this.address = new AddressDTO(entity.getAddress());
         this.description = entity.getDescription();
         this.lagerNo = entity.getLagerNo();
         this.type = entity.getType();
      }
   }

   public Lager fromDTO(Lager entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Lager();
      }
      if (this.id != null)
      {
         TypedQuery<Lager> findByIdQuery = em.createQuery(
               "SELECT DISTINCT l FROM Lager l WHERE l.id = :entityId",
               Lager.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setKst8(this.kst8);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setDescription(this.description);
      entity.setLagerNo(this.lagerNo);
      entity.setType(this.type);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getKst8()
   {
      return this.kst8;
   }

   public void setKst8(final String kst8)
   {
      this.kst8 = kst8;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getLagerNo()
   {
      return this.lagerNo;
   }

   public void setLagerNo(final String lagerNo)
   {
      this.lagerNo = lagerNo;
   }

   public LagerType getType()
   {
      return this.type;
   }

   public void setType(final LagerType type)
   {
      this.type = type;
   }
}