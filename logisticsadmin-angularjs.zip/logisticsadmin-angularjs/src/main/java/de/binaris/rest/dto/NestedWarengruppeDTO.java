package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Warengruppe;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedWarengruppeDTO implements Serializable
{

   private Long id;
   private String description;
   private String wgru;
   private Integer type;

   public NestedWarengruppeDTO()
   {
   }

   public NestedWarengruppeDTO(final Warengruppe entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.wgru = entity.getWgru();
         this.type = entity.getType();
      }
   }

   public Warengruppe fromDTO(Warengruppe entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Warengruppe();
      }
      if (this.id != null)
      {
         TypedQuery<Warengruppe> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT w FROM Warengruppe w WHERE w.id = :entityId",
                     Warengruppe.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setDescription(this.description);
      entity.setWgru(this.wgru);
      entity.setType(this.type);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getWgru()
   {
      return this.wgru;
   }

   public void setWgru(final String wgru)
   {
      this.wgru = wgru;
   }

   public Integer getType()
   {
      return this.type;
   }

   public void setType(final Integer type)
   {
      this.type = type;
   }
}