package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Warenempfang;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedLieferantDTO;
import de.binaris.rest.dto.NestedLagerDTO;
import de.binaris.rest.dto.NestedUserDTO;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class WarenempfangDTO implements Serializable
{

   private NestedLieferantDTO lieferant;
   private String rechnungEmpfangKst;
   private NestedLagerDTO lager;
   private NestedUserDTO rechnungEmpfangGeprueftUser;
   private String kreditorenBs;
   private String weVb;
   private Long id;
   private Integer verificationCode;
   private NestedUserDTO geandertBisVerbuchenUser;
   private Date giltBisEmpfaenger;
   private Date rechnungEmpfangGeprueftTimestamp;
   private String rechnungEmpfangBs;
   private Date giltVonVerbuchen;
   private Date zugangsTimestamp;
   private Date giltVonBeleg;
   private NestedUserDTO geandertBisBelegUser;
   private String rechnungEmpfangVb;
   private Date giltBisBeleg;
   private NestedUserDTO geandertBisEmpfaengerUser;
   private Date geandertBisBelegTimestamp;
   private String weBs;
   private String weKst;
   private Date geaendertBisEmpfaengerTimestamp;
   private Date giltBisVerbuchen;
   private Date geandertBisVerbuchenTimestamp;

   public WarenempfangDTO()
   {
   }

   public WarenempfangDTO(final Warenempfang entity)
   {
      if (entity != null)
      {
         this.lieferant = new NestedLieferantDTO(entity.getLieferant());
         this.rechnungEmpfangKst = entity.getRechnungEmpfangKst();
         this.lager = new NestedLagerDTO(entity.getLager());
         this.rechnungEmpfangGeprueftUser = new NestedUserDTO(
               entity.getRechnungEmpfangGeprueftUser());
         this.kreditorenBs = entity.getKreditorenBs();
         this.weVb = entity.getWeVb();
         this.id = entity.getId();
         this.verificationCode = entity.getVerificationCode();
         this.geandertBisVerbuchenUser = new NestedUserDTO(
               entity.getGeandertBisVerbuchenUser());
         this.giltBisEmpfaenger = entity.getGiltBisEmpfaenger();
         this.rechnungEmpfangGeprueftTimestamp = entity
               .getRechnungEmpfangGeprueftTimestamp();
         this.rechnungEmpfangBs = entity.getRechnungEmpfangBs();
         this.giltVonVerbuchen = entity.getGiltVonVerbuchen();
         this.zugangsTimestamp = entity.getZugangsTimestamp();
         this.giltVonBeleg = entity.getGiltVonBeleg();
         this.geandertBisBelegUser = new NestedUserDTO(
               entity.getGeandertBisBelegUser());
         this.rechnungEmpfangVb = entity.getRechnungEmpfangVb();
         this.giltBisBeleg = entity.getGiltBisBeleg();
         this.geandertBisEmpfaengerUser = new NestedUserDTO(
               entity.getGeandertBisEmpfaengerUser());
         this.geandertBisBelegTimestamp = entity
               .getGeandertBisBelegTimestamp();
         this.weBs = entity.getWeBs();
         this.weKst = entity.getWeKst();
         this.geaendertBisEmpfaengerTimestamp = entity
               .getGeaendertBisEmpfaengerTimestamp();
         this.giltBisVerbuchen = entity.getGiltBisVerbuchen();
         this.geandertBisVerbuchenTimestamp = entity
               .getGeandertBisVerbuchenTimestamp();
      }
   }

   public Warenempfang fromDTO(Warenempfang entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Warenempfang();
      }
      if (this.lieferant != null)
      {
         entity.setLieferant(this.lieferant.fromDTO(entity.getLieferant(),
               em));
      }
      entity.setRechnungEmpfangKst(this.rechnungEmpfangKst);
      if (this.lager != null)
      {
         entity.setLager(this.lager.fromDTO(entity.getLager(), em));
      }
      if (this.rechnungEmpfangGeprueftUser != null)
      {
         entity.setRechnungEmpfangGeprueftUser(this.rechnungEmpfangGeprueftUser
               .fromDTO(entity.getRechnungEmpfangGeprueftUser(), em));
      }
      entity.setKreditorenBs(this.kreditorenBs);
      entity.setWeVb(this.weVb);
      entity.setVerificationCode(this.verificationCode);
      if (this.geandertBisVerbuchenUser != null)
      {
         entity.setGeandertBisVerbuchenUser(this.geandertBisVerbuchenUser
               .fromDTO(entity.getGeandertBisVerbuchenUser(), em));
      }
      entity.setGiltBisEmpfaenger(this.giltBisEmpfaenger);
      entity.setRechnungEmpfangGeprueftTimestamp(this.rechnungEmpfangGeprueftTimestamp);
      entity.setRechnungEmpfangBs(this.rechnungEmpfangBs);
      entity.setGiltVonVerbuchen(this.giltVonVerbuchen);
      entity.setZugangsTimestamp(this.zugangsTimestamp);
      entity.setGiltVonBeleg(this.giltVonBeleg);
      if (this.geandertBisBelegUser != null)
      {
         entity.setGeandertBisBelegUser(this.geandertBisBelegUser.fromDTO(
               entity.getGeandertBisBelegUser(), em));
      }
      entity.setRechnungEmpfangVb(this.rechnungEmpfangVb);
      entity.setGiltBisBeleg(this.giltBisBeleg);
      if (this.geandertBisEmpfaengerUser != null)
      {
         entity.setGeandertBisEmpfaengerUser(this.geandertBisEmpfaengerUser
               .fromDTO(entity.getGeandertBisEmpfaengerUser(), em));
      }
      entity.setGeandertBisBelegTimestamp(this.geandertBisBelegTimestamp);
      entity.setWeBs(this.weBs);
      entity.setWeKst(this.weKst);
      entity.setGeaendertBisEmpfaengerTimestamp(this.geaendertBisEmpfaengerTimestamp);
      entity.setGiltBisVerbuchen(this.giltBisVerbuchen);
      entity.setGeandertBisVerbuchenTimestamp(this.geandertBisVerbuchenTimestamp);
      entity = em.merge(entity);
      return entity;
   }

   public NestedLieferantDTO getLieferant()
   {
      return this.lieferant;
   }

   public void setLieferant(final NestedLieferantDTO lieferant)
   {
      this.lieferant = lieferant;
   }

   public String getRechnungEmpfangKst()
   {
      return this.rechnungEmpfangKst;
   }

   public void setRechnungEmpfangKst(final String rechnungEmpfangKst)
   {
      this.rechnungEmpfangKst = rechnungEmpfangKst;
   }

   public NestedLagerDTO getLager()
   {
      return this.lager;
   }

   public void setLager(final NestedLagerDTO lager)
   {
      this.lager = lager;
   }

   public NestedUserDTO getRechnungEmpfangGeprueftUser()
   {
      return this.rechnungEmpfangGeprueftUser;
   }

   public void setRechnungEmpfangGeprueftUser(
         final NestedUserDTO rechnungEmpfangGeprueftUser)
   {
      this.rechnungEmpfangGeprueftUser = rechnungEmpfangGeprueftUser;
   }

   public String getKreditorenBs()
   {
      return this.kreditorenBs;
   }

   public void setKreditorenBs(final String kreditorenBs)
   {
      this.kreditorenBs = kreditorenBs;
   }

   public String getWeVb()
   {
      return this.weVb;
   }

   public void setWeVb(final String weVb)
   {
      this.weVb = weVb;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Integer getVerificationCode()
   {
      return this.verificationCode;
   }

   public void setVerificationCode(final Integer verificationCode)
   {
      this.verificationCode = verificationCode;
   }

   public NestedUserDTO getGeandertBisVerbuchenUser()
   {
      return this.geandertBisVerbuchenUser;
   }

   public void setGeandertBisVerbuchenUser(
         final NestedUserDTO geandertBisVerbuchenUser)
   {
      this.geandertBisVerbuchenUser = geandertBisVerbuchenUser;
   }

   public Date getGiltBisEmpfaenger()
   {
      return this.giltBisEmpfaenger;
   }

   public void setGiltBisEmpfaenger(final Date giltBisEmpfaenger)
   {
      this.giltBisEmpfaenger = giltBisEmpfaenger;
   }

   public Date getRechnungEmpfangGeprueftTimestamp()
   {
      return this.rechnungEmpfangGeprueftTimestamp;
   }

   public void setRechnungEmpfangGeprueftTimestamp(
         final Date rechnungEmpfangGeprueftTimestamp)
   {
      this.rechnungEmpfangGeprueftTimestamp = rechnungEmpfangGeprueftTimestamp;
   }

   public String getRechnungEmpfangBs()
   {
      return this.rechnungEmpfangBs;
   }

   public void setRechnungEmpfangBs(final String rechnungEmpfangBs)
   {
      this.rechnungEmpfangBs = rechnungEmpfangBs;
   }

   public Date getGiltVonVerbuchen()
   {
      return this.giltVonVerbuchen;
   }

   public void setGiltVonVerbuchen(final Date giltVonVerbuchen)
   {
      this.giltVonVerbuchen = giltVonVerbuchen;
   }

   public Date getZugangsTimestamp()
   {
      return this.zugangsTimestamp;
   }

   public void setZugangsTimestamp(final Date zugangsTimestamp)
   {
      this.zugangsTimestamp = zugangsTimestamp;
   }

   public Date getGiltVonBeleg()
   {
      return this.giltVonBeleg;
   }

   public void setGiltVonBeleg(final Date giltVonBeleg)
   {
      this.giltVonBeleg = giltVonBeleg;
   }

   public NestedUserDTO getGeandertBisBelegUser()
   {
      return this.geandertBisBelegUser;
   }

   public void setGeandertBisBelegUser(final NestedUserDTO geandertBisBelegUser)
   {
      this.geandertBisBelegUser = geandertBisBelegUser;
   }

   public String getRechnungEmpfangVb()
   {
      return this.rechnungEmpfangVb;
   }

   public void setRechnungEmpfangVb(final String rechnungEmpfangVb)
   {
      this.rechnungEmpfangVb = rechnungEmpfangVb;
   }

   public Date getGiltBisBeleg()
   {
      return this.giltBisBeleg;
   }

   public void setGiltBisBeleg(final Date giltBisBeleg)
   {
      this.giltBisBeleg = giltBisBeleg;
   }

   public NestedUserDTO getGeandertBisEmpfaengerUser()
   {
      return this.geandertBisEmpfaengerUser;
   }

   public void setGeandertBisEmpfaengerUser(
         final NestedUserDTO geandertBisEmpfaengerUser)
   {
      this.geandertBisEmpfaengerUser = geandertBisEmpfaengerUser;
   }

   public Date getGeandertBisBelegTimestamp()
   {
      return this.geandertBisBelegTimestamp;
   }

   public void setGeandertBisBelegTimestamp(
         final Date geandertBisBelegTimestamp)
   {
      this.geandertBisBelegTimestamp = geandertBisBelegTimestamp;
   }

   public String getWeBs()
   {
      return this.weBs;
   }

   public void setWeBs(final String weBs)
   {
      this.weBs = weBs;
   }

   public String getWeKst()
   {
      return this.weKst;
   }

   public void setWeKst(final String weKst)
   {
      this.weKst = weKst;
   }

   public Date getGeaendertBisEmpfaengerTimestamp()
   {
      return this.geaendertBisEmpfaengerTimestamp;
   }

   public void setGeaendertBisEmpfaengerTimestamp(
         final Date geaendertBisEmpfaengerTimestamp)
   {
      this.geaendertBisEmpfaengerTimestamp = geaendertBisEmpfaengerTimestamp;
   }

   public Date getGiltBisVerbuchen()
   {
      return this.giltBisVerbuchen;
   }

   public void setGiltBisVerbuchen(final Date giltBisVerbuchen)
   {
      this.giltBisVerbuchen = giltBisVerbuchen;
   }

   public Date getGeandertBisVerbuchenTimestamp()
   {
      return this.geandertBisVerbuchenTimestamp;
   }

   public void setGeandertBisVerbuchenTimestamp(
         final Date geandertBisVerbuchenTimestamp)
   {
      this.geandertBisVerbuchenTimestamp = geandertBisVerbuchenTimestamp;
   }
}