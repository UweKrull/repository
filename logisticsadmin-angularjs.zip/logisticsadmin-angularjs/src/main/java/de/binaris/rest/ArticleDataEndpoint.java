package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.logisticsadmin.model.ArticleData;
import de.binaris.rest.dto.ArticleDataDTO;

/**
 * 
 */
@Stateless
@Path("/articledatas")
public class ArticleDataEndpoint
{
   @PersistenceContext(unitName = "LogisticsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(ArticleDataDTO dto)
   {
      ArticleData entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(ArticleDataEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      ArticleData entity = em.find(ArticleData.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<ArticleData> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM ArticleData a LEFT JOIN FETCH a.lager LEFT JOIN FETCH a.article WHERE a.id = :entityId ORDER BY a.id", ArticleData.class);
      findByIdQuery.setParameter("entityId", id);
      ArticleData entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      ArticleDataDTO dto = new ArticleDataDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<ArticleDataDTO> listAll()
   {
      final List<ArticleData> searchResults = em.createQuery("SELECT DISTINCT a FROM ArticleData a LEFT JOIN FETCH a.lager LEFT JOIN FETCH a.article ORDER BY a.id", ArticleData.class).getResultList();
      final List<ArticleDataDTO> results = new ArrayList<ArticleDataDTO>();
      for (ArticleData searchResult : searchResults)
      {
         ArticleDataDTO dto = new ArticleDataDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, ArticleDataDTO dto)
   {
      TypedQuery<ArticleData> findByIdQuery = em.createQuery("SELECT DISTINCT a FROM ArticleData a LEFT JOIN FETCH a.lager LEFT JOIN FETCH a.article WHERE a.id = :entityId ORDER BY a.id", ArticleData.class);
      findByIdQuery.setParameter("entityId", id);
      ArticleData entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}