package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.ArticleData;
import javax.persistence.EntityManager;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedArticleDTO;
import de.binaris.logisticsadmin.model.Article;
import java.util.Iterator;
import de.binaris.rest.dto.NestedLagerDTO;
import de.binaris.logisticsadmin.model.PackageUnitType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ArticleDataDTO implements Serializable
{

   private Long id;
   private Float weight;
   private Long height;
   private Set<NestedArticleDTO> article = new HashSet<NestedArticleDTO>();
   private NestedLagerDTO lager;
   private Long width;
   private String minAmounPerPackageUnit;
   private Long length;
   private PackageUnitType packageUnit;

   public ArticleDataDTO()
   {
   }

   public ArticleDataDTO(final ArticleData entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.weight = entity.getWeight();
         this.height = entity.getHeight();
         Iterator<Article> iterArticle = entity.getArticle().iterator();
         for (; iterArticle.hasNext();)
         {
            Article element = iterArticle.next();
            this.article.add(new NestedArticleDTO(element));
         }
         this.lager = new NestedLagerDTO(entity.getLager());
         this.width = entity.getWidth();
         this.minAmounPerPackageUnit = entity.getMinAmounPerPackageUnit();
         this.length = entity.getLength();
         this.packageUnit = entity.getPackageUnit();
      }
   }

   public ArticleData fromDTO(ArticleData entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ArticleData();
      }
      entity.setWeight(this.weight);
      entity.setHeight(this.height);
      Iterator<Article> iterArticle = entity.getArticle().iterator();
      for (; iterArticle.hasNext();)
      {
         boolean found = false;
         Article article = iterArticle.next();
         Iterator<NestedArticleDTO> iterDtoArticle = this.getArticle()
               .iterator();
         for (; iterDtoArticle.hasNext();)
         {
            NestedArticleDTO dtoArticle = iterDtoArticle.next();
            if (dtoArticle.getId().equals(article.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterArticle.remove();
         }
      }
      Iterator<NestedArticleDTO> iterDtoArticle = this.getArticle()
            .iterator();
      for (; iterDtoArticle.hasNext();)
      {
         boolean found = false;
         NestedArticleDTO dtoArticle = iterDtoArticle.next();
         iterArticle = entity.getArticle().iterator();
         for (; iterArticle.hasNext();)
         {
            Article article = iterArticle.next();
            if (dtoArticle.getId().equals(article.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Article> resultIter = em
                  .createQuery("SELECT DISTINCT a FROM Article a",
                        Article.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Article result = resultIter.next();
               if (result.getId().equals(dtoArticle.getId()))
               {
                  entity.getArticle().add(result);
                  break;
               }
            }
         }
      }
      if (this.lager != null)
      {
         entity.setLager(this.lager.fromDTO(entity.getLager(), em));
      }
      entity.setWidth(this.width);
      entity.setMinAmounPerPackageUnit(this.minAmounPerPackageUnit);
      entity.setLength(this.length);
      entity.setPackageUnit(this.packageUnit);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Float getWeight()
   {
      return this.weight;
   }

   public void setWeight(final Float weight)
   {
      this.weight = weight;
   }

   public Long getHeight()
   {
      return this.height;
   }

   public void setHeight(final Long height)
   {
      this.height = height;
   }

   public Set<NestedArticleDTO> getArticle()
   {
      return this.article;
   }

   public void setArticle(final Set<NestedArticleDTO> article)
   {
      this.article = article;
   }

   public NestedLagerDTO getLager()
   {
      return this.lager;
   }

   public void setLager(final NestedLagerDTO lager)
   {
      this.lager = lager;
   }

   public Long getWidth()
   {
      return this.width;
   }

   public void setWidth(final Long width)
   {
      this.width = width;
   }

   public String getMinAmounPerPackageUnit()
   {
      return this.minAmounPerPackageUnit;
   }

   public void setMinAmounPerPackageUnit(final String minAmounPerPackageUnit)
   {
      this.minAmounPerPackageUnit = minAmounPerPackageUnit;
   }

   public Long getLength()
   {
      return this.length;
   }

   public void setLength(final Long length)
   {
      this.length = length;
   }

   public PackageUnitType getPackageUnit()
   {
      return this.packageUnit;
   }

   public void setPackageUnit(final PackageUnitType packageUnit)
   {
      this.packageUnit = packageUnit;
   }
}