package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Lieferant;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.AddressDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LieferantDTO implements Serializable
{

   private Long id;
   private String sapNo;
   private AddressDTO address;
   private String name;
   private String lieferantNo;

   public LieferantDTO()
   {
   }

   public LieferantDTO(final Lieferant entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.sapNo = entity.getSapNo();
         this.address = new AddressDTO(entity.getAddress());
         this.name = entity.getName();
         this.lieferantNo = entity.getLieferantNo();
      }
   }

   public Lieferant fromDTO(Lieferant entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Lieferant();
      }
      entity.setSapNo(this.sapNo);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setName(this.name);
      entity.setLieferantNo(this.lieferantNo);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getSapNo()
   {
      return this.sapNo;
   }

   public void setSapNo(final String sapNo)
   {
      this.sapNo = sapNo;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLieferantNo()
   {
      return this.lieferantNo;
   }

   public void setLieferantNo(final String lieferantNo)
   {
      this.lieferantNo = lieferantNo;
   }
}