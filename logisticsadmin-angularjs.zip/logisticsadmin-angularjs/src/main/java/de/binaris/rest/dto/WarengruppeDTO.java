package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Warengruppe;
import javax.persistence.EntityManager;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedArticleDTO;
import de.binaris.logisticsadmin.model.Article;
import java.util.Iterator;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class WarengruppeDTO implements Serializable
{

   private Long id;
   private Set<NestedArticleDTO> article = new HashSet<NestedArticleDTO>();
   private String description;
   private String wgru;
   private Integer type;

   public WarengruppeDTO()
   {
   }

   public WarengruppeDTO(final Warengruppe entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         Iterator<Article> iterArticle = entity.getArticle().iterator();
         for (; iterArticle.hasNext();)
         {
            Article element = iterArticle.next();
            this.article.add(new NestedArticleDTO(element));
         }
         this.description = entity.getDescription();
         this.wgru = entity.getWgru();
         this.type = entity.getType();
      }
   }

   public Warengruppe fromDTO(Warengruppe entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Warengruppe();
      }
      Iterator<Article> iterArticle = entity.getArticle().iterator();
      for (; iterArticle.hasNext();)
      {
         boolean found = false;
         Article article = iterArticle.next();
         Iterator<NestedArticleDTO> iterDtoArticle = this.getArticle()
               .iterator();
         for (; iterDtoArticle.hasNext();)
         {
            NestedArticleDTO dtoArticle = iterDtoArticle.next();
            if (dtoArticle.getId().equals(article.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterArticle.remove();
         }
      }
      Iterator<NestedArticleDTO> iterDtoArticle = this.getArticle()
            .iterator();
      for (; iterDtoArticle.hasNext();)
      {
         boolean found = false;
         NestedArticleDTO dtoArticle = iterDtoArticle.next();
         iterArticle = entity.getArticle().iterator();
         for (; iterArticle.hasNext();)
         {
            Article article = iterArticle.next();
            if (dtoArticle.getId().equals(article.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Article> resultIter = em
                  .createQuery("SELECT DISTINCT a FROM Article a",
                        Article.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Article result = resultIter.next();
               if (result.getId().equals(dtoArticle.getId()))
               {
                  entity.getArticle().add(result);
                  break;
               }
            }
         }
      }
      entity.setDescription(this.description);
      entity.setWgru(this.wgru);
      entity.setType(this.type);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedArticleDTO> getArticle()
   {
      return this.article;
   }

   public void setArticle(final Set<NestedArticleDTO> article)
   {
      this.article = article;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getWgru()
   {
      return this.wgru;
   }

   public void setWgru(final String wgru)
   {
      this.wgru = wgru;
   }

   public Integer getType()
   {
      return this.type;
   }

   public void setType(final Integer type)
   {
      this.type = type;
   }
}