package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Bezugsweg;
import javax.persistence.EntityManager;
import java.util.Date;
import de.binaris.logisticsadmin.model.AusnahmeType;
import de.binaris.rest.dto.NestedLagerDTO;
import de.binaris.rest.dto.NestedDepartmentDTO;
import de.binaris.logisticsadmin.model.AktionType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BezugswegDTO implements Serializable
{

   private Date gueltigBis;
   private AusnahmeType ausnahme;
   private String kst8;
   private NestedLagerDTO lager;
   private NestedDepartmentDTO department;
   private String ber;
   private String bs;
   private Long id;
   private String kst;
   private Integer verificationCode;
   private AktionType aktion;
   private String lieferantPreisschiene;
   private Date gueltigVon;

   public BezugswegDTO()
   {
   }

   public BezugswegDTO(final Bezugsweg entity)
   {
      if (entity != null)
      {
         this.gueltigBis = entity.getGueltigBis();
         this.ausnahme = entity.getAusnahme();
         this.kst8 = entity.getKst8();
         this.lager = new NestedLagerDTO(entity.getLager());
         this.department = new NestedDepartmentDTO(entity.getDepartment());
         this.ber = entity.getBer();
         this.bs = entity.getBs();
         this.id = entity.getId();
         this.kst = entity.getKst();
         this.verificationCode = entity.getVerificationCode();
         this.aktion = entity.getAktion();
         this.lieferantPreisschiene = entity.getLieferantPreisschiene();
         this.gueltigVon = entity.getGueltigVon();
      }
   }

   public Bezugsweg fromDTO(Bezugsweg entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Bezugsweg();
      }
      entity.setGueltigBis(this.gueltigBis);
      entity.setAusnahme(this.ausnahme);
      entity.setKst8(this.kst8);
      if (this.lager != null)
      {
         entity.setLager(this.lager.fromDTO(entity.getLager(), em));
      }
      if (this.department != null)
      {
         entity.setDepartment(this.department.fromDTO(
               entity.getDepartment(), em));
      }
      entity.setBer(this.ber);
      entity.setBs(this.bs);
      entity.setKst(this.kst);
      entity.setVerificationCode(this.verificationCode);
      entity.setAktion(this.aktion);
      entity.setLieferantPreisschiene(this.lieferantPreisschiene);
      entity.setGueltigVon(this.gueltigVon);
      entity = em.merge(entity);
      return entity;
   }

   public Date getGueltigBis()
   {
      return this.gueltigBis;
   }

   public void setGueltigBis(final Date gueltigBis)
   {
      this.gueltigBis = gueltigBis;
   }

   public AusnahmeType getAusnahme()
   {
      return this.ausnahme;
   }

   public void setAusnahme(final AusnahmeType ausnahme)
   {
      this.ausnahme = ausnahme;
   }

   public String getKst8()
   {
      return this.kst8;
   }

   public void setKst8(final String kst8)
   {
      this.kst8 = kst8;
   }

   public NestedLagerDTO getLager()
   {
      return this.lager;
   }

   public void setLager(final NestedLagerDTO lager)
   {
      this.lager = lager;
   }

   public NestedDepartmentDTO getDepartment()
   {
      return this.department;
   }

   public void setDepartment(final NestedDepartmentDTO department)
   {
      this.department = department;
   }

   public String getBer()
   {
      return this.ber;
   }

   public void setBer(final String ber)
   {
      this.ber = ber;
   }

   public String getBs()
   {
      return this.bs;
   }

   public void setBs(final String bs)
   {
      this.bs = bs;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getKst()
   {
      return this.kst;
   }

   public void setKst(final String kst)
   {
      this.kst = kst;
   }

   public Integer getVerificationCode()
   {
      return this.verificationCode;
   }

   public void setVerificationCode(final Integer verificationCode)
   {
      this.verificationCode = verificationCode;
   }

   public AktionType getAktion()
   {
      return this.aktion;
   }

   public void setAktion(final AktionType aktion)
   {
      this.aktion = aktion;
   }

   public String getLieferantPreisschiene()
   {
      return this.lieferantPreisschiene;
   }

   public void setLieferantPreisschiene(final String lieferantPreisschiene)
   {
      this.lieferantPreisschiene = lieferantPreisschiene;
   }

   public Date getGueltigVon()
   {
      return this.gueltigVon;
   }

   public void setGueltigVon(final Date gueltigVon)
   {
      this.gueltigVon = gueltigVon;
   }
}