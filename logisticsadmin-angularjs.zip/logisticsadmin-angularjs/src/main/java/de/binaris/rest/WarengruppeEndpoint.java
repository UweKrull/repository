package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.logisticsadmin.model.Warengruppe;
import de.binaris.rest.dto.WarengruppeDTO;

/**
 * 
 */
@Stateless
@Path("/warengruppes")
public class WarengruppeEndpoint
{
   @PersistenceContext(unitName = "LogisticsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(WarengruppeDTO dto)
   {
      Warengruppe entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(WarengruppeEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Warengruppe entity = em.find(Warengruppe.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Warengruppe> findByIdQuery = em.createQuery("SELECT DISTINCT w FROM Warengruppe w LEFT JOIN FETCH w.article WHERE w.id = :entityId ORDER BY w.id", Warengruppe.class);
      findByIdQuery.setParameter("entityId", id);
      Warengruppe entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      WarengruppeDTO dto = new WarengruppeDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<WarengruppeDTO> listAll()
   {
      final List<Warengruppe> searchResults = em.createQuery("SELECT DISTINCT w FROM Warengruppe w LEFT JOIN FETCH w.article ORDER BY w.id", Warengruppe.class).getResultList();
      final List<WarengruppeDTO> results = new ArrayList<WarengruppeDTO>();
      for (Warengruppe searchResult : searchResults)
      {
         WarengruppeDTO dto = new WarengruppeDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, WarengruppeDTO dto)
   {
      TypedQuery<Warengruppe> findByIdQuery = em.createQuery("SELECT DISTINCT w FROM Warengruppe w LEFT JOIN FETCH w.article WHERE w.id = :entityId ORDER BY w.id", Warengruppe.class);
      findByIdQuery.setParameter("entityId", id);
      Warengruppe entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}