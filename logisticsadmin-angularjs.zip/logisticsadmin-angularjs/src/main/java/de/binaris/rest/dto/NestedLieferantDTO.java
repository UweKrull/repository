package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Lieferant;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.rest.dto.AddressDTO;

public class NestedLieferantDTO implements Serializable
{

   private Long id;
   private String sapNo;
   private AddressDTO address;
   private String name;
   private String lieferantNo;

   public NestedLieferantDTO()
   {
   }

   public NestedLieferantDTO(final Lieferant entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.sapNo = entity.getSapNo();
         this.address = new AddressDTO(entity.getAddress());
         this.name = entity.getName();
         this.lieferantNo = entity.getLieferantNo();
      }
   }

   public Lieferant fromDTO(Lieferant entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Lieferant();
      }
      if (this.id != null)
      {
         TypedQuery<Lieferant> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT l FROM Lieferant l WHERE l.id = :entityId",
                     Lieferant.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setSapNo(this.sapNo);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setName(this.name);
      entity.setLieferantNo(this.lieferantNo);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getSapNo()
   {
      return this.sapNo;
   }

   public void setSapNo(final String sapNo)
   {
      this.sapNo = sapNo;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLieferantNo()
   {
      return this.lieferantNo;
   }

   public void setLieferantNo(final String lieferantNo)
   {
      this.lieferantNo = lieferantNo;
   }
}