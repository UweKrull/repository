package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Lieferart;
import javax.persistence.EntityManager;
import de.binaris.logisticsadmin.model.PartieAppType;
import de.binaris.logisticsadmin.model.LieferartType;
import de.binaris.rest.dto.NestedLagerDTO;
import de.binaris.logisticsadmin.model.StatusActivType;
import de.binaris.logisticsadmin.model.ArticleBetragType;
import de.binaris.logisticsadmin.model.RechnungGutschriftType;
import de.binaris.logisticsadmin.model.RueckstellungRegelType;
import de.binaris.logisticsadmin.model.BezugArtType;
import de.binaris.logisticsadmin.model.DeliveryType;
import de.binaris.logisticsadmin.model.AmountKeyType;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LieferartDTO implements Serializable
{

   private PartieAppType partieApp;
   private LieferartType lieferartType;
   private Integer buchungssatz;
   private NestedLagerDTO lager;
   private StatusActivType status;
   private ArticleBetragType articleOrBetrag;
   private RechnungGutschriftType rechnungOrGutschrift;
   private RueckstellungRegelType rueckstellungRegel;
   private Long id;
   private BezugArtType bezugart;
   private String description;
   private DeliveryType delivery;
   private AmountKeyType amountKey;
   private Date gueltigVon;

   public LieferartDTO()
   {
   }

   public LieferartDTO(final Lieferart entity)
   {
      if (entity != null)
      {
         this.partieApp = entity.getPartieApp();
         this.lieferartType = entity.getLieferartType();
         this.buchungssatz = entity.getBuchungssatz();
         this.lager = new NestedLagerDTO(entity.getLager());
         this.status = entity.getStatus();
         this.articleOrBetrag = entity.getArticleOrBetrag();
         this.rechnungOrGutschrift = entity.getRechnungOrGutschrift();
         this.rueckstellungRegel = entity.getRueckstellungRegel();
         this.id = entity.getId();
         this.bezugart = entity.getBezugart();
         this.description = entity.getDescription();
         this.delivery = entity.getDelivery();
         this.amountKey = entity.getAmountKey();
         this.gueltigVon = entity.getGueltigVon();
      }
   }

   public Lieferart fromDTO(Lieferart entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Lieferart();
      }
      entity.setPartieApp(this.partieApp);
      entity.setLieferartType(this.lieferartType);
      entity.setBuchungssatz(this.buchungssatz);
      if (this.lager != null)
      {
         entity.setLager(this.lager.fromDTO(entity.getLager(), em));
      }
      entity.setStatus(this.status);
      entity.setArticleOrBetrag(this.articleOrBetrag);
      entity.setRechnungOrGutschrift(this.rechnungOrGutschrift);
      entity.setRueckstellungRegel(this.rueckstellungRegel);
      entity.setBezugart(this.bezugart);
      entity.setDescription(this.description);
      entity.setDelivery(this.delivery);
      entity.setAmountKey(this.amountKey);
      entity.setGueltigVon(this.gueltigVon);
      entity = em.merge(entity);
      return entity;
   }

   public PartieAppType getPartieApp()
   {
      return this.partieApp;
   }

   public void setPartieApp(final PartieAppType partieApp)
   {
      this.partieApp = partieApp;
   }

   public LieferartType getLieferartType()
   {
      return this.lieferartType;
   }

   public void setLieferartType(final LieferartType lieferartType)
   {
      this.lieferartType = lieferartType;
   }

   public Integer getBuchungssatz()
   {
      return this.buchungssatz;
   }

   public void setBuchungssatz(final Integer buchungssatz)
   {
      this.buchungssatz = buchungssatz;
   }

   public NestedLagerDTO getLager()
   {
      return this.lager;
   }

   public void setLager(final NestedLagerDTO lager)
   {
      this.lager = lager;
   }

   public StatusActivType getStatus()
   {
      return this.status;
   }

   public void setStatus(final StatusActivType status)
   {
      this.status = status;
   }

   public ArticleBetragType getArticleOrBetrag()
   {
      return this.articleOrBetrag;
   }

   public void setArticleOrBetrag(final ArticleBetragType articleOrBetrag)
   {
      this.articleOrBetrag = articleOrBetrag;
   }

   public RechnungGutschriftType getRechnungOrGutschrift()
   {
      return this.rechnungOrGutschrift;
   }

   public void setRechnungOrGutschrift(
         final RechnungGutschriftType rechnungOrGutschrift)
   {
      this.rechnungOrGutschrift = rechnungOrGutschrift;
   }

   public RueckstellungRegelType getRueckstellungRegel()
   {
      return this.rueckstellungRegel;
   }

   public void setRueckstellungRegel(
         final RueckstellungRegelType rueckstellungRegel)
   {
      this.rueckstellungRegel = rueckstellungRegel;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public BezugArtType getBezugart()
   {
      return this.bezugart;
   }

   public void setBezugart(final BezugArtType bezugart)
   {
      this.bezugart = bezugart;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public DeliveryType getDelivery()
   {
      return this.delivery;
   }

   public void setDelivery(final DeliveryType delivery)
   {
      this.delivery = delivery;
   }

   public AmountKeyType getAmountKey()
   {
      return this.amountKey;
   }

   public void setAmountKey(final AmountKeyType amountKey)
   {
      this.amountKey = amountKey;
   }

   public Date getGueltigVon()
   {
      return this.gueltigVon;
   }

   public void setGueltigVon(final Date gueltigVon)
   {
      this.gueltigVon = gueltigVon;
   }
}