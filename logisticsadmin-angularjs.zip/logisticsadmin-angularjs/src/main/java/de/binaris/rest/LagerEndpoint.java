package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.logisticsadmin.model.Lager;
import de.binaris.rest.dto.LagerDTO;

/**
 * 
 */
@Stateless
@Path("/lagers")
public class LagerEndpoint
{
   @PersistenceContext(unitName = "LogisticsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(LagerDTO dto)
   {
      Lager entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(LagerEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Lager entity = em.find(Lager.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Lager> findByIdQuery = em.createQuery("SELECT DISTINCT l FROM Lager l WHERE l.id = :entityId ORDER BY l.id", Lager.class);
      findByIdQuery.setParameter("entityId", id);
      Lager entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      LagerDTO dto = new LagerDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<LagerDTO> listAll()
   {
      final List<Lager> searchResults = em.createQuery("SELECT DISTINCT l FROM Lager l ORDER BY l.id", Lager.class).getResultList();
      final List<LagerDTO> results = new ArrayList<LagerDTO>();
      for (Lager searchResult : searchResults)
      {
         LagerDTO dto = new LagerDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, LagerDTO dto)
   {
      TypedQuery<Lager> findByIdQuery = em.createQuery("SELECT DISTINCT l FROM Lager l WHERE l.id = :entityId ORDER BY l.id", Lager.class);
      findByIdQuery.setParameter("entityId", id);
      Lager entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}