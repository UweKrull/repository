package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Incoterm;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class IncotermDTO implements Serializable
{

   private Long id;
   private String shortDescription;
   private String description;
   private String iterm;

   public IncotermDTO()
   {
   }

   public IncotermDTO(final Incoterm entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.shortDescription = entity.getShortDescription();
         this.description = entity.getDescription();
         this.iterm = entity.getIterm();
      }
   }

   public Incoterm fromDTO(Incoterm entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Incoterm();
      }
      entity.setShortDescription(this.shortDescription);
      entity.setDescription(this.description);
      entity.setIterm(this.iterm);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getShortDescription()
   {
      return this.shortDescription;
   }

   public void setShortDescription(final String shortDescription)
   {
      this.shortDescription = shortDescription;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getIterm()
   {
      return this.iterm;
   }

   public void setIterm(final String iterm)
   {
      this.iterm = iterm;
   }
}