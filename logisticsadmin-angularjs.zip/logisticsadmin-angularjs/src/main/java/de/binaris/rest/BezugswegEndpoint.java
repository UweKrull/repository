package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.logisticsadmin.model.Bezugsweg;
import de.binaris.rest.dto.BezugswegDTO;

/**
 * 
 */
@Stateless
@Path("/bezugswegs")
public class BezugswegEndpoint
{
   @PersistenceContext(unitName = "LogisticsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(BezugswegDTO dto)
   {
      Bezugsweg entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(BezugswegEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Bezugsweg entity = em.find(Bezugsweg.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Bezugsweg> findByIdQuery = em.createQuery("SELECT DISTINCT b FROM Bezugsweg b LEFT JOIN FETCH b.department LEFT JOIN FETCH b.lager WHERE b.id = :entityId ORDER BY b.id", Bezugsweg.class);
      findByIdQuery.setParameter("entityId", id);
      Bezugsweg entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      BezugswegDTO dto = new BezugswegDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<BezugswegDTO> listAll()
   {
      final List<Bezugsweg> searchResults = em.createQuery("SELECT DISTINCT b FROM Bezugsweg b LEFT JOIN FETCH b.department LEFT JOIN FETCH b.lager ORDER BY b.id", Bezugsweg.class).getResultList();
      final List<BezugswegDTO> results = new ArrayList<BezugswegDTO>();
      for (Bezugsweg searchResult : searchResults)
      {
         BezugswegDTO dto = new BezugswegDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, BezugswegDTO dto)
   {
      TypedQuery<Bezugsweg> findByIdQuery = em.createQuery("SELECT DISTINCT b FROM Bezugsweg b LEFT JOIN FETCH b.department LEFT JOIN FETCH b.lager WHERE b.id = :entityId ORDER BY b.id", Bezugsweg.class);
      findByIdQuery.setParameter("entityId", id);
      Bezugsweg entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}