package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Article;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedWarengruppeDTO;
import de.binaris.logisticsadmin.model.OrderAmountUnitType;
import de.binaris.rest.dto.NestedArticleDataDTO;
import de.binaris.logisticsadmin.model.ActivType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ArticleDTO implements Serializable
{

   private String ean;
   private Long id;
   private NestedWarengruppeDTO warengruppe;
   private OrderAmountUnitType orderAmountUnit;
   private String originalArticleNo;
   private String description;
   private NestedArticleDataDTO articleData;
   private ActivType activ;
   private Integer eanType;
   private String currentArticleNo;

   public ArticleDTO()
   {
   }

   public ArticleDTO(final Article entity)
   {
      if (entity != null)
      {
         this.ean = entity.getEan();
         this.id = entity.getId();
         this.warengruppe = new NestedWarengruppeDTO(entity.getWarengruppe());
         this.orderAmountUnit = entity.getOrderAmountUnit();
         this.originalArticleNo = entity.getOriginalArticleNo();
         this.description = entity.getDescription();
         this.articleData = new NestedArticleDataDTO(entity.getArticleData());
         this.activ = entity.getActiv();
         this.eanType = entity.getEanType();
         this.currentArticleNo = entity.getCurrentArticleNo();
      }
   }

   public Article fromDTO(Article entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Article();
      }
      entity.setEan(this.ean);
      if (this.warengruppe != null)
      {
         entity.setWarengruppe(this.warengruppe.fromDTO(
               entity.getWarengruppe(), em));
      }
      entity.setOrderAmountUnit(this.orderAmountUnit);
      entity.setOriginalArticleNo(this.originalArticleNo);
      entity.setDescription(this.description);
      if (this.articleData != null)
      {
         entity.setArticleData(this.articleData.fromDTO(
               entity.getArticleData(), em));
      }
      entity.setActiv(this.activ);
      entity.setEanType(this.eanType);
      entity.setCurrentArticleNo(this.currentArticleNo);
      entity = em.merge(entity);
      return entity;
   }

   public String getEan()
   {
      return this.ean;
   }

   public void setEan(final String ean)
   {
      this.ean = ean;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedWarengruppeDTO getWarengruppe()
   {
      return this.warengruppe;
   }

   public void setWarengruppe(final NestedWarengruppeDTO warengruppe)
   {
      this.warengruppe = warengruppe;
   }

   public OrderAmountUnitType getOrderAmountUnit()
   {
      return this.orderAmountUnit;
   }

   public void setOrderAmountUnit(final OrderAmountUnitType orderAmountUnit)
   {
      this.orderAmountUnit = orderAmountUnit;
   }

   public String getOriginalArticleNo()
   {
      return this.originalArticleNo;
   }

   public void setOriginalArticleNo(final String originalArticleNo)
   {
      this.originalArticleNo = originalArticleNo;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public NestedArticleDataDTO getArticleData()
   {
      return this.articleData;
   }

   public void setArticleData(final NestedArticleDataDTO articleData)
   {
      this.articleData = articleData;
   }

   public ActivType getActiv()
   {
      return this.activ;
   }

   public void setActiv(final ActivType activ)
   {
      this.activ = activ;
   }

   public Integer getEanType()
   {
      return this.eanType;
   }

   public void setEanType(final Integer eanType)
   {
      this.eanType = eanType;
   }

   public String getCurrentArticleNo()
   {
      return this.currentArticleNo;
   }

   public void setCurrentArticleNo(final String currentArticleNo)
   {
      this.currentArticleNo = currentArticleNo;
   }
}