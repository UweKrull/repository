package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.logisticsadmin.model.Department;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.KostenstellenbasisDTO;
import de.binaris.logisticsadmin.model.DepartmentType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DepartmentDTO implements Serializable
{

   private String deptNo;
   private Long id;
   private KostenstellenbasisDTO kostenstellenbasis;
   private DepartmentType articleRelated;

   public DepartmentDTO()
   {
   }

   public DepartmentDTO(final Department entity)
   {
      if (entity != null)
      {
         this.deptNo = entity.getDeptNo();
         this.id = entity.getId();
         this.kostenstellenbasis = new KostenstellenbasisDTO(
               entity.getKostenstellenbasis());
         this.articleRelated = entity.getArticleRelated();
      }
   }

   public Department fromDTO(Department entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Department();
      }
      entity.setDeptNo(this.deptNo);
      if (this.kostenstellenbasis != null)
      {
         entity.setKostenstellenbasis(this.kostenstellenbasis.fromDTO(
               entity.getKostenstellenbasis(), em));
      }
      entity.setArticleRelated(this.articleRelated);
      entity = em.merge(entity);
      return entity;
   }

   public String getDeptNo()
   {
      return this.deptNo;
   }

   public void setDeptNo(final String deptNo)
   {
      this.deptNo = deptNo;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public KostenstellenbasisDTO getKostenstellenbasis()
   {
      return this.kostenstellenbasis;
   }

   public void setKostenstellenbasis(
         final KostenstellenbasisDTO kostenstellenbasis)
   {
      this.kostenstellenbasis = kostenstellenbasis;
   }

   public DepartmentType getArticleRelated()
   {
      return this.articleRelated;
   }

   public void setArticleRelated(final DepartmentType articleRelated)
   {
      this.articleRelated = articleRelated;
   }
}