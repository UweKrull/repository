package de.binaris.library.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.library.model.PreviewItem;
import de.binaris.library.rest.dto.PreviewItemDTO;

/**
 * The REST Endpoint for PreviewItems
 */
@Stateless
@Path("/previewitems")
public class PreviewItemEndpoint
{
   @PersistenceContext(unitName = "LibraryPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(PreviewItemDTO dto)
   {
      PreviewItem entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(PreviewItemEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      PreviewItem entity = em.find(PreviewItem.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
//    TypedQuery<PreviewItem> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM PreviewItem p LEFT JOIN FETCH p.categoryItem LEFT JOIN FETCH p.purchaseLines WHERE p.id = :entityId ORDER BY p.id", PreviewItem.class);
      TypedQuery<PreviewItem> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM PreviewItem p LEFT JOIN FETCH p.categoryItem WHERE p.id = :entityId ORDER BY p.id", PreviewItem.class);
      findByIdQuery.setParameter("entityId", id);
      PreviewItem entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      PreviewItemDTO dto = new PreviewItemDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<PreviewItemDTO> listAll()
   {
//    final List<PreviewItem> searchResults = em.createQuery("SELECT DISTINCT p FROM PreviewItem p LEFT JOIN FETCH p.categoryItem LEFT JOIN FETCH p.purchaseLines ORDER BY p.id", PreviewItem.class).getResultList();
      final List<PreviewItem> searchResults = em.createQuery("SELECT DISTINCT p FROM PreviewItem p LEFT JOIN FETCH p.categoryItem ORDER BY p.id", PreviewItem.class).getResultList();
      final List<PreviewItemDTO> results = new ArrayList<PreviewItemDTO>();
      for (PreviewItem searchResult : searchResults)
      {
         PreviewItemDTO dto = new PreviewItemDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, PreviewItemDTO dto)
   {
//    TypedQuery<PreviewItem> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM PreviewItem p LEFT JOIN FETCH p.categoryItem LEFT JOIN FETCH p.purchaseLines WHERE p.id = :entityId ORDER BY p.id", PreviewItem.class);
      TypedQuery<PreviewItem> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM PreviewItem p LEFT JOIN FETCH p.categoryItem LEFT JOIN FETCH p.purchaseLines WHERE p.id = :entityId ORDER BY p.id", PreviewItem.class);
      findByIdQuery.setParameter("entityId", id);
      PreviewItem entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}