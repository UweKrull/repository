package de.binaris.library.rest.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

import de.binaris.library.model.Category;
import de.binaris.library.model.CategoryItem;

@XmlRootElement
public class CategoryDTO implements Serializable {

	private static final long serialVersionUID = 7735678910111213156L;

	private Long id;
	private String description;
	private String name;
	private Set<NestedCategoryItemDTO> categoryItems = new HashSet<NestedCategoryItemDTO>();

	public CategoryDTO() {
	}

	public CategoryDTO(final Category entity) {
		if (entity != null) {
			Iterator<CategoryItem> iterCategoryItems = entity
					.getCategoryItems().iterator();
			for (; iterCategoryItems.hasNext();) {
				CategoryItem element = iterCategoryItems.next();
				this.categoryItems.add(new NestedCategoryItemDTO(element));
			}
			this.id = entity.getId();
			this.description = entity.getDescription();
			this.name = entity.getName();
		}
	}

	public Category fromDTO(Category entity, EntityManager em) {
		if (entity == null) {
			entity = new Category();
		}
		Iterator<CategoryItem> iterCategoryItems = entity.getCategoryItems()
				.iterator();
		for (; iterCategoryItems.hasNext();) {
			boolean found = false;
			CategoryItem categoryItem = iterCategoryItems.next();
			Iterator<NestedCategoryItemDTO> iterDtoCategoryItems = this
					.getCategoryItems().iterator();
			for (; iterDtoCategoryItems.hasNext();) {
				NestedCategoryItemDTO dtoCategoryItem = iterDtoCategoryItems
						.next();
				if (dtoCategoryItem.getId().equals(categoryItem.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterCategoryItems.remove();
			}
		}
		Iterator<NestedCategoryItemDTO> iterDtoCategoryItems = this
				.getCategoryItems().iterator();
		for (; iterDtoCategoryItems.hasNext();) {
			boolean found = false;
			NestedCategoryItemDTO dtoCategoryItem = iterDtoCategoryItems.next();
			iterCategoryItems = entity.getCategoryItems().iterator();
			for (; iterCategoryItems.hasNext();) {
				CategoryItem categoryItem = iterCategoryItems.next();
				if (dtoCategoryItem.getId().equals(categoryItem.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<CategoryItem> resultIter = em
						.createQuery("SELECT DISTINCT c FROM CategoryItem c",
								CategoryItem.class).getResultList().iterator();
				for (; resultIter.hasNext();) {
					CategoryItem result = resultIter.next();
					if (result.getId().equals(dtoCategoryItem.getId())) {
						entity.getCategoryItems().add(result);
						break;
					}
				}
			}
		}
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity = em.merge(entity);
		return entity;
	}

	public Set<NestedCategoryItemDTO> getCategoryItems() {
		return this.categoryItems;
	}

	public void setCategoryItems(final Set<NestedCategoryItemDTO> categoryItems) {
		this.categoryItems = categoryItems;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}
}