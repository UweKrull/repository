package de.binaris.library.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * The persistent class for the preview_item database table.
 * 
 */
@Cacheable
@Entity
@Table(name = "preview_item")
public class PreviewItem implements Serializable {
	
	private static final long serialVersionUID = 3975672336799127723L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_preview_item")
	@SequenceGenerator(name = "my_entity_seq_gen_preview_item", sequenceName = "sequence_preview_item", allocationSize = 1)
	private Long id;

	private String description;

	private String name;

	@Column(name="preview_path")
	private String previewPath;

	@Column(name="isbn")
	private String isbn;
	
	@Column(name="mhid")
	private String mhid;
	
	@Column(name="price_per_item")
	private float pricePerItem;

	@ManyToOne
	private CategoryItem categoryItem;

	public PreviewItem() {
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPreviewPath() {
		return this.previewPath;
	}

	public void setPreviewPath(String previewPath) {
		this.previewPath = previewPath;
	}

	public String getIsbn() {
		return this.isbn;
	}
	
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	public String getMhid() {
		return this.mhid;
	}
	
	public void setMhid(String mhid) {
		this.mhid = mhid;
	}
	
	public float getPricePerItem() {
		return this.pricePerItem;
	}

	public void setPricePerItem(float pricePerItem) {
		this.pricePerItem = pricePerItem;
	}

	public CategoryItem getCategoryItem() {
		return this.categoryItem;
	}

	public void setCategoryItem(CategoryItem categoryItem) {
		this.categoryItem = categoryItem;
	}

	/*
	 * toString(), equals() and hashCode() for PurchaseOrder, using the natural
	 * identity of the object
	 */

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof PreviewItem)) {
			return false;
		}
		PreviewItem castOther = (PreviewItem) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append('\'').append(categoryItem.toString());
		sb.append(", ").append('\'').append(description).append('\'');
		sb.append(", ").append('\'').append(name).append('\'');
		sb.append(", ").append('\'').append(isbn).append('\'');
		sb.append(", ").append('\'').append(mhid).append('\'');
		return sb.toString();
	}
}
