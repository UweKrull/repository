package de.binaris.library.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import de.binaris.library.model.Category;

/**
 * The persistent class for the category_item database table.
 * 
 */
@Cacheable
@Entity
@Table(name = "category_item")
public class CategoryItem implements Serializable {

	private static final long serialVersionUID = 797577262699127729L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_category_item")
	@SequenceGenerator(name = "my_entity_seq_gen_category_item", sequenceName = "sequence_category_item", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@ManyToOne
	private Category category;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof CategoryItem)) {
			return false;
		}
		CategoryItem castOther = (CategoryItem) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return name + ", " + description;
	}
}