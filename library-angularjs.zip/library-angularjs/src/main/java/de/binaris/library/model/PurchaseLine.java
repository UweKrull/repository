package de.binaris.library.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * A PurchaseLine may consist of one or more items.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Entity
@Table(name = "purchase_line")
public class PurchaseLine implements Serializable {

	private static final long serialVersionUID = 503211237573262925L;

	/**
	 * The ID of the PurchaseLine.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_purchase_line")
	@SequenceGenerator(name = "my_entity_seq_gen_purchase_line", sequenceName = "sequence_purchase_line", allocationSize = 1)
	private Long id;

	/**
	 * The quantity of items.
	 */
	@NotNull
	@Min(value = 1, message = "minimum 1 item")
	private Integer quantity;

	/**
	 * The previewItem of the PurchaseLine.
	 */
	@ManyToOne
	@NotNull
	private PreviewItem previewItem;

	/**
	 * The libraryPurchase of the PurchaseLine.
	 */
	@ManyToOne
	@NotNull
	private LibraryPurchase libraryPurchase;

	public PurchaseLine() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public LibraryPurchase getLibraryPurchase() {
		return this.libraryPurchase;
	}

	public void setLibraryPurchase(LibraryPurchase libraryPurchase) {
		this.libraryPurchase = libraryPurchase;
	}

	public PreviewItem getPreviewItem() {
		return this.previewItem;
	}

	public void setPreviewItem(PreviewItem previewItem) {
		this.previewItem = previewItem;
	}
	
	/*
	 * toString(), equals() and hashCode() for OrderLine, using the natural
	 * identity of the object
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof PurchaseLine)) {
			return false;
		}
		PurchaseLine castOther = (PurchaseLine) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append('\'').append("quantity: ").append(quantity).append('\'');
		sb.append('\'').append(", previewItem: ").append(previewItem.getName()).append('\'');
		sb.append('\'').append(", description: ").append(previewItem.getDescription()).append('\'');
		return sb.toString();
	}
}
