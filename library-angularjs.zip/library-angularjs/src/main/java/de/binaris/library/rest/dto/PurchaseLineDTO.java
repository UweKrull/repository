package de.binaris.library.rest.dto;

import java.io.Serializable;

import de.binaris.library.model.PurchaseLine;
import de.binaris.library.rest.dto.NestedLibraryPurchaseDTO;
import de.binaris.library.rest.dto.NestedPreviewItemDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PurchaseLineDTO implements Serializable {

	private static final long serialVersionUID = 7717778917111233391L;

	private Long id;
	private NestedLibraryPurchaseDTO libraryPurchase;
	private NestedPreviewItemDTO previewItem;
	private Integer quantity;

	public PurchaseLineDTO() {
	}

	public PurchaseLineDTO(final PurchaseLine entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.libraryPurchase = new NestedLibraryPurchaseDTO(
					entity.getLibraryPurchase());
			this.previewItem = new NestedPreviewItemDTO(entity.getPreviewItem());
			this.quantity = entity.getQuantity();
		}
	}

	public PurchaseLine fromDTO(PurchaseLine entity, EntityManager em) {
		if (entity == null) {
			entity = new PurchaseLine();
		}
		if (this.libraryPurchase != null) {
			entity.setLibraryPurchase(this.libraryPurchase.fromDTO(
					entity.getLibraryPurchase(), em));
		}
		if (this.previewItem != null) {
			entity.setPreviewItem(this.previewItem.fromDTO(
					entity.getPreviewItem(), em));
		}
		entity.setQuantity(this.quantity);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public NestedLibraryPurchaseDTO getLibraryPurchase() {
		return this.libraryPurchase;
	}

	public void setLibraryPurchase(
			final NestedLibraryPurchaseDTO libraryPurchase) {
		this.libraryPurchase = libraryPurchase;
	}

	public NestedPreviewItemDTO getPreviewItem() {
		return this.previewItem;
	}

	public void setPreviewItem(final NestedPreviewItemDTO previewItem) {
		this.previewItem = previewItem;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(final Integer quantity) {
		this.quantity = quantity;
	}
}