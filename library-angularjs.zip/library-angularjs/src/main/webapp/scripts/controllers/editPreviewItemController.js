

angular.module('libraryangularjs').controller('EditPreviewItemController', function($scope, $routeParams, $location, PreviewItemResource , CategoryItemResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.previewItem = new PreviewItemResource(self.original);
            CategoryItemResource.queryAll(function(items) {
                $scope.categoryItemSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.previewItem.categoryItem && item.id == $scope.previewItem.categoryItem.id) {
                        $scope.categoryItemSelection = labelObject;
                        $scope.previewItem.categoryItem = wrappedObject;
                        self.original.categoryItem = $scope.previewItem.categoryItem;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/PreviewItems");
        };
        PreviewItemResource.get({PreviewItemId:$routeParams.PreviewItemId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.previewItem);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.previewItem.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PreviewItems");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PreviewItems");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.previewItem.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("categoryItemSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.previewItem.categoryItem = {};
            $scope.previewItem.categoryItem.id = selection.value;
        }
    });
    
    $scope.get();
});