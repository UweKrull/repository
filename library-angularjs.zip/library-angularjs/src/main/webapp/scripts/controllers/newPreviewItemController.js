
angular.module('libraryangularjs').controller('NewPreviewItemController', function ($scope, $location, locationParser, PreviewItemResource , CategoryItemResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.previewItem = $scope.previewItem || {};
    
    $scope.categoryItemList = CategoryItemResource.queryAll(function(items){
        $scope.categoryItemSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categoryItemSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.previewItem.categoryItem = {};
            $scope.previewItem.categoryItem.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/PreviewItems/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PreviewItemResource.save($scope.previewItem, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/PreviewItems");
    };
});