

angular.module('libraryangularjs').controller('EditCategoryController', function($scope, $routeParams, $location, CategoryResource , CategoryItemResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.category = new CategoryResource(self.original);
            CategoryItemResource.queryAll(function(items) {
                $scope.categoryItemsSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.category.categoryItems){
                        $.each($scope.category.categoryItems, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.categoryItemsSelection.push(labelObject);
                                $scope.category.categoryItems.push(wrappedObject);
                            }
                        });
                        self.original.categoryItems = $scope.category.categoryItems;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Categorys");
        };
        CategoryResource.get({CategoryId:$routeParams.CategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.category);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.category.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Categorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Categorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.category.$remove(successCallback, errorCallback);
    };
    
    $scope.categoryItemsSelection = $scope.categoryItemsSelection || [];
    $scope.$watch("categoryItemsSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.category) {
            $scope.category.categoryItems = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.category.categoryItems.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});