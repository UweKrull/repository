
angular.module('libraryangularjs').controller('NewLibraryPurchaseController', function ($scope, $location, locationParser, LibraryPurchaseResource , CountryResource, CustomerResource, PurchaseLineResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.libraryPurchase = $scope.libraryPurchase || {};
    
    $scope.countryList = CountryResource.queryAll(function(items){
        $scope.countrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("countrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.libraryPurchase.country = {};
            $scope.libraryPurchase.country.id = selection.value;
        }
    });
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.libraryPurchase.customer = {};
            $scope.libraryPurchase.customer.id = selection.value;
        }
    });
    
    $scope.purchaseLinesList = PurchaseLineResource.queryAll(function(items){
        $scope.purchaseLinesSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.quantity
            });
        });
    });
    $scope.$watch("purchaseLinesSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.libraryPurchase.purchaseLines = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.libraryPurchase.purchaseLines.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/LibraryPurchases/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        LibraryPurchaseResource.save($scope.libraryPurchase, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/LibraryPurchases");
    };
});