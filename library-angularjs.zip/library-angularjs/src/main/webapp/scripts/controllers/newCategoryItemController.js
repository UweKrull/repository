
angular.module('libraryangularjs').controller('NewCategoryItemController', function ($scope, $location, locationParser, CategoryItemResource , CategoryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.categoryItem = $scope.categoryItem || {};
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.description
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.categoryItem.category = {};
            $scope.categoryItem.category.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/CategoryItems/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CategoryItemResource.save($scope.categoryItem, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/CategoryItems");
    };
});