

angular.module('libraryangularjs').controller('EditPurchaseLineController', function($scope, $routeParams, $location, PurchaseLineResource , LibraryPurchaseResource, PreviewItemResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.purchaseLine = new PurchaseLineResource(self.original);
            LibraryPurchaseResource.queryAll(function(items) {
                $scope.libraryPurchaseSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.libraryDate + ' - ' + item.estimatedReturnDate + ', ' + item.customer.firstName + ' ' + item.customer.lastName
                    };
                    if($scope.purchaseLine.libraryPurchase && item.id == $scope.purchaseLine.libraryPurchase.id) {
                        $scope.libraryPurchaseSelection = labelObject;
                        $scope.purchaseLine.libraryPurchase = wrappedObject;
                        self.original.libraryPurchase = $scope.purchaseLine.libraryPurchase;
                    }
                    return labelObject;
                });
            });
            PreviewItemResource.queryAll(function(items) {
                $scope.previewItemSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.description
                    };
                    if($scope.purchaseLine.previewItem && item.id == $scope.purchaseLine.previewItem.id) {
                        $scope.previewItemSelection = labelObject;
                        $scope.purchaseLine.previewItem = wrappedObject;
                        self.original.previewItem = $scope.purchaseLine.previewItem;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/PurchaseLines");
        };
        PurchaseLineResource.get({PurchaseLineId:$routeParams.PurchaseLineId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.purchaseLine);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.purchaseLine.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PurchaseLines");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PurchaseLines");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.purchaseLine.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("libraryPurchaseSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.purchaseLine.libraryPurchase = {};
            $scope.purchaseLine.libraryPurchase.id = selection.value;
        }
    });
    $scope.$watch("previewItemSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.purchaseLine.previewItem = {};
            $scope.purchaseLine.previewItem.id = selection.value;
        }
    });
    
    $scope.get();
});