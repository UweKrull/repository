
angular.module('libraryangularjs').controller('NewPurchaseLineController', function ($scope, $location, locationParser, PurchaseLineResource , LibraryPurchaseResource, PreviewItemResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.purchaseLine = $scope.purchaseLine || {};
    
    $scope.libraryPurchaseList = LibraryPurchaseResource.queryAll(function(items){
        $scope.libraryPurchaseSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.estimatedReturnDate
            });
        });
    });
    $scope.$watch("libraryPurchaseSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.purchaseLine.libraryPurchase = {};
            $scope.purchaseLine.libraryPurchase.id = selection.value;
        }
    });
    
    $scope.previewItemList = PreviewItemResource.queryAll(function(items){
        $scope.previewItemSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.description
            });
        });
    });
    $scope.$watch("previewItemSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.purchaseLine.previewItem = {};
            $scope.purchaseLine.previewItem.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/PurchaseLines/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PurchaseLineResource.save($scope.purchaseLine, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/PurchaseLines");
    };
});