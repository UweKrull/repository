

angular.module('libraryangularjs').controller('EditLibraryPurchaseController', function($scope, $routeParams, $location, LibraryPurchaseResource , CountryResource, CustomerResource, PurchaseLineResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.libraryPurchase = new LibraryPurchaseResource(self.original);
            CountryResource.queryAll(function(items) {
                $scope.countrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.libraryPurchase.country && item.id == $scope.libraryPurchase.country.id) {
                        $scope.countrySelection = labelObject;
                        $scope.libraryPurchase.country = wrappedObject;
                        self.original.country = $scope.libraryPurchase.country;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName + ' ' + item.lastName + ', ' + item.email + ', ' + item.phone
                    };
                    if($scope.libraryPurchase.customer && item.id == $scope.libraryPurchase.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.libraryPurchase.customer = wrappedObject;
                        self.original.customer = $scope.libraryPurchase.customer;
                    }
                    return labelObject;
                });
            });
            PurchaseLineResource.queryAll(function(items) {
                $scope.purchaseLinesSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.quantity + ' ' + item.previewItem.name
                    };
                    if($scope.libraryPurchase.purchaseLines){
                        $.each($scope.libraryPurchase.purchaseLines, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.purchaseLinesSelection.push(labelObject);
                                $scope.libraryPurchase.purchaseLines.push(wrappedObject);
                            }
                        });
                        self.original.purchaseLines = $scope.libraryPurchase.purchaseLines;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/LibraryPurchases");
        };
        LibraryPurchaseResource.get({LibraryPurchaseId:$routeParams.LibraryPurchaseId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.libraryPurchase);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.libraryPurchase.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/LibraryPurchases");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/LibraryPurchases");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.libraryPurchase.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("countrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.libraryPurchase.country = {};
            $scope.libraryPurchase.country.id = selection.value;
        }
    });
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.libraryPurchase.customer = {};
            $scope.libraryPurchase.customer.id = selection.value;
        }
    });
    $scope.purchaseLinesSelection = $scope.purchaseLinesSelection || [];
    $scope.$watch("purchaseLinesSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.libraryPurchase) {
            $scope.libraryPurchase.purchaseLines = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.libraryPurchase.purchaseLines.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});