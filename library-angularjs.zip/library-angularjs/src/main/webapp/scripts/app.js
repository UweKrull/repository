'use strict';

angular.module('libraryangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/CategoryItems',{templateUrl:'views/CategoryItem/search.html',controller:'SearchCategoryItemController'})
      .when('/CategoryItems/new',{templateUrl:'views/CategoryItem/detail.html',controller:'NewCategoryItemController'})
      .when('/CategoryItems/edit/:CategoryItemId',{templateUrl:'views/CategoryItem/detail.html',controller:'EditCategoryItemController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Customers',{templateUrl:'views/Customer/search.html',controller:'SearchCustomerController'})
      .when('/Customers/new',{templateUrl:'views/Customer/detail.html',controller:'NewCustomerController'})
      .when('/Customers/edit/:CustomerId',{templateUrl:'views/Customer/detail.html',controller:'EditCustomerController'})
      .when('/LibraryPurchases',{templateUrl:'views/LibraryPurchase/search.html',controller:'SearchLibraryPurchaseController'})
      .when('/LibraryPurchases/new',{templateUrl:'views/LibraryPurchase/detail.html',controller:'NewLibraryPurchaseController'})
      .when('/LibraryPurchases/edit/:LibraryPurchaseId',{templateUrl:'views/LibraryPurchase/detail.html',controller:'EditLibraryPurchaseController'})
      .when('/PreviewItems',{templateUrl:'views/PreviewItem/search.html',controller:'SearchPreviewItemController'})
      .when('/PreviewItems/new',{templateUrl:'views/PreviewItem/detail.html',controller:'NewPreviewItemController'})
      .when('/PreviewItems/edit/:PreviewItemId',{templateUrl:'views/PreviewItem/detail.html',controller:'EditPreviewItemController'})
      .when('/PurchaseLines',{templateUrl:'views/PurchaseLine/search.html',controller:'SearchPurchaseLineController'})
      .when('/PurchaseLines/new',{templateUrl:'views/PurchaseLine/detail.html',controller:'NewPurchaseLineController'})
      .when('/PurchaseLines/edit/:PurchaseLineId',{templateUrl:'views/PurchaseLine/detail.html',controller:'EditPurchaseLineController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
