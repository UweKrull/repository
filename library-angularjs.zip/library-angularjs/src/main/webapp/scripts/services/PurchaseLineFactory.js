angular.module('libraryangularjs').factory('PurchaseLineResource', function($resource){
    var resource = $resource('rest/purchaselines/:PurchaseLineId',{PurchaseLineId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});