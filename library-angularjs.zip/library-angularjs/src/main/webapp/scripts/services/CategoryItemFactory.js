angular.module('libraryangularjs').factory('CategoryItemResource', function($resource){
    var resource = $resource('rest/categoryitems/:CategoryItemId',{CategoryItemId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});