package de.binaris.recipeadmin.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.PreparationDirection;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedPreparationDirectionDTO implements Serializable
{

   private Long id;
   private String howToPrepare;

   public NestedPreparationDirectionDTO()
   {
   }

   public NestedPreparationDirectionDTO(final PreparationDirection entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.howToPrepare = entity.getHowToPrepare();
      }
   }

   public PreparationDirection fromDTO(PreparationDirection entity,
         EntityManager em)
   {
      if (entity == null)
      {
         entity = new PreparationDirection();
      }
      if (this.id != null)
      {
         TypedQuery<PreparationDirection> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT p FROM PreparationDirection p WHERE p.id = :entityId",
                     PreparationDirection.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setHowToPrepare(this.howToPrepare);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getHowToPrepare()
   {
      return this.howToPrepare;
   }

   public void setHowToPrepare(final String howToPrepare)
   {
      this.howToPrepare = howToPrepare;
   }
}