package de.binaris.recipeadmin.rest.dto;

import java.io.Serializable;

import de.binaris.recipeadmin.model.Category;
import de.binaris.recipeadmin.rest.dto.NestedRecipeDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable
{

   private Long id;
   private NestedRecipeDTO recipe;
   private String description;
   private String name;

   public CategoryDTO()
   {
   }

   public CategoryDTO(final Category entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.recipe = new NestedRecipeDTO(entity.getRecipe());
         this.description = entity.getDescription();
         this.name = entity.getName();
      }
   }

   public Category fromDTO(Category entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Category();
      }
      if (this.recipe != null)
      {
         entity.setRecipe(this.recipe.fromDTO(entity.getRecipe(), em));
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedRecipeDTO getRecipe()
   {
      return this.recipe;
   }

   public void setRecipe(final NestedRecipeDTO recipe)
   {
      this.recipe = recipe;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}