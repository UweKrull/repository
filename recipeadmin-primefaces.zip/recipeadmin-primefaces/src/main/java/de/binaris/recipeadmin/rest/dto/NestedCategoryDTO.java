package de.binaris.recipeadmin.rest.dto;

import java.io.Serializable;
import de.binaris.recipeadmin.model.Category;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedCategoryDTO implements Serializable
{

   private Long id;
   private String description;
   private String name;

   public NestedCategoryDTO()
   {
   }

   public NestedCategoryDTO(final Category entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
      }
   }

   public Category fromDTO(Category entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Category();
      }
      if (this.id != null)
      {
         TypedQuery<Category> findByIdQuery = em.createQuery(
               "SELECT DISTINCT c FROM Category c WHERE c.id = :entityId",
               Category.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}