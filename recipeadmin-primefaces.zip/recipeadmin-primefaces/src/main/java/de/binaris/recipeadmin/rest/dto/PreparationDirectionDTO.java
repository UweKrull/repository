package de.binaris.recipeadmin.rest.dto;

import java.io.Serializable;

import de.binaris.recipeadmin.model.PreparationDirection;
import de.binaris.recipeadmin.rest.dto.NestedRecipeDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PreparationDirectionDTO implements Serializable
{

   private Long id;
   private NestedRecipeDTO recipe;
   private String howToPrepare;

   public PreparationDirectionDTO()
   {
   }

   public PreparationDirectionDTO(final PreparationDirection entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.recipe = new NestedRecipeDTO(entity.getRecipe());
         this.howToPrepare = entity.getHowToPrepare();
      }
   }

   public PreparationDirection fromDTO(PreparationDirection entity,
         EntityManager em)
   {
      if (entity == null)
      {
         entity = new PreparationDirection();
      }
      if (this.recipe != null)
      {
         entity.setRecipe(this.recipe.fromDTO(entity.getRecipe(), em));
      }
      entity.setHowToPrepare(this.howToPrepare);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedRecipeDTO getRecipe()
   {
      return this.recipe;
   }

   public void setRecipe(final NestedRecipeDTO recipe)
   {
      this.recipe = recipe;
   }

   public String getHowToPrepare()
   {
      return this.howToPrepare;
   }

   public void setHowToPrepare(final String howToPrepare)
   {
      this.howToPrepare = howToPrepare;
   }
}