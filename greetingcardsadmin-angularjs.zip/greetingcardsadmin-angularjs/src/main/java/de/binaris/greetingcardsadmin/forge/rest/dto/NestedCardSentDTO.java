package de.binaris.greetingcardsadmin.forge.rest.dto;

import java.io.Serializable;
import de.binaris.greetingcardsadmin.forge.model.CardSent;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Date;

public class NestedCardSentDTO implements Serializable
{

   private String toEmail;
   private String toName;
   private Short isSent;
   private Date seenDate;
   private Long idCardSent;
   private String fromVorname;
   private Date expireDate;
   private String sendOnPickup;
   private String toVorname;
   private Date expireArchiv;
   private String fromEmail;
   private Short seenCount;
   private String fromName;
   private Date createDate;

   public NestedCardSentDTO()
   {
   }

   public NestedCardSentDTO(final CardSent entity)
   {
      if (entity != null)
      {
         this.toEmail = entity.getToEmail();
         this.toName = entity.getToName();
         this.isSent = entity.getIsSent();
         this.seenDate = entity.getSeenDate();
         this.idCardSent = entity.getIdCardSent();
         this.fromVorname = entity.getFromVorname();
         this.expireDate = entity.getExpireDate();
         this.sendOnPickup = entity.getSendOnPickup();
         this.toVorname = entity.getToVorname();
         this.expireArchiv = entity.getExpireArchiv();
         this.fromEmail = entity.getFromEmail();
         this.seenCount = entity.getSeenCount();
         this.fromName = entity.getFromName();
         this.createDate = entity.getCreateDate();
      }
   }

   public CardSent fromDTO(CardSent entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new CardSent();
      }
      if (this.idCardSent != null)
      {
         TypedQuery<CardSent> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT c FROM CardSent c WHERE c.idCardSent = :entityId",
                     CardSent.class);
         findByIdQuery.setParameter("entityId", this.idCardSent);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setToEmail(this.toEmail);
      entity.setToName(this.toName);
      entity.setIsSent(this.isSent);
      entity.setSeenDate(this.seenDate);
      entity.setFromVorname(this.fromVorname);
      entity.setExpireDate(this.expireDate);
      entity.setSendOnPickup(this.sendOnPickup);
      entity.setToVorname(this.toVorname);
      entity.setExpireArchiv(this.expireArchiv);
      entity.setFromEmail(this.fromEmail);
      entity.setSeenCount(this.seenCount);
      entity.setFromName(this.fromName);
      entity.setCreateDate(this.createDate);
      entity = em.merge(entity);
      return entity;
   }

   public String getToEmail()
   {
      return this.toEmail;
   }

   public void setToEmail(final String toEmail)
   {
      this.toEmail = toEmail;
   }

   public String getToName()
   {
      return this.toName;
   }

   public void setToName(final String toName)
   {
      this.toName = toName;
   }

   public Short getIsSent()
   {
      return this.isSent;
   }

   public void setIsSent(final Short isSent)
   {
      this.isSent = isSent;
   }

   public Date getSeenDate()
   {
      return this.seenDate;
   }

   public void setSeenDate(final Date seenDate)
   {
      this.seenDate = seenDate;
   }

   public Long getIdCardSent()
   {
      return this.idCardSent;
   }

   public void setIdCardSent(final Long idCardSent)
   {
      this.idCardSent = idCardSent;
   }

   public String getFromVorname()
   {
      return this.fromVorname;
   }

   public void setFromVorname(final String fromVorname)
   {
      this.fromVorname = fromVorname;
   }

   public Date getExpireDate()
   {
      return this.expireDate;
   }

   public void setExpireDate(final Date expireDate)
   {
      this.expireDate = expireDate;
   }

   public String getSendOnPickup()
   {
      return this.sendOnPickup;
   }

   public void setSendOnPickup(final String sendOnPickup)
   {
      this.sendOnPickup = sendOnPickup;
   }

   public String getToVorname()
   {
      return this.toVorname;
   }

   public void setToVorname(final String toVorname)
   {
      this.toVorname = toVorname;
   }

   public Date getExpireArchiv()
   {
      return this.expireArchiv;
   }

   public void setExpireArchiv(final Date expireArchiv)
   {
      this.expireArchiv = expireArchiv;
   }

   public String getFromEmail()
   {
      return this.fromEmail;
   }

   public void setFromEmail(final String fromEmail)
   {
      this.fromEmail = fromEmail;
   }

   public Short getSeenCount()
   {
      return this.seenCount;
   }

   public void setSeenCount(final Short seenCount)
   {
      this.seenCount = seenCount;
   }

   public String getFromName()
   {
      return this.fromName;
   }

   public void setFromName(final String fromName)
   {
      this.fromName = fromName;
   }

   public Date getCreateDate()
   {
      return this.createDate;
   }

   public void setCreateDate(final Date createDate)
   {
      this.createDate = createDate;
   }
}