package de.binaris.greetingcardsadmin.forge.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.greetingcardsadmin.forge.model.Recipient;
import de.binaris.greetingcardsadmin.forge.rest.dto.RecipientDTO;

/**
 * 
 */
@Stateless
@Path("/recipients")
public class RecipientEndpoint
{
   @PersistenceContext(unitName = "GreetingcardsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(RecipientDTO dto)
   {
      Recipient entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(RecipientEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Recipient entity = em.find(Recipient.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Recipient> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM Recipient r WHERE r.id = :entityId ORDER BY r.id", Recipient.class);
      findByIdQuery.setParameter("entityId", id);
      Recipient entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      RecipientDTO dto = new RecipientDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<RecipientDTO> listAll()
   {
      final List<Recipient> searchResults = em.createQuery("SELECT DISTINCT r FROM Recipient r ORDER BY r.id", Recipient.class).getResultList();
      final List<RecipientDTO> results = new ArrayList<RecipientDTO>();
      for (Recipient searchResult : searchResults)
      {
         RecipientDTO dto = new RecipientDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, RecipientDTO dto)
   {
      TypedQuery<Recipient> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM Recipient r WHERE r.id = :entityId ORDER BY r.id", Recipient.class);
      findByIdQuery.setParameter("entityId", id);
      Recipient entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}