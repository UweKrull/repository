package de.binaris.greetingcardsadmin.forge.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Query;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
//import javax.persistence.Table;
//import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="recipient")
public class Recipient implements Serializable {

	private static final long serialVersionUID = 743273212797976827L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="my_entity_seq_gen_recipient")
	@SequenceGenerator(name = "my_entity_seq_gen_recipient", sequenceName="sequence_recipient", allocationSize=1)
    private Long id;

    @NotNull
    @NotEmpty
    @Size(min = 1, max = 40)
    @Column(name = "name")
    private String name;

    @NotNull
    @NotEmpty
    @Email
    @Column(name = "email")
    private String email;

    @NotNull
    @NotEmpty
    @Size(min = 1, max = 80)
    @Column(name = "message")
    private String message;

    @Column(name = "pathToCard")
    private String pathToCard;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getPathToCard() {
    	return pathToCard;
    }
    
    public void setPathToCard(String pathToCard) {
    	this.pathToCard = pathToCard;
    }
    
    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : System.identityHashCode(this);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Recipient)) {
            return false;
        }
        Recipient castOther = (Recipient) object;
        return id != null ? id.equals(castOther.getId()) : false;
    }
    
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("Recipient: ");
		sb.append('\'').append(name).append('\'');
		sb.append('\'').append(email).append('\'');
		sb.append('\'').append(message).append('\'');
		sb.append('\'').append(pathToCard).append('\'');
		return sb.toString();
	}
	
    public static Long getRecipientMaxId(EntityManager em) {
        final Query q = em.createQuery("select max(r.id) from Recipient as r");
        return ((Long) q.getSingleResult());
    }
}
