package de.binaris.greetingcardsadmin.forge.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name="country")
public class Country implements Serializable {

	private static final long serialVersionUID = 7005777625699126629L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_country")
	@SequenceGenerator(name = "my_entity_seq_gen_country", sequenceName = "sequence_country", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 2, message = "must be exactly 2 letters")
	@Column(name = "iso_code")
	private String isoCode;

	@NotNull
	@Size(min = 2, max = 80, message = "must be 2-80 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 2, max = 80, message = "must be 2-80 letters and spaces")
	@Column(name = "printable_name")
	private String printableName;

	@NotNull
	@Size(min = 3, max = 3, message = "must be exactly 3 letters")
	private String iso3;

	@NotNull
	@Size(min = 3, max = 3, message = "must be exactly 3 letters")
	private String numcode;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	public String getPrintableName() {
		return printableName;
	}

	public void setPrintableName(String printableName) {
		this.printableName = printableName;
	}

	public String getIso3() {
		return iso3;
	}

	public void setIso3(String iso3) {
		this.iso3 = iso3;
	}

	public String getNumcode() {
		return numcode;
	}

	public void setNumcode(String numcode) {
		this.numcode = numcode;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Country)) {
			return false;
		}
		Country castOther = (Country) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return name + ", " + isoCode;
	}
}
