package de.binaris.greetingcardsadmin.forge.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * The persistent class for the subcategory_media database table.
 */
@Entity
@Table(name="subcategory_media")
public class SubcategoryMedia implements Serializable {
	private static final long serialVersionUID = 7123727617579126719L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_subcategory_media")
	@SequenceGenerator(name = "my_entity_seq_gen_subcategory_media", sequenceName = "sequence_subcategory_media", allocationSize = 1)
	private Long idSubcategoryMedia;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Image media;

	@Column(name="MEDIA_TYPE_ID")
	private Integer mediaTypeId;

	private Short rfolge;

	@Column(name="SUBCATEGORY_ID")
	@NotNull
	@Min(value = 1,  message = "real subcategory values range from 1-99")
	@Max(value = 99, message = "real subcategory values range from 1-99")
	private Integer subcategoryId;

    public SubcategoryMedia() {
    }

	public Long getIdSubcategoryMedia() {
		return this.idSubcategoryMedia;
	}

	public void setIdSubcategoryMedia(Long idSubcategoryMedia) {
		this.idSubcategoryMedia = idSubcategoryMedia;
	}

	public Image getMedia() {
		return this.media;
	}

	public void setMedia(Image media) {
		this.media = media;
	}

	public Integer getMediaTypeId() {
		return this.mediaTypeId;
	}

	public void setMediaTypeId(Integer mediaTypeId) {
		this.mediaTypeId = mediaTypeId;
	}

	public Short getRfolge() {
		return this.rfolge;
	}

	public void setRfolge(Short rfolge) {
		this.rfolge = rfolge;
	}

	public Integer getSubcategoryId() {
		return this.subcategoryId;
	}

	public void setSubcategoryId(Integer subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof SubcategoryMedia)) {
			return false;
		}
		SubcategoryMedia castOther = (SubcategoryMedia) object;
		return idSubcategoryMedia != null ? idSubcategoryMedia.equals(castOther.getIdSubcategoryMedia()) : false;
	}
	
	@Override
	public int hashCode() {
		return idSubcategoryMedia != null ? idSubcategoryMedia.hashCode() : System.identityHashCode(this);
	}
	
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("SubcategoryMedia: ");
		sb.append('\'').append(mediaTypeId).append('\'');
		sb.append('\'').append(media.getIdImage()).append('\'');
		sb.append('\'').append(subcategoryId).append('\'');
		sb.append('\'').append(rfolge).append('\'');
		return sb.toString();
	}
}