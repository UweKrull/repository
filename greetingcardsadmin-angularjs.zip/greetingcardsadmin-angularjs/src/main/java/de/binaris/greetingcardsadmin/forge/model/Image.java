package de.binaris.greetingcardsadmin.forge.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The persistent class for the image database table.
 */
@Entity
@Table(name="image")
public class Image implements Serializable {
	private static final long serialVersionUID = 7135727625679176721L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_image")
	@SequenceGenerator(name = "my_entity_seq_gen_image", sequenceName = "sequence_image", allocationSize = 1)
	private Long idImage;

	private Short approved;

	@Column(name="EXT_ID")
	private Long extId;

	@Column(name="EXT_NR")
	private Integer extNr;

	@Column(name="EXT_RUBRIK")
	private Integer extRubrik;

	@Column(name="FULL_URL")
	private String fullUrl;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "media")
	private Set<SubcategoryMedia> subcategoryMedia = new HashSet<SubcategoryMedia>();

	private String link;

	@Column(name="MEDIA_TYPE_ID")
	private Integer mediaTypeId;

	@NotNull
	@Size(min = 0, max = 40, message = "display name must be 0-40 letters and spaces long")
	private String name;

	@Column(name="PIC_NAME")
	@NotNull
	@Size(min = 0, max = 80, message = "technical name (with filetype) must be 0-80 letters and spaces long")
	private String picName;

	@Column(name="POOL_ID")
	@NotNull
	@Min(value = 1, message = "possible pool id values: 1-1000")
	@Max(value = 1000, message = "possible pool id values: 1-1000")
	private Integer poolId;

	private String url;

    public Image() {
    }

	public Long getIdImage() {
		return this.idImage;
	}

	public void setIdImage(Long idImage) {
		this.idImage = idImage;
	}

	public Short getApproved() {
		return this.approved;
	}

	public void setApproved(Short approved) {
		this.approved = approved;
	}

	public Long getExtId() {
		return this.extId;
	}

	public void setExtId(Long extId) {
		this.extId = extId;
	}

	public Integer getExtNr() {
		return this.extNr;
	}

	public void setExtNr(Integer extNr) {
		this.extNr = extNr;
	}

	public Integer getExtRubrik() {
		return this.extRubrik;
	}

	public void setExtRubrik(Integer extRubrik) {
		this.extRubrik = extRubrik;
	}

	public String getFullUrl() {
		return this.fullUrl;
	}

	public void setFullUrl(String fullUrl) {
		this.fullUrl = fullUrl;
	}

	public Set<SubcategoryMedia> getSubcategoryMedia() {
		return this.subcategoryMedia;
	}

	public void setSubcategoryMedia(Set<SubcategoryMedia> subcategoryMedia) {
		this.subcategoryMedia = subcategoryMedia;
	}

	public String getLink() {
		return this.link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public Integer getMediaTypeId() {
		return this.mediaTypeId;
	}

	public void setMediaTypeId(Integer mediaTypeId) {
		this.mediaTypeId = mediaTypeId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPicName() {
		return this.picName;
	}

	public void setPicName(String picName) {
		this.picName = picName;
	}

	public Integer getPoolId() {
		return this.poolId;
	}

	public void setPoolId(Integer poolId) {
		this.poolId = poolId;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Image)) {
			return false;
		}
		Image castOther = (Image) object;
		return idImage != null ? idImage.equals(castOther.getIdImage()) : false;
	}
	
	@Override
	public int hashCode() {
		return idImage != null ? idImage.hashCode() : System.identityHashCode(this);
	}
	
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("Image: ");
		sb.append('\'').append(name).append('\'');
		sb.append('\'').append(picName).append('\'');
		sb.append('\'').append(mediaTypeId).append('\'');
		sb.append('\'').append(url).append('\'');
		return sb.toString();
	}
}	
