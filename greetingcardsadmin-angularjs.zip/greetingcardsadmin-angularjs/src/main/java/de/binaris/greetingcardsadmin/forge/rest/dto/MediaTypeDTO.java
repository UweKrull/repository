package de.binaris.greetingcardsadmin.forge.rest.dto;

import java.io.Serializable;
import de.binaris.greetingcardsadmin.forge.model.MediaType;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MediaTypeDTO implements Serializable
{

   private String name;
   private Integer mediaTypeId;
   private Long idMediaType;

   public MediaTypeDTO()
   {
   }

   public MediaTypeDTO(final MediaType entity)
   {
      if (entity != null)
      {
         this.name = entity.getName();
         this.mediaTypeId = entity.getMediaTypeId();
         this.idMediaType = entity.getIdMediaType();
      }
   }

   public MediaType fromDTO(MediaType entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new MediaType();
      }
      entity.setName(this.name);
      entity.setMediaTypeId(this.mediaTypeId);
      entity = em.merge(entity);
      return entity;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Integer getMediaTypeId()
   {
      return this.mediaTypeId;
   }

   public void setMediaTypeId(final Integer mediaTypeId)
   {
      this.mediaTypeId = mediaTypeId;
   }

   public Long getIdMediaType()
   {
      return this.idMediaType;
   }

   public void setIdMediaType(final Long idMediaType)
   {
      this.idMediaType = idMediaType;
   }
}