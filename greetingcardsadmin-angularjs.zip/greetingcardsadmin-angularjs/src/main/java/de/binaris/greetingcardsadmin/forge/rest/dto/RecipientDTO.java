package de.binaris.greetingcardsadmin.forge.rest.dto;

import java.io.Serializable;
import de.binaris.greetingcardsadmin.forge.model.Recipient;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RecipientDTO implements Serializable
{

   private String message;
   private Long id;
   private String email;
   private String name;
   private String pathToCard;

   public RecipientDTO()
   {
   }

   public RecipientDTO(final Recipient entity)
   {
      if (entity != null)
      {
         this.message = entity.getMessage();
         this.id = entity.getId();
         this.email = entity.getEmail();
         this.name = entity.getName();
         this.pathToCard = entity.getPathToCard();
      }
   }

   public Recipient fromDTO(Recipient entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Recipient();
      }
      entity.setMessage(this.message);
      entity.setEmail(this.email);
      entity.setName(this.name);
      entity.setPathToCard(this.pathToCard);
      entity = em.merge(entity);
      return entity;
   }

   public String getMessage()
   {
      return this.message;
   }

   public void setMessage(final String message)
   {
      this.message = message;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getPathToCard()
   {
      return this.pathToCard;
   }

   public void setPathToCard(final String pathToCard)
   {
      this.pathToCard = pathToCard;
   }
}