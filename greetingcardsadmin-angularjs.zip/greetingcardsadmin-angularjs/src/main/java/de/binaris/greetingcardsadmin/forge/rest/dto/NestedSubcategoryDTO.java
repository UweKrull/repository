package de.binaris.greetingcardsadmin.forge.rest.dto;

import java.io.Serializable;
import de.binaris.greetingcardsadmin.forge.model.Subcategory;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedSubcategoryDTO implements Serializable
{

   private Integer subcategoryId;
   private String textColor;
   private Long idSubcategory;
   private String categoryDescription;
   private String htmlKeyword;
   private String fontSize;
   private String textLink;
   private Short approved;
   private String description;
   private String htmlTitle;
   private String htmlDescription;
   private String commercial;

   public NestedSubcategoryDTO()
   {
   }

   public NestedSubcategoryDTO(final Subcategory entity)
   {
      if (entity != null)
      {
         this.subcategoryId = entity.getSubcategoryId();
         this.textColor = entity.getTextColor();
         this.idSubcategory = entity.getIdSubcategory();
         this.categoryDescription = entity.getCategoryDescription();
         this.htmlKeyword = entity.getHtmlKeyword();
         this.fontSize = entity.getFontSize();
         this.textLink = entity.getTextLink();
         this.approved = entity.getApproved();
         this.description = entity.getDescription();
         this.htmlTitle = entity.getHtmlTitle();
         this.htmlDescription = entity.getHtmlDescription();
         this.commercial = entity.getCommercial();
      }
   }

   public Subcategory fromDTO(Subcategory entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Subcategory();
      }
      if (this.idSubcategory != null)
      {
         TypedQuery<Subcategory> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT s FROM Subcategory s WHERE s.idSubcategory = :entityId",
                     Subcategory.class);
         findByIdQuery.setParameter("entityId", this.idSubcategory);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setSubcategoryId(this.subcategoryId);
      entity.setTextColor(this.textColor);
      entity.setCategoryDescription(this.categoryDescription);
      entity.setHtmlKeyword(this.htmlKeyword);
      entity.setFontSize(this.fontSize);
      entity.setTextLink(this.textLink);
      entity.setApproved(this.approved);
      entity.setDescription(this.description);
      entity.setHtmlTitle(this.htmlTitle);
      entity.setHtmlDescription(this.htmlDescription);
      entity.setCommercial(this.commercial);
      entity = em.merge(entity);
      return entity;
   }

   public Integer getSubcategoryId()
   {
      return this.subcategoryId;
   }

   public void setSubcategoryId(final Integer subcategoryId)
   {
      this.subcategoryId = subcategoryId;
   }

   public String getTextColor()
   {
      return this.textColor;
   }

   public void setTextColor(final String textColor)
   {
      this.textColor = textColor;
   }

   public Long getIdSubcategory()
   {
      return this.idSubcategory;
   }

   public void setIdSubcategory(final Long idSubcategory)
   {
      this.idSubcategory = idSubcategory;
   }

   public String getCategoryDescription()
   {
      return this.categoryDescription;
   }

   public void setCategoryDescription(final String categoryDescription)
   {
      this.categoryDescription = categoryDescription;
   }

   public String getHtmlKeyword()
   {
      return this.htmlKeyword;
   }

   public void setHtmlKeyword(final String htmlKeyword)
   {
      this.htmlKeyword = htmlKeyword;
   }

   public String getFontSize()
   {
      return this.fontSize;
   }

   public void setFontSize(final String fontSize)
   {
      this.fontSize = fontSize;
   }

   public String getTextLink()
   {
      return this.textLink;
   }

   public void setTextLink(final String textLink)
   {
      this.textLink = textLink;
   }

   public Short getApproved()
   {
      return this.approved;
   }

   public void setApproved(final Short approved)
   {
      this.approved = approved;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getHtmlTitle()
   {
      return this.htmlTitle;
   }

   public void setHtmlTitle(final String htmlTitle)
   {
      this.htmlTitle = htmlTitle;
   }

   public String getHtmlDescription()
   {
      return this.htmlDescription;
   }

   public void setHtmlDescription(final String htmlDescription)
   {
      this.htmlDescription = htmlDescription;
   }

   public String getCommercial()
   {
      return this.commercial;
   }

   public void setCommercial(final String commercial)
   {
      this.commercial = commercial;
   }
}