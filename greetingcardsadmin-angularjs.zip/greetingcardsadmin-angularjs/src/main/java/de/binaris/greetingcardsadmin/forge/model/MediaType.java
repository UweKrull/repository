package de.binaris.greetingcardsadmin.forge.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The persistent class for the media_type database table.
 */
@Entity
@Table(name="media_type")
public class MediaType implements Serializable {
	private static final long serialVersionUID = 7125727623679126729L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_media_type")
	@SequenceGenerator(name = "my_entity_seq_gen_media_type", sequenceName = "sequence_media_type", allocationSize = 1)
	private Long idMediaType;

	@Column(name="MEDIA_TYPE_ID")
	private Integer mediaTypeId;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces long")
	private String name;

    public MediaType() {
    }

	public Long getIdMediaType() {
		return this.idMediaType;
	}

	public void setIdMediaType(Long idMediaType) {
		this.idMediaType = idMediaType;
	}

	public Integer getMediaTypeId() {
		return this.mediaTypeId;
	}

	public void setMediaTypeId(Integer mediaTypeId) {
		this.mediaTypeId = mediaTypeId;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof MediaType)) {
			return false;
		}
		MediaType castOther = (MediaType) object;
		return idMediaType != null ? idMediaType.equals(castOther.getIdMediaType()) : false;
	}
	
	@Override
	public int hashCode() {
		return idMediaType != null ? idMediaType.hashCode() : System.identityHashCode(this);
	}
	
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("MediaType: ");
		sb.append('\'').append(name).append('\'');
		sb.append('\'').append(mediaTypeId).append('\'');
		return sb.toString();
	}
}