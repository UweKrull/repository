package de.binaris.greetingcardsadmin.forge.rest.dto;

import java.io.Serializable;
import de.binaris.greetingcardsadmin.forge.model.SubcategoryMedia;
import javax.persistence.EntityManager;
import de.binaris.greetingcardsadmin.forge.rest.dto.NestedImageDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SubcategoryMediaDTO implements Serializable
{

   private Integer subcategoryId;
   private Integer mediaTypeId;
   private Short rfolge;
   private Long idSubcategoryMedia;
   private NestedImageDTO media;

   public SubcategoryMediaDTO()
   {
   }

   public SubcategoryMediaDTO(final SubcategoryMedia entity)
   {
      if (entity != null)
      {
         this.subcategoryId = entity.getSubcategoryId();
         this.mediaTypeId = entity.getMediaTypeId();
         this.rfolge = entity.getRfolge();
         this.idSubcategoryMedia = entity.getIdSubcategoryMedia();
         this.media = new NestedImageDTO(entity.getMedia());
      }
   }

   public SubcategoryMedia fromDTO(SubcategoryMedia entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new SubcategoryMedia();
      }
      entity.setSubcategoryId(this.subcategoryId);
      entity.setMediaTypeId(this.mediaTypeId);
      entity.setRfolge(this.rfolge);
      if (this.media != null)
      {
         entity.setMedia(this.media.fromDTO(entity.getMedia(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Integer getSubcategoryId()
   {
      return this.subcategoryId;
   }

   public void setSubcategoryId(final Integer subcategoryId)
   {
      this.subcategoryId = subcategoryId;
   }

   public Integer getMediaTypeId()
   {
      return this.mediaTypeId;
   }

   public void setMediaTypeId(final Integer mediaTypeId)
   {
      this.mediaTypeId = mediaTypeId;
   }

   public Short getRfolge()
   {
      return this.rfolge;
   }

   public void setRfolge(final Short rfolge)
   {
      this.rfolge = rfolge;
   }

   public Long getIdSubcategoryMedia()
   {
      return this.idSubcategoryMedia;
   }

   public void setIdSubcategoryMedia(final Long idSubcategoryMedia)
   {
      this.idSubcategoryMedia = idSubcategoryMedia;
   }

   public NestedImageDTO getMedia()
   {
      return this.media;
   }

   public void setMedia(final NestedImageDTO media)
   {
      this.media = media;
   }
}