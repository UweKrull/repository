package de.binaris.greetingcardsadmin.forge.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Query;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The persistent class for the quotes database table.
 */
@Entity
@Table(name="quote")
public class Quote implements Serializable {
	private static final long serialVersionUID = 743263212497976827L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="my_entity_seq_gen_Quote")
	@SequenceGenerator(name = "my_entity_seq_gen_Quote", sequenceName="sequence_Quote", allocationSize=1)
	private Long idQuote;

	@NotNull
	@Size(min = 3, max = 400, message = "must be 3-400 letters and spaces long")
	private String spruchText;

	@NotNull
	@Size(min = 1, max = 1, message = "must be one of j(oke), f(lirt), k(onfuzius)")
	private String spruchType;

    public Quote() {
    }

    public Quote(String spruchText, String spruchType) {
    	this.spruchText = spruchText;
    	this.spruchType = spruchType;
    }
    
	public Long getIdQuote() {
		return this.idQuote;
	}

	public void setIdQuote(Long idQuote) {
		this.idQuote = idQuote;
	}

	public String getSpruchText() {
		return this.spruchText;
	}

	public void setSpruchText(String spruchText) {
		this.spruchText = spruchText;
	}

	public String getSpruchType() {
		return this.spruchType;
	}

	public void setSpruchType(String spruchType) {
		this.spruchType = spruchType;
	}

    @Override
    public int hashCode() {
        return idQuote != null ? idQuote.hashCode() : System.identityHashCode(this);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Quote)) {
            return false;
        }
        Quote castOther = (Quote) object;
        return idQuote != null ? idQuote.equals(castOther.getIdQuote()) : false;
    }
    
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("Quote: ");
		sb.append('\'').append(spruchText).append('\'');
		sb.append('\'').append(spruchType).append('\'');
		return sb.toString();
	}
	
    public static Long getQuoteMaxId(EntityManager em) {
        final Query q = em.createQuery("select max(q.idQuote) from Quote as q");
        return ((Long) q.getSingleResult());
    }
}