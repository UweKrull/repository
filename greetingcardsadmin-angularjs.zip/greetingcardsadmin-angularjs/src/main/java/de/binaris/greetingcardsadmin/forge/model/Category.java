package de.binaris.greetingcardsadmin.forge.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Query;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The persistent class for the category database table.
 */
@Entity
@Table(name="category")
public class Category implements Serializable {
	private static final long serialVersionUID = 273567972019125678L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="my_entity_seq_gen_category")
	@SequenceGenerator(name = "my_entity_seq_gen_category", sequenceName="sequence_card_category", allocationSize=1)
	private Long idCategory;

	private Short approved;
    
	@Column(name="CATEGORY_DESCRIPTION")
	private String categoryDescription;

	@Column(name="CATEGORY_ID")
	private Long categoryId;

	private String commercial;

	@NotNull
	@Size(min = 0, max = 400, message = "must be 0-400 letters and spaces long")
	private String description;

	@Column(name="FONT_SIZE")
	private String fontSize;
    
	@Column(name="HTML_DESCRIPTION")
	private String htmlDescription;
    
	@Column(name="HTML_KEYWORD")
	private String htmlKeyword;
    
	@Column(name="HTML_TITLE")
	private String htmlTitle;

	@Column(name="TEXT_COLOR")
	private String textColor;

	@Column(name="TEXT_LINK")
	private String textLink;

    public Category() {
    }

	public Long getIdCategory() {
		return this.idCategory;
	}

	public void setIdCategory(Long idCategory) {
		this.idCategory = idCategory;
	}

	public Short getApproved() {
		return this.approved;
	}

	public void setApproved(Short approved) {
		this.approved = approved;
	}

	public String getCategoryDescription() {
		return this.categoryDescription;
	}

	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public Long getCategoryId() {
		return this.categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getCommercial() {
		return this.commercial;
	}

	public void setCommercial(String commercial) {
		this.commercial = commercial;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFontSize() {
		return this.fontSize;
	}

	public void setFontSize(String fontSize) {
		this.fontSize = fontSize;
	}

	public String getHtmlDescription() {
		return this.htmlDescription;
	}

	public void setHtmlDescription(String htmlDescription) {
		this.htmlDescription = htmlDescription;
	}

	public String getHtmlKeyword() {
		return this.htmlKeyword;
	}

	public void setHtmlKeyword(String htmlKeyword) {
		this.htmlKeyword = htmlKeyword;
	}

	public String getHtmlTitle() {
		return this.htmlTitle;
	}

	public void setHtmlTitle(String htmlTitle) {
		this.htmlTitle = htmlTitle;
	}

	public String getTextColor() {
		return this.textColor;
	}

	public void setTextColor(String textColor) {
		this.textColor = textColor;
	}

	public String getTextLink() {
		return this.textLink;
	}

	public void setTextLink(String textLink) {
		this.textLink = textLink;
	}
	
    @Override
    public int hashCode() {
        return idCategory != null ? idCategory.hashCode() : System.identityHashCode(this);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Category)) {
            return false;
        }
        Category castOther = (Category) object;
        return idCategory != null ? idCategory.equals(castOther.getIdCategory()) : false;
    }
    
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("Category: ");
		sb.append('\'').append(description).append('\'');
		sb.append('\'').append(approved).append('\'');
		sb.append('\'').append(categoryId).append('\'');
		return sb.toString();
	}
	
    public static Long getCategoryMaxId(EntityManager em) {
        final Query q = em.createQuery("select max(c.idCategory) from Category as c");
        return ((Long) q.getSingleResult());
    }
}