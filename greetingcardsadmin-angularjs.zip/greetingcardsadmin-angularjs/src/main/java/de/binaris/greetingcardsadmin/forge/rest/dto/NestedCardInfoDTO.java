package de.binaris.greetingcardsadmin.forge.rest.dto;

import java.io.Serializable;
import de.binaris.greetingcardsadmin.forge.model.CardInfo;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Date;

public class NestedCardInfoDTO implements Serializable
{

   private String fontColor;
   private String thumbPath;
   private String jokeText;
   private Long idCardInfo;
   private String flirtText;
   private String fontSize;
   private String konfuzText;
   private Date sendDate;
   private String message;
   private Integer cardLayout;
   private String fontFamily;

   public NestedCardInfoDTO()
   {
   }

   public NestedCardInfoDTO(final CardInfo entity)
   {
      if (entity != null)
      {
         this.fontColor = entity.getFontColor();
         this.thumbPath = entity.getThumbPath();
         this.jokeText = entity.getJokeText();
         this.idCardInfo = entity.getIdCardInfo();
         this.flirtText = entity.getFlirtText();
         this.fontSize = entity.getFontSize();
         this.konfuzText = entity.getKonfuzText();
         this.sendDate = entity.getSendDate();
         this.message = entity.getMessage();
         this.cardLayout = entity.getCardLayout();
         this.fontFamily = entity.getFontFamily();
      }
   }

   public CardInfo fromDTO(CardInfo entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new CardInfo();
      }
      if (this.idCardInfo != null)
      {
         TypedQuery<CardInfo> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT c FROM CardInfo c WHERE c.idCardInfo = :entityId",
                     CardInfo.class);
         findByIdQuery.setParameter("entityId", this.idCardInfo);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setFontColor(this.fontColor);
      entity.setThumbPath(this.thumbPath);
      entity.setJokeText(this.jokeText);
      entity.setFlirtText(this.flirtText);
      entity.setFontSize(this.fontSize);
      entity.setKonfuzText(this.konfuzText);
      entity.setSendDate(this.sendDate);
      entity.setMessage(this.message);
      entity.setCardLayout(this.cardLayout);
      entity.setFontFamily(this.fontFamily);
      entity = em.merge(entity);
      return entity;
   }

   public String getFontColor()
   {
      return this.fontColor;
   }

   public void setFontColor(final String fontColor)
   {
      this.fontColor = fontColor;
   }

   public String getThumbPath()
   {
      return this.thumbPath;
   }

   public void setThumbPath(final String thumbPath)
   {
      this.thumbPath = thumbPath;
   }

   public String getJokeText()
   {
      return this.jokeText;
   }

   public void setJokeText(final String jokeText)
   {
      this.jokeText = jokeText;
   }

   public Long getIdCardInfo()
   {
      return this.idCardInfo;
   }

   public void setIdCardInfo(final Long idCardInfo)
   {
      this.idCardInfo = idCardInfo;
   }

   public String getFlirtText()
   {
      return this.flirtText;
   }

   public void setFlirtText(final String flirtText)
   {
      this.flirtText = flirtText;
   }

   public String getFontSize()
   {
      return this.fontSize;
   }

   public void setFontSize(final String fontSize)
   {
      this.fontSize = fontSize;
   }

   public String getKonfuzText()
   {
      return this.konfuzText;
   }

   public void setKonfuzText(final String konfuzText)
   {
      this.konfuzText = konfuzText;
   }

   public Date getSendDate()
   {
      return this.sendDate;
   }

   public void setSendDate(final Date sendDate)
   {
      this.sendDate = sendDate;
   }

   public String getMessage()
   {
      return this.message;
   }

   public void setMessage(final String message)
   {
      this.message = message;
   }

   public Integer getCardLayout()
   {
      return this.cardLayout;
   }

   public void setCardLayout(final Integer cardLayout)
   {
      this.cardLayout = cardLayout;
   }

   public String getFontFamily()
   {
      return this.fontFamily;
   }

   public void setFontFamily(final String fontFamily)
   {
      this.fontFamily = fontFamily;
   }
}