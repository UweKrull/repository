package de.binaris.greetingcardsadmin.forge.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.greetingcardsadmin.forge.model.CardSent;
import de.binaris.greetingcardsadmin.forge.rest.dto.CardSentDTO;

/**
 * 
 */
@Stateless
@Path("/cardsents")
public class CardSentEndpoint
{
   @PersistenceContext(unitName = "GreetingcardsadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(CardSentDTO dto)
   {
      CardSent entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(CardSentEndpoint.class).path(String.valueOf(entity.getIdCardSent())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      CardSent entity = em.find(CardSent.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<CardSent> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM CardSent c LEFT JOIN FETCH c.cardInfo LEFT JOIN FETCH c.image LEFT JOIN FETCH c.customer WHERE c.idCardSent = :entityId ORDER BY c.idCardSent", CardSent.class);
      findByIdQuery.setParameter("entityId", id);
      CardSent entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      CardSentDTO dto = new CardSentDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<CardSentDTO> listAll()
   {
      final List<CardSent> searchResults = em.createQuery("SELECT DISTINCT c FROM CardSent c LEFT JOIN FETCH c.cardInfo LEFT JOIN FETCH c.image LEFT JOIN FETCH c.customer ORDER BY c.idCardSent", CardSent.class).getResultList();
      final List<CardSentDTO> results = new ArrayList<CardSentDTO>();
      for (CardSent searchResult : searchResults)
      {
         CardSentDTO dto = new CardSentDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, CardSentDTO dto)
   {
      TypedQuery<CardSent> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM CardSent c LEFT JOIN FETCH c.cardInfo LEFT JOIN FETCH c.image LEFT JOIN FETCH c.customer WHERE c.idCardSent = :entityId ORDER BY c.idCardSent", CardSent.class);
      findByIdQuery.setParameter("entityId", id);
      CardSent entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}