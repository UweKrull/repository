package de.binaris.greetingcardsadmin.forge.rest.dto;

import java.io.Serializable;
import de.binaris.greetingcardsadmin.forge.model.CardInfo;
import javax.persistence.EntityManager;
import de.binaris.greetingcardsadmin.forge.rest.dto.NestedImageDTO;
import de.binaris.greetingcardsadmin.forge.rest.dto.NestedCustomerDTO;
import java.util.Date;
import de.binaris.greetingcardsadmin.forge.rest.dto.NestedCategoryDTO;
import de.binaris.greetingcardsadmin.forge.rest.dto.NestedSubcategoryDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CardInfoDTO implements Serializable
{

   private String fontColor;
   private String thumbPath;
   private String jokeText;
   private Long idCardInfo;
   private String flirtText;
   private NestedImageDTO image;
   private NestedImageDTO imageBg;
   private NestedCustomerDTO customer;
   private String fontSize;
   private String konfuzText;
   private Date sendDate;
   private String message;
   private NestedCategoryDTO category;
   private NestedSubcategoryDTO subcategory;
   private Integer cardLayout;
   private String fontFamily;

   public CardInfoDTO()
   {
   }

   public CardInfoDTO(final CardInfo entity)
   {
      if (entity != null)
      {
         this.fontColor = entity.getFontColor();
         this.thumbPath = entity.getThumbPath();
         this.jokeText = entity.getJokeText();
         this.idCardInfo = entity.getIdCardInfo();
         this.flirtText = entity.getFlirtText();
         this.image = new NestedImageDTO(entity.getImage());
         this.imageBg = new NestedImageDTO(entity.getImageBg());
         this.customer = new NestedCustomerDTO(entity.getCustomer());
         this.fontSize = entity.getFontSize();
         this.konfuzText = entity.getKonfuzText();
         this.sendDate = entity.getSendDate();
         this.message = entity.getMessage();
         this.category = new NestedCategoryDTO(entity.getCategory());
         this.subcategory = new NestedSubcategoryDTO(entity.getSubcategory());
         this.cardLayout = entity.getCardLayout();
         this.fontFamily = entity.getFontFamily();
      }
   }

   public CardInfo fromDTO(CardInfo entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new CardInfo();
      }
      entity.setFontColor(this.fontColor);
      entity.setThumbPath(this.thumbPath);
      entity.setJokeText(this.jokeText);
      entity.setFlirtText(this.flirtText);
      if (this.image != null)
      {
         entity.setImage(this.image.fromDTO(entity.getImage(), em));
      }
      if (this.imageBg != null)
      {
         entity.setImageBg(this.imageBg.fromDTO(entity.getImageBg(), em));
      }
      if (this.customer != null)
      {
         entity.setCustomer(this.customer.fromDTO(entity.getCustomer(), em));
      }
      entity.setFontSize(this.fontSize);
      entity.setKonfuzText(this.konfuzText);
      entity.setSendDate(this.sendDate);
      entity.setMessage(this.message);
      if (this.category != null)
      {
         entity.setCategory(this.category.fromDTO(entity.getCategory(), em));
      }
      if (this.subcategory != null)
      {
         entity.setSubcategory(this.subcategory.fromDTO(
               entity.getSubcategory(), em));
      }
      entity.setCardLayout(this.cardLayout);
      entity.setFontFamily(this.fontFamily);
      entity = em.merge(entity);
      return entity;
   }

   public String getFontColor()
   {
      return this.fontColor;
   }

   public void setFontColor(final String fontColor)
   {
      this.fontColor = fontColor;
   }

   public String getThumbPath()
   {
      return this.thumbPath;
   }

   public void setThumbPath(final String thumbPath)
   {
      this.thumbPath = thumbPath;
   }

   public String getJokeText()
   {
      return this.jokeText;
   }

   public void setJokeText(final String jokeText)
   {
      this.jokeText = jokeText;
   }

   public Long getIdCardInfo()
   {
      return this.idCardInfo;
   }

   public void setIdCardInfo(final Long idCardInfo)
   {
      this.idCardInfo = idCardInfo;
   }

   public String getFlirtText()
   {
      return this.flirtText;
   }

   public void setFlirtText(final String flirtText)
   {
      this.flirtText = flirtText;
   }

   public NestedImageDTO getImage()
   {
      return this.image;
   }

   public void setImage(final NestedImageDTO image)
   {
      this.image = image;
   }

   public NestedImageDTO getImageBg()
   {
      return this.imageBg;
   }

   public void setImageBg(final NestedImageDTO imageBg)
   {
      this.imageBg = imageBg;
   }

   public NestedCustomerDTO getCustomer()
   {
      return this.customer;
   }

   public void setCustomer(final NestedCustomerDTO customer)
   {
      this.customer = customer;
   }

   public String getFontSize()
   {
      return this.fontSize;
   }

   public void setFontSize(final String fontSize)
   {
      this.fontSize = fontSize;
   }

   public String getKonfuzText()
   {
      return this.konfuzText;
   }

   public void setKonfuzText(final String konfuzText)
   {
      this.konfuzText = konfuzText;
   }

   public Date getSendDate()
   {
      return this.sendDate;
   }

   public void setSendDate(final Date sendDate)
   {
      this.sendDate = sendDate;
   }

   public String getMessage()
   {
      return this.message;
   }

   public void setMessage(final String message)
   {
      this.message = message;
   }

   public NestedCategoryDTO getCategory()
   {
      return this.category;
   }

   public void setCategory(final NestedCategoryDTO category)
   {
      this.category = category;
   }

   public NestedSubcategoryDTO getSubcategory()
   {
      return this.subcategory;
   }

   public void setSubcategory(final NestedSubcategoryDTO subcategory)
   {
      this.subcategory = subcategory;
   }

   public Integer getCardLayout()
   {
      return this.cardLayout;
   }

   public void setCardLayout(final Integer cardLayout)
   {
      this.cardLayout = cardLayout;
   }

   public String getFontFamily()
   {
      return this.fontFamily;
   }

   public void setFontFamily(final String fontFamily)
   {
      this.fontFamily = fontFamily;
   }
}