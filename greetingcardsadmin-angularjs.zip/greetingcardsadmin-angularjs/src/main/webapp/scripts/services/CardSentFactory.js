angular.module('greetingcardsadmin').factory('CardSentResource', function($resource){
    var resource = $resource('rest/cardsents/:CardSentId',{CardSentId:'@idCardSent'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});