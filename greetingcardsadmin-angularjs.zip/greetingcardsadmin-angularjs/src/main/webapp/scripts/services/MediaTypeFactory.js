angular.module('greetingcardsadmin').factory('MediaTypeResource', function($resource){
    var resource = $resource('rest/mediatypes/:MediaTypeId',{MediaTypeId:'@idMediaType'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});