angular.module('greetingcardsadmin').factory('SubcategoryResource', function($resource){
    var resource = $resource('rest/subcategorys/:SubcategoryId',{SubcategoryId:'@idSubcategory'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});