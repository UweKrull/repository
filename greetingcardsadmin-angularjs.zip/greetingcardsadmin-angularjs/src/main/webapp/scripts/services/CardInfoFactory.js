angular.module('greetingcardsadmin').factory('CardInfoResource', function($resource){
    var resource = $resource('rest/cardinfos/:CardInfoId',{CardInfoId:'@idCardInfo'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});