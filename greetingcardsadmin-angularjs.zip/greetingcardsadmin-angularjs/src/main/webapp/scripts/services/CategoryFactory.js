angular.module('greetingcardsadmin').factory('CategoryResource', function($resource){
    var resource = $resource('rest/categorys/:CategoryId',{CategoryId:'@idCategory'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});