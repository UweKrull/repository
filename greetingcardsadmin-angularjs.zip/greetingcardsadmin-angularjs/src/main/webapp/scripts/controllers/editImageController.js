angular.module('greetingcardsadmin').controller('EditImageController', function($scope, $routeParams, $location, ImageResource , SubcategoryMediaResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.image = new ImageResource(self.original);
            SubcategoryMediaResource.queryAll(function(items) {
                $scope.subcategoryMediaSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idSubcategoryMedia : item.idSubcategoryMedia
                    };
                    var labelObject = {
                        value : item.idSubcategoryMedia,
                        text : item.mediaTypeId
                    };
                    if($scope.image.subcategoryMedia){
                        $.each($scope.image.subcategoryMedia, function(idx, element) {
                            if(item.idSubcategoryMedia == element.idSubcategoryMedia) {
                                $scope.subcategoryMediaSelection.push(labelObject);
                                $scope.image.subcategoryMedia.push(wrappedObject);
                            }
                        });
                        self.original.subcategoryMedia = $scope.image.subcategoryMedia;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Images");
        };
        ImageResource.get({ImageId:$routeParams.ImageId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.image);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.image.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Images");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Images");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.image.$remove(successCallback, errorCallback);
    };
    
    $scope.subcategoryMediaSelection = $scope.subcategoryMediaSelection || [];
    $scope.$watch("subcategoryMediaSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.image) {
            $scope.image.subcategoryMedia = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.idSubcategoryMedia = selectedItem.value;
                $scope.image.subcategoryMedia.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});