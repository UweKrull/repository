angular.module('greetingcardsadmin').controller('NewImageController', function ($scope, $location, locationParser, ImageResource , SubcategoryMediaResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.image = $scope.image || {};
    
    $scope.subcategoryMediaList = SubcategoryMediaResource.queryAll(function(items){
        $scope.subcategoryMediaSelectionList = $.map(items, function(item) {
            return ( {
                value : item.idSubcategoryMedia,
                text : item.mediaTypeId
            });
        });
    });
    $scope.$watch("subcategoryMediaSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.image.subcategoryMedia = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.idSubcategoryMedia = selectedItem.value;
                $scope.image.subcategoryMedia.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Images/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ImageResource.save($scope.image, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Images");
    };
});