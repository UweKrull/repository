angular.module('greetingcardsadmin').controller('NewCardInfoController', function ($scope, $location, locationParser, CardInfoResource , CategoryResource, CustomerResource, SubcategoryResource, ImageResource, ImageResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.cardInfo = $scope.cardInfo || {};
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.idCategory,
                text : item.approved + ', ' + item.description
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.cardInfo.category = {};
            $scope.cardInfo.category.idCategory = selection.value;
        }
    });
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName + ' ' + item.lastName
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.cardInfo.customer = {};
            $scope.cardInfo.customer.id = selection.value;
        }
    });
    
    $scope.subcategoryList = SubcategoryResource.queryAll(function(items){
        $scope.subcategorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.idSubcategory,
                text : item.approved
            });
        });
    });
    $scope.$watch("subcategorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.cardInfo.subcategory = {};
            $scope.cardInfo.subcategory.idSubcategory = selection.value;
        }
    });
    
    $scope.imageBgList = ImageResource.queryAll(function(items){
        $scope.imageBgSelectionList = $.map(items, function(item) {
            return ( {
                value : item.idImage,
                text : item.approved
            });
        });
    });
    $scope.$watch("imageBgSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.cardInfo.imageBg = {};
            $scope.cardInfo.imageBg.idImage = selection.value;
        }
    });
    
    $scope.imageList = ImageResource.queryAll(function(items){
        $scope.imageSelectionList = $.map(items, function(item) {
            return ( {
                value : item.idImage,
                text : item.approved
            });
        });
    });
    $scope.$watch("imageSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.cardInfo.image = {};
            $scope.cardInfo.image.idImage = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/CardInfos/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CardInfoResource.save($scope.cardInfo, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/CardInfos");
    };
});