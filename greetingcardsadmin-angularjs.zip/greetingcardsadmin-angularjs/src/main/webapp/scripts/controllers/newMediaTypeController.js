angular.module('greetingcardsadmin').controller('NewMediaTypeController', function ($scope, $location, locationParser, MediaTypeResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.mediaType = $scope.mediaType || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/MediaTypes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        MediaTypeResource.save($scope.mediaType, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/MediaTypes");
    };
});