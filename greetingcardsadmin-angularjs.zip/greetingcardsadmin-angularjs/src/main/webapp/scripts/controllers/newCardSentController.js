angular.module('greetingcardsadmin').controller('NewCardSentController', function ($scope, $location, locationParser, CardSentResource , CardInfoResource, ImageResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.cardSent = $scope.cardSent || {};
    
    $scope.cardInfoList = CardInfoResource.queryAll(function(items){
        $scope.cardInfoSelectionList = $.map(items, function(item) {
            return ( {
                value : item.idCardInfo,
                text : item.cardLayout
            });
        });
    });
    $scope.$watch("cardInfoSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.cardSent.cardInfo = {};
            $scope.cardSent.cardInfo.idCardInfo = selection.value;
        }
    });
    
    $scope.imageList = ImageResource.queryAll(function(items){
        $scope.imageSelectionList = $.map(items, function(item) {
            return ( {
                value : item.idImage,
                text : item.approved + ', ' + item.name + ', ' + item.picName
            });
        });
    });
    $scope.$watch("imageSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.cardSent.image = {};
            $scope.cardSent.image.idImage = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/CardSents/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CardSentResource.save($scope.cardSent, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/CardSents");
    };
});