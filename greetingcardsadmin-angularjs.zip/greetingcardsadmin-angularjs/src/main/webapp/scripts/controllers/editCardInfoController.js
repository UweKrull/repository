angular.module('greetingcardsadmin').controller('EditCardInfoController', function($scope, $routeParams, $location, CardInfoResource , CategoryResource, CustomerResource, SubcategoryResource, ImageResource, ImageResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.cardInfo = new CardInfoResource(self.original);
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idCategory : item.idCategory
                    };
                    var labelObject = {
                        value : item.idCategory,
                        text : item.approved + ', ' + item.categoryDescription
                    };
                    if($scope.cardInfo.category && item.idCategory == $scope.cardInfo.category.idCategory) {
                        $scope.categorySelection = labelObject;
                        $scope.cardInfo.category = wrappedObject;
                        self.original.category = $scope.cardInfo.category;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName + ' ' + item.lastName
                    };
                    if($scope.cardInfo.customer && item.id == $scope.cardInfo.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.cardInfo.customer = wrappedObject;
                        self.original.customer = $scope.cardInfo.customer;
                    }
                    return labelObject;
                });
            });
            SubcategoryResource.queryAll(function(items) {
                $scope.subcategorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idSubcategory : item.idSubcategory
                    };
                    var labelObject = {
                        value : item.idSubcategory,
                        text : item.approved + ', ' + item.description
                    };
                    if($scope.cardInfo.subcategory && item.idSubcategory == $scope.cardInfo.subcategory.idSubcategory) {
                        $scope.subcategorySelection = labelObject;
                        $scope.cardInfo.subcategory = wrappedObject;
                        self.original.subcategory = $scope.cardInfo.subcategory;
                    }
                    return labelObject;
                });
            });
            ImageResource.queryAll(function(items) {
                $scope.imageBgSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idImage : item.idImage
                    };
                    var labelObject = {
                        value : item.idImage,
                        text : item.approved
                    };
                    if($scope.cardInfo.imageBg && item.idImage == $scope.cardInfo.imageBg.idImage) {
                        $scope.imageBgSelection = labelObject;
                        $scope.cardInfo.imageBg = wrappedObject;
                        self.original.imageBg = $scope.cardInfo.imageBg;
                    }
                    return labelObject;
                });
            });
            ImageResource.queryAll(function(items) {
                $scope.imageSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idImage : item.idImage
                    };
                    var labelObject = {
                        value : item.idImage,
                        text : item.approved + ', ' + item.name + ', ' + item.picName
                    };
                    if($scope.cardInfo.image && item.idImage == $scope.cardInfo.image.idImage) {
                        $scope.imageSelection = labelObject;
                        $scope.cardInfo.image = wrappedObject;
                        self.original.image = $scope.cardInfo.image;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/CardInfos");
        };
        CardInfoResource.get({CardInfoId:$routeParams.CardInfoId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.cardInfo);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.cardInfo.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/CardInfos");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/CardInfos");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.cardInfo.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.cardInfo.category = {};
            $scope.cardInfo.category.idCategory = selection.value;
        }
    });
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.cardInfo.customer = {};
            $scope.cardInfo.customer.id = selection.value;
        }
    });
    $scope.$watch("subcategorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.cardInfo.subcategory = {};
            $scope.cardInfo.subcategory.idSubcategory = selection.value;
        }
    });
    $scope.$watch("imageBgSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.cardInfo.imageBg = {};
            $scope.cardInfo.imageBg.idImage = selection.value;
        }
    });
    $scope.$watch("imageSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.cardInfo.image = {};
            $scope.cardInfo.image.idImage = selection.value;
        }
    });
    
    $scope.get();
});