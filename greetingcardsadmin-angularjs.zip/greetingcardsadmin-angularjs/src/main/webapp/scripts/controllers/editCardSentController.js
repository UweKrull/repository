angular.module('greetingcardsadmin').controller('EditCardSentController', function($scope, $routeParams, $location, CardSentResource, CardInfoResource, ImageResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.cardSent = new CardSentResource(self.original);
            CardInfoResource.queryAll(function(items) {
                $scope.cardInfoSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idCardInfo : item.idCardInfo
                    };
                    var labelObject = {
                        value : item.idCardInfo,
                        text : item.cardLayout + ', ' + item.sendDate + ', ' + item.message
                    };
                    if($scope.cardSent.cardInfo && item.idCardInfo == $scope.cardSent.cardInfo.idCardInfo) {
                        $scope.cardInfoSelection = labelObject;
                        $scope.cardSent.cardInfo = wrappedObject;
                        self.original.cardInfo = $scope.cardSent.cardInfo;
                    }
                    return labelObject;
                });
            });
            ImageResource.queryAll(function(items) {
                $scope.imageSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idImage : item.idImage
                    };
                    var labelObject = {
                        value : item.idImage,
                        text : item.approved + ', ' + item.name + ', ' + item.picName
                    };
                    if($scope.cardSent.image && item.idImage == $scope.cardSent.image.idImage) {
                        $scope.imageSelection = labelObject;
                        $scope.cardSent.image = wrappedObject;
                        self.original.image = $scope.cardSent.image;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/CardSents");
        };
        CardSentResource.get({CardSentId:$routeParams.CardSentId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.cardSent);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.cardSent.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/CardSents");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/CardSents");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.cardSent.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("cardInfoSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.cardSent.cardInfo = {};
            $scope.cardSent.cardInfo.idCardInfo = selection.value;
        }
    });
    $scope.$watch("imageSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.cardSent.image = {};
            $scope.cardSent.image.idImage = selection.value;
        }
    });
    
    $scope.get();
});