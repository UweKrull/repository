angular.module('greetingcardsadmin').controller('NewQuoteController', function ($scope, $location, locationParser, QuoteResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.quote = $scope.quote || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Quotes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        QuoteResource.save($scope.quote, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Quotes");
    };
});