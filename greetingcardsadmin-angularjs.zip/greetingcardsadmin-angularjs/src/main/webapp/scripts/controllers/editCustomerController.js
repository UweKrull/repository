angular.module('greetingcardsadmin').controller('EditCustomerController', function($scope, $routeParams, $location, CustomerResource , CardSentResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.customer = new CustomerResource(self.original);
            CardSentResource.queryAll(function(items) {
                $scope.cardsSentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idCardSent : item.idCardSent
                    };
                    var labelObject = {
                        value : item.idCardSent,
                        text : item.createDate + ', ' + item.image.name
                    };
                    if($scope.customer.cardsSent){
                        $.each($scope.customer.cardsSent, function(idx, element) {
                            if(item.idCardSent == element.idCardSent) {
                                $scope.cardsSentSelection.push(labelObject);
                                $scope.customer.cardsSent.push(wrappedObject);
                            }
                        });
                        self.original.cardsSent = $scope.customer.cardsSent;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.customer.address.country && item.id == $scope.customer.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.customer.address.country = wrappedObject;
                        self.original.address.country = $scope.customer.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Customers");
        };
        CustomerResource.get({CustomerId:$routeParams.CustomerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.customer);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.customer.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Customers");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Customers");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.customer.$remove(successCallback, errorCallback);
    };
    
    $scope.cardsSentSelection = $scope.cardsSentSelection || [];
    $scope.$watch("cardsSentSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.customer) {
            $scope.customer.cardsSent = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.idCardSent = selectedItem.value;
                $scope.customer.cardsSent.push(collectionItem);
            });
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.address.country = {};
            $scope.customer.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});