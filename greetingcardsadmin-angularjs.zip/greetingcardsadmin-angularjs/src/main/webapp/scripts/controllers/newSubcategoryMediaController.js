angular.module('greetingcardsadmin').controller('NewSubcategoryMediaController', function ($scope, $location, locationParser, SubcategoryMediaResource , ImageResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.subcategoryMedia = $scope.subcategoryMedia || {};
    
    $scope.mediaList = ImageResource.queryAll(function(items){
        $scope.mediaSelectionList = $.map(items, function(item) {
            return ( {
                value : item.idImage,
                text : item.approved
            });
        });
    });
    $scope.$watch("mediaSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.subcategoryMedia.media = {};
            $scope.subcategoryMedia.media.idImage = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/SubcategoryMedias/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SubcategoryMediaResource.save($scope.subcategoryMedia, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/SubcategoryMedias");
    };
});