angular.module('greetingcardsadmin').controller('EditQuoteController', function($scope, $routeParams, $location, QuoteResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.quote = new QuoteResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Quotes");
        };
        QuoteResource.get({QuoteId:$routeParams.QuoteId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.quote);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.quote.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Quotes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Quotes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.quote.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});