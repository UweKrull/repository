angular.module('greetingcardsadmin').controller('EditMediaTypeController', function($scope, $routeParams, $location, MediaTypeResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.mediaType = new MediaTypeResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/MediaTypes");
        };
        MediaTypeResource.get({MediaTypeId:$routeParams.MediaTypeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.mediaType);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.mediaType.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/MediaTypes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/MediaTypes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.mediaType.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});