angular.module('greetingcardsadmin').controller('NewCustomerController', function ($scope, $location, locationParser, CustomerResource , CardSentResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.customer = $scope.customer || {};
    
    $scope.cardsSentList = CardSentResource.queryAll(function(items){
        $scope.cardsSentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.idCardSent,
                text : item.createDate + ', ' + item.image.picSent
            });
        });
    });
    $scope.$watch("cardsSentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.cardsSent = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.idCardSent = selectedItem.value;
                $scope.customer.cardsSent.push(collectionItem);
            });
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.customer.address.country = {};
            $scope.customer.address.country.id = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Customers/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CustomerResource.save($scope.customer, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Customers");
    };
});