angular.module('greetingcardsadmin').controller('EditSubcategoryController', function($scope, $routeParams, $location, SubcategoryResource , CategoryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.subcategory = new SubcategoryResource(self.original);
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idCategory : item.idCategory
                    };
                    var labelObject = {
                        value : item.idCategory,
                        text : item.approved
                    };
                    if($scope.subcategory.category && item.idCategory == $scope.subcategory.category.idCategory) {
                        $scope.categorySelection = labelObject;
                        $scope.subcategory.category = wrappedObject;
                        self.original.category = $scope.subcategory.category;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Subcategorys");
        };
        SubcategoryResource.get({SubcategoryId:$routeParams.SubcategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.subcategory);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.subcategory.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Subcategorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Subcategorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.subcategory.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.subcategory.category = {};
            $scope.subcategory.category.idCategory = selection.value;
        }
    });
    
    $scope.get();
});