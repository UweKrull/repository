angular.module('greetingcardsadmin').controller('NewRecipientController', function ($scope, $location, locationParser, RecipientResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.recipient = $scope.recipient || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Recipients/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        RecipientResource.save($scope.recipient, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Recipients");
    };
});