angular.module('greetingcardsadmin').controller('EditSubcategoryMediaController', function($scope, $routeParams, $location, SubcategoryMediaResource , ImageResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.subcategoryMedia = new SubcategoryMediaResource(self.original);
            ImageResource.queryAll(function(items) {
                $scope.mediaSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        idImage : item.idImage
                    };
                    var labelObject = {
                        value : item.idImage,
                        text : item.approved
                    };
                    if($scope.subcategoryMedia.media && item.idImage == $scope.subcategoryMedia.media.idImage) {
                        $scope.mediaSelection = labelObject;
                        $scope.subcategoryMedia.media = wrappedObject;
                        self.original.media = $scope.subcategoryMedia.media;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/SubcategoryMedias");
        };
        SubcategoryMediaResource.get({SubcategoryMediaId:$routeParams.SubcategoryMediaId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.subcategoryMedia);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.subcategoryMedia.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/SubcategoryMedias");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/SubcategoryMedias");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.subcategoryMedia.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("mediaSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.subcategoryMedia.media = {};
            $scope.subcategoryMedia.media.idImage = selection.value;
        }
    });
    
    $scope.get();
});