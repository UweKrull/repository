angular.module('greetingcardsadmin').controller('NewSubcategoryController', function ($scope, $location, locationParser, SubcategoryResource , CategoryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.subcategory = $scope.subcategory || {};
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.idCategory,
                text : item.approved
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.subcategory.category = {};
            $scope.subcategory.category.idCategory = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Subcategorys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SubcategoryResource.save($scope.subcategory, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Subcategorys");
    };
});