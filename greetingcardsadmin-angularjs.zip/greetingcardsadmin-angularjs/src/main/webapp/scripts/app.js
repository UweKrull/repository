'use strict';

angular.module('greetingcardsadmin',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/CardInfos',{templateUrl:'views/CardInfo/search.html',controller:'SearchCardInfoController'})
      .when('/CardInfos/new',{templateUrl:'views/CardInfo/detail.html',controller:'NewCardInfoController'})
      .when('/CardInfos/edit/:CardInfoId',{templateUrl:'views/CardInfo/detail.html',controller:'EditCardInfoController'})
      .when('/CardSents',{templateUrl:'views/CardSent/search.html',controller:'SearchCardSentController'})
      .when('/CardSents/new',{templateUrl:'views/CardSent/detail.html',controller:'NewCardSentController'})
      .when('/CardSents/edit/:CardSentId',{templateUrl:'views/CardSent/detail.html',controller:'EditCardSentController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Customers',{templateUrl:'views/Customer/search.html',controller:'SearchCustomerController'})
      .when('/Customers/new',{templateUrl:'views/Customer/detail.html',controller:'NewCustomerController'})
      .when('/Customers/edit/:CustomerId',{templateUrl:'views/Customer/detail.html',controller:'EditCustomerController'})
      .when('/Images',{templateUrl:'views/Image/search.html',controller:'SearchImageController'})
      .when('/Images/new',{templateUrl:'views/Image/detail.html',controller:'NewImageController'})
      .when('/Images/edit/:ImageId',{templateUrl:'views/Image/detail.html',controller:'EditImageController'})
      .when('/MediaTypes',{templateUrl:'views/MediaType/search.html',controller:'SearchMediaTypeController'})
      .when('/MediaTypes/new',{templateUrl:'views/MediaType/detail.html',controller:'NewMediaTypeController'})
      .when('/MediaTypes/edit/:MediaTypeId',{templateUrl:'views/MediaType/detail.html',controller:'EditMediaTypeController'})
      .when('/Quotes',{templateUrl:'views/Quote/search.html',controller:'SearchQuoteController'})
      .when('/Quotes/new',{templateUrl:'views/Quote/detail.html',controller:'NewQuoteController'})
      .when('/Quotes/edit/:QuoteId',{templateUrl:'views/Quote/detail.html',controller:'EditQuoteController'})
      .when('/Recipients',{templateUrl:'views/Recipient/search.html',controller:'SearchRecipientController'})
      .when('/Recipients/new',{templateUrl:'views/Recipient/detail.html',controller:'NewRecipientController'})
      .when('/Recipients/edit/:RecipientId',{templateUrl:'views/Recipient/detail.html',controller:'EditRecipientController'})
      .when('/Subcategorys',{templateUrl:'views/Subcategory/search.html',controller:'SearchSubcategoryController'})
      .when('/Subcategorys/new',{templateUrl:'views/Subcategory/detail.html',controller:'NewSubcategoryController'})
      .when('/Subcategorys/edit/:SubcategoryId',{templateUrl:'views/Subcategory/detail.html',controller:'EditSubcategoryController'})
      .when('/SubcategoryMedias',{templateUrl:'views/SubcategoryMedia/search.html',controller:'SearchSubcategoryMediaController'})
      .when('/SubcategoryMedias/new',{templateUrl:'views/SubcategoryMedia/detail.html',controller:'NewSubcategoryMediaController'})
      .when('/SubcategoryMedias/edit/:SubcategoryMediaId',{templateUrl:'views/SubcategoryMedia/detail.html',controller:'EditSubcategoryMediaController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
