angular.module('employeetimetrackerangularjs').factory('TimeOffReasonResource', function($resource){
    var resource = $resource('rest/timeoffreasons/:TimeOffReasonId',{TimeOffReasonId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});