angular.module('employeetimetrackerangularjs').factory('TimeshiftResource', function($resource){
    var resource = $resource('rest/timeshifts/:TimeshiftId',{TimeshiftId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});