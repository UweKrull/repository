angular.module('employeetimetrackerangularjs').factory('TimeSheetResource', function($resource){
    var resource = $resource('rest/timesheets/:TimeSheetId',{TimeSheetId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});