'use strict';

angular.module('employeetimetrackerangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/ActivityTypes',{templateUrl:'views/ActivityType/search.html',controller:'SearchActivityTypeController'})
      .when('/ActivityTypes/new',{templateUrl:'views/ActivityType/detail.html',controller:'NewActivityTypeController'})
      .when('/ActivityTypes/edit/:ActivityTypeId',{templateUrl:'views/ActivityType/detail.html',controller:'EditActivityTypeController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/DayAndTimes',{templateUrl:'views/DayAndTime/search.html',controller:'SearchDayAndTimeController'})
      .when('/DayAndTimes/new',{templateUrl:'views/DayAndTime/detail.html',controller:'NewDayAndTimeController'})
      .when('/DayAndTimes/edit/:DayAndTimeId',{templateUrl:'views/DayAndTime/detail.html',controller:'EditDayAndTimeController'})
      .when('/Projects',{templateUrl:'views/Project/search.html',controller:'SearchProjectController'})
      .when('/Projects/new',{templateUrl:'views/Project/detail.html',controller:'NewProjectController'})
      .when('/Projects/edit/:ProjectId',{templateUrl:'views/Project/detail.html',controller:'EditProjectController'})
      .when('/ProjectTasks',{templateUrl:'views/ProjectTask/search.html',controller:'SearchProjectTaskController'})
      .when('/ProjectTasks/new',{templateUrl:'views/ProjectTask/detail.html',controller:'NewProjectTaskController'})
      .when('/ProjectTasks/edit/:ProjectTaskId',{templateUrl:'views/ProjectTask/detail.html',controller:'EditProjectTaskController'})
      .when('/Schedules',{templateUrl:'views/Schedule/search.html',controller:'SearchScheduleController'})
      .when('/Schedules/new',{templateUrl:'views/Schedule/detail.html',controller:'NewScheduleController'})
      .when('/Schedules/edit/:ScheduleId',{templateUrl:'views/Schedule/detail.html',controller:'EditScheduleController'})
      .when('/TaskTypes',{templateUrl:'views/TaskType/search.html',controller:'SearchTaskTypeController'})
      .when('/TaskTypes/new',{templateUrl:'views/TaskType/detail.html',controller:'NewTaskTypeController'})
      .when('/TaskTypes/edit/:TaskTypeId',{templateUrl:'views/TaskType/detail.html',controller:'EditTaskTypeController'})
      .when('/TimeOffs',{templateUrl:'views/TimeOff/search.html',controller:'SearchTimeOffController'})
      .when('/TimeOffs/new',{templateUrl:'views/TimeOff/detail.html',controller:'NewTimeOffController'})
      .when('/TimeOffs/edit/:TimeOffId',{templateUrl:'views/TimeOff/detail.html',controller:'EditTimeOffController'})
      .when('/TimeOffReasons',{templateUrl:'views/TimeOffReason/search.html',controller:'SearchTimeOffReasonController'})
      .when('/TimeOffReasons/new',{templateUrl:'views/TimeOffReason/detail.html',controller:'NewTimeOffReasonController'})
      .when('/TimeOffReasons/edit/:TimeOffReasonId',{templateUrl:'views/TimeOffReason/detail.html',controller:'EditTimeOffReasonController'})
      .when('/TimeSheets',{templateUrl:'views/TimeSheet/search.html',controller:'SearchTimeSheetController'})
      .when('/TimeSheets/new',{templateUrl:'views/TimeSheet/detail.html',controller:'NewTimeSheetController'})
      .when('/TimeSheets/edit/:TimeSheetId',{templateUrl:'views/TimeSheet/detail.html',controller:'EditTimeSheetController'})
      .when('/Timeshifts',{templateUrl:'views/Timeshift/search.html',controller:'SearchTimeshiftController'})
      .when('/Timeshifts/new',{templateUrl:'views/Timeshift/detail.html',controller:'NewTimeshiftController'})
      .when('/Timeshifts/edit/:TimeshiftId',{templateUrl:'views/Timeshift/detail.html',controller:'EditTimeshiftController'})
      .when('/Users',{templateUrl:'views/User/search.html',controller:'SearchUserController'})
      .when('/Users/new',{templateUrl:'views/User/detail.html',controller:'NewUserController'})
      .when('/Users/edit/:UserId',{templateUrl:'views/User/detail.html',controller:'EditUserController'})
      .when('/Weekdays',{templateUrl:'views/Weekday/search.html',controller:'SearchWeekdayController'})
      .when('/Weekdays/new',{templateUrl:'views/Weekday/detail.html',controller:'NewWeekdayController'})
      .when('/Weekdays/edit/:WeekdayId',{templateUrl:'views/Weekday/detail.html',controller:'EditWeekdayController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
