
angular.module('employeetimetrackerangularjs').controller('NewScheduleController', function ($scope, $location, locationParser, ScheduleResource , UserResource, DayAndTimeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.schedule = $scope.schedule || {};
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.schedule.user = {};
            $scope.schedule.user.id = selection.value;
        }
    });
    
    $scope.dayAndTimesList = DayAndTimeResource.queryAll(function(items){
        $scope.dayAndTimesSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : (new Date(item.startTime)).toISOString().replace('T',' ').replace(':00.000Z','')+" - "+(new Date(item.endTime)).toISOString().replace('T',' ').replace(':00.000Z','')
            });
        });
    });
    $scope.$watch("dayAndTimesSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.schedule.dayAndTimes = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.schedule.dayAndTimes.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Schedules/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ScheduleResource.save($scope.schedule, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Schedules");
    };
});