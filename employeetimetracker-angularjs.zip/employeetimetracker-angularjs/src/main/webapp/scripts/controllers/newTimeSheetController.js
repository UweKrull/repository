
angular.module('employeetimetrackerangularjs').controller('NewTimeSheetController', function ($scope, $location, locationParser, TimeSheetResource , UserResource, ProjectTaskResource, ActivityTypeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.timeSheet = $scope.timeSheet || {};
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.timeSheet.user = {};
            $scope.timeSheet.user.id = selection.value;
        }
    });
    
    $scope.projectTasksList = ProjectTaskResource.queryAll(function(items){
        $scope.projectTasksSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.startOn+' '+item.name
            });
        });
    });
    $scope.$watch("projectTasksSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timeSheet.projectTasks = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.timeSheet.projectTasks.push(collectionItem);
            });
        }
    });
    
    $scope.activityTypeList = ActivityTypeResource.queryAll(function(items){
        $scope.activityTypeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("activityTypeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.timeSheet.activityType = {};
            $scope.timeSheet.activityType.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/TimeSheets/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TimeSheetResource.save($scope.timeSheet, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/TimeSheets");
    };
});