

angular.module('employeetimetrackerangularjs').controller('EditTimeOffReasonController', function($scope, $routeParams, $location, TimeOffReasonResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.timeOffReason = new TimeOffReasonResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/TimeOffReasons");
        };
        TimeOffReasonResource.get({TimeOffReasonId:$routeParams.TimeOffReasonId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.timeOffReason);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.timeOffReason.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/TimeOffReasons");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/TimeOffReasons");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.timeOffReason.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});