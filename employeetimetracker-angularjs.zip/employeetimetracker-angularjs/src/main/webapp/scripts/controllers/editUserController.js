

angular.module('employeetimetrackerangularjs').controller('EditUserController', function($scope, $routeParams, $location, UserResource , ProjectResource, TimeSheetResource, TimeOffResource, ScheduleResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.user = new UserResource(self.original);
            ProjectResource.queryAll(function(items) {
                $scope.projectSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.startOn+' '+item.name
                    };
                    if($scope.user.project){
                        $.each($scope.user.project, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.projectSelection.push(labelObject);
                                $scope.user.project.push(wrappedObject);
                            }
                        });
                        self.original.project = $scope.user.project;
                    }
                    return labelObject;
                });
            });
            TimeSheetResource.queryAll(function(items) {
                $scope.timeSheetSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.startedAt+' '+item.activityType.name
                    };
                    if($scope.user.timeSheet){
                        $.each($scope.user.timeSheet, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.timeSheetSelection.push(labelObject);
                                $scope.user.timeSheet.push(wrappedObject);
                            }
                        });
                        self.original.timeSheet = $scope.user.timeSheet;
                    }
                    return labelObject;
                });
            });
            TimeOffResource.queryAll(function(items) {
                $scope.timeOffSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : (new Date(item.fromDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')+" - "+(new Date(item.toDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')
                    };
                    if($scope.user.timeOff){
                        $.each($scope.user.timeOff, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.timeOffSelection.push(labelObject);
                                $scope.user.timeOff.push(wrappedObject);
                            }
                        });
                        self.original.timeOff = $scope.user.timeOff;
                    }
                    return labelObject;
                });
            });
            ScheduleResource.queryAll(function(items) {
                $scope.scheduleSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : (new Date(item.startDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')+" - "+(new Date(item.endDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')
                    };
                    if($scope.user.schedule){
                        $.each($scope.user.schedule, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.scheduleSelection.push(labelObject);
                                $scope.user.schedule.push(wrappedObject);
                            }
                        });
                        self.original.schedule = $scope.user.schedule;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.user.address.country && item.id == $scope.user.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.user.address.country = wrappedObject;
                        self.original.address.country = $scope.user.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Users");
        };
        UserResource.get({UserId:$routeParams.UserId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.user);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.user.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Users");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Users");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.user.$remove(successCallback, errorCallback);
    };
    
    $scope.projectSelection = $scope.projectSelection || [];
    $scope.$watch("projectSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.user) {
            $scope.user.project = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.project.push(collectionItem);
            });
        }
    });
    $scope.timeSheetSelection = $scope.timeSheetSelection || [];
    $scope.$watch("timeSheetSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.user) {
            $scope.user.timeSheet = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.timeSheet.push(collectionItem);
            });
        }
    });
    $scope.timeOffSelection = $scope.timeOffSelection || [];
    $scope.$watch("timeOffSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.user) {
            $scope.user.timeOff = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.timeOff.push(collectionItem);
            });
        }
    });
    $scope.scheduleSelection = $scope.scheduleSelection || [];
    $scope.$watch("scheduleSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.user) {
            $scope.user.schedule = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.schedule.push(collectionItem);
            });
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.user.address.country = {};
            $scope.user.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});