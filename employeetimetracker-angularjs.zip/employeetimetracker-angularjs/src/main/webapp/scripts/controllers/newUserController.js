
angular.module('employeetimetrackerangularjs').controller('NewUserController', function ($scope, $location, locationParser, UserResource , ProjectResource, TimeSheetResource, TimeOffResource, ScheduleResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.user = $scope.user || {};
    
    $scope.projectList = ProjectResource.queryAll(function(items){
        $scope.projectSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.startOn+' '+item.name
            });
        });
    });
    $scope.$watch("projectSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.user.project = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.project.push(collectionItem);
            });
        }
    });
    
    $scope.timeSheetList = TimeSheetResource.queryAll(function(items){
        $scope.timeSheetSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.startedAt+' '+item.activityType.name
            });
        });
    });
    $scope.$watch("timeSheetSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.user.timeSheet = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.timeSheet.push(collectionItem);
            });
        }
    });
    
    $scope.timeOffList = TimeOffResource.queryAll(function(items){
        $scope.timeOffSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : (new Date(item.fromDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')+" - "+(new Date(item.toDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')
            });
        });
    });
    $scope.$watch("timeOffSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.user.timeOff = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.timeOff.push(collectionItem);
            });
        }
    });
    
    $scope.scheduleList = ScheduleResource.queryAll(function(items){
        $scope.scheduleSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : (new Date(item.startDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')+" - "+(new Date(item.endDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')
            });
        });
    });
    $scope.$watch("scheduleSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.user.schedule = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.user.schedule.push(collectionItem);
            });
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.user.address.country = {};
            $scope.user.address.country.id = selection.value;
        }
    });
    
    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Users/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        UserResource.save($scope.user, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Users");
    };
});