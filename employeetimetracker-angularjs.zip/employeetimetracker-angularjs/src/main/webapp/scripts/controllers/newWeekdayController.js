
angular.module('employeetimetrackerangularjs').controller('NewWeekdayController', function ($scope, $location, locationParser, WeekdayResource , DayAndTimeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.weekday = $scope.weekday || {};
    
    $scope.dayAndTimeList = DayAndTimeResource.queryAll(function(items){
        $scope.dayAndTimeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.startTime
            });
        });
    });
    $scope.$watch("dayAndTimeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.weekday.dayAndTime = {};
            $scope.weekday.dayAndTime.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Weekdays/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        WeekdayResource.save($scope.weekday, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Weekdays");
    };
});