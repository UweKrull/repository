

angular.module('employeetimetrackerangularjs').controller('EditScheduleController', function($scope, $routeParams, $location, ScheduleResource , UserResource, DayAndTimeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.schedule = new ScheduleResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.schedule.user && item.id == $scope.schedule.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.schedule.user = wrappedObject;
                        self.original.user = $scope.schedule.user;
                    }
                    return labelObject;
                });
            });
            DayAndTimeResource.queryAll(function(items) {
                $scope.dayAndTimesSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : (new Date(item.startTime)).toISOString().replace('T',' ').replace(':00.000Z','')+" - "+(new Date(item.endTime)).toISOString().replace('T',' ').replace(':00.000Z','')
                    };
                    if($scope.schedule.dayAndTimes){
                        $.each($scope.schedule.dayAndTimes, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.dayAndTimesSelection.push(labelObject);
                                $scope.schedule.dayAndTimes.push(wrappedObject);
                            }
                        });
                        self.original.dayAndTimes = $scope.schedule.dayAndTimes;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Schedules");
        };
        ScheduleResource.get({ScheduleId:$routeParams.ScheduleId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.schedule);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.schedule.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Schedules");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Schedules");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.schedule.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.schedule.user = {};
            $scope.schedule.user.id = selection.value;
        }
    });
    $scope.dayAndTimesSelection = $scope.dayAndTimesSelection || [];
    $scope.$watch("dayAndTimesSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.schedule) {
            $scope.schedule.dayAndTimes = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.schedule.dayAndTimes.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});