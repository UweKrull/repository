

angular.module('employeetimetrackerangularjs').controller('EditProjectController', function($scope, $routeParams, $location, ProjectResource , UserResource, ProjectTaskResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.project = new ProjectResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.project.user && item.id == $scope.project.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.project.user = wrappedObject;
                        self.original.user = $scope.project.user;
                    }
                    return labelObject;
                });
            });
            ProjectTaskResource.queryAll(function(items) {
                $scope.projectTasksSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.startOn+' '+item.name
                    };
                    if($scope.project.projectTasks){
                        $.each($scope.project.projectTasks, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.projectTasksSelection.push(labelObject);
                                $scope.project.projectTasks.push(wrappedObject);
                            }
                        });
                        self.original.projectTasks = $scope.project.projectTasks;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Projects");
        };
        ProjectResource.get({ProjectId:$routeParams.ProjectId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.project);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.project.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Projects");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Projects");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.project.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.project.user = {};
            $scope.project.user.id = selection.value;
        }
    });
    $scope.projectTasksSelection = $scope.projectTasksSelection || [];
    $scope.$watch("projectTasksSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.project) {
            $scope.project.projectTasks = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.project.projectTasks.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});