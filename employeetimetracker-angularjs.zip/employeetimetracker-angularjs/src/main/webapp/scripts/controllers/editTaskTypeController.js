

angular.module('employeetimetrackerangularjs').controller('EditTaskTypeController', function($scope, $routeParams, $location, TaskTypeResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.taskType = new TaskTypeResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/TaskTypes");
        };
        TaskTypeResource.get({TaskTypeId:$routeParams.TaskTypeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.taskType);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.taskType.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/TaskTypes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/TaskTypes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.taskType.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});