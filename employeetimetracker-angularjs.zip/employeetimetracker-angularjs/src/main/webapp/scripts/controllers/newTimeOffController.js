
angular.module('employeetimetrackerangularjs').controller('NewTimeOffController', function ($scope, $location, locationParser, TimeOffResource , UserResource, TimeOffReasonResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.timeOff = $scope.timeOff || {};
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.timeOff.user = {};
            $scope.timeOff.user.id = selection.value;
        }
    });
    
    $scope.timeOffReasonList = TimeOffReasonResource.queryAll(function(items){
        $scope.timeOffReasonSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("timeOffReasonSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.timeOff.timeOffReason = {};
            $scope.timeOff.timeOffReason.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/TimeOffs/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TimeOffResource.save($scope.timeOff, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/TimeOffs");
    };
});