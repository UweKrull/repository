

angular.module('employeetimetrackerangularjs').controller('EditTimeOffController', function($scope, $routeParams, $location, TimeOffResource , UserResource, TimeOffReasonResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.timeOff = new TimeOffResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.timeOff.user && item.id == $scope.timeOff.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.timeOff.user = wrappedObject;
                        self.original.user = $scope.timeOff.user;
                    }
                    return labelObject;
                });
            });
            TimeOffReasonResource.queryAll(function(items) {
                $scope.timeOffReasonSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.timeOff.timeOffReason && item.id == $scope.timeOff.timeOffReason.id) {
                        $scope.timeOffReasonSelection = labelObject;
                        $scope.timeOff.timeOffReason = wrappedObject;
                        self.original.timeOffReason = $scope.timeOff.timeOffReason;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/TimeOffs");
        };
        TimeOffResource.get({TimeOffId:$routeParams.TimeOffId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.timeOff);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.timeOff.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/TimeOffs");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/TimeOffs");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.timeOff.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timeOff.user = {};
            $scope.timeOff.user.id = selection.value;
        }
    });
    $scope.$watch("timeOffReasonSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timeOff.timeOffReason = {};
            $scope.timeOff.timeOffReason.id = selection.value;
        }
    });
    
    $scope.get();
});