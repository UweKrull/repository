
angular.module('employeetimetrackerangularjs').controller('NewProjectTaskController', function ($scope, $location, locationParser, ProjectTaskResource , TaskTypeResource, ProjectResource, TimeSheetResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.projectTask = $scope.projectTask || {};
    
    $scope.tasktypeList = TaskTypeResource.queryAll(function(items){
        $scope.tasktypeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("tasktypeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.projectTask.tasktype = {};
            $scope.projectTask.tasktype.id = selection.value;
        }
    });
    
    $scope.projectList = ProjectResource.queryAll(function(items){
        $scope.projectSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.startOn+' '+item.name
            });
        });
    });
    $scope.$watch("projectSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.projectTask.project = {};
            $scope.projectTask.project.id = selection.value;
        }
    });
    
    $scope.timeSheetList = TimeSheetResource.queryAll(function(items){
        $scope.timeSheetSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.startedAt+' '+item.activityType.name
            });
        });
    });
    $scope.$watch("timeSheetSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.projectTask.timeSheet = {};
            $scope.projectTask.timeSheet.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/ProjectTasks/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ProjectTaskResource.save($scope.projectTask, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/ProjectTasks");
    };
});