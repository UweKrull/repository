
angular.module('employeetimetrackerangularjs').controller('NewProjectController', function ($scope, $location, locationParser, ProjectResource , UserResource, ProjectTaskResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.project = $scope.project || {};
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.project.user = {};
            $scope.project.user.id = selection.value;
        }
    });
    
    $scope.projectTasksList = ProjectTaskResource.queryAll(function(items){
        $scope.projectTasksSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.startOn+' '+item.name
            });
        });
    });
    $scope.$watch("projectTasksSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.project.projectTasks = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.project.projectTasks.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Projects/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ProjectResource.save($scope.project, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Projects");
    };
});