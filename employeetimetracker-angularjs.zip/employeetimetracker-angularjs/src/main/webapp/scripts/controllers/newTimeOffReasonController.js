
angular.module('employeetimetrackerangularjs').controller('NewTimeOffReasonController', function ($scope, $location, locationParser, TimeOffReasonResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.timeOffReason = $scope.timeOffReason || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/TimeOffReasons/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TimeOffReasonResource.save($scope.timeOffReason, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/TimeOffReasons");
    };
});