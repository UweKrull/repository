

angular.module('employeetimetrackerangularjs').controller('EditDayAndTimeController', function($scope, $routeParams, $location, DayAndTimeResource , TimeshiftResource, ScheduleResource, WeekdayResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.dayAndTime = new DayAndTimeResource(self.original);
            TimeshiftResource.queryAll(function(items) {
                $scope.timeshiftSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.dayAndTime.timeshift && item.id == $scope.dayAndTime.timeshift.id) {
                        $scope.timeshiftSelection = labelObject;
                        $scope.dayAndTime.timeshift = wrappedObject;
                        self.original.timeshift = $scope.dayAndTime.timeshift;
                    }
                    return labelObject;
                });
            });
            ScheduleResource.queryAll(function(items) {
                $scope.scheduleSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : (new Date(item.startDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')+" - "+(new Date(item.endDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')
                    };
                    if($scope.dayAndTime.schedule && item.id == $scope.dayAndTime.schedule.id) {
                        $scope.scheduleSelection = labelObject;
                        $scope.dayAndTime.schedule = wrappedObject;
                        self.original.schedule = $scope.dayAndTime.schedule;
                    }
                    return labelObject;
                });
            });
            WeekdayResource.queryAll(function(items) {
                $scope.daySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.dayAndTime.day && item.id == $scope.dayAndTime.day.id) {
                        $scope.daySelection = labelObject;
                        $scope.dayAndTime.day = wrappedObject;
                        self.original.day = $scope.dayAndTime.day;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/DayAndTimes");
        };
        DayAndTimeResource.get({DayAndTimeId:$routeParams.DayAndTimeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.dayAndTime);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.dayAndTime.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/DayAndTimes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/DayAndTimes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.dayAndTime.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("timeshiftSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dayAndTime.timeshift = {};
            $scope.dayAndTime.timeshift.id = selection.value;
        }
    });
    $scope.$watch("scheduleSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dayAndTime.schedule = {};
            $scope.dayAndTime.schedule.id = selection.value;
        }
    });
    $scope.$watch("daySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.dayAndTime.day = {};
            $scope.dayAndTime.day.id = selection.value;
        }
    });
    
    $scope.get();
});