
angular.module('employeetimetrackerangularjs').controller('NewDayAndTimeController', function ($scope, $location, locationParser, DayAndTimeResource , TimeshiftResource, ScheduleResource, WeekdayResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.dayAndTime = $scope.dayAndTime || {};
    
    $scope.timeshiftList = TimeshiftResource.queryAll(function(items){
        $scope.timeshiftSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("timeshiftSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.dayAndTime.timeshift = {};
            $scope.dayAndTime.timeshift.id = selection.value;
        }
    });
    
    $scope.scheduleList = ScheduleResource.queryAll(function(items){
        $scope.scheduleSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : (new Date(item.startDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')+" - "+(new Date(item.endDateTime)).toISOString().replace('T',' ').replace(':00.000Z','')
            });
        });
    });
    $scope.$watch("scheduleSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.dayAndTime.schedule = {};
            $scope.dayAndTime.schedule.id = selection.value;
        }
    });
    
    $scope.dayList = WeekdayResource.queryAll(function(items){
        $scope.daySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("daySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.dayAndTime.day = {};
            $scope.dayAndTime.day.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/DayAndTimes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        DayAndTimeResource.save($scope.dayAndTime, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/DayAndTimes");
    };
});