
angular.module('employeetimetrackerangularjs').controller('NewTimeshiftController', function ($scope, $location, locationParser, TimeshiftResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.timeshift = $scope.timeshift || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Timeshifts/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TimeshiftResource.save($scope.timeshift, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Timeshifts");
    };
});