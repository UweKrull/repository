

angular.module('employeetimetrackerangularjs').controller('EditTimeSheetController', function($scope, $routeParams, $location, TimeSheetResource , UserResource, ProjectTaskResource, ActivityTypeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.timeSheet = new TimeSheetResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.timeSheet.user && item.id == $scope.timeSheet.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.timeSheet.user = wrappedObject;
                        self.original.user = $scope.timeSheet.user;
                    }
                    return labelObject;
                });
            });
            ProjectTaskResource.queryAll(function(items) {
                $scope.projectTasksSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.startOn+' '+item.name
                    };
                    if($scope.timeSheet.projectTasks){
                        $.each($scope.timeSheet.projectTasks, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.projectTasksSelection.push(labelObject);
                                $scope.timeSheet.projectTasks.push(wrappedObject);
                            }
                        });
                        self.original.projectTasks = $scope.timeSheet.projectTasks;
                    }
                    return labelObject;
                });
            });
            ActivityTypeResource.queryAll(function(items) {
                $scope.activityTypeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.timeSheet.activityType && item.id == $scope.timeSheet.activityType.id) {
                        $scope.activityTypeSelection = labelObject;
                        $scope.timeSheet.activityType = wrappedObject;
                        self.original.activityType = $scope.timeSheet.activityType;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/TimeSheets");
        };
        TimeSheetResource.get({TimeSheetId:$routeParams.TimeSheetId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.timeSheet);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.timeSheet.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/TimeSheets");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/TimeSheets");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.timeSheet.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timeSheet.user = {};
            $scope.timeSheet.user.id = selection.value;
        }
    });
    $scope.projectTasksSelection = $scope.projectTasksSelection || [];
    $scope.$watch("projectTasksSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.timeSheet) {
            $scope.timeSheet.projectTasks = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.timeSheet.projectTasks.push(collectionItem);
            });
        }
    });
    $scope.$watch("activityTypeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timeSheet.activityType = {};
            $scope.timeSheet.activityType.id = selection.value;
        }
    });
    
    $scope.get();
});