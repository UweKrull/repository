

angular.module('employeetimetrackerangularjs').controller('EditProjectTaskController', function($scope, $routeParams, $location, ProjectTaskResource , TaskTypeResource, ProjectResource, TimeSheetResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.projectTask = new ProjectTaskResource(self.original);
            TaskTypeResource.queryAll(function(items) {
                $scope.tasktypeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.projectTask.tasktype && item.id == $scope.projectTask.tasktype.id) {
                        $scope.tasktypeSelection = labelObject;
                        $scope.projectTask.tasktype = wrappedObject;
                        self.original.tasktype = $scope.projectTask.tasktype;
                    }
                    return labelObject;
                });
            });
            ProjectResource.queryAll(function(items) {
                $scope.projectSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.startOn+' '+item.name
                    };
                    if($scope.projectTask.project && item.id == $scope.projectTask.project.id) {
                        $scope.projectSelection = labelObject;
                        $scope.projectTask.project = wrappedObject;
                        self.original.project = $scope.projectTask.project;
                    }
                    return labelObject;
                });
            });
            TimeSheetResource.queryAll(function(items) {
                $scope.timeSheetSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.startedAt+' '+item.activityType.name
                    };
                    if($scope.projectTask.timeSheet && item.id == $scope.projectTask.timeSheet.id) {
                        $scope.timeSheetSelection = labelObject;
                        $scope.projectTask.timeSheet = wrappedObject;
                        self.original.timeSheet = $scope.projectTask.timeSheet;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/ProjectTasks");
        };
        ProjectTaskResource.get({ProjectTaskId:$routeParams.ProjectTaskId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.projectTask);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.projectTask.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/ProjectTasks");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/ProjectTasks");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.projectTask.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("tasktypeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.projectTask.tasktype = {};
            $scope.projectTask.tasktype.id = selection.value;
        }
    });
    $scope.$watch("projectSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.projectTask.project = {};
            $scope.projectTask.project.id = selection.value;
        }
    });
    $scope.$watch("timeSheetSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.projectTask.timeSheet = {};
            $scope.projectTask.timeSheet.id = selection.value;
        }
    });
    
    $scope.get();
});