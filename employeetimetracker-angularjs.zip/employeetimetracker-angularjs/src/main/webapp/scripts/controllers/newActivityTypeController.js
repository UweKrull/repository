
angular.module('employeetimetrackerangularjs').controller('NewActivityTypeController', function ($scope, $location, locationParser, ActivityTypeResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.activityType = $scope.activityType || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/ActivityTypes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ActivityTypeResource.save($scope.activityType, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/ActivityTypes");
    };
});