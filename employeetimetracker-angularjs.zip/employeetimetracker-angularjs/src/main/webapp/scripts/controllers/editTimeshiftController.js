

angular.module('employeetimetrackerangularjs').controller('EditTimeshiftController', function($scope, $routeParams, $location, TimeshiftResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.timeshift = new TimeshiftResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Timeshifts");
        };
        TimeshiftResource.get({TimeshiftId:$routeParams.TimeshiftId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.timeshift);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.timeshift.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Timeshifts");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Timeshifts");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.timeshift.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});