
angular.module('employeetimetrackerangularjs').controller('NewTaskTypeController', function ($scope, $location, locationParser, TaskTypeResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.taskType = $scope.taskType || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/TaskTypes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TaskTypeResource.save($scope.taskType, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/TaskTypes");
    };
});