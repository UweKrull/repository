

angular.module('employeetimetrackerangularjs').controller('EditWeekdayController', function($scope, $routeParams, $location, WeekdayResource , DayAndTimeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.weekday = new WeekdayResource(self.original);
            DayAndTimeResource.queryAll(function(items) {
                $scope.dayAndTimeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.startTime
                    };
                    if($scope.weekday.dayAndTime && item.id == $scope.weekday.dayAndTime.id) {
                        $scope.dayAndTimeSelection = labelObject;
                        $scope.weekday.dayAndTime = wrappedObject;
                        self.original.dayAndTime = $scope.weekday.dayAndTime;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Weekdays");
        };
        WeekdayResource.get({WeekdayId:$routeParams.WeekdayId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.weekday);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.weekday.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Weekdays");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Weekdays");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.weekday.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("dayAndTimeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.weekday.dayAndTime = {};
            $scope.weekday.dayAndTime.id = selection.value;
        }
    });
    
    $scope.get();
});