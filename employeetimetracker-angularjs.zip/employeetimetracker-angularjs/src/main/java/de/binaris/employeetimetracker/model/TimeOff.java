package de.binaris.employeetimetracker.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * An TimeOff may consist of one or more projectTasks.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "time_off")
public class TimeOff implements Serializable {

	private static final long serialVersionUID = 7275923592719262915L;

	/**
	 * The ID of the TimeOff.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_time_off")
	@SequenceGenerator(name = "my_entity_seq_gen_time_off", sequenceName = "sequence_time_off", allocationSize = 1)
	private Long id;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "from_date_time", updatable = true)
	private Date fromDateTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "to_date_time", updatable = true)
	private Date toDateTime;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private User user;

	@ManyToOne
	private TimeOffReason timeOffReason;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@PrePersist
	private void setDefaultData() {
	}

	public Date getFromDateTime() {
		return fromDateTime;
	}

	public void setFromDateTime(Date fromDateTime) {
		this.fromDateTime = fromDateTime;
	}

	public Date getToDateTime() {
		return toDateTime;
	}
	
	public void setToDateTime(Date toDateTime) {
		this.toDateTime = toDateTime;
	}
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public TimeOffReason getTimeOffReason() {
		return timeOffReason;
	}

	public void setTimeOffReason(TimeOffReason timeOffReason) {
		this.timeOffReason = timeOffReason;
	}
	
	public Float getTotal() {
//		if (projectTasks == null || projectTasks.isEmpty()) {
//			return 0f;
//		}
//		Float sum = 0f;
//		for (ProjectTask projectTask : projectTasks) {
//			sum += (projectTask.getSubTotal());
//			this.hours = sum;
//		}
//		return hours;
		return 0F;
	}

	/*
	 * toString(), equals() and hashCode() for TimeSheet, using the natural
	 * identity of the object
	 */

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof TimeOff)) {
			return false;
		}
		TimeOff castOther = (TimeOff) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append('\'').append(fromDateTime);
		sb.append('\'').append(toDateTime);
		sb.append(", ").append('\'').append(user).append('\'');
		sb.append(", ").append('\'').append(timeOffReason).append('\'');
		return sb.toString();
	}
}
