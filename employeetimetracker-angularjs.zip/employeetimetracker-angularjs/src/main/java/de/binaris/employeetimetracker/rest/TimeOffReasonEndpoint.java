package de.binaris.employeetimetracker.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.employeetimetracker.model.TimeOffReason;
import de.binaris.employeetimetracker.rest.dto.TimeOffReasonDTO;

/**
 * 
 */
@Stateless
@Path("/timeoffreasons")
public class TimeOffReasonEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(TimeOffReasonDTO dto)
   {
      TimeOffReason entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(TimeOffReasonEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      TimeOffReason entity = em.find(TimeOffReason.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<TimeOffReason> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TimeOffReason t WHERE t.id = :entityId ORDER BY t.id", TimeOffReason.class);
      findByIdQuery.setParameter("entityId", id);
      TimeOffReason entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      TimeOffReasonDTO dto = new TimeOffReasonDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<TimeOffReasonDTO> listAll()
   {
      final List<TimeOffReason> searchResults = em.createQuery("SELECT DISTINCT t FROM TimeOffReason t ORDER BY t.id", TimeOffReason.class).getResultList();
      final List<TimeOffReasonDTO> results = new ArrayList<TimeOffReasonDTO>();
      for (TimeOffReason searchResult : searchResults)
      {
         TimeOffReasonDTO dto = new TimeOffReasonDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, TimeOffReasonDTO dto)
   {
      TypedQuery<TimeOffReason> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TimeOffReason t WHERE t.id = :entityId ORDER BY t.id", TimeOffReason.class);
      findByIdQuery.setParameter("entityId", id);
      TimeOffReason entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}