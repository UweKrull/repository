package de.binaris.employeetimetracker.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>
 * An Schedule may consist of one or more dayAndTime periods.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "schedule")
public class Schedule implements Serializable {

	private static final long serialVersionUID = 3212323756789162915L;

	/**
	 * The ID of the Schedule.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_schedule")
	@SequenceGenerator(name = "my_entity_seq_gen_schedule", sequenceName = "sequence_schedule", allocationSize = 1)
	private Long id;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_date_time", updatable = true)
	private Date startDateTime;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_date_time", updatable = true)
	private Date endDateTime;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private User user;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "schedule")
	private Set<DayAndTime> dayAndTimes = new HashSet<DayAndTime>();

	@NotNull
	@Size(min = 1, max = 10, message = "must be 1-10 letters and spaces")
	private String color;

	@Column(name = "company_code", updatable = true)
	private String companyCode;
	
	@Column(name = "company_name", updatable = true)
	private String companyName;
	
	@NotNull
	@Size(min = 1, max = 60, message = "must be 1-60 letters and spaces")
	private String name;

	private String description;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getStartDateTime() {
		return startDateTime;
	}

	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	public Date getEndDateTime() {
		return endDateTime;
	}
	
	public void setEndDateTime(Date endDateTime) {
		this.endDateTime = endDateTime;
	}
	
	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Set<DayAndTime> getDayAndTimes() {
		return dayAndTimes;
	}

	public void setDayAndTimes(Set<DayAndTime> dayAndTimes) {
		this.dayAndTimes = dayAndTimes;
	}
	
	/*
	 * toString(), equals() and hashCode() for Schedule, using the natural
	 * identity of the object
	 */

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Schedule)) {
			return false;
		}
		Schedule castOther = (Schedule) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append('\'').append(startDateTime.toString());
		sb.append('\'').append(endDateTime.toString());
		sb.append(", ").append('\'').append(user.getLastName()).append(", ").append(user.getFirstName()).append(" ").append(user.getMiddleName()).append('\'');
		return sb.toString();
	}
}
