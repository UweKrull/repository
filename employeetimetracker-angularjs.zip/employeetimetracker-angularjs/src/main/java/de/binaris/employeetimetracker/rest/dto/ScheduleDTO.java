package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.Schedule;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.employeetimetracker.model.DayAndTime;
import de.binaris.employeetimetracker.rest.dto.NestedDayAndTimeDTO;
import de.binaris.employeetimetracker.rest.dto.NestedUserDTO;

import java.util.Iterator;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ScheduleDTO implements Serializable
{

   private Long id;
   private Set<NestedDayAndTimeDTO> dayAndTimes = new HashSet<NestedDayAndTimeDTO>();
   private Date startDateTime;
   private String description;
   private String name;
   private NestedUserDTO user;
   private Date endDateTime;

   public ScheduleDTO()
   {
   }

   public ScheduleDTO(final Schedule entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         Iterator<DayAndTime> iterDayAndTimes = entity.getDayAndTimes()
               .iterator();
         for (; iterDayAndTimes.hasNext();)
         {
            DayAndTime element = iterDayAndTimes.next();
            this.dayAndTimes.add(new NestedDayAndTimeDTO(element));
         }
         this.startDateTime = entity.getStartDateTime();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.user = new NestedUserDTO(entity.getUser());
         this.endDateTime = entity.getEndDateTime();
      }
   }

   public Schedule fromDTO(Schedule entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Schedule();
      }
      Iterator<DayAndTime> iterDayAndTimes = entity.getDayAndTimes()
            .iterator();
      for (; iterDayAndTimes.hasNext();)
      {
         boolean found = false;
         DayAndTime dayAndTime = iterDayAndTimes.next();
         Iterator<NestedDayAndTimeDTO> iterDtoDayAndTimes = this
               .getDayAndTimes().iterator();
         for (; iterDtoDayAndTimes.hasNext();)
         {
            NestedDayAndTimeDTO dtoDayAndTime = iterDtoDayAndTimes.next();
            if (dtoDayAndTime.getId().equals(dayAndTime.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterDayAndTimes.remove();
         }
      }
      Iterator<NestedDayAndTimeDTO> iterDtoDayAndTimes = this
            .getDayAndTimes().iterator();
      for (; iterDtoDayAndTimes.hasNext();)
      {
         boolean found = false;
         NestedDayAndTimeDTO dtoDayAndTime = iterDtoDayAndTimes.next();
         iterDayAndTimes = entity.getDayAndTimes().iterator();
         for (; iterDayAndTimes.hasNext();)
         {
            DayAndTime dayAndTime = iterDayAndTimes.next();
            if (dtoDayAndTime.getId().equals(dayAndTime.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<DayAndTime> resultIter = em
                  .createQuery("SELECT DISTINCT d FROM DayAndTime d",
                        DayAndTime.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               DayAndTime result = resultIter.next();
               if (result.getId().equals(dtoDayAndTime.getId()))
               {
                  entity.getDayAndTimes().add(result);
                  break;
               }
            }
         }
      }
      entity.setStartDateTime(this.startDateTime);
      entity.setDescription(this.description);
      entity.setName(this.name);
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity.setEndDateTime(this.endDateTime);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedDayAndTimeDTO> getDayAndTimes()
   {
      return this.dayAndTimes;
   }

   public void setDayAndTimes(final Set<NestedDayAndTimeDTO> dayAndTimes)
   {
      this.dayAndTimes = dayAndTimes;
   }

   public Date getStartDateTime()
   {
      return this.startDateTime;
   }

   public void setStartDateTime(final Date startDateTime)
   {
      this.startDateTime = startDateTime;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }

   public Date getEndDateTime()
   {
      return this.endDateTime;
   }

   public void setEndDateTime(final Date endDateTime)
   {
      this.endDateTime = endDateTime;
   }
}