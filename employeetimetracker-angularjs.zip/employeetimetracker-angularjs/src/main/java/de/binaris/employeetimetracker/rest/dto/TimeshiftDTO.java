package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;
import de.binaris.employeetimetracker.model.Timeshift;
import javax.persistence.EntityManager;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TimeshiftDTO implements Serializable
{

   private Date startTime;
   private Long id;
   private String description;
   private String name;
   private Date endTime;

   public TimeshiftDTO()
   {
   }

   public TimeshiftDTO(final Timeshift entity)
   {
      if (entity != null)
      {
         this.startTime = entity.getStartTime();
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.endTime = entity.getEndTime();
      }
   }

   public Timeshift fromDTO(Timeshift entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Timeshift();
      }
      entity.setStartTime(this.startTime);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setEndTime(this.endTime);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartTime()
   {
      return this.startTime;
   }

   public void setStartTime(final Date startTime)
   {
      this.startTime = startTime;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Date getEndTime()
   {
      return this.endTime;
   }

   public void setEndTime(final Date endTime)
   {
      this.endTime = endTime;
   }
}