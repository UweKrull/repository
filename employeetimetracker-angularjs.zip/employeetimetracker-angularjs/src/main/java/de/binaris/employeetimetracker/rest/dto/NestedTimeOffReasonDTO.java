package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;
import de.binaris.employeetimetracker.model.TimeOffReason;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedTimeOffReasonDTO implements Serializable
{

   private Long id;
   private String color;
   private String description;
   private String name;

   public NestedTimeOffReasonDTO()
   {
   }

   public NestedTimeOffReasonDTO(final TimeOffReason entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.color = entity.getColor();
         this.description = entity.getDescription();
         this.name = entity.getName();
      }
   }

   public TimeOffReason fromDTO(TimeOffReason entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new TimeOffReason();
      }
      if (this.id != null)
      {
         TypedQuery<TimeOffReason> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT t FROM TimeOffReason t WHERE t.id = :entityId",
                     TimeOffReason.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setColor(this.color);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getColor()
   {
      return this.color;
   }

   public void setColor(final String color)
   {
      this.color = color;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}