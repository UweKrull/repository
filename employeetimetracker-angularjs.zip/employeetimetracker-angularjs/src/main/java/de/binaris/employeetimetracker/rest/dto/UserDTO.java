package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.User;

import javax.persistence.EntityManager;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;

import de.binaris.employeetimetracker.model.Project;

import java.util.Iterator;

import de.binaris.employeetimetracker.model.Schedule;
import de.binaris.employeetimetracker.model.TimeOff;
import de.binaris.employeetimetracker.model.TimeSheet;
import de.binaris.employeetimetracker.rest.dto.AddressDTO;
import de.binaris.employeetimetracker.rest.dto.NestedProjectDTO;
import de.binaris.employeetimetracker.rest.dto.NestedScheduleDTO;
import de.binaris.employeetimetracker.rest.dto.NestedTimeOffDTO;
import de.binaris.employeetimetracker.rest.dto.NestedTimeSheetDTO;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserDTO implements Serializable
{

   private String middleName;
   private Date dateOfBirth;
   private String lastName;
   private String phone;
   private Date dateOfLeave;
   private String password;
   private Long id;
   private Set<NestedProjectDTO> project = new HashSet<NestedProjectDTO>();
   private Set<NestedScheduleDTO> schedule = new HashSet<NestedScheduleDTO>();
   private AddressDTO address;
   private String email;
   private Date dateOfEntry;
   private Set<NestedTimeOffDTO> timeOff = new HashSet<NestedTimeOffDTO>();
   private Set<NestedTimeSheetDTO> timeSheet = new HashSet<NestedTimeSheetDTO>();
   private String login;
   private String firstName;
   private String jobTitle;

   public UserDTO()
   {
   }

   public UserDTO(final User entity)
   {
      if (entity != null)
      {
         this.middleName = entity.getMiddleName();
         this.dateOfBirth = entity.getDateOfBirth();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         this.dateOfLeave = entity.getDateOfLeave();
         this.password = entity.getPassword();
         this.id = entity.getId();
         Iterator<Project> iterProject = entity.getProject().iterator();
         for (; iterProject.hasNext();)
         {
            Project element = iterProject.next();
            this.project.add(new NestedProjectDTO(element));
         }
         Iterator<Schedule> iterSchedule = entity.getSchedule().iterator();
         for (; iterSchedule.hasNext();)
         {
            Schedule element = iterSchedule.next();
            this.schedule.add(new NestedScheduleDTO(element));
         }
         this.address = new AddressDTO(entity.getAddress());
         this.email = entity.getEmail();
         this.dateOfEntry = entity.getDateOfEntry();
         Iterator<TimeOff> iterTimeOff = entity.getTimeOff().iterator();
         for (; iterTimeOff.hasNext();)
         {
            TimeOff element = iterTimeOff.next();
            this.timeOff.add(new NestedTimeOffDTO(element));
         }
         Iterator<TimeSheet> iterTimeSheet = entity.getTimeSheet()
               .iterator();
         for (; iterTimeSheet.hasNext();)
         {
            TimeSheet element = iterTimeSheet.next();
            this.timeSheet.add(new NestedTimeSheetDTO(element));
         }
         this.login = entity.getLogin();
         this.firstName = entity.getFirstName();
         this.jobTitle = entity.getJobTitle();
      }
   }

   public User fromDTO(User entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new User();
      }
      entity.setMiddleName(this.middleName);
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      entity.setDateOfLeave(this.dateOfLeave);
      entity.setPassword(this.password);
      Iterator<Project> iterProject = entity.getProject().iterator();
      for (; iterProject.hasNext();)
      {
         boolean found = false;
         Project project = iterProject.next();
         Iterator<NestedProjectDTO> iterDtoProject = this.getProject()
               .iterator();
         for (; iterDtoProject.hasNext();)
         {
            NestedProjectDTO dtoProject = iterDtoProject.next();
            if (dtoProject.getId().equals(project.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterProject.remove();
         }
      }
      Iterator<NestedProjectDTO> iterDtoProject = this.getProject()
            .iterator();
      for (; iterDtoProject.hasNext();)
      {
         boolean found = false;
         NestedProjectDTO dtoProject = iterDtoProject.next();
         iterProject = entity.getProject().iterator();
         for (; iterProject.hasNext();)
         {
            Project project = iterProject.next();
            if (dtoProject.getId().equals(project.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Project> resultIter = em
                  .createQuery("SELECT DISTINCT p FROM Project p",
                        Project.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Project result = resultIter.next();
               if (result.getId().equals(dtoProject.getId()))
               {
                  entity.getProject().add(result);
                  break;
               }
            }
         }
      }
      Iterator<Schedule> iterSchedule = entity.getSchedule().iterator();
      for (; iterSchedule.hasNext();)
      {
         boolean found = false;
         Schedule schedule = iterSchedule.next();
         Iterator<NestedScheduleDTO> iterDtoSchedule = this.getSchedule()
               .iterator();
         for (; iterDtoSchedule.hasNext();)
         {
            NestedScheduleDTO dtoSchedule = iterDtoSchedule.next();
            if (dtoSchedule.getId().equals(schedule.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterSchedule.remove();
         }
      }
      Iterator<NestedScheduleDTO> iterDtoSchedule = this.getSchedule()
            .iterator();
      for (; iterDtoSchedule.hasNext();)
      {
         boolean found = false;
         NestedScheduleDTO dtoSchedule = iterDtoSchedule.next();
         iterSchedule = entity.getSchedule().iterator();
         for (; iterSchedule.hasNext();)
         {
            Schedule schedule = iterSchedule.next();
            if (dtoSchedule.getId().equals(schedule.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Schedule> resultIter = em
                  .createQuery("SELECT DISTINCT s FROM Schedule s",
                        Schedule.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Schedule result = resultIter.next();
               if (result.getId().equals(dtoSchedule.getId()))
               {
                  entity.getSchedule().add(result);
                  break;
               }
            }
         }
      }
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setEmail(this.email);
      entity.setDateOfEntry(this.dateOfEntry);
      Iterator<TimeOff> iterTimeOff = entity.getTimeOff().iterator();
      for (; iterTimeOff.hasNext();)
      {
         boolean found = false;
         TimeOff timeOff = iterTimeOff.next();
         Iterator<NestedTimeOffDTO> iterDtoTimeOff = this.getTimeOff()
               .iterator();
         for (; iterDtoTimeOff.hasNext();)
         {
            NestedTimeOffDTO dtoTimeOff = iterDtoTimeOff.next();
            if (dtoTimeOff.getId().equals(timeOff.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterTimeOff.remove();
         }
      }
      Iterator<NestedTimeOffDTO> iterDtoTimeOff = this.getTimeOff()
            .iterator();
      for (; iterDtoTimeOff.hasNext();)
      {
         boolean found = false;
         NestedTimeOffDTO dtoTimeOff = iterDtoTimeOff.next();
         iterTimeOff = entity.getTimeOff().iterator();
         for (; iterTimeOff.hasNext();)
         {
            TimeOff timeOff = iterTimeOff.next();
            if (dtoTimeOff.getId().equals(timeOff.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<TimeOff> resultIter = em
                  .createQuery("SELECT DISTINCT t FROM TimeOff t",
                        TimeOff.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               TimeOff result = resultIter.next();
               if (result.getId().equals(dtoTimeOff.getId()))
               {
                  entity.getTimeOff().add(result);
                  break;
               }
            }
         }
      }
      Iterator<TimeSheet> iterTimeSheet = entity.getTimeSheet().iterator();
      for (; iterTimeSheet.hasNext();)
      {
         boolean found = false;
         TimeSheet timeSheet = iterTimeSheet.next();
         Iterator<NestedTimeSheetDTO> iterDtoTimeSheet = this.getTimeSheet()
               .iterator();
         for (; iterDtoTimeSheet.hasNext();)
         {
            NestedTimeSheetDTO dtoTimeSheet = iterDtoTimeSheet.next();
            if (dtoTimeSheet.getId().equals(timeSheet.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterTimeSheet.remove();
         }
      }
      Iterator<NestedTimeSheetDTO> iterDtoTimeSheet = this.getTimeSheet()
            .iterator();
      for (; iterDtoTimeSheet.hasNext();)
      {
         boolean found = false;
         NestedTimeSheetDTO dtoTimeSheet = iterDtoTimeSheet.next();
         iterTimeSheet = entity.getTimeSheet().iterator();
         for (; iterTimeSheet.hasNext();)
         {
            TimeSheet timeSheet = iterTimeSheet.next();
            if (dtoTimeSheet.getId().equals(timeSheet.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<TimeSheet> resultIter = em
                  .createQuery("SELECT DISTINCT t FROM TimeSheet t",
                        TimeSheet.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               TimeSheet result = resultIter.next();
               if (result.getId().equals(dtoTimeSheet.getId()))
               {
                  entity.getTimeSheet().add(result);
                  break;
               }
            }
         }
      }
      entity.setLogin(this.login);
      entity.setFirstName(this.firstName);
      entity.setJobTitle(this.jobTitle);
      entity = em.merge(entity);
      return entity;
   }

   public String getMiddleName()
   {
      return this.middleName;
   }

   public void setMiddleName(final String middleName)
   {
      this.middleName = middleName;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public Date getDateOfLeave()
   {
      return this.dateOfLeave;
   }

   public void setDateOfLeave(final Date dateOfLeave)
   {
      this.dateOfLeave = dateOfLeave;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedProjectDTO> getProject()
   {
      return this.project;
   }

   public void setProject(final Set<NestedProjectDTO> project)
   {
      this.project = project;
   }

   public Set<NestedScheduleDTO> getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final Set<NestedScheduleDTO> schedule)
   {
      this.schedule = schedule;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public Date getDateOfEntry()
   {
      return this.dateOfEntry;
   }

   public void setDateOfEntry(final Date dateOfEntry)
   {
      this.dateOfEntry = dateOfEntry;
   }

   public Set<NestedTimeOffDTO> getTimeOff()
   {
      return this.timeOff;
   }

   public void setTimeOff(final Set<NestedTimeOffDTO> timeOff)
   {
      this.timeOff = timeOff;
   }

   public Set<NestedTimeSheetDTO> getTimeSheet()
   {
      return this.timeSheet;
   }

   public void setTimeSheet(final Set<NestedTimeSheetDTO> timeSheet)
   {
      this.timeSheet = timeSheet;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }

   public String getJobTitle()
   {
      return this.jobTitle;
   }

   public void setJobTitle(final String jobTitle)
   {
      this.jobTitle = jobTitle;
   }
}