package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.TimeOff;
import de.binaris.employeetimetracker.rest.dto.NestedTimeOffReasonDTO;
import de.binaris.employeetimetracker.rest.dto.NestedUserDTO;

import javax.persistence.EntityManager;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TimeOffDTO implements Serializable
{

   private Float total;
   private Long id;
   private Date toDateTime;
   private Date fromDateTime;
   private NestedTimeOffReasonDTO timeOffReason;
   private NestedUserDTO user;

   public TimeOffDTO()
   {
   }

   public TimeOffDTO(final TimeOff entity)
   {
      if (entity != null)
      {
         this.total = entity.getTotal();
         this.id = entity.getId();
         this.toDateTime = entity.getToDateTime();
         this.fromDateTime = entity.getFromDateTime();
         this.timeOffReason = new NestedTimeOffReasonDTO(
               entity.getTimeOffReason());
         this.user = new NestedUserDTO(entity.getUser());
      }
   }

   public TimeOff fromDTO(TimeOff entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new TimeOff();
      }
      entity.setToDateTime(this.toDateTime);
      entity.setFromDateTime(this.fromDateTime);
      if (this.timeOffReason != null)
      {
         entity.setTimeOffReason(this.timeOffReason.fromDTO(
               entity.getTimeOffReason(), em));
      }
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Float getTotal()
   {
      return this.total;
   }

   public void setTotal(final Float total)
   {
      this.total = total;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Date getToDateTime()
   {
      return this.toDateTime;
   }

   public void setToDateTime(final Date toDateTime)
   {
      this.toDateTime = toDateTime;
   }

   public Date getFromDateTime()
   {
      return this.fromDateTime;
   }

   public void setFromDateTime(final Date fromDateTime)
   {
      this.fromDateTime = fromDateTime;
   }

   public NestedTimeOffReasonDTO getTimeOffReason()
   {
      return this.timeOffReason;
   }

   public void setTimeOffReason(final NestedTimeOffReasonDTO timeOffReason)
   {
      this.timeOffReason = timeOffReason;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }
}