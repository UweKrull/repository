package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;
import de.binaris.employeetimetracker.model.Project;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Date;

public class NestedProjectDTO implements Serializable
{

   private Date startOn;
   private Long id;
   private String status;
   private String color;
   private String description;
   private String name;
   private String companyName;
   private String companyCode;

   public NestedProjectDTO()
   {
   }

   public NestedProjectDTO(final Project entity)
   {
      if (entity != null)
      {
         this.startOn = entity.getStartOn();
         this.id = entity.getId();
         this.status = entity.getStatus();
         this.color = entity.getColor();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.companyName = entity.getCompanyName();
         this.companyCode = entity.getCompanyCode();
      }
   }

   public Project fromDTO(Project entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Project();
      }
      if (this.id != null)
      {
         TypedQuery<Project> findByIdQuery = em.createQuery(
               "SELECT DISTINCT p FROM Project p WHERE p.id = :entityId",
               Project.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setStartOn(this.startOn);
      entity.setStatus(this.status);
      entity.setColor(this.color);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setCompanyName(this.companyName);
      entity.setCompanyCode(this.companyCode);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartOn()
   {
      return this.startOn;
   }

   public void setStartOn(final Date startOn)
   {
      this.startOn = startOn;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getStatus()
   {
      return this.status;
   }

   public void setStatus(final String status)
   {
      this.status = status;
   }

   public String getColor()
   {
      return this.color;
   }

   public void setColor(final String color)
   {
      this.color = color;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getCompanyName()
   {
      return this.companyName;
   }

   public void setCompanyName(final String companyName)
   {
      this.companyName = companyName;
   }

   public String getCompanyCode()
   {
      return this.companyCode;
   }

   public void setCompanyCode(final String companyCode)
   {
      this.companyCode = companyCode;
   }
}