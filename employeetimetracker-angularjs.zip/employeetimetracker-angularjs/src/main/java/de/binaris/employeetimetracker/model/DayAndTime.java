package de.binaris.employeetimetracker.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * A DayAndTime may have one Timeshift.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "day_and_time")
public class DayAndTime implements Serializable {

	private static final long serialVersionUID = 5215212375678916915L;

	/**
	 * The ID of the DayAndTime.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_day_and_time")
	@SequenceGenerator(name = "my_entity_seq_gen_day_and_time", sequenceName = "sequence_day_and_time", allocationSize = 1)
	private Long id;

	/**
	 * The timeshift of the DayAndTime.
	 */
	@ManyToOne
	private Timeshift timeshift;

	/**
	 * The schedule of the DayAndTime.
	 */
	@ManyToOne
	private Schedule schedule;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_time", updatable = true)
	private Date startTime;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_time", updatable = true)
	private Date endTime;
	
	/**
	 * The weekday of the DayAndTime.
	 */
	@ManyToOne
	private Weekday day;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Timeshift getTimeshift() {
		return timeshift;
	}

	public void setTimeshift(Timeshift timeshift) {
		this.timeshift = timeshift;
	}
	
	public Schedule getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Weekday getDay() {
		return day;
	}

	public void setDay(Weekday day) {
		this.day = day;
	}
	
	public Float getSubTotal() {
		return 0F;
//		return (taskType != null)? taskType.getUnitCost() * quantity : 0F;
	}

	/*
	 * toString(), equals() and hashCode() for ProjectTask, using the natural
	 * identity of the object
	 */

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof DayAndTime)) {
			return false;
		}
		DayAndTime castOther = (DayAndTime) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append('\'').append(", Schedule:   ").append(getSchedule().toString()).append('\'');
		sb.append('\'').append(", Timeshift:  ").append(getTimeshift().toString()).append('\'');
		sb.append('\'').append(", Start time: ").append(getStartTime().toString()).append('\'');
		sb.append('\'').append(", End time:   ").append(getEndTime().toString()).append('\'');
		sb.append('\'').append(", Weekday:    ").append(getDay().toString()).append('\'');
		return sb.toString();
	}
}
