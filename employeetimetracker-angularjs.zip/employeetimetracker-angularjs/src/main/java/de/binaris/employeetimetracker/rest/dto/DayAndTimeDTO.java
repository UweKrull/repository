package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.DayAndTime;
import de.binaris.employeetimetracker.rest.dto.NestedScheduleDTO;
import de.binaris.employeetimetracker.rest.dto.NestedTimeshiftDTO;
import de.binaris.employeetimetracker.rest.dto.NestedWeekdayDTO;

import javax.persistence.EntityManager;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DayAndTimeDTO implements Serializable
{

   private Date startTime;
   private Long id;
   private NestedScheduleDTO schedule;
   private Float subTotal;
   private NestedTimeshiftDTO timeshift;
   private NestedWeekdayDTO day;
   private Date endTime;

   public DayAndTimeDTO()
   {
   }

   public DayAndTimeDTO(final DayAndTime entity)
   {
      if (entity != null)
      {
         this.startTime = entity.getStartTime();
         this.id = entity.getId();
         this.schedule = new NestedScheduleDTO(entity.getSchedule());
         this.subTotal = entity.getSubTotal();
         this.timeshift = new NestedTimeshiftDTO(entity.getTimeshift());
         this.day = new NestedWeekdayDTO(entity.getDay());
         this.endTime = entity.getEndTime();
      }
   }

   public DayAndTime fromDTO(DayAndTime entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new DayAndTime();
      }
      entity.setStartTime(this.startTime);
      if (this.schedule != null)
      {
         entity.setSchedule(this.schedule.fromDTO(entity.getSchedule(), em));
      }
      if (this.timeshift != null)
      {
         entity.setTimeshift(this.timeshift.fromDTO(entity.getTimeshift(),
               em));
      }
      if (this.day != null)
      {
         entity.setDay(this.day.fromDTO(entity.getDay(), em));
      }
      entity.setEndTime(this.endTime);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartTime()
   {
      return this.startTime;
   }

   public void setStartTime(final Date startTime)
   {
      this.startTime = startTime;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedScheduleDTO getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final NestedScheduleDTO schedule)
   {
      this.schedule = schedule;
   }

   public Float getSubTotal()
   {
      return this.subTotal;
   }

   public void setSubTotal(final Float subTotal)
   {
      this.subTotal = subTotal;
   }

   public NestedTimeshiftDTO getTimeshift()
   {
      return this.timeshift;
   }

   public void setTimeshift(final NestedTimeshiftDTO timeshift)
   {
      this.timeshift = timeshift;
   }

   public NestedWeekdayDTO getDay()
   {
      return this.day;
   }

   public void setDay(final NestedWeekdayDTO day)
   {
      this.day = day;
   }

   public Date getEndTime()
   {
      return this.endTime;
   }

   public void setEndTime(final Date endTime)
   {
      this.endTime = endTime;
   }
}