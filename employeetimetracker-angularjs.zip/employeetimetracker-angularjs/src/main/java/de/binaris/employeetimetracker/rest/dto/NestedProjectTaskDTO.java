package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;
import de.binaris.employeetimetracker.model.ProjectTask;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.Date;

public class NestedProjectTaskDTO implements Serializable
{

   private Date startOn;
   private Long id;
   private Float bidHours;
   private Float subTotal;
   private String status;
   private String color;
   private String description;
   private String name;
   private Date dueOn;

   public NestedProjectTaskDTO()
   {
   }

   public NestedProjectTaskDTO(final ProjectTask entity)
   {
      if (entity != null)
      {
         this.startOn = entity.getStartOn();
         this.id = entity.getId();
         this.bidHours = entity.getBidHours();
         this.subTotal = entity.getSubTotal();
         this.status = entity.getStatus();
         this.color = entity.getColor();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.dueOn = entity.getDueOn();
      }
   }

   public ProjectTask fromDTO(ProjectTask entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ProjectTask();
      }
      if (this.id != null)
      {
         TypedQuery<ProjectTask> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT p FROM ProjectTask p WHERE p.id = :entityId",
                     ProjectTask.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setStartOn(this.startOn);
      entity.setBidHours(this.bidHours);
      entity.setStatus(this.status);
      entity.setColor(this.color);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setDueOn(this.dueOn);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartOn()
   {
      return this.startOn;
   }

   public void setStartOn(final Date startOn)
   {
      this.startOn = startOn;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Float getBidHours()
   {
      return this.bidHours;
   }

   public void setBidHours(final Float bidHours)
   {
      this.bidHours = bidHours;
   }

   public Float getSubTotal()
   {
      return this.subTotal;
   }

   public void setSubTotal(final Float subTotal)
   {
      this.subTotal = subTotal;
   }

   public String getStatus()
   {
      return this.status;
   }

   public void setStatus(final String status)
   {
      this.status = status;
   }

   public String getColor()
   {
      return this.color;
   }

   public void setColor(final String color)
   {
      this.color = color;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Date getDueOn()
   {
      return this.dueOn;
   }

   public void setDueOn(final Date dueOn)
   {
      this.dueOn = dueOn;
   }
}