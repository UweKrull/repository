package de.binaris.employeetimetracker.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.employeetimetracker.model.Timeshift;
import de.binaris.employeetimetracker.rest.dto.TimeshiftDTO;

/**
 * 
 */
@Stateless
@Path("/timeshifts")
public class TimeshiftEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(TimeshiftDTO dto)
   {
      Timeshift entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(TimeshiftEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Timeshift entity = em.find(Timeshift.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Timeshift> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM Timeshift t WHERE t.id = :entityId ORDER BY t.id", Timeshift.class);
      findByIdQuery.setParameter("entityId", id);
      Timeshift entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      TimeshiftDTO dto = new TimeshiftDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<TimeshiftDTO> listAll()
   {
      final List<Timeshift> searchResults = em.createQuery("SELECT DISTINCT t FROM Timeshift t ORDER BY t.id", Timeshift.class).getResultList();
      final List<TimeshiftDTO> results = new ArrayList<TimeshiftDTO>();
      for (Timeshift searchResult : searchResults)
      {
         TimeshiftDTO dto = new TimeshiftDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, TimeshiftDTO dto)
   {
      TypedQuery<Timeshift> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM Timeshift t WHERE t.id = :entityId ORDER BY t.id", Timeshift.class);
      findByIdQuery.setParameter("entityId", id);
      Timeshift entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}