'use strict';

angular.module('fileuploadangularjs',['ngRoute','ngResource','ngFileUpload','ngImgCrop'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/FileUploads',{templateUrl:'views/FileUploads/detail.html',controller:'NewUploadController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NewUploadController', ['$scope', 'Upload', '$timeout', function NewUploadController($scope, Upload, $timeout, $location, locationParser, FileUploadResource) {
    $scope.save = function (dataUrl) {
        var successCallback = function(data,responseHeaders){
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        FileUploadResource.save(dataUrl, successCallback, errorCallback);
    };

    $scope.upload = function (dataUrl) {
        Upload.upload({
            url: 'https://angular-file-upload-cors-srv.appspot.com/upload',
            data: {
                file: Upload.dataUrltoBlob(dataUrl)
            },
        }).then(function (response) {
            $timeout(function () {
                $scope.result = response.data;
            });
        }, function (response) {
            if (response.status > 0) $scope.errorMsg = response.status + ': ' + response.data;
        }, function (evt) {
            $scope.progress = parseInt(100.0 * evt.loaded / evt.total);
        });
        $scope.save(dataUrl);
    };
}])
.controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
});
