angular.module('fileuploadangularjs').factory('FileUploadResource', function($resource){
    var resource = $resource('rest/fileupload/upload',{upload: {method:'GET'}});
    return resource;
});