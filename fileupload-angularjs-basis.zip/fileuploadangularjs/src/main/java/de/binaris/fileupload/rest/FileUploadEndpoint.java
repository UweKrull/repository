package de.binaris.fileupload.rest;

import java.util.logging.Logger;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

/**
 * The FileUpload REST service endpoint
 */
@Stateless
@Path("/fileupload")
public class FileUploadEndpoint
{
   @PersistenceContext(unitName = "FileuploadangularjsPU")
   private EntityManager em;

   @GET
   @Path("/upload")
   public Response upload(Object obj)
   {
	   Logger.getAnonymousLogger().info("******* /fileupload-GET/upload called *******");
       return Response.status(Status.OK).build();
//	   return Response.noContent().build();
//	   return Response.ok().build();
   }
   
   @POST
   public Response upload()
   {
	   Logger.getAnonymousLogger().info("******* /fileupload-POST/upload called *******");
	   return Response.status(Status.OK).build();
//	   return Response.noContent().build();
//	   return Response.ok().build();
   }

}