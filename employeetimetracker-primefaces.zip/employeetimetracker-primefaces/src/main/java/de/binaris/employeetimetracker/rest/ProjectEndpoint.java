package de.binaris.employeetimetracker.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.employeetimetracker.model.Project;
import de.binaris.employeetimetracker.rest.dto.ProjectDTO;

/**
 * 
 */
@Stateless
@Path("/projects")
public class ProjectEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(ProjectDTO dto)
   {
      Project entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(ProjectEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Project entity = em.find(Project.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Project> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM Project p LEFT JOIN FETCH p.user LEFT JOIN FETCH p.projectTasks WHERE p.id = :entityId ORDER BY p.id", Project.class);
      findByIdQuery.setParameter("entityId", id);
      Project entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      ProjectDTO dto = new ProjectDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<ProjectDTO> listAll()
   {
      final List<Project> searchResults = em.createQuery("SELECT DISTINCT p FROM Project p LEFT JOIN FETCH p.user LEFT JOIN FETCH p.projectTasks ORDER BY p.id", Project.class).getResultList();
      final List<ProjectDTO> results = new ArrayList<ProjectDTO>();
      for (Project searchResult : searchResults)
      {
         ProjectDTO dto = new ProjectDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, ProjectDTO dto)
   {
      TypedQuery<Project> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM Project p LEFT JOIN FETCH p.user LEFT JOIN FETCH p.projectTasks WHERE p.id = :entityId ORDER BY p.id", Project.class);
      findByIdQuery.setParameter("entityId", id);
      Project entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}