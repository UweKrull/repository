package de.binaris.employeetimetracker.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "timeshift")
public class Timeshift implements Serializable {

	private static final long serialVersionUID = 79757512756657179L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_time_shift")
	@SequenceGenerator(name = "my_entity_seq_gen_time_shift", sequenceName = "sequence_time_shift", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_time", updatable = true)
	private Date startTime;

	@NotNull
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_time", updatable = true)
	private Date endTime;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Timeshift)) {
			return false;
		}
		Timeshift castOther = (Timeshift) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return (name + ", " + description + ", " + startTime + ", " + endTime).replace(":00.0,", " -").replace(":00.0", "");
	}
}
