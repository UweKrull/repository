package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import de.binaris.employeetimetracker.model.DayAndTime;
import de.binaris.employeetimetracker.model.Schedule;

public class NestedScheduleDTO implements Serializable
{

   private Date startDateTime;
   private Date endDateTime;
   private Long id;
   private String description;
   private String name;

   public NestedScheduleDTO()
   {
   }

   public NestedScheduleDTO(final Schedule entity)
   {
      if (entity != null)
      {
         this.startDateTime = entity.getStartDateTime();
         this.endDateTime = entity.getEndDateTime();
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
      }
   }

   public Schedule fromDTO(Schedule entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Schedule();
      }
      if (this.id != null)
      {
         TypedQuery<Schedule> findByIdQuery = em.createQuery(
               "SELECT DISTINCT s FROM Schedule s WHERE s.id = :entityId",
               Schedule.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setStartDateTime(this.startDateTime);
      entity.setEndDateTime(this.endDateTime);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartDateTime()
   {
      return this.startDateTime;
   }

   public void setStartDateTime(final Date startDateTime)
   {
      this.startDateTime = startDateTime;
   }

   public Date getEndDateTime()
   {
	   return this.endDateTime;
   }
   
   public void setEndDateTime(final Date endDateTime)
   {
	   this.endDateTime = endDateTime;
   }
   
   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}