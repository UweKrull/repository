package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;

import de.binaris.employeetimetracker.model.Project;
import de.binaris.employeetimetracker.model.User;
import de.binaris.employeetimetracker.rest.dto.AddressDTO;
import de.binaris.employeetimetracker.rest.dto.NestedProjectDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserDTO implements Serializable
{

   private String middleName;
   private Date dateOfBirth;
   private String lastName;
   private String phone;
   private Date dateOfLeave;
   private String password;
   private Long id;
   private Set<NestedProjectDTO> project = new HashSet<NestedProjectDTO>();
   private AddressDTO address;
   private String email;
   private Date dateOfEntry;
   private String login;
   private String firstName;
   private String jobTitle;

   public UserDTO()
   {
   }

   public UserDTO(final User entity)
   {
      if (entity != null)
      {
         this.middleName = entity.getMiddleName();
         this.dateOfBirth = entity.getDateOfBirth();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         this.dateOfLeave = entity.getDateOfLeave();
         this.password = entity.getPassword();
         this.id = entity.getId();
         Iterator<Project> iterProject = entity.getProject().iterator();
         for (; iterProject.hasNext();)
         {
            Project element = iterProject.next();
            this.project.add(new NestedProjectDTO(element));
         }
         this.address = new AddressDTO(entity.getAddress());
         this.email = entity.getEmail();
         this.dateOfEntry = entity.getDateOfEntry();
         this.login = entity.getLogin();
         this.firstName = entity.getFirstName();
         this.jobTitle = entity.getJobTitle();
      }
   }

   public User fromDTO(User entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new User();
      }
      entity.setMiddleName(this.middleName);
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      entity.setDateOfLeave(this.dateOfLeave);
      entity.setPassword(this.password);
      Iterator<Project> iterProject = entity.getProject().iterator();
      for (; iterProject.hasNext();)
      {
         boolean found = false;
         Project project = iterProject.next();
         Iterator<NestedProjectDTO> iterDtoProject = this.getProject()
               .iterator();
         for (; iterDtoProject.hasNext();)
         {
            NestedProjectDTO dtoProject = iterDtoProject.next();
            if (dtoProject.getId().equals(project.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterProject.remove();
         }
      }
      Iterator<NestedProjectDTO> iterDtoProject = this.getProject()
            .iterator();
      for (; iterDtoProject.hasNext();)
      {
         boolean found = false;
         NestedProjectDTO dtoProject = iterDtoProject.next();
         iterProject = entity.getProject().iterator();
         for (; iterProject.hasNext();)
         {
            Project project = iterProject.next();
            if (dtoProject.getId().equals(project.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Project> resultIter = em
                  .createQuery("SELECT DISTINCT p FROM Project p",
                        Project.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Project result = resultIter.next();
               if (result.getId().equals(dtoProject.getId()))
               {
                  entity.getProject().add(result);
                  break;
               }
            }
         }
      }
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setEmail(this.email);
      entity.setDateOfEntry(this.dateOfEntry);
      entity.setLogin(this.login);
      entity.setFirstName(this.firstName);
      entity.setJobTitle(this.jobTitle);
      entity = em.merge(entity);
      return entity;
   }

   public String getMiddleName()
   {
      return this.middleName;
   }

   public void setMiddleName(final String middleName)
   {
      this.middleName = middleName;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public Date getDateOfLeave()
   {
      return this.dateOfLeave;
   }

   public void setDateOfLeave(final Date dateOfLeave)
   {
      this.dateOfLeave = dateOfLeave;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedProjectDTO> getProject()
   {
      return this.project;
   }

   public void setProject(final Set<NestedProjectDTO> project)
   {
      this.project = project;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public Date getDateOfEntry()
   {
      return this.dateOfEntry;
   }

   public void setDateOfEntry(final Date dateOfEntry)
   {
      this.dateOfEntry = dateOfEntry;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }

   public String getJobTitle()
   {
      return this.jobTitle;
   }

   public void setJobTitle(final String jobTitle)
   {
      this.jobTitle = jobTitle;
   }
}