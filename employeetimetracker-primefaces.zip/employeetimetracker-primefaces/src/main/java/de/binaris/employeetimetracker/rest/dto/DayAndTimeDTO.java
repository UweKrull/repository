package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

import de.binaris.employeetimetracker.model.DayAndTime;
import de.binaris.employeetimetracker.model.Schedule;
import de.binaris.employeetimetracker.model.Timeshift;
import de.binaris.employeetimetracker.model.Weekday;

@XmlRootElement
public class DayAndTimeDTO implements Serializable
{

   private Date startTime;
   private Long id;
   private Schedule schedule;
   private Timeshift timeshift;
   private Weekday day;
   private Float subTotal;
   private Date endTime;

   public DayAndTimeDTO()
   {
   }

   public DayAndTimeDTO(final DayAndTime entity)
   {
      if (entity != null)
      {
         this.startTime = entity.getStartTime();
         this.id = entity.getId();
         this.schedule = entity.getSchedule();
         this.timeshift = entity.getTimeshift();
         this.day = entity.getDay();
         this.subTotal = entity.getSubTotal();
         this.endTime = entity.getEndTime();
      }
   }

   public DayAndTime fromDTO(DayAndTime entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new DayAndTime();
      }
      entity.setStartTime(this.startTime);
      if (this.schedule != null)
      {
         entity.setSchedule(this.schedule);
      }
      if (this.timeshift != null)
      {
    	  entity.setTimeshift(this.timeshift);
      }
      if (this.day != null)
      {
    	  entity.setDay(this.day);
      }
      entity.setEndTime(this.endTime);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartTime()
   {
      return this.startTime;
   }

   public void setStartTime(final Date startTime)
   {
      this.startTime = startTime;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Schedule getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final Schedule schedule)
   {
      this.schedule = schedule;
   }

   public Timeshift getTimeshift()
   {
      return this.timeshift;
   }

   public void setTimeshift(final Timeshift timeshift)
   {
      this.timeshift = timeshift;
   }

   public Weekday getDay()
   {
      return this.day;
   }

   public void setDay(final Weekday day)
   {
      this.day = day;
   }

   public Float getSubTotal()
   {
      return this.subTotal;
   }

   public void setSubTotal(final Float subTotal)
   {
      this.subTotal = subTotal;
   }

   public Date getEndTime()
   {
      return this.endTime;
   }

   public void setEndTime(final Date endTime)
   {
      this.endTime = endTime;
   }
}