package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.DayAndTime;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import java.util.Date;

public class NestedDayAndTimeDTO implements Serializable
{

   private Date startTime;
   private Long id;
   private Float subTotal;
   private Date endTime;

   public NestedDayAndTimeDTO()
   {
   }

   public NestedDayAndTimeDTO(final DayAndTime entity)
   {
      if (entity != null)
      {
         this.startTime = entity.getStartTime();
         this.id = entity.getId();
         this.subTotal = entity.getSubTotal();
         this.endTime = entity.getEndTime();
      }
   }

   public DayAndTime fromDTO(DayAndTime entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new DayAndTime();
      }
      if (this.id != null)
      {
         TypedQuery<DayAndTime> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT d FROM DayAndTime d WHERE d.id = :entityId",
                     DayAndTime.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setStartTime(this.startTime);
      entity.setEndTime(this.endTime);
      entity = em.merge(entity);
      return entity;
   }

   public Date getStartTime()
   {
      return this.startTime;
   }

   public void setStartTime(final Date startTime)
   {
      this.startTime = startTime;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Float getSubTotal()
   {
      return this.subTotal;
   }

   public void setSubTotal(final Float subTotal)
   {
      this.subTotal = subTotal;
   }

   public Date getEndTime()
   {
      return this.endTime;
   }

   public void setEndTime(final Date endTime)
   {
      this.endTime = endTime;
   }
}