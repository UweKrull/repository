package de.binaris.employeetimetracker.rest.dto;

import java.io.Serializable;

import de.binaris.employeetimetracker.model.Weekday;
import de.binaris.employeetimetracker.rest.dto.NestedDayAndTimeDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class WeekdayDTO implements Serializable
{

   private Long id;
   private NestedDayAndTimeDTO dayAndTime;
   private String name;

   public WeekdayDTO()
   {
   }

   public WeekdayDTO(final Weekday entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.dayAndTime = new NestedDayAndTimeDTO(entity.getDayAndTime());
         this.name = entity.getName();
      }
   }

   public Weekday fromDTO(Weekday entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Weekday();
      }
      if (this.dayAndTime != null)
      {
         entity.setDayAndTime(this.dayAndTime.fromDTO(
               entity.getDayAndTime(), em));
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedDayAndTimeDTO getDayAndTime()
   {
      return this.dayAndTime;
   }

   public void setDayAndTime(final NestedDayAndTimeDTO dayAndTime)
   {
      this.dayAndTime = dayAndTime;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}