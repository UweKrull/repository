package de.binaris.employeetimetracker.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.employeetimetracker.model.TaskType;
import de.binaris.employeetimetracker.rest.dto.TaskTypeDTO;

/**
 * 
 */
@Stateless
@Path("/tasktypes")
public class TaskTypeEndpoint
{
   @PersistenceContext(unitName = "EmployeetimetrackerPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(TaskTypeDTO dto)
   {
      TaskType entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(TaskTypeEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      TaskType entity = em.find(TaskType.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<TaskType> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TaskType t WHERE t.id = :entityId ORDER BY t.id", TaskType.class);
      findByIdQuery.setParameter("entityId", id);
      TaskType entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      TaskTypeDTO dto = new TaskTypeDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<TaskTypeDTO> listAll()
   {
      final List<TaskType> searchResults = em.createQuery("SELECT DISTINCT t FROM TaskType t ORDER BY t.id", TaskType.class).getResultList();
      final List<TaskTypeDTO> results = new ArrayList<TaskTypeDTO>();
      for (TaskType searchResult : searchResults)
      {
         TaskTypeDTO dto = new TaskTypeDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, TaskTypeDTO dto)
   {
      TypedQuery<TaskType> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TaskType t WHERE t.id = :entityId ORDER BY t.id", TaskType.class);
      findByIdQuery.setParameter("entityId", id);
      TaskType entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}