package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

import de.binaris.bookstore.forge.rest.dto.AddressDTO;
import de.binaris.bookstore.forge.rest.dto.CreditCardDTO;
import de.binaris.bookstore.forge.rest.dto.NestedCustomerDTO;
import de.binaris.bookstore.forge.rest.dto.NestedOrderLineDTO;
import de.binaris.bookstore.model.OrderLine;
import de.binaris.bookstore.model.PurchaseOrder;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PurchaseOrderDTO implements Serializable {

	private static final long serialVersionUID = 7117777710111753391L;

	private Float total;
	private Date orderDate;
	private Float vat;
	private Float totalWithVat;
	private NestedCustomerDTO customer;
	private Float vatRate;
	private Float discount;
	private Long id;
	private CreditCardDTO creditCard;
	private Set<NestedOrderLineDTO> orderLines = new HashSet<NestedOrderLineDTO>();
	private Float discountRate;
	private AddressDTO deliveryAddress;
	private Float totalWithoutVat;

	public PurchaseOrderDTO() {
	}

	public PurchaseOrderDTO(final PurchaseOrder entity) {
		if (entity != null) {
			this.total = entity.getTotal();
			this.orderDate = entity.getOrderDate();
			this.vat = entity.getVat();
			this.totalWithVat = entity.getTotalWithVat();
			this.customer = new NestedCustomerDTO(entity.getCustomer());
			this.vatRate = entity.getVatRate();
			this.discount = entity.getDiscount();
			this.id = entity.getId();
			this.creditCard = new CreditCardDTO(entity.getCreditCard());
			Iterator<OrderLine> iterOrderLines = entity.getOrderLines()
					.iterator();
			for (; iterOrderLines.hasNext();) {
				OrderLine element = iterOrderLines.next();
				this.orderLines.add(new NestedOrderLineDTO(element));
			}
			this.discountRate = entity.getDiscountRate();
			this.deliveryAddress = new AddressDTO(entity.getDeliveryAddress());
			this.totalWithoutVat = entity.getTotalWithoutVat();
		}
	}

	public PurchaseOrder fromDTO(PurchaseOrder entity, EntityManager em) {
		if (entity == null) {
			entity = new PurchaseOrder();
		}
		entity.setTotal(this.total);
		entity.setOrderDate(this.orderDate);
		entity.setVat(this.vat);
		entity.setTotalWithVat(this.totalWithVat);
		if (this.customer != null) {
			entity.setCustomer(this.customer.fromDTO(entity.getCustomer(), em));
		}
		entity.setVatRate(this.vatRate);
		entity.setDiscount(this.discount);
		if (this.creditCard != null) {
			entity.setCreditCard(this.creditCard.fromDTO(
					entity.getCreditCard(), em));
		}
		Iterator<OrderLine> iterOrderLines = entity.getOrderLines().iterator();
		for (; iterOrderLines.hasNext();) {
			boolean found = false;
			OrderLine orderLine = iterOrderLines.next();
			Iterator<NestedOrderLineDTO> iterDtoOrderLines = this
					.getOrderLines().iterator();
			for (; iterDtoOrderLines.hasNext();) {
				NestedOrderLineDTO dtoOrderLine = iterDtoOrderLines.next();
				if (dtoOrderLine.getId().equals(orderLine.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterOrderLines.remove();
			}
		}
		Iterator<NestedOrderLineDTO> iterDtoOrderLines = this.getOrderLines()
				.iterator();
		for (; iterDtoOrderLines.hasNext();) {
			boolean found = false;
			NestedOrderLineDTO dtoOrderLine = iterDtoOrderLines.next();
			iterOrderLines = entity.getOrderLines().iterator();
			for (; iterOrderLines.hasNext();) {
				OrderLine orderLine = iterOrderLines.next();
				if (dtoOrderLine.getId().equals(orderLine.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<OrderLine> resultIter = em
						.createQuery("SELECT DISTINCT o FROM OrderLine o",
								OrderLine.class).getResultList().iterator();
				for (; resultIter.hasNext();) {
					OrderLine result = resultIter.next();
					if (result.getId().equals(dtoOrderLine.getId())) {
						entity.getOrderLines().add(result);
						break;
					}
				}
			}
		}
		entity.setDiscountRate(this.discountRate);
		if (this.deliveryAddress != null) {
			entity.setDeliveryAddress(this.deliveryAddress.fromDTO(
					entity.getDeliveryAddress(), em));
		}
		entity.setTotalWithoutVat(this.totalWithoutVat);
		entity = em.merge(entity);
		return entity;
	}

	public Float getTotal() {
		return this.total;
	}

	public void setTotal(final Float total) {
		this.total = total;
	}

	public Date getOrderDate() {
		return this.orderDate;
	}

	public void setOrderDate(final Date orderDate) {
		this.orderDate = orderDate;
	}

	public Float getVat() {
		return this.vat;
	}

	public void setVat(final Float vat) {
		this.vat = vat;
	}

	public Float getTotalWithVat() {
		return this.totalWithVat;
	}

	public void setTotalWithVat(final Float totalWithVat) {
		this.totalWithVat = totalWithVat;
	}

	public NestedCustomerDTO getCustomer() {
		return this.customer;
	}

	public void setCustomer(final NestedCustomerDTO customer) {
		this.customer = customer;
	}

	public Float getVatRate() {
		return this.vatRate;
	}

	public void setVatRate(final Float vatRate) {
		this.vatRate = vatRate;
	}

	public Float getDiscount() {
		return this.discount;
	}

	public void setDiscount(final Float discount) {
		this.discount = discount;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public CreditCardDTO getCreditCard() {
		return this.creditCard;
	}

	public void setCreditCard(final CreditCardDTO creditCard) {
		this.creditCard = creditCard;
	}

	public Set<NestedOrderLineDTO> getOrderLines() {
		return this.orderLines;
	}

	public void setOrderLines(final Set<NestedOrderLineDTO> orderLines) {
		this.orderLines = orderLines;
	}

	public Float getDiscountRate() {
		return this.discountRate;
	}

	public void setDiscountRate(final Float discountRate) {
		this.discountRate = discountRate;
	}

	public AddressDTO getDeliveryAddress() {
		return this.deliveryAddress;
	}

	public void setDeliveryAddress(final AddressDTO deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public Float getTotalWithoutVat() {
		return this.totalWithoutVat;
	}

	public void setTotalWithoutVat(final Float totalWithoutVat) {
		this.totalWithoutVat = totalWithoutVat;
	}	
}