package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;

import de.binaris.bookstore.model.Product;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedProductDTO implements Serializable {

	private static final long serialVersionUID = 7115678910111213191L;

	private Long id;
	private String description;
	private String name;

	public NestedProductDTO() {
	}

	public NestedProductDTO(final Product entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.description = entity.getDescription();
			this.name = entity.getName();
		}
	}

	public Product fromDTO(Product entity, EntityManager em) {
		if (entity == null) {
			entity = new Product();
		}
		if (this.id != null) {
			TypedQuery<Product> findByIdQuery = em.createQuery(
					"SELECT DISTINCT p FROM Product p WHERE p.id = :entityId",
					Product.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}
}