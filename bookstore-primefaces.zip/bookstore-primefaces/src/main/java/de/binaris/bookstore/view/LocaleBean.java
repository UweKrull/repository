package de.binaris.bookstore.view;

import javax.enterprise.context.SessionScoped;
import javax.enterprise.inject.Produces;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import de.binaris.bookstore.annotations.Loggable;

import java.io.Serializable;
import java.util.Locale;

@Named
@SessionScoped
@Loggable
public class LocaleBean implements Serializable {

	private static final long serialVersionUID = 5187997881833212772L;
	
	@Produces
    private Locale locale = FacesContext.getCurrentInstance().getViewRoot().getLocale();

    public Locale getLocale() {
        return locale;
    }

    public String getLanguage() {
        return locale.getLanguage();
    }

    public void setLanguage(String language) {
        locale = new Locale(language);
        FacesContext.getCurrentInstance().getViewRoot().setLocale(locale);
    }
}