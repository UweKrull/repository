package de.binaris.bookstore.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * An PurchaseOrder may consist of one or more orderlines.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Entity
@Table(name = "purchase_order")
public class PurchaseOrder implements Serializable {

	private static final long serialVersionUID = 7277723756789162915L;

	/**
	 * The ID of the PurchaseOrder.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_purchase_order")
	@SequenceGenerator(name = "my_entity_seq_gen_purchase_order", sequenceName = "sequence_purchase_order", allocationSize = 1)
	private Long id;

	@NotNull
	@Temporal(TemporalType.DATE)
	@Column(name = "order_date", updatable = false)
	private Date orderDate;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Customer customer;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "purchaseOrder")
	private Set<OrderLine> orderLines = new HashSet<OrderLine>();

	private Address deliveryAddress = new Address();

	private CreditCard creditCard = new CreditCard();

	private Float totalWithoutVat;

	@Column(name = "vat_rate")
	private Float vatRate;

	private Float vat;

	private Float totalWithVat;

	@Column(name = "discount_rate")
	private Float discountRate;

	private Float discount;

	private Float total;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@PrePersist
	private void setDefaultData() {
		orderDate = new Date();
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Set<OrderLine> getOrderLines() {
		return orderLines;
	}

	public void setOrderLines(Set<OrderLine> orderLines) {
		this.orderLines = orderLines;
	}

	public Address getDeliveryAddress() {
		return deliveryAddress;
	}

	public void setDeliveryAddress(Address deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public CreditCard getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}

	public Float getTotalWithoutVat() {
		return totalWithoutVat;
	}

	public void setTotalWithoutVat(Float totalWithoutVat) {
		this.totalWithoutVat = totalWithoutVat;
	}

	public Float getVatRate() {
		return vatRate;
	}

	public void setVatRate(Float vatRate) {
		this.vatRate = vatRate;
	}

	public Float getVat() {
		return vat;
	}

	public void setVat(Float vat) {
		this.vat = vat;
	}

	public Float getTotalWithVat() {
		return totalWithVat;
	}

	public void setTotalWithVat(Float totalWithVat) {
		this.totalWithVat = totalWithVat;
	}

	public Float getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(Float discountRate) {
		this.discountRate = discountRate;
	}

	public Float getDiscount() {
		return discount;
	}

	public void setDiscount(Float discount) {
		this.discount = discount;
	}

	public void setTotal(Float total) {
		this.total = total;
	}

	public Float getTotal() {
		if (orderLines == null || orderLines.isEmpty()) {
			return 0f;
		}
		Float sum = 0f;
		for (OrderLine orderLine : orderLines) {
			sum += (orderLine.getSubTotal());
		}
		this.total = sum;
		return total;
	}

	/*
	 * toString(), equals() and hashCode() for PurchaseOrder, using the natural
	 * identity of the object
	 */

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof PurchaseOrder)) {
			return false;
		}
		PurchaseOrder castOther = (PurchaseOrder) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(customer.toString());
		sb.append(", ").append(customer.getAddress().getCountry().toString());
		sb.append(", ").append(orderDate.toString());
//		sb.append('\'').append(orderDate);
//		sb.append(", ").append('\'').append(customer).append('\'');
//		sb.append(", ").append('\'').append(orderLines).append('\'');
//		sb.append(", ").append('\'').append(deliveryAddress).append('\'');
//		sb.append(", ").append('\'').append(creditCard).append('\'');
		return sb.toString();
	}
}
