package de.binaris.bookstore.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * An OrderLine may consist of one or more items.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Entity
@Table(name = "order_line")
public class OrderLine implements Serializable {

	private static final long serialVersionUID = 5012312375678916915L;

	/**
	 * The ID of the OrderLine.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_order_line")
	@SequenceGenerator(name = "my_entity_seq_gen_order_line", sequenceName = "sequence_order_line", allocationSize = 1)
	private Long id;

	/**
	 * The quantity of items.
	 */
	@NotNull
	@Min(value = 1, message = "minimum 1 item")
	private Integer quantity;

	/**
	 * The item of the OrderLine.
	 */
	@ManyToOne
	@NotNull
	private Item item;

	/**
	 * The purchaseOrder of the OrderLine.
	 */
	@ManyToOne
	@NotNull
	private PurchaseOrder purchaseOrder;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public PurchaseOrder getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(PurchaseOrder purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public Float getSubTotal() {
		return (item != null)? item.getUnitCost() * quantity : 0F;
	}

	/*
	 * toString(), equals() and hashCode() for OrderLine, using the natural
	 * identity of the object
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof OrderLine)) {
			return false;
		}
		OrderLine castOther = (OrderLine) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(quantity).append('x');
		sb.append(" ").append(item.getName());
		sb.append(", ").append(item.getDescription());
		return sb.toString();
	}
}
