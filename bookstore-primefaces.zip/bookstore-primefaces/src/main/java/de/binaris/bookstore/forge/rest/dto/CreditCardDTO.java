package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import de.binaris.bookstore.model.CreditCard;
import de.binaris.bookstore.model.CreditCardType;

public class CreditCardDTO implements Serializable {

	private static final long serialVersionUID = 5235678910111213153L;

	private String creditCardNumber;
	private String creditCardExpDate;
	private CreditCardType creditCardType;

	public CreditCardDTO() {
	}

	public CreditCardDTO(final CreditCard entity) {
		if (entity != null) {
			this.creditCardNumber = entity.getCreditCardNumber();
			this.creditCardExpDate = entity.getCreditCardExpDate();
			this.creditCardType = entity.getCreditCardType();
		}
	}

	public CreditCard fromDTO(CreditCard entity, EntityManager em) {
		if (entity == null) {
			entity = new CreditCard();
		}
		entity.setCreditCardNumber(this.creditCardNumber);
		entity.setCreditCardExpDate(this.creditCardExpDate);
		entity.setCreditCardType(this.creditCardType);
		return entity;
	}

	public String getCreditCardNumber() {
		return this.creditCardNumber;
	}

	public void setCreditCardNumber(final String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	public String getCreditCardExpDate() {
		return this.creditCardExpDate;
	}

	public void setCreditCardExpDate(final String creditCardExpDate) {
		this.creditCardExpDate = creditCardExpDate;
	}

	public CreditCardType getCreditCardType() {
		return this.creditCardType;
	}

	public void setCreditCardType(final CreditCardType creditCardType) {
		this.creditCardType = creditCardType;
	}
}