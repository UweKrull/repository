package de.binaris.bookstore.model;

/**
 * <p>
 * The {@link CreditCardType} describes the types of credit card this application 
 * can handle and render.
 * 
 * The media type is a <em>closed set</em> - as each different type of 
 * media requires support coded into the view layers, 
 * it cannot be expanded upon without rebuilding the application. 
 * It is therefore represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * so that we can later reorder the enum members,
 * without changing the data. This does mean we cannot change 
 * the names of credit card types once the app is put into production. 
 * To do this add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link CreditCardType} describes whether or not the 
 * type of media can be cached locally and used offline.
 * </p>
 */
public enum CreditCardType {

    /**
     * The types of credit cards the application can currently handle.
     */
    VISA("Visa", true),
    MASTER_CARD("Mastercard", true),
    AMERICAN_EXPRESS("American Express", true);   

    /**
     * A human readable description of the credit card type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the credit card type can be cached.
     */
    private final boolean cacheable;
    
    private CreditCardType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
