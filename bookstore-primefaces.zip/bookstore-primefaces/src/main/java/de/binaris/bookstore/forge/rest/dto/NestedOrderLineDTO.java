package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;

import de.binaris.bookstore.model.OrderLine;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedOrderLineDTO implements Serializable {

	private static final long serialVersionUID = 7935678910111213190L;

	private Long id;
	private Float subTotal;
	private Integer quantity;

	public NestedOrderLineDTO() {
	}

	public NestedOrderLineDTO(final OrderLine entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.subTotal = entity.getSubTotal();
			this.quantity = entity.getQuantity();
		}
	}

	public OrderLine fromDTO(OrderLine entity, EntityManager em) {
		if (entity == null) {
			entity = new OrderLine();
		}
		if (this.id != null) {
			TypedQuery<OrderLine> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT o FROM OrderLine o WHERE o.id = :entityId",
							OrderLine.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setQuantity(this.quantity);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Float getSubTotal() {
		return this.subTotal;
	}

	public void setSubTotal(final Float subTotal) {
		this.subTotal = subTotal;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(final Integer quantity) {
		this.quantity = quantity;
	}
}