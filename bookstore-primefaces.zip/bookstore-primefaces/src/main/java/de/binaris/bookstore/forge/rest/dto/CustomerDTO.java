package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

import de.binaris.bookstore.model.Customer;
import de.binaris.bookstore.model.PurchaseOrder;

@XmlRootElement
public class CustomerDTO implements Serializable {

	private static final long serialVersionUID = 6235678910111213152L;

	private Date dateOfBirth;
	private Long id;
	private String lastName;
	private String phone;
	private AddressDTO address;
	private String email;
	private Set<NestedPurchaseOrderDTO> purchaseOrder = new HashSet<NestedPurchaseOrderDTO>();
	private String login;
	private String firstName;
	private String password;

	public CustomerDTO() {
	}

	public CustomerDTO(final Customer entity) {
		if (entity != null) {
			this.dateOfBirth = entity.getDateOfBirth();
			this.id = entity.getId();
			this.lastName = entity.getLastName();
			this.phone = entity.getPhone();
			this.address = new AddressDTO(entity.getAddress());
			this.email = entity.getEmail();
			Iterator<PurchaseOrder> iterPurchaseOrder = entity
					.getPurchaseOrder().iterator();
			for (; iterPurchaseOrder.hasNext();) {
				PurchaseOrder element = iterPurchaseOrder.next();
				this.purchaseOrder.add(new NestedPurchaseOrderDTO(element));
			}
			this.login = entity.getLogin();
			this.firstName = entity.getFirstName();
			this.password = entity.getPassword();
		}
	}

	public Customer fromDTO(Customer entity, EntityManager em) {
		if (entity == null) {
			entity = new Customer();
		}
		entity.setDateOfBirth(this.dateOfBirth);
		entity.setLastName(this.lastName);
		entity.setPhone(this.phone);
		if (this.address != null) {
			entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
		}
		entity.setEmail(this.email);
		Iterator<PurchaseOrder> iterPurchaseOrder = entity.getPurchaseOrder()
				.iterator();
		for (; iterPurchaseOrder.hasNext();) {
			boolean found = false;
			PurchaseOrder purchaseOrder = iterPurchaseOrder.next();
			Iterator<NestedPurchaseOrderDTO> iterDtoPurchaseOrder = this
					.getPurchaseOrder().iterator();
			for (; iterDtoPurchaseOrder.hasNext();) {
				NestedPurchaseOrderDTO dtoPurchaseOrder = iterDtoPurchaseOrder
						.next();
				if (dtoPurchaseOrder.getId().equals(purchaseOrder.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterPurchaseOrder.remove();
			}
		}
		Iterator<NestedPurchaseOrderDTO> iterDtoPurchaseOrder = this
				.getPurchaseOrder().iterator();
		for (; iterDtoPurchaseOrder.hasNext();) {
			boolean found = false;
			NestedPurchaseOrderDTO dtoPurchaseOrder = iterDtoPurchaseOrder
					.next();
			iterPurchaseOrder = entity.getPurchaseOrder().iterator();
			for (; iterPurchaseOrder.hasNext();) {
				PurchaseOrder purchaseOrder = iterPurchaseOrder.next();
				if (dtoPurchaseOrder.getId().equals(purchaseOrder.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<PurchaseOrder> resultIter = em
						.createQuery("SELECT DISTINCT p FROM PurchaseOrder p",
								PurchaseOrder.class).getResultList().iterator();
				for (; resultIter.hasNext();) {
					PurchaseOrder result = resultIter.next();
					if (result.getId().equals(dtoPurchaseOrder.getId())) {
						entity.getPurchaseOrder().add(result);
						break;
					}
				}
			}
		}
		entity.setLogin(this.login);
		entity.setFirstName(this.firstName);
		entity.setPassword(this.password);
		entity = em.merge(entity);
		return entity;
	}

	public Date getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(final Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(final String phone) {
		this.phone = phone;
	}

	public AddressDTO getAddress() {
		return this.address;
	}

	public void setAddress(final AddressDTO address) {
		this.address = address;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public Set<NestedPurchaseOrderDTO> getPurchaseOrder() {
		return this.purchaseOrder;
	}

	public void setPurchaseOrder(final Set<NestedPurchaseOrderDTO> purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	public String getLogin() {
		return this.login;
	}

	public void setLogin(final String login) {
		this.login = login;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(final String password) {
		this.password = password;
	}
}