package de.binaris.bookstore.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "item")
public class Item implements Serializable {

	private static final long serialVersionUID = 79757512797127179L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_item")
	@SequenceGenerator(name = "my_entity_seq_gen_item", sequenceName = "sequence_item", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@Column(name = "image_path")
	private String imagePath;

	@NotNull
	@Column(name = "unit_cost")
	private Float unitCost;

	@ManyToOne
	private Product product;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public Float getUnitCost() {
		return unitCost;
	}

	public void setUnitCost(Float unitCost) {
		this.unitCost = unitCost;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Item)) {
			return false;
		}
		Item castOther = (Item) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return name + ", " + description;
	}
	
	public String getReducedString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(product.getName());
		sb.append(", ");
		sb.append(product.toString().split(", ")[1]);
		sb.append("...");
		return sb.toString();
	}
}
