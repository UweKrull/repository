package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import java.util.Date;

import de.binaris.bookstore.forge.rest.dto.AddressDTO;
import de.binaris.bookstore.forge.rest.dto.CreditCardDTO;
import de.binaris.bookstore.model.PurchaseOrder;

public class NestedPurchaseOrderDTO implements Serializable {

	private static final long serialVersionUID = 7117678910111213391L;

	private Float total;
	private Date orderDate;
	private Float vat;
	private Float totalWithVat;
	private Float vatRate;
	private Float discount;
	private Long id;
	private CreditCardDTO creditCard;
	private Float discountRate;
	private AddressDTO deliveryAddress;
	private Float totalWithoutVat;

	public NestedPurchaseOrderDTO() {
	}

	public NestedPurchaseOrderDTO(final PurchaseOrder entity) {
		if (entity != null) {
			this.total = entity.getTotal();
			this.orderDate = entity.getOrderDate();
			this.vat = entity.getVat();
			this.totalWithVat = entity.getTotalWithVat();
			this.vatRate = entity.getVatRate();
			this.discount = entity.getDiscount();
			this.id = entity.getId();
			this.creditCard = new CreditCardDTO(entity.getCreditCard());
			this.discountRate = entity.getDiscountRate();
			this.deliveryAddress = new AddressDTO(entity.getDeliveryAddress());
			this.totalWithoutVat = entity.getTotalWithoutVat();
		}
	}

	public PurchaseOrder fromDTO(PurchaseOrder entity, EntityManager em) {
		if (entity == null) {
			entity = new PurchaseOrder();
		}
		if (this.id != null) {
			TypedQuery<PurchaseOrder> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT p FROM PurchaseOrder p WHERE p.id = :entityId",
							PurchaseOrder.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setTotal(this.total);
		entity.setOrderDate(this.orderDate);
		entity.setVat(this.vat);
		entity.setTotalWithVat(this.totalWithVat);
		entity.setVatRate(this.vatRate);
		entity.setDiscount(this.discount);
		if (this.creditCard != null) {
			entity.setCreditCard(this.creditCard.fromDTO(
					entity.getCreditCard(), em));
		}
		entity.setDiscountRate(this.discountRate);
		if (this.deliveryAddress != null) {
			entity.setDeliveryAddress(this.deliveryAddress.fromDTO(
					entity.getDeliveryAddress(), em));
		}
		entity.setTotalWithoutVat(this.totalWithoutVat);
		entity = em.merge(entity);
		return entity;
	}

	public Float getTotal() {
		return this.total;
	}

	public void setTotal(final Float total) {
		this.total = total;
	}

	public Date getOrderDate() {
		return this.orderDate;
	}

	public void setOrderDate(final Date orderDate) {
		this.orderDate = orderDate;
	}

	public Float getVat() {
		return this.vat;
	}

	public void setVat(final Float vat) {
		this.vat = vat;
	}

	public Float getTotalWithVat() {
		return this.totalWithVat;
	}

	public void setTotalWithVat(final Float totalWithVat) {
		this.totalWithVat = totalWithVat;
	}

	public Float getVatRate() {
		return this.vatRate;
	}

	public void setVatRate(final Float vatRate) {
		this.vatRate = vatRate;
	}

	public Float getDiscount() {
		return this.discount;
	}

	public void setDiscount(final Float discount) {
		this.discount = discount;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public CreditCardDTO getCreditCard() {
		return this.creditCard;
	}

	public void setCreditCard(final CreditCardDTO creditCard) {
		this.creditCard = creditCard;
	}

	public Float getDiscountRate() {
		return this.discountRate;
	}

	public void setDiscountRate(final Float discountRate) {
		this.discountRate = discountRate;
	}

	public AddressDTO getDeliveryAddress() {
		return this.deliveryAddress;
	}

	public void setDeliveryAddress(final AddressDTO deliveryAddress) {
		this.deliveryAddress = deliveryAddress;
	}

	public Float getTotalWithoutVat() {
		return this.totalWithoutVat;
	}

	public void setTotalWithoutVat(final Float totalWithoutVat) {
		this.totalWithoutVat = totalWithoutVat;
	}
}