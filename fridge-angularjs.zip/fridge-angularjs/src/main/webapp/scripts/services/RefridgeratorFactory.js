angular.module('fridgeangularjs').factory('RefridgeratorResource', function($resource){
    var resource = $resource('rest/refridgerators/:RefridgeratorId',{RefridgeratorId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});