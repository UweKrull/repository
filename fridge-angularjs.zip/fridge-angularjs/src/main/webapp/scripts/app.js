'use strict';

angular.module('fridgeangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Articles',{templateUrl:'views/Article/search.html',controller:'SearchArticleController'})
      .when('/Articles/new',{templateUrl:'views/Article/detail.html',controller:'NewArticleController'})
      .when('/Articles/edit/:ArticleId',{templateUrl:'views/Article/detail.html',controller:'EditArticleController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Customers',{templateUrl:'views/Customer/search.html',controller:'SearchCustomerController'})
      .when('/Customers/new',{templateUrl:'views/Customer/detail.html',controller:'NewCustomerController'})
      .when('/Customers/edit/:CustomerId',{templateUrl:'views/Customer/detail.html',controller:'EditCustomerController'})
      .when('/Ingredients',{templateUrl:'views/Ingredient/search.html',controller:'SearchIngredientController'})
      .when('/Ingredients/new',{templateUrl:'views/Ingredient/detail.html',controller:'NewIngredientController'})
      .when('/Ingredients/edit/:IngredientId',{templateUrl:'views/Ingredient/detail.html',controller:'EditIngredientController'})
      .when('/Refridgerators',{templateUrl:'views/Refridgerator/search.html',controller:'SearchRefridgeratorController'})
      .when('/Refridgerators/new',{templateUrl:'views/Refridgerator/detail.html',controller:'NewRefridgeratorController'})
      .when('/Refridgerators/edit/:RefridgeratorId',{templateUrl:'views/Refridgerator/detail.html',controller:'EditRefridgeratorController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
