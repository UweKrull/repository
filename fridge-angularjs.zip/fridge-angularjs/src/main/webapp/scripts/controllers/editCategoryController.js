

angular.module('fridgeangularjs').controller('EditCategoryController', function($scope, $routeParams, $location, CategoryResource , ArticleResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.category = new CategoryResource(self.original);
            ArticleResource.queryAll(function(items) {
                $scope.articleSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title+', '+(new Date(item.expiryDateTime)).toISOString().replace('T',' ').replace(':00.000Z','').replace('.000Z','').substring(0,10)
                    };
                    if($scope.category.article){
                        $.each($scope.category.article, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.articleSelection.push(labelObject);
                                $scope.category.article.push(wrappedObject);
                            }
                        });
                        self.original.article = $scope.category.article;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Categorys");
        };
        CategoryResource.get({CategoryId:$routeParams.CategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.category);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.category.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Categorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Categorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.category.$remove(successCallback, errorCallback);
    };
    
    $scope.typeList = [
        "Bread_Butter",  
        "Cheese",  
        "Chips_Crackers",  
        "Drinks",  
        "Eggs",  
        "Fruit",  
        "Honey_Marmelade",  
        "Ice",  
        "Meat",  
        "Veggies",  
        "Milk",  
        "Milk_Products",  
        "Nuts",  
        "Sweets"  
    ];
    $scope.articleSelection = $scope.articleSelection || [];
    $scope.$watch("articleSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.category) {
            $scope.category.article = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.category.article.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});