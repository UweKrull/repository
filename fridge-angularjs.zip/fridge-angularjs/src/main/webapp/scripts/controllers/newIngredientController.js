
angular.module('fridgeangularjs').controller('NewIngredientController', function ($scope, $location, locationParser, IngredientResource , ArticleResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.ingredient = $scope.ingredient || {};
    
    $scope.articleList = ArticleResource.queryAll(function(items){
        $scope.articleSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("articleSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.ingredient.article = {};
            $scope.ingredient.article.id = selection.value;
        }
    });
    
    $scope.typeList = [
        "Conserving",
        "Nutrition",
        "Modifier",
        "TasteEnhancer"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Ingredients/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        IngredientResource.save($scope.ingredient, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Ingredients");
    };
});