
angular.module('fridgeangularjs').controller('NewRefridgeratorController', function ($scope, $location, locationParser, RefridgeratorResource , CustomerResource, ArticleResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.refridgerator = $scope.refridgerator || {};
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.refridgerator.customer = {};
            $scope.refridgerator.customer.id = selection.value;
        }
    });
    
    $scope.typeList = [
        "Superfridge",
        "Homefridge",
        "Minibar"
    ];
    
    $scope.articleList = ArticleResource.queryAll(function(items){
        $scope.articleSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("articleSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.refridgerator.article = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.refridgerator.article.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Refridgerators/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        RefridgeratorResource.save($scope.refridgerator, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Refridgerators");
    };
});