

angular.module('fridgeangularjs').controller('EditArticleController', function($scope, $routeParams, $location, ArticleResource , CategoryResource, RefridgeratorResource, IngredientResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.article = new ArticleResource(self.original);
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.article.category && item.id == $scope.article.category.id) {
                        $scope.categorySelection = labelObject;
                        $scope.article.category = wrappedObject;
                        self.original.category = $scope.article.category;
                    }
                    return labelObject;
                });
            });
            RefridgeratorResource.queryAll(function(items) {
                $scope.refridgeratorSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.article.refridgerator && item.id == $scope.article.refridgerator.id) {
                        $scope.refridgeratorSelection = labelObject;
                        $scope.article.refridgerator = wrappedObject;
                        self.original.refridgerator = $scope.article.refridgerator;
                    }
                    return labelObject;
                });
            });
            IngredientResource.queryAll(function(items) {
                $scope.ingredientSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.article.ingredient){
                        $.each($scope.article.ingredient, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.ingredientSelection.push(labelObject);
                                $scope.article.ingredient.push(wrappedObject);
                            }
                        });
                        self.original.ingredient = $scope.article.ingredient;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Articles");
        };
        ArticleResource.get({ArticleId:$routeParams.ArticleId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.article);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.article.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Articles");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Articles");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.article.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.article.category = {};
            $scope.article.category.id = selection.value;
        }
    });
    $scope.$watch("refridgeratorSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.article.refridgerator = {};
            $scope.article.refridgerator.id = selection.value;
        }
    });
    $scope.deletedList = [
        "Deleted",  
        "Not_Deleted"  
    ];
    $scope.ingredientSelection = $scope.ingredientSelection || [];
    $scope.$watch("ingredientSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.article) {
            $scope.article.ingredient = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.article.ingredient.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});