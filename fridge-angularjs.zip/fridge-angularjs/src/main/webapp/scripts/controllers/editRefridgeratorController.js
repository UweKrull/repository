

angular.module('fridgeangularjs').controller('EditRefridgeratorController', function($scope, $routeParams, $location, RefridgeratorResource , CustomerResource, ArticleResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.refridgerator = new RefridgeratorResource(self.original);
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName
                    };
                    if($scope.refridgerator.customer && item.id == $scope.refridgerator.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.refridgerator.customer = wrappedObject;
                        self.original.customer = $scope.refridgerator.customer;
                    }
                    return labelObject;
                });
            });
            ArticleResource.queryAll(function(items) {
                $scope.articleSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title+', '+(new Date(item.expiryDateTime)).toISOString().replace('T',' ').replace(':00.000Z','').replace('.000Z','').substring(0,10)
                    };
                    if($scope.refridgerator.article){
                        $.each($scope.refridgerator.article, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.articleSelection.push(labelObject);
                                $scope.refridgerator.article.push(wrappedObject);
                            }
                        });
                        self.original.article = $scope.refridgerator.article;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Refridgerators");
        };
        RefridgeratorResource.get({RefridgeratorId:$routeParams.RefridgeratorId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.refridgerator);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.refridgerator.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Refridgerators");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Refridgerators");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.refridgerator.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.refridgerator.customer = {};
            $scope.refridgerator.customer.id = selection.value;
        }
    });
    $scope.typeList = [
        "Superfridge",  
        "Homefridge",  
        "Minibar"  
    ];
    $scope.articleSelection = $scope.articleSelection || [];
    $scope.$watch("articleSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.refridgerator) {
            $scope.refridgerator.article = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.refridgerator.article.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});