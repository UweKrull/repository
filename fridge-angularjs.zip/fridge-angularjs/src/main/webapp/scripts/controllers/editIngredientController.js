

angular.module('fridgeangularjs').controller('EditIngredientController', function($scope, $routeParams, $location, IngredientResource , ArticleResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.ingredient = new IngredientResource(self.original);
            ArticleResource.queryAll(function(items) {
                $scope.articleSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.ingredient.article && item.id == $scope.ingredient.article.id) {
                        $scope.articleSelection = labelObject;
                        $scope.ingredient.article = wrappedObject;
                        self.original.article = $scope.ingredient.article;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Ingredients");
        };
        IngredientResource.get({IngredientId:$routeParams.IngredientId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.ingredient);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.ingredient.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Ingredients");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Ingredients");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.ingredient.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("articleSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.ingredient.article = {};
            $scope.ingredient.article.id = selection.value;
        }
    });
    $scope.typeList = [
        "Conserving",  
        "Nutrition",  
        "Modifier",  
        "TasteEnhancer"  
    ];
    
    $scope.get();
});