

angular.module('fridgeangularjs').controller('EditCustomerController', function($scope, $routeParams, $location, CustomerResource , RefridgeratorResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.customer = new CustomerResource(self.original);
            RefridgeratorResource.queryAll(function(items) {
                $scope.refridgeratorSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.customer.refridgerator){
                        $.each($scope.customer.refridgerator, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.refridgeratorSelection.push(labelObject);
                                $scope.customer.refridgerator.push(wrappedObject);
                            }
                        });
                        self.original.refridgerator = $scope.customer.refridgerator;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Customers");
        };
        CustomerResource.get({CustomerId:$routeParams.CustomerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.customer);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.customer.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Customers");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Customers");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.customer.$remove(successCallback, errorCallback);
    };
    
    $scope.refridgeratorSelection = $scope.refridgeratorSelection || [];
    $scope.$watch("refridgeratorSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.customer) {
            $scope.customer.refridgerator = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.customer.refridgerator.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});