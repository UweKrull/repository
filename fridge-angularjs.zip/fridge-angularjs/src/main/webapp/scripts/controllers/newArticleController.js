
angular.module('fridgeangularjs').controller('NewArticleController', function ($scope, $location, locationParser, ArticleResource , CategoryResource, RefridgeratorResource, IngredientResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.article = $scope.article || {};
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.article.category = {};
            $scope.article.category.id = selection.value;
        }
    });
    
    $scope.refridgeratorList = RefridgeratorResource.queryAll(function(items){
        $scope.refridgeratorSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("refridgeratorSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.article.refridgerator = {};
            $scope.article.refridgerator.id = selection.value;
        }
    });
    
    $scope.deletedList = [
        "Deleted",
        "Not_Deleted"
    ];
    
    $scope.ingredientList = IngredientResource.queryAll(function(items){
        $scope.ingredientSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("ingredientSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.article.ingredient = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.article.ingredient.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Articles/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ArticleResource.save($scope.article, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Articles");
    };
});