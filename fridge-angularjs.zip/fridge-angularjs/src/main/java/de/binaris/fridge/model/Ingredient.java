package de.binaris.fridge.model;

import static javax.persistence.EnumType.STRING;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>
 * An Ingredient has a name and a type.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "ingredient")
public class Ingredient implements Serializable {

	private static final long serialVersionUID = 7272771756721277965L;

	/**
	 * The ID of the Ingredient.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_ingredient")
	@SequenceGenerator(name = "my_entity_seq_gen_ingredient", sequenceName = "sequence_ingredient", allocationSize = 1)
	private Long id;

	@ManyToOne
	private Article article;

	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String name;
	
	@Column(name = "type")
    @Enumerated(STRING)
    private IngredientType type;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Article getArticle() {
		return article;
	}

	public void setArticle(Article article) {
		this.article = article;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public IngredientType getType() {
		return type;
	}

	public void setType(IngredientType type) {
		this.type = type;
	}

	/*
	 * toString(), equals() and hashCode() for Ingredient, using the natural
	 * identity of the object
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Ingredient)) {
			return false;
		}
		Ingredient castOther = (Ingredient) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name).append(", ");
		sb.append(type.toString());
		return sb.toString();
	}
}