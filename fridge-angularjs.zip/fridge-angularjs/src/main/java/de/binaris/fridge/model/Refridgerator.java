package de.binaris.fridge.model;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "refridgerator")
public class Refridgerator implements Serializable {

	private static final long serialVersionUID = 5555589729659127329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_refridgerator")
	@SequenceGenerator(name = "my_entity_seq_gen_refridgerator", sequenceName = "sequence_refridgerator", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String name;

	@Column(name = "type")
    @Enumerated(STRING)
    private RefridgeratorType type;
	
	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String description;

	@ManyToOne
	private Customer customer;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "refridgerator")
	private Set<Article> article = new HashSet<Article>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Customer getCustomer() {
		return customer;
	}
	
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
	public RefridgeratorType getType() {
		return type;
	}
	
	public void setType(RefridgeratorType type) {
		this.type = type;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<Article> getArticle() {
		return article;
	}
	
	public void setArticle(Set<Article> article) {
		this.article = article;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Refridgerator)) {
			return false;
		}
		Refridgerator castOther = (Refridgerator) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name).append(", ");
		sb.append(type);//.append(", ");
//		sb.append(description);
		return sb.toString();
	}
}