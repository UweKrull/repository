package de.binaris.fridge.model;

/**
 * <p>
 * The {@link IngredientType} describes the type of ingredients
 * Conserving or Nutrition or Modifier or TasteEnhancer .
 * 
 * IngredientType is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the Refridgerator types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link IngredientType} describes the ingredient types (C,N,M,T).
 * </p>
 */
public enum IngredientType {

    /**
     * The type of ingredient .
     */
    Conserving("C", true),
    Nutrition("N", true),  
    Modifier("M", true),
    TasteEnhancer("T", true);

    /**
     * A human readable description of the ingredient type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the ingredient type can be cached.
     */
    private final boolean cacheable;
    
    private IngredientType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}