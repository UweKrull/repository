package de.binaris.shows.rest.dto;

import java.io.Serializable;

import de.binaris.shows.model.BookByPhone;
import de.binaris.shows.rest.dto.NestedShowDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BookByPhoneDTO implements Serializable
{

   private Long id;
   private String phoneNumber;
   private String name;
   private NestedShowDTO show;

   public BookByPhoneDTO()
   {
   }

   public BookByPhoneDTO(final BookByPhone entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.phoneNumber = entity.getPhoneNumber();
         this.name = entity.getName();
         this.show = new NestedShowDTO(entity.getShow());
      }
   }

   public BookByPhone fromDTO(BookByPhone entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new BookByPhone();
      }
      entity.setPhoneNumber(this.phoneNumber);
      entity.setName(this.name);
      if (this.show != null)
      {
         entity.setShow(this.show.fromDTO(entity.getShow(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getPhoneNumber()
   {
      return this.phoneNumber;
   }

   public void setPhoneNumber(final String phoneNumber)
   {
      this.phoneNumber = phoneNumber;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public NestedShowDTO getShow()
   {
      return this.show;
   }

   public void setShow(final NestedShowDTO show)
   {
      this.show = show;
   }
}