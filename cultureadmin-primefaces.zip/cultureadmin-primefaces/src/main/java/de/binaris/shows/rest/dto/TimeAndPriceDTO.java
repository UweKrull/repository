package de.binaris.shows.rest.dto;

import java.io.Serializable;

import de.binaris.shows.model.TimeAndPrice;
import de.binaris.shows.rest.dto.NestedShowDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TimeAndPriceDTO implements Serializable
{

   private String startTime;
   private Long id;
   private String price;
   private String days;
   private NestedShowDTO show;
   private String seating;
   private String seller;

   public TimeAndPriceDTO()
   {
   }

   public TimeAndPriceDTO(final TimeAndPrice entity)
   {
      if (entity != null)
      {
         this.startTime = entity.getStartTime();
         this.id = entity.getId();
         this.price = entity.getPrice();
         this.days = entity.getDays();
         this.show = new NestedShowDTO(entity.getShow());
         this.seating = entity.getSeating();
         this.seller = entity.getSeller();
      }
   }

   public TimeAndPrice fromDTO(TimeAndPrice entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new TimeAndPrice();
      }
      entity.setStartTime(this.startTime);
      entity.setPrice(this.price);
      entity.setDays(this.days);
      if (this.show != null)
      {
         entity.setShow(this.show.fromDTO(entity.getShow(), em));
      }
      entity.setSeating(this.seating);
      entity.setSeller(this.seller);
      entity = em.merge(entity);
      return entity;
   }

   public String getStartTime()
   {
      return this.startTime;
   }

   public void setStartTime(final String startTime)
   {
      this.startTime = startTime;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getPrice()
   {
      return this.price;
   }

   public void setPrice(final String price)
   {
      this.price = price;
   }

   public String getDays()
   {
      return this.days;
   }

   public void setDays(final String days)
   {
      this.days = days;
   }

   public NestedShowDTO getShow()
   {
      return this.show;
   }

   public void setShow(final NestedShowDTO show)
   {
      this.show = show;
   }

   public String getSeating()
   {
      return this.seating;
   }

   public void setSeating(final String seating)
   {
      this.seating = seating;
   }

   public String getSeller()
   {
      return this.seller;
   }

   public void setSeller(final String seller)
   {
      this.seller = seller;
   }
}