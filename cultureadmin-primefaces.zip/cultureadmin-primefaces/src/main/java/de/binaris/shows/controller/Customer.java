package de.binaris.shows.controller;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import de.binaris.shows.annotations.Login;

@Cacheable
public class Customer implements Serializable {

	private static final long serialVersionUID = 7173777629393127779L;

	@NotNull
	@Size(min = 1, max = 10, message = "must be 1-10 letters and spaces")
	@Login
	private String login;

	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String password;
	
	public Customer() {
	}

	public Customer(final String login, final String password) {
		this.login = login;
		this.password = password;
	}
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Customer)) {
			return false;
		}
		Customer castOther = (Customer) object;
		return (login != null && password != null)? (login.compareTo(castOther.getLogin()) == 0 && password.compareTo(castOther.getPassword()) == 0) : false;
	}

	@Override
	public int hashCode() {
		return login != null ? login.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
//		sb.append("Customer: ");
		sb.append(login);
		return sb.toString();
	}
}