package de.binaris.shows.model;

/**
 * <p>
 * The {@link AdultOnlyType} describes the adult-only types (Yes, No, Unknown)
 * 
 * Adult-only is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the partner types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link AdultOnlyType} describes whether or not the
 * show is an adult-only one.
 * </p>
 */
public enum AdultOnlyType {

    /**
     * The AdultOnlyType of the show.
     */
    yes("yes", true),
    no("no", true);

    /**
     * A human readable description of the adult-only type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the adult-only type can be cached.
     */
    private final boolean cacheable;
    
    private AdultOnlyType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
