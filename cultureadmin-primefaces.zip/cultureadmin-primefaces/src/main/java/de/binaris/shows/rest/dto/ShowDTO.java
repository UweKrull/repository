package de.binaris.shows.rest.dto;

import java.io.Serializable;

import de.binaris.shows.model.Show;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.shows.model.TimeAndPrice;

import java.util.Iterator;

import de.binaris.shows.model.AdultOnlyType;
import de.binaris.shows.model.BookByPhone;
import de.binaris.shows.rest.dto.NestedBookByPhoneDTO;
import de.binaris.shows.rest.dto.NestedCategoryDTO;
import de.binaris.shows.rest.dto.NestedTimeAndPriceDTO;
import de.binaris.shows.rest.dto.NestedVenueDTO;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ShowDTO implements Serializable
{

   private String priceRangeMin;
   private Set<NestedTimeAndPriceDTO> timeAndPrice = new HashSet<NestedTimeAndPriceDTO>();
   private String linkBookOnlineAtVenue;
   private NestedVenueDTO venue;
   private String dressCode;
   private Long id;
   private String linkBookOnlineAtTicketmaster;
   private NestedCategoryDTO category;
   private String schedule;
   private AdultOnlyType adultOnly;
   private String linkBookOnlineAtShowtickets;
   private Set<NestedBookByPhoneDTO> bookByPhone = new HashSet<NestedBookByPhoneDTO>();
   private String description;
   private String priceRangeMax;
   private String name;
   private String linkDetails;
   private String linkSeatingChart;
   private String linkBookOnlineLocally;

   public ShowDTO()
   {
   }

   public ShowDTO(final Show entity)
   {
      if (entity != null)
      {
         this.priceRangeMin = entity.getPriceRangeMin();
         Iterator<TimeAndPrice> iterTimeAndPrice = entity.getTimeAndPrice()
               .iterator();
         for (; iterTimeAndPrice.hasNext();)
         {
            TimeAndPrice element = iterTimeAndPrice.next();
            this.timeAndPrice.add(new NestedTimeAndPriceDTO(element));
         }
         this.linkBookOnlineAtVenue = entity.getLinkBookOnlineAtVenue();
         this.venue = new NestedVenueDTO(entity.getVenue());
         this.dressCode = entity.getDressCode();
         this.id = entity.getId();
         this.linkBookOnlineAtTicketmaster = entity
               .getLinkBookOnlineAtTicketmaster();
         this.category = new NestedCategoryDTO(entity.getCategory());
         this.schedule = entity.getSchedule();
         this.adultOnly = entity.getAdultOnly();
         this.linkBookOnlineAtShowtickets = entity
               .getLinkBookOnlineAtShowtickets();
         Iterator<BookByPhone> iterBookByPhone = entity.getBookByPhone()
               .iterator();
         for (; iterBookByPhone.hasNext();)
         {
            BookByPhone element = iterBookByPhone.next();
            this.bookByPhone.add(new NestedBookByPhoneDTO(element));
         }
         this.description = entity.getDescription();
         this.priceRangeMax = entity.getPriceRangeMax();
         this.name = entity.getName();
         this.linkDetails = entity.getLinkDetails();
         this.linkSeatingChart = entity.getLinkSeatingChart();
         this.linkBookOnlineLocally = entity.getLinkBookOnlineLocally();
      }
   }

   public Show fromDTO(Show entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Show();
      }
      entity.setPriceRangeMin(this.priceRangeMin);
      Iterator<TimeAndPrice> iterTimeAndPrice = entity.getTimeAndPrice()
            .iterator();
      for (; iterTimeAndPrice.hasNext();)
      {
         boolean found = false;
         TimeAndPrice timeAndPrice = iterTimeAndPrice.next();
         Iterator<NestedTimeAndPriceDTO> iterDtoTimeAndPrice = this
               .getTimeAndPrice().iterator();
         for (; iterDtoTimeAndPrice.hasNext();)
         {
            NestedTimeAndPriceDTO dtoTimeAndPrice = iterDtoTimeAndPrice
                  .next();
            if (dtoTimeAndPrice.getId().equals(timeAndPrice.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterTimeAndPrice.remove();
         }
      }
      Iterator<NestedTimeAndPriceDTO> iterDtoTimeAndPrice = this
            .getTimeAndPrice().iterator();
      for (; iterDtoTimeAndPrice.hasNext();)
      {
         boolean found = false;
         NestedTimeAndPriceDTO dtoTimeAndPrice = iterDtoTimeAndPrice.next();
         iterTimeAndPrice = entity.getTimeAndPrice().iterator();
         for (; iterTimeAndPrice.hasNext();)
         {
            TimeAndPrice timeAndPrice = iterTimeAndPrice.next();
            if (dtoTimeAndPrice.getId().equals(timeAndPrice.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<TimeAndPrice> resultIter = em
                  .createQuery("SELECT DISTINCT t FROM TimeAndPrice t",
                        TimeAndPrice.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               TimeAndPrice result = resultIter.next();
               if (result.getId().equals(dtoTimeAndPrice.getId()))
               {
                  entity.getTimeAndPrice().add(result);
                  break;
               }
            }
         }
      }
      entity.setLinkBookOnlineAtVenue(this.linkBookOnlineAtVenue);
      if (this.venue != null)
      {
         entity.setVenue(this.venue.fromDTO(entity.getVenue(), em));
      }
      entity.setDressCode(this.dressCode);
      entity.setLinkBookOnlineAtTicketmaster(this.linkBookOnlineAtTicketmaster);
      if (this.category != null)
      {
         entity.setCategory(this.category.fromDTO(entity.getCategory(), em));
      }
      entity.setSchedule(this.schedule);
      entity.setAdultOnly(this.adultOnly);
      entity.setLinkBookOnlineAtShowtickets(this.linkBookOnlineAtShowtickets);
      Iterator<BookByPhone> iterBookByPhone = entity.getBookByPhone()
            .iterator();
      for (; iterBookByPhone.hasNext();)
      {
         boolean found = false;
         BookByPhone bookByPhone = iterBookByPhone.next();
         Iterator<NestedBookByPhoneDTO> iterDtoBookByPhone = this
               .getBookByPhone().iterator();
         for (; iterDtoBookByPhone.hasNext();)
         {
            NestedBookByPhoneDTO dtoBookByPhone = iterDtoBookByPhone.next();
            if (dtoBookByPhone.getId().equals(bookByPhone.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterBookByPhone.remove();
         }
      }
      Iterator<NestedBookByPhoneDTO> iterDtoBookByPhone = this
            .getBookByPhone().iterator();
      for (; iterDtoBookByPhone.hasNext();)
      {
         boolean found = false;
         NestedBookByPhoneDTO dtoBookByPhone = iterDtoBookByPhone.next();
         iterBookByPhone = entity.getBookByPhone().iterator();
         for (; iterBookByPhone.hasNext();)
         {
            BookByPhone bookByPhone = iterBookByPhone.next();
            if (dtoBookByPhone.getId().equals(bookByPhone.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<BookByPhone> resultIter = em
                  .createQuery("SELECT DISTINCT b FROM BookByPhone b",
                        BookByPhone.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               BookByPhone result = resultIter.next();
               if (result.getId().equals(dtoBookByPhone.getId()))
               {
                  entity.getBookByPhone().add(result);
                  break;
               }
            }
         }
      }
      entity.setDescription(this.description);
      entity.setPriceRangeMax(this.priceRangeMax);
      entity.setName(this.name);
      entity.setLinkDetails(this.linkDetails);
      entity.setLinkSeatingChart(this.linkSeatingChart);
      entity.setLinkBookOnlineLocally(this.linkBookOnlineLocally);
      entity = em.merge(entity);
      return entity;
   }

   public String getPriceRangeMin()
   {
      return this.priceRangeMin;
   }

   public void setPriceRangeMin(final String priceRangeMin)
   {
      this.priceRangeMin = priceRangeMin;
   }

   public Set<NestedTimeAndPriceDTO> getTimeAndPrice()
   {
      return this.timeAndPrice;
   }

   public void setTimeAndPrice(final Set<NestedTimeAndPriceDTO> timeAndPrice)
   {
      this.timeAndPrice = timeAndPrice;
   }

   public String getLinkBookOnlineAtVenue()
   {
      return this.linkBookOnlineAtVenue;
   }

   public void setLinkBookOnlineAtVenue(final String linkBookOnlineAtVenue)
   {
      this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
   }

   public NestedVenueDTO getVenue()
   {
      return this.venue;
   }

   public void setVenue(final NestedVenueDTO venue)
   {
      this.venue = venue;
   }

   public String getDressCode()
   {
      return this.dressCode;
   }

   public void setDressCode(final String dressCode)
   {
      this.dressCode = dressCode;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getLinkBookOnlineAtTicketmaster()
   {
      return this.linkBookOnlineAtTicketmaster;
   }

   public void setLinkBookOnlineAtTicketmaster(
         final String linkBookOnlineAtTicketmaster)
   {
      this.linkBookOnlineAtTicketmaster = linkBookOnlineAtTicketmaster;
   }

   public NestedCategoryDTO getCategory()
   {
      return this.category;
   }

   public void setCategory(final NestedCategoryDTO category)
   {
      this.category = category;
   }

   public String getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final String schedule)
   {
      this.schedule = schedule;
   }

   public AdultOnlyType getAdultOnly()
   {
      return this.adultOnly;
   }

   public void setAdultOnly(final AdultOnlyType adultOnly)
   {
      this.adultOnly = adultOnly;
   }

   public String getLinkBookOnlineAtShowtickets()
   {
      return this.linkBookOnlineAtShowtickets;
   }

   public void setLinkBookOnlineAtShowtickets(
         final String linkBookOnlineAtShowtickets)
   {
      this.linkBookOnlineAtShowtickets = linkBookOnlineAtShowtickets;
   }

   public Set<NestedBookByPhoneDTO> getBookByPhone()
   {
      return this.bookByPhone;
   }

   public void setBookByPhone(final Set<NestedBookByPhoneDTO> bookByPhone)
   {
      this.bookByPhone = bookByPhone;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getPriceRangeMax()
   {
      return this.priceRangeMax;
   }

   public void setPriceRangeMax(final String priceRangeMax)
   {
      this.priceRangeMax = priceRangeMax;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLinkDetails()
   {
      return this.linkDetails;
   }

   public void setLinkDetails(final String linkDetails)
   {
      this.linkDetails = linkDetails;
   }

   public String getLinkSeatingChart()
   {
      return this.linkSeatingChart;
   }

   public void setLinkSeatingChart(final String linkSeatingChart)
   {
      this.linkSeatingChart = linkSeatingChart;
   }

   public String getLinkBookOnlineLocally()
   {
      return this.linkBookOnlineLocally;
   }

   public void setLinkBookOnlineLocally(final String linkBookOnlineLocally)
   {
      this.linkBookOnlineLocally = linkBookOnlineLocally;
   }
}