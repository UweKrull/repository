package de.binaris.view;

import java.io.Serializable;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.NoResultException;

import de.binaris.shows.controller.Customer;

/**
 * Backing bean for Customer.
 */
@Named
@Stateful
@ConversationScoped
public class CustomerBean implements Serializable {

	private static final long serialVersionUID = 7157791350753273391L;

	private static final Customer loginCustomer = new Customer("showfinder", "finder");
	
	private String login;

	public String getLogin() {
		return this.login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	private Customer customer;

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Customer getCustomer() {
		return this.customer;
	}
	
	@Inject
	private Conversation conversation;

	public String create() {

		this.conversation.begin();
		return "create?faces-redirect=true";
	}

	public void retrieve() {

		if (FacesContext.getCurrentInstance().isPostback()) {
			return;
		}

		if (this.conversation.isTransient()) {
			this.conversation.begin();
		}

		if (this.login == null) {
			this.customer = this.example;
		} else {
			this.customer = loginCustomer.equals(new Customer(getLogin(), loginCustomer.getPassword()))? loginCustomer : null;
		}
	}

	public Customer findById(Long id) {
		return loginCustomer.equals(new Customer(getLogin(), loginCustomer.getPassword()))? loginCustomer : null;
	}

	public Customer findByLogin(String login) {
        try {
        	return loginCustomer.equals(new Customer(login, loginCustomer.getPassword()))? loginCustomer : null;
        } catch (NoResultException e) {
            return null;
        }
	}
	
	public Customer findCustomer(String login, String pwd) {
		try {
			return loginCustomer.equals(new Customer(login, pwd))? loginCustomer : null;
		} catch (NoResultException e) {
			return null;
		}
	}
	
	public String createNew() {
		this.conversation.end();

		try {
			if (this.login == null) {
				return "signon?faces-redirect=true";
			} else {
				if (this.customer == null) {
					this.customer = loginCustomer.equals(new Customer(getLogin(), loginCustomer.getPassword()))? loginCustomer : null;
				}
				return "signon?faces-redirect=true&id=" + this.customer.getLogin();
			}
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}

	public String update() {
		this.conversation.end();
		
		try {
			if (this.login == null) {
				return "search?faces-redirect=true";
			} else {
				return "view?faces-redirect=true&id=" + this.customer.getLogin();
			}
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}
	
	public String delete() {
		this.conversation.end();

		try {
			this.customer = null;
			return "search?faces-redirect=true";
		} catch (Exception e) {
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(e.getMessage()));
			return null;
		}
	}
	
	private Customer example = new Customer();

	public Customer getExample() {
		return this.example;
	}

	public void setExample(Customer example) {
		this.example = example;
	}

	@Resource
	private SessionContext sessionContext;

	public Converter getConverter() {

		final CustomerBean ejbProxy = this.sessionContext
				.getBusinessObject(CustomerBean.class);

		return new Converter() {

			@Override
			public Object getAsObject(FacesContext context,
					UIComponent component, String value) {

				return findById(Long.valueOf(value));
			}

			@Override
			public String getAsString(FacesContext context,
					UIComponent component, Object value) {

				if (value == null) {
					return "";
				}

				return String.valueOf(((Customer) value).getLogin());
			}
		};
	}

	/*
	 * Support adding children to bidirectional, one-to-many tables
	 */

	private Customer add = new Customer();

	public Customer getAdd() {
		return this.add;
	}

	public Customer getAdded() {
		Customer added = this.add;
		this.add = new Customer();
		return added;
	}
}