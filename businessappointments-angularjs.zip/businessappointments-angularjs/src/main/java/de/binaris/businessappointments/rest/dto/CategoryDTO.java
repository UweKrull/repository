package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;

import de.binaris.businessappointments.model.Category;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessappointments.model.Appointment;
import de.binaris.businessappointments.rest.dto.NestedAppointmentDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable
{

   private Long id;
   private String description;
   private String name;
   private Set<NestedAppointmentDTO> appointment = new HashSet<NestedAppointmentDTO>();

   public CategoryDTO()
   {
   }

   public CategoryDTO(final Category entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         Iterator<Appointment> iterAppointment = entity.getAppointment()
               .iterator();
         for (; iterAppointment.hasNext();)
         {
            Appointment element = iterAppointment.next();
            this.appointment.add(new NestedAppointmentDTO(element));
         }
      }
   }

   public Category fromDTO(Category entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Category();
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      Iterator<Appointment> iterAppointment = entity.getAppointment()
            .iterator();
      for (; iterAppointment.hasNext();)
      {
         boolean found = false;
         Appointment appointment = iterAppointment.next();
         Iterator<NestedAppointmentDTO> iterDtoAppointment = this
               .getAppointment().iterator();
         for (; iterDtoAppointment.hasNext();)
         {
            NestedAppointmentDTO dtoAppointment = iterDtoAppointment.next();
            if (dtoAppointment.getId().equals(appointment.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterAppointment.remove();
         }
      }
      Iterator<NestedAppointmentDTO> iterDtoAppointment = this
            .getAppointment().iterator();
      for (; iterDtoAppointment.hasNext();)
      {
         boolean found = false;
         NestedAppointmentDTO dtoAppointment = iterDtoAppointment.next();
         iterAppointment = entity.getAppointment().iterator();
         for (; iterAppointment.hasNext();)
         {
            Appointment appointment = iterAppointment.next();
            if (dtoAppointment.getId().equals(appointment.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Appointment> resultIter = em
                  .createQuery("SELECT DISTINCT a FROM Appointment a",
                        Appointment.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Appointment result = resultIter.next();
               if (result.getId().equals(dtoAppointment.getId()))
               {
                  entity.getAppointment().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Set<NestedAppointmentDTO> getAppointment()
   {
      return this.appointment;
   }

   public void setAppointment(final Set<NestedAppointmentDTO> appointment)
   {
      this.appointment = appointment;
   }
}