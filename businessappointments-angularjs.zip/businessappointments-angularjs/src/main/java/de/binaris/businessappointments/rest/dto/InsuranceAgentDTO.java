package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;

import de.binaris.businessappointments.model.InsuranceAgent;
import de.binaris.businessappointments.rest.dto.AddressDTO;
import de.binaris.businessappointments.rest.dto.NestedAppointmentDTO;

import javax.persistence.EntityManager;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class InsuranceAgentDTO implements Serializable
{

   private Date dateOfBirth;
   private String lastName;
   private String phone;
   private String password;
   private NestedAppointmentDTO appointment;
   private Long id;
   private String aliasName;
   private String email;
   private AddressDTO address;
   private String login;
   private Date lastTimeAttended;
   private String firstName;

   public InsuranceAgentDTO()
   {
   }

   public InsuranceAgentDTO(final InsuranceAgent entity)
   {
      if (entity != null)
      {
         this.dateOfBirth = entity.getDateOfBirth();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         this.password = entity.getPassword();
         this.appointment = new NestedAppointmentDTO(entity.getAppointment());
         this.id = entity.getId();
         this.aliasName = entity.getAliasName();
         this.email = entity.getEmail();
         this.address = new AddressDTO(entity.getAddress());
         this.login = entity.getLogin();
         this.lastTimeAttended = entity.getLastTimeAttended();
         this.firstName = entity.getFirstName();
      }
   }

   public InsuranceAgent fromDTO(InsuranceAgent entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new InsuranceAgent();
      }
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      entity.setPassword(this.password);
      if (this.appointment != null)
      {
         entity.setAppointment(this.appointment.fromDTO(
               entity.getAppointment(), em));
      }
      entity.setAliasName(this.aliasName);
      entity.setEmail(this.email);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setLogin(this.login);
      entity.setLastTimeAttended(this.lastTimeAttended);
      entity.setFirstName(this.firstName);
      entity = em.merge(entity);
      return entity;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }

   public NestedAppointmentDTO getAppointment()
   {
      return this.appointment;
   }

   public void setAppointment(final NestedAppointmentDTO appointment)
   {
      this.appointment = appointment;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getAliasName()
   {
      return this.aliasName;
   }

   public void setAliasName(final String aliasName)
   {
      this.aliasName = aliasName;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public Date getLastTimeAttended()
   {
      return this.lastTimeAttended;
   }

   public void setLastTimeAttended(final Date lastTimeAttended)
   {
      this.lastTimeAttended = lastTimeAttended;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }
}