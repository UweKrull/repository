package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;

import de.binaris.businessappointments.model.EquipmentType;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessappointments.model.Equipment;
import de.binaris.businessappointments.rest.dto.NestedEquipmentDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EquipmentTypeDTO implements Serializable
{

   private Long id;
   private String description;
   private String name;
   private Set<NestedEquipmentDTO> equipment = new HashSet<NestedEquipmentDTO>();

   public EquipmentTypeDTO()
   {
   }

   public EquipmentTypeDTO(final EquipmentType entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         Iterator<Equipment> iterEquipment = entity.getEquipment()
               .iterator();
         for (; iterEquipment.hasNext();)
         {
            Equipment element = iterEquipment.next();
            this.equipment.add(new NestedEquipmentDTO(element));
         }
      }
   }

   public EquipmentType fromDTO(EquipmentType entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new EquipmentType();
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      Iterator<Equipment> iterEquipment = entity.getEquipment().iterator();
      for (; iterEquipment.hasNext();)
      {
         boolean found = false;
         Equipment equipment = iterEquipment.next();
         Iterator<NestedEquipmentDTO> iterDtoEquipment = this.getEquipment()
               .iterator();
         for (; iterDtoEquipment.hasNext();)
         {
            NestedEquipmentDTO dtoEquipment = iterDtoEquipment.next();
            if (dtoEquipment.getId().equals(equipment.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterEquipment.remove();
         }
      }
      Iterator<NestedEquipmentDTO> iterDtoEquipment = this.getEquipment()
            .iterator();
      for (; iterDtoEquipment.hasNext();)
      {
         boolean found = false;
         NestedEquipmentDTO dtoEquipment = iterDtoEquipment.next();
         iterEquipment = entity.getEquipment().iterator();
         for (; iterEquipment.hasNext();)
         {
            Equipment equipment = iterEquipment.next();
            if (dtoEquipment.getId().equals(equipment.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Equipment> resultIter = em
                  .createQuery("SELECT DISTINCT e FROM Equipment e",
                        Equipment.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Equipment result = resultIter.next();
               if (result.getId().equals(dtoEquipment.getId()))
               {
                  entity.getEquipment().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Set<NestedEquipmentDTO> getEquipment()
   {
      return this.equipment;
   }

   public void setEquipment(final Set<NestedEquipmentDTO> equipment)
   {
      this.equipment = equipment;
   }
}