package de.binaris.businessappointments.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.businessappointments.model.InsuranceAgent;
import de.binaris.businessappointments.rest.dto.InsuranceAgentDTO;

/**
 * 
 */
@Stateless
@Path("/insuranceagents")
public class InsuranceAgentEndpoint
{
   @PersistenceContext(unitName = "BusinessappointmentsPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(InsuranceAgentDTO dto)
   {
      InsuranceAgent entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(InsuranceAgentEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      InsuranceAgent entity = em.find(InsuranceAgent.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<InsuranceAgent> findByIdQuery = em.createQuery("SELECT DISTINCT i FROM InsuranceAgent i LEFT JOIN FETCH i.appointment WHERE i.id = :entityId ORDER BY i.id", InsuranceAgent.class);
      findByIdQuery.setParameter("entityId", id);
      InsuranceAgent entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      InsuranceAgentDTO dto = new InsuranceAgentDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<InsuranceAgentDTO> listAll()
   {
      final List<InsuranceAgent> searchResults = em.createQuery("SELECT DISTINCT i FROM InsuranceAgent i LEFT JOIN FETCH i.appointment ORDER BY i.id", InsuranceAgent.class).getResultList();
      final List<InsuranceAgentDTO> results = new ArrayList<InsuranceAgentDTO>();
      for (InsuranceAgent searchResult : searchResults)
      {
         InsuranceAgentDTO dto = new InsuranceAgentDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, InsuranceAgentDTO dto)
   {
      TypedQuery<InsuranceAgent> findByIdQuery = em.createQuery("SELECT DISTINCT i FROM InsuranceAgent i LEFT JOIN FETCH i.appointment WHERE i.id = :entityId ORDER BY i.id", InsuranceAgent.class);
      findByIdQuery.setParameter("entityId", id);
      InsuranceAgent entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}