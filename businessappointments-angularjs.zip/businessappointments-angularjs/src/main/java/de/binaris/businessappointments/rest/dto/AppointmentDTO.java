package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;

import de.binaris.businessappointments.model.Appointment;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessappointments.model.Equipment;

import java.util.Iterator;

import de.binaris.businessappointments.model.InsuranceAgent;
import de.binaris.businessappointments.model.TimeAndCharge;
import de.binaris.businessappointments.model.PhoneContact;
import de.binaris.businessappointments.model.PrivateOnlyType;
import de.binaris.businessappointments.rest.dto.NestedCategoryDTO;
import de.binaris.businessappointments.rest.dto.NestedEquipmentDTO;
import de.binaris.businessappointments.rest.dto.NestedInsuranceAgentDTO;
import de.binaris.businessappointments.rest.dto.NestedPhoneContactDTO;
import de.binaris.businessappointments.rest.dto.NestedTimeAndChargeDTO;
import de.binaris.businessappointments.rest.dto.NestedVenueDTO;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AppointmentDTO implements Serializable
{

   private Set<NestedEquipmentDTO> equipment = new HashSet<NestedEquipmentDTO>();
   private String dressCode;
   private Long id;
   private Set<NestedInsuranceAgentDTO> insuranceAgent = new HashSet<NestedInsuranceAgentDTO>();
   private Set<NestedTimeAndChargeDTO> timeAndCharge = new HashSet<NestedTimeAndChargeDTO>();
   private String description;
   private String name;
   private String appointmentWebsite;
   private String linkDrinkMenu;
   private String linkBookOnlineAtVenue;
   private String businessContactLink10;
   private String appointmentParticipantsNames;
   private String hostname;
   private NestedVenueDTO venue;
   private NestedCategoryDTO category;
   private String schedule;
   private String businessContactLink1;
   private Set<NestedPhoneContactDTO> phoneContact = new HashSet<NestedPhoneContactDTO>();
   private String businessContactLink2;
   private String linkDetails;
   private String businessContactLink3;
   private String businessContactLink4;
   private String businessContactLink5;
   private String linkGooglemaps;
   private String businessContactLink6;
   private String businessContactLink7;
   private String businessContactLink8;
   private PrivateOnlyType privateOnly;
   private String businessContactLink9;

   public AppointmentDTO()
   {
   }

   public AppointmentDTO(final Appointment entity)
   {
      if (entity != null)
      {
         Iterator<Equipment> iterEquipment = entity.getEquipment()
               .iterator();
         for (; iterEquipment.hasNext();)
         {
            Equipment element = iterEquipment.next();
            this.equipment.add(new NestedEquipmentDTO(element));
         }
         this.dressCode = entity.getDressCode();
         this.id = entity.getId();
         Iterator<InsuranceAgent> iterInsuranceAgent = entity
               .getInsuranceAgent().iterator();
         for (; iterInsuranceAgent.hasNext();)
         {
            InsuranceAgent element = iterInsuranceAgent.next();
            this.insuranceAgent.add(new NestedInsuranceAgentDTO(element));
         }
         Iterator<TimeAndCharge> iterTimeAndCharge = entity
               .getTimeAndCharge().iterator();
         for (; iterTimeAndCharge.hasNext();)
         {
            TimeAndCharge element = iterTimeAndCharge.next();
            this.timeAndCharge.add(new NestedTimeAndChargeDTO(element));
         }
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.appointmentWebsite = entity.getAppointmentWebsite();
         this.linkDrinkMenu = entity.getLinkDrinkMenu();
         this.linkBookOnlineAtVenue = entity.getLinkBookOnlineAtVenue();
         this.businessContactLink10 = entity.getBusinessContactLink10();
         this.appointmentParticipantsNames = entity
               .getAppointmentParticipantsNames();
         this.hostname = entity.getHostname();
         this.venue = new NestedVenueDTO(entity.getVenue());
         this.category = new NestedCategoryDTO(entity.getCategory());
         this.schedule = entity.getSchedule();
         this.businessContactLink1 = entity.getBusinessContactLink1();
         Iterator<PhoneContact> iterPhoneContact = entity.getPhoneContact()
               .iterator();
         for (; iterPhoneContact.hasNext();)
         {
            PhoneContact element = iterPhoneContact.next();
            this.phoneContact.add(new NestedPhoneContactDTO(element));
         }
         this.businessContactLink2 = entity.getBusinessContactLink2();
         this.linkDetails = entity.getLinkDetails();
         this.businessContactLink3 = entity.getBusinessContactLink3();
         this.businessContactLink4 = entity.getBusinessContactLink4();
         this.businessContactLink5 = entity.getBusinessContactLink5();
         this.linkGooglemaps = entity.getLinkGooglemaps();
         this.businessContactLink6 = entity.getBusinessContactLink6();
         this.businessContactLink7 = entity.getBusinessContactLink7();
         this.businessContactLink8 = entity.getBusinessContactLink8();
         this.privateOnly = entity.getPrivateOnly();
         this.businessContactLink9 = entity.getBusinessContactLink9();
      }
   }

   public Appointment fromDTO(Appointment entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Appointment();
      }
      Iterator<Equipment> iterEquipment = entity.getEquipment().iterator();
      for (; iterEquipment.hasNext();)
      {
         boolean found = false;
         Equipment equipment = iterEquipment.next();
         Iterator<NestedEquipmentDTO> iterDtoEquipment = this.getEquipment()
               .iterator();
         for (; iterDtoEquipment.hasNext();)
         {
            NestedEquipmentDTO dtoEquipment = iterDtoEquipment.next();
            if (dtoEquipment.getId().equals(equipment.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterEquipment.remove();
         }
      }
      Iterator<NestedEquipmentDTO> iterDtoEquipment = this.getEquipment()
            .iterator();
      for (; iterDtoEquipment.hasNext();)
      {
         boolean found = false;
         NestedEquipmentDTO dtoEquipment = iterDtoEquipment.next();
         iterEquipment = entity.getEquipment().iterator();
         for (; iterEquipment.hasNext();)
         {
            Equipment equipment = iterEquipment.next();
            if (dtoEquipment.getId().equals(equipment.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Equipment> resultIter = em
                  .createQuery("SELECT DISTINCT e FROM Equipment e",
                        Equipment.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Equipment result = resultIter.next();
               if (result.getId().equals(dtoEquipment.getId()))
               {
                  entity.getEquipment().add(result);
                  break;
               }
            }
         }
      }
      entity.setDressCode(this.dressCode);
      Iterator<InsuranceAgent> iterInsuranceAgent = entity
            .getInsuranceAgent().iterator();
      for (; iterInsuranceAgent.hasNext();)
      {
         boolean found = false;
         InsuranceAgent insuranceAgent = iterInsuranceAgent.next();
         Iterator<NestedInsuranceAgentDTO> iterDtoInsuranceAgent = this
               .getInsuranceAgent().iterator();
         for (; iterDtoInsuranceAgent.hasNext();)
         {
            NestedInsuranceAgentDTO dtoInsuranceAgent = iterDtoInsuranceAgent
                  .next();
            if (dtoInsuranceAgent.getId().equals(insuranceAgent.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterInsuranceAgent.remove();
         }
      }
      Iterator<NestedInsuranceAgentDTO> iterDtoInsuranceAgent = this
            .getInsuranceAgent().iterator();
      for (; iterDtoInsuranceAgent.hasNext();)
      {
         boolean found = false;
         NestedInsuranceAgentDTO dtoInsuranceAgent = iterDtoInsuranceAgent
               .next();
         iterInsuranceAgent = entity.getInsuranceAgent().iterator();
         for (; iterInsuranceAgent.hasNext();)
         {
            InsuranceAgent insuranceAgent = iterInsuranceAgent.next();
            if (dtoInsuranceAgent.getId().equals(insuranceAgent.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<InsuranceAgent> resultIter = em
                  .createQuery("SELECT DISTINCT i FROM InsuranceAgent i",
                        InsuranceAgent.class).getResultList()
                  .iterator();
            for (; resultIter.hasNext();)
            {
               InsuranceAgent result = resultIter.next();
               if (result.getId().equals(dtoInsuranceAgent.getId()))
               {
                  entity.getInsuranceAgent().add(result);
                  break;
               }
            }
         }
      }
      Iterator<TimeAndCharge> iterTimeAndCharge = entity.getTimeAndCharge()
            .iterator();
      for (; iterTimeAndCharge.hasNext();)
      {
         boolean found = false;
         TimeAndCharge timeAndCharge = iterTimeAndCharge.next();
         Iterator<NestedTimeAndChargeDTO> iterDtoTimeAndCharge = this
               .getTimeAndCharge().iterator();
         for (; iterDtoTimeAndCharge.hasNext();)
         {
            NestedTimeAndChargeDTO dtoTimeAndCharge = iterDtoTimeAndCharge
                  .next();
            if (dtoTimeAndCharge.getId().equals(timeAndCharge.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterTimeAndCharge.remove();
         }
      }
      Iterator<NestedTimeAndChargeDTO> iterDtoTimeAndCharge = this
            .getTimeAndCharge().iterator();
      for (; iterDtoTimeAndCharge.hasNext();)
      {
         boolean found = false;
         NestedTimeAndChargeDTO dtoTimeAndCharge = iterDtoTimeAndCharge
               .next();
         iterTimeAndCharge = entity.getTimeAndCharge().iterator();
         for (; iterTimeAndCharge.hasNext();)
         {
            TimeAndCharge timeAndCharge = iterTimeAndCharge.next();
            if (dtoTimeAndCharge.getId().equals(timeAndCharge.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<TimeAndCharge> resultIter = em
                  .createQuery("SELECT DISTINCT t FROM TimeAndCharge t",
                        TimeAndCharge.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               TimeAndCharge result = resultIter.next();
               if (result.getId().equals(dtoTimeAndCharge.getId()))
               {
                  entity.getTimeAndCharge().add(result);
                  break;
               }
            }
         }
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setAppointmentWebsite(this.appointmentWebsite);
      entity.setLinkDrinkMenu(this.linkDrinkMenu);
      entity.setLinkBookOnlineAtVenue(this.linkBookOnlineAtVenue);
      entity.setBusinessContactLink10(this.businessContactLink10);
      entity.setAppointmentParticipantsNames(this.appointmentParticipantsNames);
      entity.setHostname(this.hostname);
      if (this.venue != null)
      {
         entity.setVenue(this.venue.fromDTO(entity.getVenue(), em));
      }
      if (this.category != null)
      {
         entity.setCategory(this.category.fromDTO(entity.getCategory(), em));
      }
      entity.setSchedule(this.schedule);
      entity.setBusinessContactLink1(this.businessContactLink1);
      Iterator<PhoneContact> iterPhoneContact = entity.getPhoneContact()
            .iterator();
      for (; iterPhoneContact.hasNext();)
      {
         boolean found = false;
         PhoneContact phoneContact = iterPhoneContact.next();
         Iterator<NestedPhoneContactDTO> iterDtoPhoneContact = this
               .getPhoneContact().iterator();
         for (; iterDtoPhoneContact.hasNext();)
         {
            NestedPhoneContactDTO dtoPhoneContact = iterDtoPhoneContact
                  .next();
            if (dtoPhoneContact.getId().equals(phoneContact.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterPhoneContact.remove();
         }
      }
      Iterator<NestedPhoneContactDTO> iterDtoPhoneContact = this
            .getPhoneContact().iterator();
      for (; iterDtoPhoneContact.hasNext();)
      {
         boolean found = false;
         NestedPhoneContactDTO dtoPhoneContact = iterDtoPhoneContact.next();
         iterPhoneContact = entity.getPhoneContact().iterator();
         for (; iterPhoneContact.hasNext();)
         {
            PhoneContact phoneContact = iterPhoneContact.next();
            if (dtoPhoneContact.getId().equals(phoneContact.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<PhoneContact> resultIter = em
                  .createQuery("SELECT DISTINCT p FROM PhoneContact p",
                        PhoneContact.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               PhoneContact result = resultIter.next();
               if (result.getId().equals(dtoPhoneContact.getId()))
               {
                  entity.getPhoneContact().add(result);
                  break;
               }
            }
         }
      }
      entity.setBusinessContactLink2(this.businessContactLink2);
      entity.setLinkDetails(this.linkDetails);
      entity.setBusinessContactLink3(this.businessContactLink3);
      entity.setBusinessContactLink4(this.businessContactLink4);
      entity.setBusinessContactLink5(this.businessContactLink5);
      entity.setLinkGooglemaps(this.linkGooglemaps);
      entity.setBusinessContactLink6(this.businessContactLink6);
      entity.setBusinessContactLink7(this.businessContactLink7);
      entity.setBusinessContactLink8(this.businessContactLink8);
      entity.setPrivateOnly(this.privateOnly);
      entity.setBusinessContactLink9(this.businessContactLink9);
      entity = em.merge(entity);
      return entity;
   }

   public Set<NestedEquipmentDTO> getEquipment()
   {
      return this.equipment;
   }

   public void setEquipment(final Set<NestedEquipmentDTO> equipment)
   {
      this.equipment = equipment;
   }

   public String getDressCode()
   {
      return this.dressCode;
   }

   public void setDressCode(final String dressCode)
   {
      this.dressCode = dressCode;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedInsuranceAgentDTO> getInsuranceAgent()
   {
      return this.insuranceAgent;
   }

   public void setInsuranceAgent(
         final Set<NestedInsuranceAgentDTO> insuranceAgent)
   {
      this.insuranceAgent = insuranceAgent;
   }

   public Set<NestedTimeAndChargeDTO> getTimeAndCharge()
   {
      return this.timeAndCharge;
   }

   public void setTimeAndCharge(final Set<NestedTimeAndChargeDTO> timeAndCharge)
   {
      this.timeAndCharge = timeAndCharge;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getAppointmentWebsite()
   {
      return this.appointmentWebsite;
   }

   public void setAppointmentWebsite(final String appointmentWebsite)
   {
      this.appointmentWebsite = appointmentWebsite;
   }

   public String getLinkDrinkMenu()
   {
      return this.linkDrinkMenu;
   }

   public void setLinkDrinkMenu(final String linkDrinkMenu)
   {
      this.linkDrinkMenu = linkDrinkMenu;
   }

   public String getLinkBookOnlineAtVenue()
   {
      return this.linkBookOnlineAtVenue;
   }

   public void setLinkBookOnlineAtVenue(final String linkBookOnlineAtVenue)
   {
      this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
   }

   public String getBusinessContactLink10()
   {
      return this.businessContactLink10;
   }

   public void setBusinessContactLink10(final String businessContactLink10)
   {
      this.businessContactLink10 = businessContactLink10;
   }

   public String getAppointmentParticipantsNames()
   {
      return this.appointmentParticipantsNames;
   }

   public void setAppointmentParticipantsNames(
         final String appointmentParticipantsNames)
   {
      this.appointmentParticipantsNames = appointmentParticipantsNames;
   }

   public String getHostname()
   {
      return this.hostname;
   }

   public void setHostname(final String hostname)
   {
      this.hostname = hostname;
   }

   public NestedVenueDTO getVenue()
   {
      return this.venue;
   }

   public void setVenue(final NestedVenueDTO venue)
   {
      this.venue = venue;
   }

   public NestedCategoryDTO getCategory()
   {
      return this.category;
   }

   public void setCategory(final NestedCategoryDTO category)
   {
      this.category = category;
   }

   public String getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final String schedule)
   {
      this.schedule = schedule;
   }

   public String getBusinessContactLink1()
   {
      return this.businessContactLink1;
   }

   public void setBusinessContactLink1(final String businessContactLink1)
   {
      this.businessContactLink1 = businessContactLink1;
   }

   public Set<NestedPhoneContactDTO> getPhoneContact()
   {
      return this.phoneContact;
   }

   public void setPhoneContact(final Set<NestedPhoneContactDTO> phoneContact)
   {
      this.phoneContact = phoneContact;
   }

   public String getBusinessContactLink2()
   {
      return this.businessContactLink2;
   }

   public void setBusinessContactLink2(final String businessContactLink2)
   {
      this.businessContactLink2 = businessContactLink2;
   }

   public String getLinkDetails()
   {
      return this.linkDetails;
   }

   public void setLinkDetails(final String linkDetails)
   {
      this.linkDetails = linkDetails;
   }

   public String getBusinessContactLink3()
   {
      return this.businessContactLink3;
   }

   public void setBusinessContactLink3(final String businessContactLink3)
   {
      this.businessContactLink3 = businessContactLink3;
   }

   public String getBusinessContactLink4()
   {
      return this.businessContactLink4;
   }

   public void setBusinessContactLink4(final String businessContactLink4)
   {
      this.businessContactLink4 = businessContactLink4;
   }

   public String getBusinessContactLink5()
   {
      return this.businessContactLink5;
   }

   public void setBusinessContactLink5(final String businessContactLink5)
   {
      this.businessContactLink5 = businessContactLink5;
   }

   public String getLinkGooglemaps()
   {
      return this.linkGooglemaps;
   }

   public void setLinkGooglemaps(final String linkGooglemaps)
   {
      this.linkGooglemaps = linkGooglemaps;
   }

   public String getBusinessContactLink6()
   {
      return this.businessContactLink6;
   }

   public void setBusinessContactLink6(final String businessContactLink6)
   {
      this.businessContactLink6 = businessContactLink6;
   }

   public String getBusinessContactLink7()
   {
      return this.businessContactLink7;
   }

   public void setBusinessContactLink7(final String businessContactLink7)
   {
      this.businessContactLink7 = businessContactLink7;
   }

   public String getBusinessContactLink8()
   {
      return this.businessContactLink8;
   }

   public void setBusinessContactLink8(final String businessContactLink8)
   {
      this.businessContactLink8 = businessContactLink8;
   }

   public PrivateOnlyType getPrivateOnly()
   {
      return this.privateOnly;
   }

   public void setPrivateOnly(final PrivateOnlyType privateOnly)
   {
      this.privateOnly = privateOnly;
   }

   public String getBusinessContactLink9()
   {
      return this.businessContactLink9;
   }

   public void setBusinessContactLink9(final String businessContactLink9)
   {
      this.businessContactLink9 = businessContactLink9;
   }
}