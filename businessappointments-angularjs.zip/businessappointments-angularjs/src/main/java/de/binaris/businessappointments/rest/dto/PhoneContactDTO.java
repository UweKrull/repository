package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;

import de.binaris.businessappointments.model.PhoneContact;
import de.binaris.businessappointments.rest.dto.NestedAppointmentDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PhoneContactDTO implements Serializable
{

   private Long id;
   private String phoneNumber;
   private String name;
   private NestedAppointmentDTO appointment;

   public PhoneContactDTO()
   {
   }

   public PhoneContactDTO(final PhoneContact entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.phoneNumber = entity.getPhoneNumber();
         this.name = entity.getName();
         this.appointment = new NestedAppointmentDTO(entity.getAppointment());
      }
   }

   public PhoneContact fromDTO(PhoneContact entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new PhoneContact();
      }
      entity.setPhoneNumber(this.phoneNumber);
      entity.setName(this.name);
      if (this.appointment != null)
      {
         entity.setAppointment(this.appointment.fromDTO(
               entity.getAppointment(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getPhoneNumber()
   {
      return this.phoneNumber;
   }

   public void setPhoneNumber(final String phoneNumber)
   {
      this.phoneNumber = phoneNumber;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public NestedAppointmentDTO getAppointment()
   {
      return this.appointment;
   }

   public void setAppointment(final NestedAppointmentDTO appointment)
   {
      this.appointment = appointment;
   }
}