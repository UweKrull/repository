package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;
import de.binaris.businessappointments.model.Equipment;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedEquipmentDTO implements Serializable
{

   private Long id;
   private String title;

   public NestedEquipmentDTO()
   {
   }

   public NestedEquipmentDTO(final Equipment entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
      }
   }

   public Equipment fromDTO(Equipment entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Equipment();
      }
      if (this.id != null)
      {
         TypedQuery<Equipment> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT e FROM Equipment e WHERE e.id = :entityId",
                     Equipment.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
}