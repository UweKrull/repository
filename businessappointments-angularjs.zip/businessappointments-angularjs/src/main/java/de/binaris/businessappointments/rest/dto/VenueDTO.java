package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;

import de.binaris.businessappointments.model.Venue;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.businessappointments.model.Appointment;
import de.binaris.businessappointments.rest.dto.AddressDTO;
import de.binaris.businessappointments.rest.dto.NestedAppointmentDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class VenueDTO implements Serializable
{

   private Long id;
   private AddressDTO address;
   private String website;
   private String location;
   private String name;
   private String linkGooglemaps;
   private Set<NestedAppointmentDTO> appointment = new HashSet<NestedAppointmentDTO>();

   public VenueDTO()
   {
   }

   public VenueDTO(final Venue entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.address = new AddressDTO(entity.getAddress());
         this.website = entity.getWebsite();
         this.location = entity.getLocation();
         this.name = entity.getName();
         this.linkGooglemaps = entity.getLinkGooglemaps();
         Iterator<Appointment> iterAppointment = entity.getAppointment()
               .iterator();
         for (; iterAppointment.hasNext();)
         {
            Appointment element = iterAppointment.next();
            this.appointment.add(new NestedAppointmentDTO(element));
         }
      }
   }

   public Venue fromDTO(Venue entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Venue();
      }
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setWebsite(this.website);
      entity.setLocation(this.location);
      entity.setName(this.name);
      entity.setLinkGooglemaps(this.linkGooglemaps);
      Iterator<Appointment> iterAppointment = entity.getAppointment()
            .iterator();
      for (; iterAppointment.hasNext();)
      {
         boolean found = false;
         Appointment appointment = iterAppointment.next();
         Iterator<NestedAppointmentDTO> iterDtoAppointment = this
               .getAppointment().iterator();
         for (; iterDtoAppointment.hasNext();)
         {
            NestedAppointmentDTO dtoAppointment = iterDtoAppointment.next();
            if (dtoAppointment.getId().equals(appointment.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterAppointment.remove();
         }
      }
      Iterator<NestedAppointmentDTO> iterDtoAppointment = this
            .getAppointment().iterator();
      for (; iterDtoAppointment.hasNext();)
      {
         boolean found = false;
         NestedAppointmentDTO dtoAppointment = iterDtoAppointment.next();
         iterAppointment = entity.getAppointment().iterator();
         for (; iterAppointment.hasNext();)
         {
            Appointment appointment = iterAppointment.next();
            if (dtoAppointment.getId().equals(appointment.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Appointment> resultIter = em
                  .createQuery("SELECT DISTINCT a FROM Appointment a",
                        Appointment.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Appointment result = resultIter.next();
               if (result.getId().equals(dtoAppointment.getId()))
               {
                  entity.getAppointment().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getWebsite()
   {
      return this.website;
   }

   public void setWebsite(final String website)
   {
      this.website = website;
   }

   public String getLocation()
   {
      return this.location;
   }

   public void setLocation(final String location)
   {
      this.location = location;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLinkGooglemaps()
   {
      return this.linkGooglemaps;
   }

   public void setLinkGooglemaps(final String linkGooglemaps)
   {
      this.linkGooglemaps = linkGooglemaps;
   }

   public Set<NestedAppointmentDTO> getAppointment()
   {
      return this.appointment;
   }

   public void setAppointment(final Set<NestedAppointmentDTO> appointment)
   {
      this.appointment = appointment;
   }
}