package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;
import de.binaris.businessappointments.model.Appointment;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.businessappointments.model.PrivateOnlyType;

public class NestedAppointmentDTO implements Serializable
{

   private String dressCode;
   private Long id;
   private String description;
   private String name;
   private String appointmentWebsite;
   private String linkDrinkMenu;
   private String linkBookOnlineAtVenue;
   private String businessContactLink10;
   private String appointmentParticipantsNames;
   private String hostname;
   private String schedule;
   private String businessContactLink1;
   private String businessContactLink2;
   private String linkDetails;
   private String businessContactLink3;
   private String businessContactLink4;
   private String businessContactLink5;
   private String linkGooglemaps;
   private String businessContactLink6;
   private String businessContactLink7;
   private String businessContactLink8;
   private PrivateOnlyType privateOnly;
   private String businessContactLink9;

   public NestedAppointmentDTO()
   {
   }

   public NestedAppointmentDTO(final Appointment entity)
   {
      if (entity != null)
      {
         this.dressCode = entity.getDressCode();
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.appointmentWebsite = entity.getAppointmentWebsite();
         this.linkDrinkMenu = entity.getLinkDrinkMenu();
         this.linkBookOnlineAtVenue = entity.getLinkBookOnlineAtVenue();
         this.businessContactLink10 = entity.getBusinessContactLink10();
         this.appointmentParticipantsNames = entity
               .getAppointmentParticipantsNames();
         this.hostname = entity.getHostname();
         this.schedule = entity.getSchedule();
         this.businessContactLink1 = entity.getBusinessContactLink1();
         this.businessContactLink2 = entity.getBusinessContactLink2();
         this.linkDetails = entity.getLinkDetails();
         this.businessContactLink3 = entity.getBusinessContactLink3();
         this.businessContactLink4 = entity.getBusinessContactLink4();
         this.businessContactLink5 = entity.getBusinessContactLink5();
         this.linkGooglemaps = entity.getLinkGooglemaps();
         this.businessContactLink6 = entity.getBusinessContactLink6();
         this.businessContactLink7 = entity.getBusinessContactLink7();
         this.businessContactLink8 = entity.getBusinessContactLink8();
         this.privateOnly = entity.getPrivateOnly();
         this.businessContactLink9 = entity.getBusinessContactLink9();
      }
   }

   public Appointment fromDTO(Appointment entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Appointment();
      }
      if (this.id != null)
      {
         TypedQuery<Appointment> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT a FROM Appointment a WHERE a.id = :entityId",
                     Appointment.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setDressCode(this.dressCode);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setAppointmentWebsite(this.appointmentWebsite);
      entity.setLinkDrinkMenu(this.linkDrinkMenu);
      entity.setLinkBookOnlineAtVenue(this.linkBookOnlineAtVenue);
      entity.setBusinessContactLink10(this.businessContactLink10);
      entity.setAppointmentParticipantsNames(this.appointmentParticipantsNames);
      entity.setHostname(this.hostname);
      entity.setSchedule(this.schedule);
      entity.setBusinessContactLink1(this.businessContactLink1);
      entity.setBusinessContactLink2(this.businessContactLink2);
      entity.setLinkDetails(this.linkDetails);
      entity.setBusinessContactLink3(this.businessContactLink3);
      entity.setBusinessContactLink4(this.businessContactLink4);
      entity.setBusinessContactLink5(this.businessContactLink5);
      entity.setLinkGooglemaps(this.linkGooglemaps);
      entity.setBusinessContactLink6(this.businessContactLink6);
      entity.setBusinessContactLink7(this.businessContactLink7);
      entity.setBusinessContactLink8(this.businessContactLink8);
      entity.setPrivateOnly(this.privateOnly);
      entity.setBusinessContactLink9(this.businessContactLink9);
      entity = em.merge(entity);
      return entity;
   }

   public String getDressCode()
   {
      return this.dressCode;
   }

   public void setDressCode(final String dressCode)
   {
      this.dressCode = dressCode;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getAppointmentWebsite()
   {
      return this.appointmentWebsite;
   }

   public void setAppointmentWebsite(final String appointmentWebsite)
   {
      this.appointmentWebsite = appointmentWebsite;
   }

   public String getLinkDrinkMenu()
   {
      return this.linkDrinkMenu;
   }

   public void setLinkDrinkMenu(final String linkDrinkMenu)
   {
      this.linkDrinkMenu = linkDrinkMenu;
   }

   public String getLinkBookOnlineAtVenue()
   {
      return this.linkBookOnlineAtVenue;
   }

   public void setLinkBookOnlineAtVenue(final String linkBookOnlineAtVenue)
   {
      this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
   }

   public String getBusinessContactLink10()
   {
      return this.businessContactLink10;
   }

   public void setBusinessContactLink10(final String businessContactLink10)
   {
      this.businessContactLink10 = businessContactLink10;
   }

   public String getAppointmentParticipantsNames()
   {
      return this.appointmentParticipantsNames;
   }

   public void setAppointmentParticipantsNames(
         final String appointmentParticipantsNames)
   {
      this.appointmentParticipantsNames = appointmentParticipantsNames;
   }

   public String getHostname()
   {
      return this.hostname;
   }

   public void setHostname(final String hostname)
   {
      this.hostname = hostname;
   }

   public String getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final String schedule)
   {
      this.schedule = schedule;
   }

   public String getBusinessContactLink1()
   {
      return this.businessContactLink1;
   }

   public void setBusinessContactLink1(final String businessContactLink1)
   {
      this.businessContactLink1 = businessContactLink1;
   }

   public String getBusinessContactLink2()
   {
      return this.businessContactLink2;
   }

   public void setBusinessContactLink2(final String businessContactLink2)
   {
      this.businessContactLink2 = businessContactLink2;
   }

   public String getLinkDetails()
   {
      return this.linkDetails;
   }

   public void setLinkDetails(final String linkDetails)
   {
      this.linkDetails = linkDetails;
   }

   public String getBusinessContactLink3()
   {
      return this.businessContactLink3;
   }

   public void setBusinessContactLink3(final String businessContactLink3)
   {
      this.businessContactLink3 = businessContactLink3;
   }

   public String getBusinessContactLink4()
   {
      return this.businessContactLink4;
   }

   public void setBusinessContactLink4(final String businessContactLink4)
   {
      this.businessContactLink4 = businessContactLink4;
   }

   public String getBusinessContactLink5()
   {
      return this.businessContactLink5;
   }

   public void setBusinessContactLink5(final String businessContactLink5)
   {
      this.businessContactLink5 = businessContactLink5;
   }

   public String getLinkGooglemaps()
   {
      return this.linkGooglemaps;
   }

   public void setLinkGooglemaps(final String linkGooglemaps)
   {
      this.linkGooglemaps = linkGooglemaps;
   }

   public String getBusinessContactLink6()
   {
      return this.businessContactLink6;
   }

   public void setBusinessContactLink6(final String businessContactLink6)
   {
      this.businessContactLink6 = businessContactLink6;
   }

   public String getBusinessContactLink7()
   {
      return this.businessContactLink7;
   }

   public void setBusinessContactLink7(final String businessContactLink7)
   {
      this.businessContactLink7 = businessContactLink7;
   }

   public String getBusinessContactLink8()
   {
      return this.businessContactLink8;
   }

   public void setBusinessContactLink8(final String businessContactLink8)
   {
      this.businessContactLink8 = businessContactLink8;
   }

   public PrivateOnlyType getPrivateOnly()
   {
      return this.privateOnly;
   }

   public void setPrivateOnly(final PrivateOnlyType privateOnly)
   {
      this.privateOnly = privateOnly;
   }

   public String getBusinessContactLink9()
   {
      return this.businessContactLink9;
   }

   public void setBusinessContactLink9(final String businessContactLink9)
   {
      this.businessContactLink9 = businessContactLink9;
   }
}