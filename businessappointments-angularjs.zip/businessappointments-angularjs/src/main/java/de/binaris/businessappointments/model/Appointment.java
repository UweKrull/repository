package de.binaris.businessappointments.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "business_appointment")
public class Appointment implements Serializable {

	private static final long serialVersionUID = 7972379629657125327L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_business_appointment")
	@SequenceGenerator(name = "my_entity_seq_gen_business_appointment", sequenceName = "sequence_business_appointment", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String name;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Venue venue;
	
	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Category category;
	
	@NotNull
	@Size(min = 1, max = 200, message = "must be 1-200 letters and spaces")
	private String hostname;
	
    @Size(min = 0, max = 3000, message = "optional max. 2000 letters and spaces")
	private String appointmentParticipantsNames;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink1;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink2;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink3;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink4;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink5;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink6;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink7;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink8;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink9;
	
    @Size(min = 0, max = 200, message = "optional max. 2000 letters and spaces")
	private String businessContactLink10;
	
	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
    private String schedule;
    
    @Column(name = "private_only")
    @Enumerated(STRING)
    private PrivateOnlyType privateOnly;
    
	@Size(min = 0, max = 100, message = "optional max. 100 letters and spaces")
	private String dressCode;
		
	@Size(min = 0, max = 200, message = "optional max. 200 letters and spaces")
	private String linkDetails;

	@Size(min = 0, max = 200, message = "optional max. 200 letters and spaces")
	private String linkBookOnlineAtVenue;
	
	@Size(min = 0, max = 200, message = "optional max. 200 letters and spaces")
	private String linkDrinkMenu;
	
	@Size(min = 0, max = 500, message = "optional max. 500 letters and spaces")
	private String linkGooglemaps;
	
	@Size(min = 0, max = 500, message = "optional max. 2000 letters and spaces")
	private String appointmentWebsite;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "appointment")
	private Set<InsuranceAgent> insuranceAgent = new HashSet<InsuranceAgent>();

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "appointment")
	private Set<Equipment> equipment = new HashSet<Equipment>();
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "appointment")
	private Set<TimeAndCharge> timeAndCharge = new HashSet<TimeAndCharge>();
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "appointment")
	private Set<PhoneContact> phoneContact = new HashSet<PhoneContact>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Venue getVenue() {
		return venue;
	}
	
	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Set<Equipment> getEquipment() {
		return equipment;
	}

	public void setEquipment(Set<Equipment> equipment) {
		this.equipment = equipment;
	}

	public Set<TimeAndCharge> getTimeAndCharge() {
		return timeAndCharge;
	}
	
	public void setTimeAndCharge(Set<TimeAndCharge> timeAndCharge) {
		this.timeAndCharge = timeAndCharge;
	}
	
	public Set<PhoneContact> getPhoneContact() {
		return phoneContact;
	}

	public void setPhoneContact(Set<PhoneContact> phoneContact) {
		this.phoneContact = phoneContact;
	}

	public Set<InsuranceAgent> getInsuranceAgent() {
		return insuranceAgent;
	}
	
	public void setInsuranceAgent(Set<InsuranceAgent> insuranceAgent) {
		this.insuranceAgent = insuranceAgent;
	}
	
	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	public String getHostname() {
		return hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getAppointmentParticipantsNames() {
		return appointmentParticipantsNames;
	}
	
	public void setAppointmentParticipantsNames(String appointmentParticipantsNames) {
		this.appointmentParticipantsNames = appointmentParticipantsNames;
	}
	
	public String getBusinessContactLink1() {
		return businessContactLink1;
	}
	
	public void setBusinessContactLink2(String businessContactLink2) {
		this.businessContactLink2 = businessContactLink2;
	}
	
	public String getBusinessContactLink2() {
		return businessContactLink2;
	}
	
	public void setBusinessContactLink3(String businessContactLink3) {
		this.businessContactLink3 = businessContactLink3;
	}
	
	public String getBusinessContactLink3() {
		return businessContactLink3;
	}
	
	public void setBusinessContactLink4(String businessContactLink4) {
		this.businessContactLink4 = businessContactLink4;
	}
	
	public String getBusinessContactLink4() {
		return businessContactLink4;
	}
	
	public void setBusinessContactLink5(String businessContactLink5) {
		this.businessContactLink5 = businessContactLink5;
	}
	
	public String getBusinessContactLink5() {
		return businessContactLink5;
	}
	
	public void setBusinessContactLink6(String businessContactLink6) {
		this.businessContactLink6 = businessContactLink6;
	}
	
	public String getBusinessContactLink6() {
		return businessContactLink6;
	}
	
	public void setBusinessContactLink7(String businessContactLink7) {
		this.businessContactLink7 = businessContactLink7;
	}
	
	public String getBusinessContactLink7() {
		return businessContactLink7;
	}
	
	public void setBusinessContactLink8(String businessContactLink8) {
		this.businessContactLink8 = businessContactLink8;
	}
	
	public String getBusinessContactLink8() {
		return businessContactLink8;
	}
	
	public void setBusinessContactLink9(String businessContactLink9) {
		this.businessContactLink9 = businessContactLink9;
	}
	
	public String getBusinessContactLink9() {
		return businessContactLink9;
	}
	
	public void setBusinessContactLink10(String businessContactLink10) {
		this.businessContactLink10 = businessContactLink10;
	}
	
	public String getBusinessContactLink10() {
		return businessContactLink10;
	}
	
	public void setBusinessContactLink1(String businessContactLink1) {
		this.businessContactLink1 = businessContactLink1;
	}
	
	public PrivateOnlyType getPrivateOnly() {
		return privateOnly;
	}

	public void setPrivateOnly(PrivateOnlyType privateOnly) {
		this.privateOnly = privateOnly;
	}

	public String getDressCode() {
		return dressCode;
	}

	public void setDressCode(String dressCode) {
		this.dressCode = dressCode;
	}

	public String getLinkDetails() {
		return linkDetails;
	}

	public void setLinkDetails(String linkDetails) {
		this.linkDetails = linkDetails;
	}

	public String getLinkBookOnlineAtVenue() {
		return linkBookOnlineAtVenue;
	}

	public void setLinkBookOnlineAtVenue(String linkBookOnlineAtVenue) {
		this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
	}

	public String getLinkDrinkMenu() {
		return linkDrinkMenu;
	}
	
	public void setLinkDrinkMenu(String linkDrinkMenu) {
		this.linkDrinkMenu = linkDrinkMenu;
	}
	
	public String getLinkGooglemaps() {
		return linkGooglemaps;
	}
	
	public void setLinkGooglemaps(String linkGooglemaps) {
		this.linkGooglemaps = linkGooglemaps;
	}
	
	public String getAppointmentWebsite() {
		return appointmentWebsite;
	}

	public void setAppointmentWebsite(String appointmentWebsite) {
		this.appointmentWebsite = appointmentWebsite;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Appointment)) {
			return false;
		}
		Appointment castOther = (Appointment) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name);
		return sb.toString();
	}
}
