package de.binaris.businessappointments.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.businessappointments.model.BusinessContact;
import de.binaris.businessappointments.rest.dto.BusinessContactDTO;

/**
 * 
 */
@Stateless
@Path("/businesscontacts")
public class BusinessContactEndpoint
{
   @PersistenceContext(unitName = "BusinessappointmentsPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(BusinessContactDTO dto)
   {
      BusinessContact entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(BusinessContactEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      BusinessContact entity = em.find(BusinessContact.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<BusinessContact> findByIdQuery = em.createQuery("SELECT DISTINCT b FROM BusinessContact b LEFT JOIN FETCH b.appointment WHERE b.id = :entityId ORDER BY b.id", BusinessContact.class);
      findByIdQuery.setParameter("entityId", id);
      BusinessContact entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      BusinessContactDTO dto = new BusinessContactDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<BusinessContactDTO> listAll()
   {
      final List<BusinessContact> searchResults = em.createQuery("SELECT DISTINCT b FROM BusinessContact b LEFT JOIN FETCH b.appointment ORDER BY b.id", BusinessContact.class).getResultList();
      final List<BusinessContactDTO> results = new ArrayList<BusinessContactDTO>();
      for (BusinessContact searchResult : searchResults)
      {
         BusinessContactDTO dto = new BusinessContactDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, BusinessContactDTO dto)
   {
      TypedQuery<BusinessContact> findByIdQuery = em.createQuery("SELECT DISTINCT b FROM BusinessContact b LEFT JOIN FETCH b.appointment WHERE b.id = :entityId ORDER BY b.id", BusinessContact.class);
      findByIdQuery.setParameter("entityId", id);
      BusinessContact entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}