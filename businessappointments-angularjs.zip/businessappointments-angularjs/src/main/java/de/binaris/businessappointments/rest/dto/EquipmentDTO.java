package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;

import de.binaris.businessappointments.model.Equipment;
import de.binaris.businessappointments.rest.dto.NestedAppointmentDTO;
import de.binaris.businessappointments.rest.dto.NestedEquipmentTypeDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EquipmentDTO implements Serializable
{

   private Long id;
   private String title;
   private NestedEquipmentTypeDTO equipmentType;
   private NestedAppointmentDTO appointment;

   public EquipmentDTO()
   {
   }

   public EquipmentDTO(final Equipment entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.equipmentType = new NestedEquipmentTypeDTO(
               entity.getEquipmentType());
         this.appointment = new NestedAppointmentDTO(entity.getAppointment());
      }
   }

   public Equipment fromDTO(Equipment entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Equipment();
      }
      entity.setTitle(this.title);
      if (this.equipmentType != null)
      {
         entity.setEquipmentType(this.equipmentType.fromDTO(
               entity.getEquipmentType(), em));
      }
      if (this.appointment != null)
      {
         entity.setAppointment(this.appointment.fromDTO(
               entity.getAppointment(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public NestedEquipmentTypeDTO getEquipmentType()
   {
      return this.equipmentType;
   }

   public void setEquipmentType(final NestedEquipmentTypeDTO equipmentType)
   {
      this.equipmentType = equipmentType;
   }

   public NestedAppointmentDTO getAppointment()
   {
      return this.appointment;
   }

   public void setAppointment(final NestedAppointmentDTO appointment)
   {
      this.appointment = appointment;
   }
}