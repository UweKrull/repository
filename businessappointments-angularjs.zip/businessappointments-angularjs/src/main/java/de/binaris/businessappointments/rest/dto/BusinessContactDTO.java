package de.binaris.businessappointments.rest.dto;

import java.io.Serializable;

import de.binaris.businessappointments.model.BusinessContact;
import de.binaris.businessappointments.rest.dto.AddressDTO;
import de.binaris.businessappointments.rest.dto.NestedAppointmentDTO;

import javax.persistence.EntityManager;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BusinessContactDTO implements Serializable
{

   private Date dateOfBirth;
   private String lastName;
   private String phone;
   private String website;
   private String linkXINGProfile;
   private NestedAppointmentDTO appointment;
   private Long id;
   private String aliasName;
   private String email;
   private AddressDTO address;
   private String firstName;
   private String linkLinkedInProfile;

   public BusinessContactDTO()
   {
   }

   public BusinessContactDTO(final BusinessContact entity)
   {
      if (entity != null)
      {
         this.dateOfBirth = entity.getDateOfBirth();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         this.website = entity.getWebsite();
         this.linkXINGProfile = entity.getLinkXINGProfile();
         this.appointment = new NestedAppointmentDTO(entity.getAppointment());
         this.id = entity.getId();
         this.aliasName = entity.getAliasName();
         this.email = entity.getEmail();
         this.address = new AddressDTO(entity.getAddress());
         this.firstName = entity.getFirstName();
         this.linkLinkedInProfile = entity.getLinkLinkedInProfile();
      }
   }

   public BusinessContact fromDTO(BusinessContact entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new BusinessContact();
      }
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      entity.setWebsite(this.website);
      entity.setLinkXINGProfile(this.linkXINGProfile);
      if (this.appointment != null)
      {
         entity.setAppointment(this.appointment.fromDTO(
               entity.getAppointment(), em));
      }
      entity.setAliasName(this.aliasName);
      entity.setEmail(this.email);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setFirstName(this.firstName);
      entity.setLinkLinkedInProfile(this.linkLinkedInProfile);
      entity = em.merge(entity);
      return entity;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public String getWebsite()
   {
      return this.website;
   }

   public void setWebsite(final String website)
   {
      this.website = website;
   }

   public String getLinkXINGProfile()
   {
      return this.linkXINGProfile;
   }

   public void setLinkXINGProfile(final String linkXINGProfile)
   {
      this.linkXINGProfile = linkXINGProfile;
   }

   public NestedAppointmentDTO getAppointment()
   {
      return this.appointment;
   }

   public void setAppointment(final NestedAppointmentDTO appointment)
   {
      this.appointment = appointment;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getAliasName()
   {
      return this.aliasName;
   }

   public void setAliasName(final String aliasName)
   {
      this.aliasName = aliasName;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }

   public String getLinkLinkedInProfile()
   {
      return this.linkLinkedInProfile;
   }

   public void setLinkLinkedInProfile(final String linkLinkedInProfile)
   {
      this.linkLinkedInProfile = linkLinkedInProfile;
   }
}