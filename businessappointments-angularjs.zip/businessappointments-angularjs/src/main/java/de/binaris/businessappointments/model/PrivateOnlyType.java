package de.binaris.businessappointments.model;

/**
 * <p>
 * The {@link PrivateOnlyType} describes the private-only types (Yes, No)
 * 
 * Private-only is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the partner types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link PrivateOnlyType} describes whether or not the
 * appointment is a private-only one (e.g. not in public, only invited members).
 * </p>
 */
public enum PrivateOnlyType {

    /**
     * The PrivateOnlyType of the appointment.
     */
    yes("yes", true),
    no("no", true);

    /**
     * A human readable description of the private-only type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the private-only type can be cached.
     */
    private final boolean cacheable;
    
    private PrivateOnlyType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
