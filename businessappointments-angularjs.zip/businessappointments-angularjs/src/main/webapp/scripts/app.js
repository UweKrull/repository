'use strict';

angular.module('businessappointmentsangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Appointments',{templateUrl:'views/Appointment/search.html',controller:'SearchAppointmentController'})
      .when('/Appointments/new',{templateUrl:'views/Appointment/detail.html',controller:'NewAppointmentController'})
      .when('/Appointments/edit/:AppointmentId',{templateUrl:'views/Appointment/detail.html',controller:'EditAppointmentController'})
      .when('/BusinessContacts',{templateUrl:'views/BusinessContact/search.html',controller:'SearchBusinessContactController'})
      .when('/BusinessContacts/new',{templateUrl:'views/BusinessContact/detail.html',controller:'NewBusinessContactController'})
      .when('/BusinessContacts/edit/:BusinessContactId',{templateUrl:'views/BusinessContact/detail.html',controller:'EditBusinessContactController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Equipments',{templateUrl:'views/Equipment/search.html',controller:'SearchEquipmentController'})
      .when('/Equipments/new',{templateUrl:'views/Equipment/detail.html',controller:'NewEquipmentController'})
      .when('/Equipments/edit/:EquipmentId',{templateUrl:'views/Equipment/detail.html',controller:'EditEquipmentController'})
      .when('/EquipmentTypes',{templateUrl:'views/EquipmentType/search.html',controller:'SearchEquipmentTypeController'})
      .when('/EquipmentTypes/new',{templateUrl:'views/EquipmentType/detail.html',controller:'NewEquipmentTypeController'})
      .when('/EquipmentTypes/edit/:EquipmentTypeId',{templateUrl:'views/EquipmentType/detail.html',controller:'EditEquipmentTypeController'})
      .when('/InsuranceAgents',{templateUrl:'views/InsuranceAgent/search.html',controller:'SearchInsuranceAgentController'})
      .when('/InsuranceAgents/new',{templateUrl:'views/InsuranceAgent/detail.html',controller:'NewInsuranceAgentController'})
      .when('/InsuranceAgents/edit/:InsuranceAgentId',{templateUrl:'views/InsuranceAgent/detail.html',controller:'EditInsuranceAgentController'})
      .when('/PhoneContacts',{templateUrl:'views/PhoneContact/search.html',controller:'SearchPhoneContactController'})
      .when('/PhoneContacts/new',{templateUrl:'views/PhoneContact/detail.html',controller:'NewPhoneContactController'})
      .when('/PhoneContacts/edit/:PhoneContactId',{templateUrl:'views/PhoneContact/detail.html',controller:'EditPhoneContactController'})
      .when('/TimeAndCharges',{templateUrl:'views/TimeAndCharge/search.html',controller:'SearchTimeAndChargeController'})
      .when('/TimeAndCharges/new',{templateUrl:'views/TimeAndCharge/detail.html',controller:'NewTimeAndChargeController'})
      .when('/TimeAndCharges/edit/:TimeAndChargeId',{templateUrl:'views/TimeAndCharge/detail.html',controller:'EditTimeAndChargeController'})
      .when('/Venues',{templateUrl:'views/Venue/search.html',controller:'SearchVenueController'})
      .when('/Venues/new',{templateUrl:'views/Venue/detail.html',controller:'NewVenueController'})
      .when('/Venues/edit/:VenueId',{templateUrl:'views/Venue/detail.html',controller:'EditVenueController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
