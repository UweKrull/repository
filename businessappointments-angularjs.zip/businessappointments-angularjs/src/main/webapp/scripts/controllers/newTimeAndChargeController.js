
angular.module('businessappointmentsangularjs').controller('NewTimeAndChargeController', function ($scope, $location, locationParser, TimeAndChargeResource , AppointmentResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.timeAndCharge = $scope.timeAndCharge || {};
    
    $scope.appointmentList = AppointmentResource.queryAll(function(items){
        $scope.appointmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("appointmentSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.timeAndCharge.appointment = {};
            $scope.timeAndCharge.appointment.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/TimeAndCharges/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TimeAndChargeResource.save($scope.timeAndCharge, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/TimeAndCharges");
    };
});