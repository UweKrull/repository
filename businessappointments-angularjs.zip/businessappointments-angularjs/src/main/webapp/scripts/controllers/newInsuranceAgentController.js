
angular.module('businessappointmentsangularjs').controller('NewInsuranceAgentController', function ($scope, $location, locationParser, InsuranceAgentResource , AppointmentResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.insuranceAgent = $scope.insuranceAgent || {};
    
    $scope.appointmentList = AppointmentResource.queryAll(function(items){
        $scope.appointmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("appointmentSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.insuranceAgent.appointment = {};
            $scope.insuranceAgent.appointment.id = selection.value;
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.insuranceAgent.address.country = {};
            $scope.insuranceAgent.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/InsuranceAgents/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        InsuranceAgentResource.save($scope.insuranceAgent, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/InsuranceAgents");
    };
});