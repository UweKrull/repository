

angular.module('businessappointmentsangularjs').controller('EditEquipmentController', function($scope, $routeParams, $location, EquipmentResource , AppointmentResource, EquipmentTypeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.equipment = new EquipmentResource(self.original);
            AppointmentResource.queryAll(function(items) {
                $scope.appointmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.equipment.appointment && item.id == $scope.equipment.appointment.id) {
                        $scope.appointmentSelection = labelObject;
                        $scope.equipment.appointment = wrappedObject;
                        self.original.appointment = $scope.equipment.appointment;
                    }
                    return labelObject;
                });
            });
            EquipmentTypeResource.queryAll(function(items) {
                $scope.equipmentTypeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.equipment.equipmentType && item.id == $scope.equipment.equipmentType.id) {
                        $scope.equipmentTypeSelection = labelObject;
                        $scope.equipment.equipmentType = wrappedObject;
                        self.original.equipmentType = $scope.equipment.equipmentType;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Equipments");
        };
        EquipmentResource.get({EquipmentId:$routeParams.EquipmentId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.equipment);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.equipment.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Equipments");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Equipments");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.equipment.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.equipment.appointment = {};
            $scope.equipment.appointment.id = selection.value;
        }
    });
    $scope.$watch("equipmentTypeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.equipment.equipmentType = {};
            $scope.equipment.equipmentType.id = selection.value;
        }
    });
    
    $scope.get();
});