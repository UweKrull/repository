

angular.module('businessappointmentsangularjs').controller('EditPhoneContactController', function($scope, $routeParams, $location, PhoneContactResource , AppointmentResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.phoneContact = new PhoneContactResource(self.original);
            AppointmentResource.queryAll(function(items) {
                $scope.appointmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.phoneContact.appointment && item.id == $scope.phoneContact.appointment.id) {
                        $scope.appointmentSelection = labelObject;
                        $scope.phoneContact.appointment = wrappedObject;
                        self.original.appointment = $scope.phoneContact.appointment;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/PhoneContacts");
        };
        PhoneContactResource.get({PhoneContactId:$routeParams.PhoneContactId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.phoneContact);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.phoneContact.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PhoneContacts");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PhoneContacts");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.phoneContact.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.phoneContact.appointment = {};
            $scope.phoneContact.appointment.id = selection.value;
        }
    });
    
    $scope.get();
});