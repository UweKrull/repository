
angular.module('businessappointmentsangularjs').controller('NewEquipmentController', function ($scope, $location, locationParser, EquipmentResource , AppointmentResource, EquipmentTypeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.equipment = $scope.equipment || {};
    
    $scope.appointmentList = AppointmentResource.queryAll(function(items){
        $scope.appointmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("appointmentSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.equipment.appointment = {};
            $scope.equipment.appointment.id = selection.value;
        }
    });
    
    $scope.equipmentTypeList = EquipmentTypeResource.queryAll(function(items){
        $scope.equipmentTypeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("equipmentTypeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.equipment.equipmentType = {};
            $scope.equipment.equipmentType.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Equipments/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        EquipmentResource.save($scope.equipment, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Equipments");
    };
});