
angular.module('businessappointmentsangularjs').controller('NewCategoryController', function ($scope, $location, locationParser, CategoryResource , AppointmentResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.category = $scope.category || {};
    
    $scope.appointmentList = AppointmentResource.queryAll(function(items){
        $scope.appointmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.category.appointment = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.category.appointment.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Categorys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CategoryResource.save($scope.category, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Categorys");
    };
});