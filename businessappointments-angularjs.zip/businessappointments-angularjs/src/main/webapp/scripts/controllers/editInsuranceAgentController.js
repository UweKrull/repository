

angular.module('businessappointmentsangularjs').controller('EditInsuranceAgentController', function($scope, $routeParams, $location, InsuranceAgentResource , AppointmentResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.insuranceAgent = new InsuranceAgentResource(self.original);
            AppointmentResource.queryAll(function(items) {
                $scope.appointmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.insuranceAgent.appointment && item.id == $scope.insuranceAgent.appointment.id) {
                        $scope.appointmentSelection = labelObject;
                        $scope.insuranceAgent.appointment = wrappedObject;
                        self.original.appointment = $scope.insuranceAgent.appointment;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.insuranceAgent.address.country && item.id == $scope.insuranceAgent.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.insuranceAgent.address.country = wrappedObject;
                        self.original.address.country = $scope.insuranceAgent.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/InsuranceAgents");
        };
        InsuranceAgentResource.get({InsuranceAgentId:$routeParams.InsuranceAgentId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.insuranceAgent);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.insuranceAgent.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/InsuranceAgents");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/InsuranceAgents");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.insuranceAgent.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.insuranceAgent.appointment = {};
            $scope.insuranceAgent.appointment.id = selection.value;
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.insuranceAgent.address.country = {};
            $scope.insuranceAgent.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});