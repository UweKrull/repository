

angular.module('businessappointmentsangularjs').controller('EditAppointmentController', function($scope, $routeParams, $location, AppointmentResource , VenueResource, CategoryResource, EquipmentResource, TimeAndChargeResource, PhoneContactResource, InsuranceAgentResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.appointment = new AppointmentResource(self.original);
            VenueResource.queryAll(function(items) {
                $scope.venueSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.appointment.venue && item.id == $scope.appointment.venue.id) {
                        $scope.venueSelection = labelObject;
                        $scope.appointment.venue = wrappedObject;
                        self.original.venue = $scope.appointment.venue;
                    }
                    return labelObject;
                });
            });
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.appointment.category && item.id == $scope.appointment.category.id) {
                        $scope.categorySelection = labelObject;
                        $scope.appointment.category = wrappedObject;
                        self.original.category = $scope.appointment.category;
                    }
                    return labelObject;
                });
            });
            EquipmentResource.queryAll(function(items) {
                $scope.equipmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.appointment.equipment){
                        $.each($scope.appointment.equipment, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.equipmentSelection.push(labelObject);
                                $scope.appointment.equipment.push(wrappedObject);
                            }
                        });
                        self.original.equipment = $scope.appointment.equipment;
                    }
                    return labelObject;
                });
            });
            TimeAndChargeResource.queryAll(function(items) {
                $scope.timeAndChargeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.days + ", " + item.startTime + "-" + item.endTime + ", " + item.charge
                    };
                    if($scope.appointment.timeAndCharge){
                        $.each($scope.appointment.timeAndCharge, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.timeAndChargeSelection.push(labelObject);
                                $scope.appointment.timeAndCharge.push(wrappedObject);
                            }
                        });
                        self.original.timeAndCharge = $scope.appointment.timeAndCharge;
                    }
                    return labelObject;
                });
            });
            PhoneContactResource.queryAll(function(items) {
                $scope.phoneContactSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.phoneNumber + ", " + item.name
                    };
                    if($scope.appointment.phoneContact){
                        $.each($scope.appointment.phoneContact, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.phoneContactSelection.push(labelObject);
                                $scope.appointment.phoneContact.push(wrappedObject);
                            }
                        });
                        self.original.phoneContact = $scope.appointment.phoneContact;
                    }
                    return labelObject;
                });
            });
            InsuranceAgentResource.queryAll(function(items) {
                $scope.insuranceAgentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName
                    };
                    if($scope.appointment.insuranceAgent){
                        $.each($scope.appointment.insuranceAgent, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.insuranceAgentSelection.push(labelObject);
                                $scope.appointment.insuranceAgent.push(wrappedObject);
                            }
                        });
                        self.original.insuranceAgent = $scope.appointment.insuranceAgent;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Appointments");
        };
        AppointmentResource.get({AppointmentId:$routeParams.AppointmentId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.appointment);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.appointment.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Appointments");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Appointments");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.appointment.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("venueSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.appointment.venue = {};
            $scope.appointment.venue.id = selection.value;
        }
    });
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.appointment.category = {};
            $scope.appointment.category.id = selection.value;
        }
    });
    $scope.equipmentSelection = $scope.equipmentSelection || [];
    $scope.$watch("equipmentSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.appointment) {
            $scope.appointment.equipment = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.equipment.push(collectionItem);
            });
        }
    });
    $scope.timeAndChargeSelection = $scope.timeAndChargeSelection || [];
    $scope.$watch("timeAndChargeSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.appointment) {
            $scope.appointment.timeAndCharge = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.timeAndCharge.push(collectionItem);
            });
        }
    });
    $scope.phoneContactSelection = $scope.phoneContactSelection || [];
    $scope.$watch("phoneContactSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.appointment) {
            $scope.appointment.phoneContact = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.phoneContact.push(collectionItem);
            });
        }
    });
    $scope.insuranceAgentSelection = $scope.insuranceAgentSelection || [];
    $scope.$watch("insuranceAgentSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.appointment) {
            $scope.appointment.insuranceAgent = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.insuranceAgent.push(collectionItem);
            });
        }
    });
    $scope.privateOnlyList = [
        "yes",  
        "no"  
    ];
    
    $scope.get();
});