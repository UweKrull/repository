
angular.module('businessappointmentsangularjs').controller('NewAppointmentController', function ($scope, $location, locationParser, AppointmentResource , VenueResource, CategoryResource, EquipmentResource, TimeAndChargeResource, PhoneContactResource, InsuranceAgentResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.appointment = $scope.appointment || {};
    
    $scope.venueList = VenueResource.queryAll(function(items){
        $scope.venueSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("venueSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.appointment.venue = {};
            $scope.appointment.venue.id = selection.value;
        }
    });
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.appointment.category = {};
            $scope.appointment.category.id = selection.value;
        }
    });
    
    $scope.equipmentList = EquipmentResource.queryAll(function(items){
        $scope.equipmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("equipmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.appointment.equipment = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.equipment.push(collectionItem);
            });
        }
    });
    
    $scope.timeAndChargeList = TimeAndChargeResource.queryAll(function(items){
        $scope.timeAndChargeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.days
            });
        });
    });
    $scope.$watch("timeAndChargeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.appointment.timeAndCharge = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.timeAndCharge.push(collectionItem);
            });
        }
    });
    
    $scope.phoneContactList = PhoneContactResource.queryAll(function(items){
        $scope.phoneContactSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.phoneNumber
            });
        });
    });
    $scope.$watch("phoneContactSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.appointment.phoneContact = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.phoneContact.push(collectionItem);
            });
        }
    });
    
    $scope.insuranceAgentList = InsuranceAgentResource.queryAll(function(items){
        $scope.insuranceAgentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName + " " + item.lastName
            });
        });
    });
    $scope.$watch("insuranceAgentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.appointment.insuranceAgent = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.appointment.insuranceAgent.push(collectionItem);
            });
        }
    });
    
    $scope.privateOnlyList = [
        "yes",
        "no"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Appointments/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        AppointmentResource.save($scope.appointment, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Appointments");
    };
});