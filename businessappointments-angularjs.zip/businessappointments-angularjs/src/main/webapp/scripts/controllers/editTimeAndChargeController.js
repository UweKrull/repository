

angular.module('businessappointmentsangularjs').controller('EditTimeAndChargeController', function($scope, $routeParams, $location, TimeAndChargeResource , AppointmentResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.timeAndCharge = new TimeAndChargeResource(self.original);
            AppointmentResource.queryAll(function(items) {
                $scope.appointmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.timeAndCharge.appointment && item.id == $scope.timeAndCharge.appointment.id) {
                        $scope.appointmentSelection = labelObject;
                        $scope.timeAndCharge.appointment = wrappedObject;
                        self.original.appointment = $scope.timeAndCharge.appointment;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/TimeAndCharges");
        };
        TimeAndChargeResource.get({TimeAndChargeId:$routeParams.TimeAndChargeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.timeAndCharge);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.timeAndCharge.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/TimeAndCharges");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/TimeAndCharges");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.timeAndCharge.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timeAndCharge.appointment = {};
            $scope.timeAndCharge.appointment.id = selection.value;
        }
    });
    
    $scope.get();
});