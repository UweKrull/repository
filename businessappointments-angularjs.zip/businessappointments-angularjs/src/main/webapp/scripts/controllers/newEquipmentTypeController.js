
angular.module('businessappointmentsangularjs').controller('NewEquipmentTypeController', function ($scope, $location, locationParser, EquipmentTypeResource , EquipmentResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.equipmentType = $scope.equipmentType || {};
    
    $scope.equipmentList = EquipmentResource.queryAll(function(items){
        $scope.equipmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("equipmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.equipmentType.equipment = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.equipmentType.equipment.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/EquipmentTypes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        EquipmentTypeResource.save($scope.equipmentType, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/EquipmentTypes");
    };
});