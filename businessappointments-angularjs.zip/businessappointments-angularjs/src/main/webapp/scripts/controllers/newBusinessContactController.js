
angular.module('businessappointmentsangularjs').controller('NewBusinessContactController', function ($scope, $location, locationParser, BusinessContactResource , AppointmentResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.businessContact = $scope.businessContact || {};
    
    $scope.appointmentList = AppointmentResource.queryAll(function(items){
        $scope.appointmentSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("appointmentSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.businessContact.appointment = {};
            $scope.businessContact.appointment.id = selection.value;
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.businessContact.address.country = {};
            $scope.businessContact.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/BusinessContacts/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        BusinessContactResource.save($scope.businessContact, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/BusinessContacts");
    };
});