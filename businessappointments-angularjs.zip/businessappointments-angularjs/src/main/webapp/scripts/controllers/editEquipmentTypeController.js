

angular.module('businessappointmentsangularjs').controller('EditEquipmentTypeController', function($scope, $routeParams, $location, EquipmentTypeResource , EquipmentResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.equipmentType = new EquipmentTypeResource(self.original);
            EquipmentResource.queryAll(function(items) {
                $scope.equipmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.equipmentType.equipment){
                        $.each($scope.equipmentType.equipment, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.equipmentSelection.push(labelObject);
                                $scope.equipmentType.equipment.push(wrappedObject);
                            }
                        });
                        self.original.equipment = $scope.equipmentType.equipment;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/EquipmentTypes");
        };
        EquipmentTypeResource.get({EquipmentTypeId:$routeParams.EquipmentTypeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.equipmentType);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.equipmentType.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/EquipmentTypes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/EquipmentTypes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.equipmentType.$remove(successCallback, errorCallback);
    };
    
    $scope.equipmentSelection = $scope.equipmentSelection || [];
    $scope.$watch("equipmentSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.equipmentType) {
            $scope.equipmentType.equipment = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.equipmentType.equipment.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});