

angular.module('businessappointmentsangularjs').controller('EditBusinessContactController', function($scope, $routeParams, $location, BusinessContactResource , AppointmentResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.businessContact = new BusinessContactResource(self.original);
            AppointmentResource.queryAll(function(items) {
                $scope.appointmentSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.businessContact.appointment && item.id == $scope.businessContact.appointment.id) {
                        $scope.appointmentSelection = labelObject;
                        $scope.businessContact.appointment = wrappedObject;
                        self.original.appointment = $scope.businessContact.appointment;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.businessContact.address.country && item.id == $scope.businessContact.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.businessContact.address.country = wrappedObject;
                        self.original.address.country = $scope.businessContact.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/BusinessContacts");
        };
        BusinessContactResource.get({BusinessContactId:$routeParams.BusinessContactId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.businessContact);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.businessContact.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/BusinessContacts");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/BusinessContacts");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.businessContact.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("appointmentSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.businessContact.appointment = {};
            $scope.businessContact.appointment.id = selection.value;
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.businessContact.address.country = {};
            $scope.businessContact.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});