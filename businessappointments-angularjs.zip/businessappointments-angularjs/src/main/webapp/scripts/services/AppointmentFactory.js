angular.module('businessappointmentsangularjs').factory('AppointmentResource', function($resource){
    var resource = $resource('rest/appointments/:AppointmentId',{AppointmentId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});