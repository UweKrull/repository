angular.module('businessappointmentsangularjs').factory('EquipmentResource', function($resource){
    var resource = $resource('rest/equipments/:EquipmentId',{EquipmentId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});