angular.module('businessappointmentsangularjs').factory('InsuranceAgentResource', function($resource){
    var resource = $resource('rest/insuranceagents/:InsuranceAgentId',{InsuranceAgentId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});