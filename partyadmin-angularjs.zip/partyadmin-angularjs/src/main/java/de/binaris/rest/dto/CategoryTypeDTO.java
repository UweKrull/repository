package de.binaris.rest.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

import de.binaris.parties.model.CategoryType;
import de.binaris.parties.model.DrinksAndBeverages;

@XmlRootElement
public class CategoryTypeDTO implements Serializable {

	private Long id;
	private Set<NestedDrinksAndBeveragesDTO> drinksAndBeverages = new HashSet<NestedDrinksAndBeveragesDTO>();
	private String description;
	private String name;

	public CategoryTypeDTO() {
	}

	public CategoryTypeDTO(final CategoryType entity) {
		if (entity != null) {
			this.id = entity.getId();
			Iterator<DrinksAndBeverages> iterDrinksAndBeverages = entity
					.getDrinksAndBeverages().iterator();
			for (; iterDrinksAndBeverages.hasNext();) {
				DrinksAndBeverages element = iterDrinksAndBeverages.next();
				this.drinksAndBeverages.add(new NestedDrinksAndBeveragesDTO(
						element));
			}
			this.description = entity.getDescription();
			this.name = entity.getName();
		}
	}

	public CategoryType fromDTO(CategoryType entity, EntityManager em) {
		if (entity == null) {
			entity = new CategoryType();
		}
		Iterator<DrinksAndBeverages> iterDrinksAndBeverages = entity
				.getDrinksAndBeverages().iterator();
		for (; iterDrinksAndBeverages.hasNext();) {
			boolean found = false;
			DrinksAndBeverages drinksAndBeverages = iterDrinksAndBeverages
					.next();
			Iterator<NestedDrinksAndBeveragesDTO> iterDtoDrinksAndBeverages = this
					.getDrinksAndBeverages().iterator();
			for (; iterDtoDrinksAndBeverages.hasNext();) {
				NestedDrinksAndBeveragesDTO dtoDrinksAndBeverages = iterDtoDrinksAndBeverages
						.next();
				if (dtoDrinksAndBeverages.getId().equals(
						drinksAndBeverages.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterDrinksAndBeverages.remove();
			}
		}
		Iterator<NestedDrinksAndBeveragesDTO> iterDtoDrinksAndBeverages = this
				.getDrinksAndBeverages().iterator();
		for (; iterDtoDrinksAndBeverages.hasNext();) {
			boolean found = false;
			NestedDrinksAndBeveragesDTO dtoDrinksAndBeverages = iterDtoDrinksAndBeverages
					.next();
			iterDrinksAndBeverages = entity.getDrinksAndBeverages().iterator();
			for (; iterDrinksAndBeverages.hasNext();) {
				DrinksAndBeverages drinksAndBeverages = iterDrinksAndBeverages
						.next();
				if (dtoDrinksAndBeverages.getId().equals(
						drinksAndBeverages.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<DrinksAndBeverages> resultIter = em
						.createQuery(
								"SELECT DISTINCT d FROM DrinksAndBeverages d",
								DrinksAndBeverages.class).getResultList()
						.iterator();
				for (; resultIter.hasNext();) {
					DrinksAndBeverages result = resultIter.next();
					if (result.getId().equals(dtoDrinksAndBeverages.getId())) {
						entity.getDrinksAndBeverages().add(result);
						break;
					}
				}
			}
		}
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Set<NestedDrinksAndBeveragesDTO> getDrinksAndBeverages() {
		return this.drinksAndBeverages;
	}

	public void setDrinksAndBeverages(
			final Set<NestedDrinksAndBeveragesDTO> drinksAndBeverages) {
		this.drinksAndBeverages = drinksAndBeverages;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}
}