package de.binaris.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import de.binaris.parties.model.AdultOnlyType;
import de.binaris.parties.model.Party;

public class NestedPartyDTO implements Serializable {

	private String linkBookOnlineAtVenue;
	private String dressCode;
	private Long id;
	private String schedule;
	private AdultOnlyType adultOnly;
	private String description;
	private String name;
	private String hostname;
	private String linkDetails;

	public NestedPartyDTO() {
	}

	public NestedPartyDTO(final Party entity) {
		if (entity != null) {
			this.linkBookOnlineAtVenue = entity.getLinkBookOnlineAtVenue();
			this.dressCode = entity.getDressCode();
			this.id = entity.getId();
			this.schedule = entity.getSchedule();
			this.adultOnly = entity.getAdultOnly();
			this.description = entity.getDescription();
			this.name = entity.getName();
			this.hostname = entity.getHostname();
			this.linkDetails = entity.getLinkDetails();
		}
	}

	public Party fromDTO(Party entity, EntityManager em) {
		if (entity == null) {
			entity = new Party();
		}
		if (this.id != null) {
			TypedQuery<Party> findByIdQuery = em.createQuery(
					"SELECT DISTINCT p FROM Party p WHERE p.id = :entityId",
					Party.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setLinkBookOnlineAtVenue(this.linkBookOnlineAtVenue);
		entity.setDressCode(this.dressCode);
		entity.setSchedule(this.schedule);
		entity.setAdultOnly(this.adultOnly);
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity.setHostname(this.hostname);
		entity.setLinkDetails(this.linkDetails);
		entity = em.merge(entity);
		return entity;
	}

	public String getLinkBookOnlineAtVenue() {
		return this.linkBookOnlineAtVenue;
	}

	public void setLinkBookOnlineAtVenue(final String linkBookOnlineAtVenue) {
		this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
	}

	public String getDressCode() {
		return this.dressCode;
	}

	public void setDressCode(final String dressCode) {
		this.dressCode = dressCode;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getSchedule() {
		return this.schedule;
	}

	public void setSchedule(final String schedule) {
		this.schedule = schedule;
	}

	public AdultOnlyType getAdultOnly() {
		return this.adultOnly;
	}

	public void setAdultOnly(final AdultOnlyType adultOnly) {
		this.adultOnly = adultOnly;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public String getHostname() {
		return this.hostname;
	}
	
	public void setHostname(final String hostname) {
		this.hostname = hostname;
	}
	
	public String getLinkDetails() {
		return this.linkDetails;
	}

	public void setLinkDetails(final String linkDetails) {
		this.linkDetails = linkDetails;
	}
}