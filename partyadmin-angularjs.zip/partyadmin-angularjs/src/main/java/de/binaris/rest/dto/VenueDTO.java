package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.parties.model.Venue;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.AddressDTO;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedPartyDTO;
import de.binaris.parties.model.Party;
import java.util.Iterator;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class VenueDTO implements Serializable {

	private Long id;
	private AddressDTO address;
	private String website;
	private String location;
	private String name;
	private Set<NestedPartyDTO> party = new HashSet<NestedPartyDTO>();

	public VenueDTO() {
	}

	public VenueDTO(final Venue entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.address = new AddressDTO(entity.getAddress());
			this.website = entity.getWebsite();
			this.location = entity.getLocation();
			this.name = entity.getName();
			Iterator<Party> iterParty = entity.getParty().iterator();
			for (; iterParty.hasNext();) {
				Party element = iterParty.next();
				this.party.add(new NestedPartyDTO(element));
			}
		}
	}

	public Venue fromDTO(Venue entity, EntityManager em) {
		if (entity == null) {
			entity = new Venue();
		}
		if (this.address != null) {
			entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
		}
		entity.setWebsite(this.website);
		entity.setLocation(this.location);
		entity.setName(this.name);
		Iterator<Party> iterParty = entity.getParty().iterator();
		for (; iterParty.hasNext();) {
			boolean found = false;
			Party party = iterParty.next();
			Iterator<NestedPartyDTO> iterDtoParty = this.getParty().iterator();
			for (; iterDtoParty.hasNext();) {
				NestedPartyDTO dtoParty = iterDtoParty.next();
				if (dtoParty.getId().equals(party.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterParty.remove();
			}
		}
		Iterator<NestedPartyDTO> iterDtoParty = this.getParty().iterator();
		for (; iterDtoParty.hasNext();) {
			boolean found = false;
			NestedPartyDTO dtoParty = iterDtoParty.next();
			iterParty = entity.getParty().iterator();
			for (; iterParty.hasNext();) {
				Party party = iterParty.next();
				if (dtoParty.getId().equals(party.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<Party> resultIter = em
						.createQuery("SELECT DISTINCT p FROM Party p",
								Party.class).getResultList().iterator();
				for (; resultIter.hasNext();) {
					Party result = resultIter.next();
					if (result.getId().equals(dtoParty.getId())) {
						entity.getParty().add(result);
						break;
					}
				}
			}
		}
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public AddressDTO getAddress() {
		return this.address;
	}

	public void setAddress(final AddressDTO address) {
		this.address = address;
	}

	public String getWebsite() {
		return this.website;
	}

	public void setWebsite(final String website) {
		this.website = website;
	}

	public String getLocation() {
		return this.location;
	}

	public void setLocation(final String location) {
		this.location = location;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public Set<NestedPartyDTO> getParty() {
		return this.party;
	}

	public void setParty(final Set<NestedPartyDTO> party) {
		this.party = party;
	}
}