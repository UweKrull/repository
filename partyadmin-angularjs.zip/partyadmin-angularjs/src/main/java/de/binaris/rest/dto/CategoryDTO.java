package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.parties.model.Category;
import javax.persistence.EntityManager;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedPartyDTO;
import de.binaris.parties.model.Party;
import java.util.Iterator;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable {

	private Long id;
	private String description;
	private String name;
	private Set<NestedPartyDTO> party = new HashSet<NestedPartyDTO>();

	public CategoryDTO() {
	}

	public CategoryDTO(final Category entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.description = entity.getDescription();
			this.name = entity.getName();
			Iterator<Party> iterParty = entity.getParty().iterator();
			for (; iterParty.hasNext();) {
				Party element = iterParty.next();
				this.party.add(new NestedPartyDTO(element));
			}
		}
	}

	public Category fromDTO(Category entity, EntityManager em) {
		if (entity == null) {
			entity = new Category();
		}
		entity.setDescription(this.description);
		entity.setName(this.name);
		Iterator<Party> iterParty = entity.getParty().iterator();
		for (; iterParty.hasNext();) {
			boolean found = false;
			Party party = iterParty.next();
			Iterator<NestedPartyDTO> iterDtoParty = this.getParty().iterator();
			for (; iterDtoParty.hasNext();) {
				NestedPartyDTO dtoParty = iterDtoParty.next();
				if (dtoParty.getId().equals(party.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterParty.remove();
			}
		}
		Iterator<NestedPartyDTO> iterDtoParty = this.getParty().iterator();
		for (; iterDtoParty.hasNext();) {
			boolean found = false;
			NestedPartyDTO dtoParty = iterDtoParty.next();
			iterParty = entity.getParty().iterator();
			for (; iterParty.hasNext();) {
				Party party = iterParty.next();
				if (dtoParty.getId().equals(party.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<Party> resultIter = em
						.createQuery("SELECT DISTINCT p FROM Party p",
								Party.class).getResultList().iterator();
				for (; resultIter.hasNext();) {
					Party result = resultIter.next();
					if (result.getId().equals(dtoParty.getId())) {
						entity.getParty().add(result);
						break;
					}
				}
			}
		}
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public Set<NestedPartyDTO> getParty() {
		return this.party;
	}

	public void setParty(final Set<NestedPartyDTO> party) {
		this.party = party;
	}
}