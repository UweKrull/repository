package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.parties.model.CategoryType;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedCategoryTypeDTO implements Serializable {

	private Long id;
	private String description;
	private String name;

	public NestedCategoryTypeDTO() {
	}

	public NestedCategoryTypeDTO(final CategoryType entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.description = entity.getDescription();
			this.name = entity.getName();
		}
	}

	public CategoryType fromDTO(CategoryType entity, EntityManager em) {
		if (entity == null) {
			entity = new CategoryType();
		}
		if (this.id != null) {
			TypedQuery<CategoryType> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT c FROM CategoryType c WHERE c.id = :entityId",
							CategoryType.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}
}