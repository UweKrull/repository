package de.binaris.parties.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.parties.model.Party;
import de.binaris.rest.dto.PartyDTO;

/**
 * The REST Webservice Party endpoint.
 */
@Stateless
@Path("/partys")
public class PartyEndpoint
{
   @PersistenceContext(unitName = "PartyadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(PartyDTO dto)
   {
      Party entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(PartyEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Party entity = em.find(Party.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Party> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM Party p LEFT JOIN FETCH p.venue LEFT JOIN FETCH p.category LEFT JOIN FETCH p.guest LEFT JOIN FETCH p.drinksAndBeverages LEFT JOIN FETCH p.timeAndCharge LEFT JOIN FETCH p.phoneContact WHERE p.id = :entityId ORDER BY p.id", Party.class);
      findByIdQuery.setParameter("entityId", id);
      Party entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      PartyDTO dto = new PartyDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<PartyDTO> listAll()
   {
      final List<Party> searchResults = em.createQuery("SELECT DISTINCT p FROM Party p LEFT JOIN FETCH p.venue LEFT JOIN FETCH p.category LEFT JOIN FETCH p.guest LEFT JOIN FETCH p.drinksAndBeverages LEFT JOIN FETCH p.timeAndCharge LEFT JOIN FETCH p.phoneContact ORDER BY p.id", Party.class).getResultList();
      final List<PartyDTO> results = new ArrayList<PartyDTO>();
      for (Party searchResult : searchResults)
      {
         PartyDTO dto = new PartyDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, PartyDTO dto)
   {
      TypedQuery<Party> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM Party p LEFT JOIN FETCH p.venue LEFT JOIN FETCH p.category LEFT JOIN FETCH p.guest LEFT JOIN FETCH p.drinksAndBeverages LEFT JOIN FETCH p.timeAndCharge LEFT JOIN FETCH p.phoneContact WHERE p.id = :entityId ORDER BY p.id", Party.class);
      findByIdQuery.setParameter("entityId", id);
      Party entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}