'use strict';

angular.module('partyadminangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/CategoryTypes',{templateUrl:'views/CategoryType/search.html',controller:'SearchCategoryTypeController'})
      .when('/CategoryTypes/new',{templateUrl:'views/CategoryType/detail.html',controller:'NewCategoryTypeController'})
      .when('/CategoryTypes/edit/:CategoryTypeId',{templateUrl:'views/CategoryType/detail.html',controller:'EditCategoryTypeController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Customers',{templateUrl:'views/Customer/search.html',controller:'SearchCustomerController'})
      .when('/Customers/new',{templateUrl:'views/Customer/detail.html',controller:'NewCustomerController'})
      .when('/Customers/edit/:CustomerId',{templateUrl:'views/Customer/detail.html',controller:'EditCustomerController'})
      .when('/DrinksAndBeveragess',{templateUrl:'views/DrinksAndBeverages/search.html',controller:'SearchDrinksAndBeveragesController'})
      .when('/DrinksAndBeveragess/new',{templateUrl:'views/DrinksAndBeverages/detail.html',controller:'NewDrinksAndBeveragesController'})
      .when('/DrinksAndBeveragess/edit/:DrinksAndBeveragesId',{templateUrl:'views/DrinksAndBeverages/detail.html',controller:'EditDrinksAndBeveragesController'})
      .when('/Partys',{templateUrl:'views/Party/search.html',controller:'SearchPartyController'})
      .when('/Partys/new',{templateUrl:'views/Party/detail.html',controller:'NewPartyController'})
      .when('/Partys/edit/:PartyId',{templateUrl:'views/Party/detail.html',controller:'EditPartyController'})
      .when('/PhoneContacts',{templateUrl:'views/PhoneContact/search.html',controller:'SearchPhoneContactController'})
      .when('/PhoneContacts/new',{templateUrl:'views/PhoneContact/detail.html',controller:'NewPhoneContactController'})
      .when('/PhoneContacts/edit/:PhoneContactId',{templateUrl:'views/PhoneContact/detail.html',controller:'EditPhoneContactController'})
      .when('/TimeAndCharges',{templateUrl:'views/TimeAndCharge/search.html',controller:'SearchTimeAndChargeController'})
      .when('/TimeAndCharges/new',{templateUrl:'views/TimeAndCharge/detail.html',controller:'NewTimeAndChargeController'})
      .when('/TimeAndCharges/edit/:TimeAndChargeId',{templateUrl:'views/TimeAndCharge/detail.html',controller:'EditTimeAndChargeController'})
      .when('/Venues',{templateUrl:'views/Venue/search.html',controller:'SearchVenueController'})
      .when('/Venues/new',{templateUrl:'views/Venue/detail.html',controller:'NewVenueController'})
      .when('/Venues/edit/:VenueId',{templateUrl:'views/Venue/detail.html',controller:'EditVenueController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
