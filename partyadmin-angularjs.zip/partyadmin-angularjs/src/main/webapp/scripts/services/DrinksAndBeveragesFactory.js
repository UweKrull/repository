angular.module('partyadminangularjs').factory('DrinksAndBeveragesResource', function($resource){
    var resource = $resource('rest/drinksandbeveragess/:DrinksAndBeveragesId',{DrinksAndBeveragesId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});