angular.module('partyadminangularjs').factory('PartyResource', function($resource){
    var resource = $resource('rest/partys/:PartyId',{PartyId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});