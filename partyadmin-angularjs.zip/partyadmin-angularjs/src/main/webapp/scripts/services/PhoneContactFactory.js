angular.module('partyadminangularjs').factory('PhoneContactResource', function($resource){
    var resource = $resource('rest/phonecontacts/:PhoneContactId',{PhoneContactId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});