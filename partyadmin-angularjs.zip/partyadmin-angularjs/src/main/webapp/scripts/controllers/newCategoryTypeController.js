
angular.module('partyadminangularjs').controller('NewCategoryTypeController', function ($scope, $location, locationParser, CategoryTypeResource , DrinksAndBeveragesResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.categoryType = $scope.categoryType || {};
    
    $scope.drinksAndBeveragesList = DrinksAndBeveragesResource.queryAll(function(items){
        $scope.drinksAndBeveragesSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("drinksAndBeveragesSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.categoryType.drinksAndBeverages = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.categoryType.drinksAndBeverages.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/CategoryTypes/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CategoryTypeResource.save($scope.categoryType, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/CategoryTypes");
    };
});