

angular.module('partyadminangularjs').controller('EditDrinksAndBeveragesController', function($scope, $routeParams, $location, DrinksAndBeveragesResource , PartyResource, CategoryTypeResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.drinksAndBeverages = new DrinksAndBeveragesResource(self.original);
            PartyResource.queryAll(function(items) {
                $scope.partySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.drinksAndBeverages.party && item.id == $scope.drinksAndBeverages.party.id) {
                        $scope.partySelection = labelObject;
                        $scope.drinksAndBeverages.party = wrappedObject;
                        self.original.party = $scope.drinksAndBeverages.party;
                    }
                    return labelObject;
                });
            });
            CategoryTypeResource.queryAll(function(items) {
                $scope.categoryTypeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.drinksAndBeverages.categoryType && item.id == $scope.drinksAndBeverages.categoryType.id) {
                        $scope.categoryTypeSelection = labelObject;
                        $scope.drinksAndBeverages.categoryType = wrappedObject;
                        self.original.categoryType = $scope.drinksAndBeverages.categoryType;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/DrinksAndBeveragess");
        };
        DrinksAndBeveragesResource.get({DrinksAndBeveragesId:$routeParams.DrinksAndBeveragesId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.drinksAndBeverages);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.drinksAndBeverages.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/DrinksAndBeveragess");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/DrinksAndBeveragess");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.drinksAndBeverages.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("partySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.drinksAndBeverages.party = {};
            $scope.drinksAndBeverages.party.id = selection.value;
        }
    });
    $scope.$watch("categoryTypeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.drinksAndBeverages.categoryType = {};
            $scope.drinksAndBeverages.categoryType.id = selection.value;
        }
    });
    
    $scope.get();
});