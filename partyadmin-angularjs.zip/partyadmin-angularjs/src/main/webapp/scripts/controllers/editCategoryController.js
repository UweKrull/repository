

angular.module('partyadminangularjs').controller('EditCategoryController', function($scope, $routeParams, $location, CategoryResource , PartyResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.category = new CategoryResource(self.original);
            PartyResource.queryAll(function(items) {
                $scope.partySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.category.party){
                        $.each($scope.category.party, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.partySelection.push(labelObject);
                                $scope.category.party.push(wrappedObject);
                            }
                        });
                        self.original.party = $scope.category.party;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Categorys");
        };
        CategoryResource.get({CategoryId:$routeParams.CategoryId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.category);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.category.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Categorys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Categorys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.category.$remove(successCallback, errorCallback);
    };
    
    $scope.partySelection = $scope.partySelection || [];
    $scope.$watch("partySelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.category) {
            $scope.category.party = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.category.party.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});