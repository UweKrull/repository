

angular.module('partyadminangularjs').controller('EditCategoryTypeController', function($scope, $routeParams, $location, CategoryTypeResource , DrinksAndBeveragesResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.categoryType = new CategoryTypeResource(self.original);
            DrinksAndBeveragesResource.queryAll(function(items) {
                $scope.drinksAndBeveragesSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.categoryType.drinksAndBeverages){
                        $.each($scope.categoryType.drinksAndBeverages, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.drinksAndBeveragesSelection.push(labelObject);
                                $scope.categoryType.drinksAndBeverages.push(wrappedObject);
                            }
                        });
                        self.original.drinksAndBeverages = $scope.categoryType.drinksAndBeverages;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/CategoryTypes");
        };
        CategoryTypeResource.get({CategoryTypeId:$routeParams.CategoryTypeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.categoryType);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.categoryType.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/CategoryTypes");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/CategoryTypes");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.categoryType.$remove(successCallback, errorCallback);
    };
    
    $scope.drinksAndBeveragesSelection = $scope.drinksAndBeveragesSelection || [];
    $scope.$watch("drinksAndBeveragesSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.categoryType) {
            $scope.categoryType.drinksAndBeverages = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.categoryType.drinksAndBeverages.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});