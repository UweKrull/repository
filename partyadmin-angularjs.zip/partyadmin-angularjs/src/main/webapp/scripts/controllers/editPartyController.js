angular.module('partyadminangularjs').controller('EditPartyController', function($scope, $routeParams, $location, PartyResource , VenueResource, CategoryResource, DrinksAndBeveragesResource, TimeAndChargeResource, PhoneContactResource, CustomerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.party = new PartyResource(self.original);
            VenueResource.queryAll(function(items) {
                $scope.venueSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.party.venue && item.id == $scope.party.venue.id) {
                        $scope.venueSelection = labelObject;
                        $scope.party.venue = wrappedObject;
                        self.original.venue = $scope.party.venue;
                    }
                    return labelObject;
                });
            });
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.party.category && item.id == $scope.party.category.id) {
                        $scope.categorySelection = labelObject;
                        $scope.party.category = wrappedObject;
                        self.original.category = $scope.party.category;
                    }
                    return labelObject;
                });
            });
            DrinksAndBeveragesResource.queryAll(function(items) {
                $scope.drinksAndBeveragesSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title+' '+item.categoryType.name
                    };
                    if($scope.party.drinksAndBeverages){
                        $.each($scope.party.drinksAndBeverages, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.drinksAndBeveragesSelection.push(labelObject);
                                $scope.party.drinksAndBeverages.push(wrappedObject);
                            }
                        });
                        self.original.drinksAndBeverages = $scope.party.drinksAndBeverages;
                    }
                    return labelObject;
                });
            });
            TimeAndChargeResource.queryAll(function(items) {
                $scope.timeAndChargeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.days+' '+item.startTime+' '+item.charge
                    };
                    if($scope.party.timeAndCharge){
                        $.each($scope.party.timeAndCharge, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.timeAndChargeSelection.push(labelObject);
                                $scope.party.timeAndCharge.push(wrappedObject);
                            }
                        });
                        self.original.timeAndCharge = $scope.party.timeAndCharge;
                    }
                    return labelObject;
                });
            });
            PhoneContactResource.queryAll(function(items) {
                $scope.phoneContactSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.phoneNumber+' '+item.name
                    };
                    if($scope.party.phoneContact){
                        $.each($scope.party.phoneContact, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.phoneContactSelection.push(labelObject);
                                $scope.party.phoneContact.push(wrappedObject);
                            }
                        });
                        self.original.phoneContact = $scope.party.phoneContact;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.guestSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.lastName+', '+item.firstName+', '+item.email 
                    };
                    if($scope.party.guest){
                        $.each($scope.party.guest, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.guestSelection.push(labelObject);
                                $scope.party.guest.push(wrappedObject);
                            }
                        });
                        self.original.guest = $scope.party.guest;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Partys");
        };
        PartyResource.get({PartyId:$routeParams.PartyId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.party);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.party.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Partys");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Partys");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.party.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("venueSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.party.venue = {};
            $scope.party.venue.id = selection.value;
        }
    });
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.party.category = {};
            $scope.party.category.id = selection.value;
        }
    });
    $scope.drinksAndBeveragesSelection = $scope.drinksAndBeveragesSelection || [];
    $scope.$watch("drinksAndBeveragesSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.party) {
            $scope.party.drinksAndBeverages = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.party.drinksAndBeverages.push(collectionItem);
            });
        }
    });
    $scope.timeAndChargeSelection = $scope.timeAndChargeSelection || [];
    $scope.$watch("timeAndChargeSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.party) {
            $scope.party.timeAndCharge = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.party.timeAndCharge.push(collectionItem);
            });
        }
    });
    $scope.phoneContactSelection = $scope.phoneContactSelection || [];
    $scope.$watch("phoneContactSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.party) {
            $scope.party.phoneContact = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.party.phoneContact.push(collectionItem);
            });
        }
    });
    $scope.guestSelection = $scope.guestSelection || [];
    $scope.$watch("guestSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.party) {
            $scope.party.guest = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.party.guest.push(collectionItem);
            });
        }
    });
    $scope.adultOnlyList = [
        "yes",  
        "no"  
    ];
    
    $scope.get();
});