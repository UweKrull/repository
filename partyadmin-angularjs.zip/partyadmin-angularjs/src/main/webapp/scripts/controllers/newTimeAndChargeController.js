
angular.module('partyadminangularjs').controller('NewTimeAndChargeController', function ($scope, $location, locationParser, TimeAndChargeResource , PartyResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.timeAndCharge = $scope.timeAndCharge || {};
    
    $scope.partyList = PartyResource.queryAll(function(items){
        $scope.partySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("partySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.timeAndCharge.party = {};
            $scope.timeAndCharge.party.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/TimeAndCharges/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        TimeAndChargeResource.save($scope.timeAndCharge, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/TimeAndCharges");
    };
});