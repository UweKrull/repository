

angular.module('partyadminangularjs').controller('EditTimeAndChargeController', function($scope, $routeParams, $location, TimeAndChargeResource , PartyResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.timeAndCharge = new TimeAndChargeResource(self.original);
            PartyResource.queryAll(function(items) {
                $scope.partySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.timeAndCharge.party && item.id == $scope.timeAndCharge.party.id) {
                        $scope.partySelection = labelObject;
                        $scope.timeAndCharge.party = wrappedObject;
                        self.original.party = $scope.timeAndCharge.party;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/TimeAndCharges");
        };
        TimeAndChargeResource.get({TimeAndChargeId:$routeParams.TimeAndChargeId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.timeAndCharge);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.timeAndCharge.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/TimeAndCharges");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/TimeAndCharges");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.timeAndCharge.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("partySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.timeAndCharge.party = {};
            $scope.timeAndCharge.party.id = selection.value;
        }
    });
    
    $scope.get();
});