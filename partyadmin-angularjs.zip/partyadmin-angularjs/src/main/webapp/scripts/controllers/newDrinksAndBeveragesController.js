
angular.module('partyadminangularjs').controller('NewDrinksAndBeveragesController', function ($scope, $location, locationParser, DrinksAndBeveragesResource , PartyResource, CategoryTypeResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.drinksAndBeverages = $scope.drinksAndBeverages || {};
    
    $scope.partyList = PartyResource.queryAll(function(items){
        $scope.partySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("partySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.drinksAndBeverages.party = {};
            $scope.drinksAndBeverages.party.id = selection.value;
        }
    });
    
    $scope.categoryTypeList = CategoryTypeResource.queryAll(function(items){
        $scope.categoryTypeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categoryTypeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.drinksAndBeverages.categoryType = {};
            $scope.drinksAndBeverages.categoryType.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/DrinksAndBeveragess/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        DrinksAndBeveragesResource.save($scope.drinksAndBeverages, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/DrinksAndBeveragess");
    };
});