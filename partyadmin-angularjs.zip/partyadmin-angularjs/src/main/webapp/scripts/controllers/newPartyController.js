angular.module('partyadminangularjs').controller('NewPartyController', function ($scope, $location, locationParser, PartyResource , VenueResource, CategoryResource, DrinksAndBeveragesResource, TimeAndChargeResource, PhoneContactResource, CustomerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.party = $scope.party || {};
    
    $scope.venueList = VenueResource.queryAll(function(items){
        $scope.venueSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("venueSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.party.venue = {};
            $scope.party.venue.id = selection.value;
        }
    });
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.party.category = {};
            $scope.party.category.id = selection.value;
        }
    });
    
    $scope.drinksAndBeveragesList = DrinksAndBeveragesResource.queryAll(function(items){
        $scope.drinksAndBeveragesSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("drinksAndBeveragesSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.party.drinksAndBeverages = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.party.drinksAndBeverages.push(collectionItem);
            });
        }
    });
    
    $scope.timeAndChargeList = TimeAndChargeResource.queryAll(function(items){
        $scope.timeAndChargeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.days
            });
        });
    });
    $scope.$watch("timeAndChargeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.party.timeAndCharge = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.party.timeAndCharge.push(collectionItem);
            });
        }
    });
    
    $scope.phoneContactList = PhoneContactResource.queryAll(function(items){
        $scope.phoneContactSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.phoneNumber
            });
        });
    });
    $scope.$watch("phoneContactSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.party.phoneContact = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.party.phoneContact.push(collectionItem);
            });
        }
    });
    
    $scope.guestList = CustomerResource.queryAll(function(items){
        $scope.guestSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName
            });
        });
    });
    $scope.$watch("guestSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.party.guest = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.party.guest.push(collectionItem);
            });
        }
    });
    
    $scope.adultOnlyList = [
        "yes",
        "no"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Partys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PartyResource.save($scope.party, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Partys");
    };
});