

angular.module('partyadminangularjs').controller('EditCustomerController', function($scope, $routeParams, $location, CustomerResource , PartyResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.customer = new CustomerResource(self.original);
            PartyResource.queryAll(function(items) {
                $scope.partySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.customer.party && item.id == $scope.customer.party.id) {
                        $scope.partySelection = labelObject;
                        $scope.customer.party = wrappedObject;
                        self.original.party = $scope.customer.party;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.customer.address.country && item.id == $scope.customer.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.customer.address.country = wrappedObject;
                        self.original.address.country = $scope.customer.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Customers");
        };
        CustomerResource.get({CustomerId:$routeParams.CustomerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.customer);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.customer.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Customers");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Customers");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.customer.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("partySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.party = {};
            $scope.customer.party.id = selection.value;
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.address.country = {};
            $scope.customer.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});