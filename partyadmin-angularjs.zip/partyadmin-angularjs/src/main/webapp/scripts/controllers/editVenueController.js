

angular.module('partyadminangularjs').controller('EditVenueController', function($scope, $routeParams, $location, VenueResource , PartyResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.venue = new VenueResource(self.original);
            PartyResource.queryAll(function(items) {
                $scope.partySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.venue.party){
                        $.each($scope.venue.party, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.partySelection.push(labelObject);
                                $scope.venue.party.push(wrappedObject);
                            }
                        });
                        self.original.party = $scope.venue.party;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.venue.address.country && item.id == $scope.venue.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.venue.address.country = wrappedObject;
                        self.original.address.country = $scope.venue.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Venues");
        };
        VenueResource.get({VenueId:$routeParams.VenueId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.venue);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.venue.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Venues");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Venues");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.venue.$remove(successCallback, errorCallback);
    };
    
    $scope.partySelection = $scope.partySelection || [];
    $scope.$watch("partySelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.venue) {
            $scope.venue.party = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.venue.party.push(collectionItem);
            });
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.venue.address.country = {};
            $scope.venue.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});