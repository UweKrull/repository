

angular.module('partyadminangularjs').controller('EditPhoneContactController', function($scope, $routeParams, $location, PhoneContactResource , PartyResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.phoneContact = new PhoneContactResource(self.original);
            PartyResource.queryAll(function(items) {
                $scope.partySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.phoneContact.party && item.id == $scope.phoneContact.party.id) {
                        $scope.partySelection = labelObject;
                        $scope.phoneContact.party = wrappedObject;
                        self.original.party = $scope.phoneContact.party;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/PhoneContacts");
        };
        PhoneContactResource.get({PhoneContactId:$routeParams.PhoneContactId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.phoneContact);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.phoneContact.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PhoneContacts");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PhoneContacts");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.phoneContact.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("partySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.phoneContact.party = {};
            $scope.phoneContact.party.id = selection.value;
        }
    });
    
    $scope.get();
});