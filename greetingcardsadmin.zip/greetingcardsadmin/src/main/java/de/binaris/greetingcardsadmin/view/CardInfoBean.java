package de.binaris.greetingcardsadmin.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import de.binaris.greetingcardsadmin.model.CardInfo;

/**
 * Backing bean for CardInfo entities.
 * <p>
 * This class provides CRUD functionality for all CardInfo entities. It focuses
 * purely on Java EE 6 standards (e.g. <tt>&#64;ConversationScoped</tt> for
 * state management, <tt>PersistenceContext</tt> for persistence,
 * <tt>CriteriaBuilder</tt> for searches) rather than introducing a CRUD framework or
 * custom base class.
 */

@Named
@Stateful
@ConversationScoped
public class CardInfoBean implements Serializable
{

   private static final long serialVersionUID = 1L;

   /*
    * Support creating and retrieving CardInfo entities
    */

   private Long id;

   public Long getId()
   {
      return this.id;
   }

   public void setId(Long id)
   {
      this.id = id;
   }

   private CardInfo cardInfo;

   public CardInfo getCardInfo()
   {
      return this.cardInfo;
   }

   @Inject
   private Conversation conversation;

   @PersistenceContext(type = PersistenceContextType.EXTENDED)
   private EntityManager entityManager;

   public String create()
   {

      this.conversation.begin();
      return "create?faces-redirect=true";
   }

   public void retrieve()
   {

      if (FacesContext.getCurrentInstance().isPostback())
      {
         return;
      }

      if (this.conversation.isTransient())
      {
         this.conversation.begin();
      }

      if (this.id == null)
      {
         this.cardInfo = this.example;
      }
      else
      {
         this.cardInfo = findById(getId());
      }
   }

   public CardInfo findById(Long id)
   {

      return this.entityManager.find(CardInfo.class, id);
   }

   /*
    * Support updating and deleting CardInfo entities
    */

   public String update()
   {
      this.conversation.end();

      try
      {
         if (this.id == null)
         {
            this.entityManager.persist(this.cardInfo);
            return "search?faces-redirect=true";
         }
         else
         {
            this.entityManager.merge(this.cardInfo);
            return "view?faces-redirect=true&id=" + this.cardInfo.getIdCardInfo();
         }
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   public String delete()
   {
      this.conversation.end();

      try
      {
         CardInfo deletableEntity = findById(getId());

         this.entityManager.remove(deletableEntity);
         this.entityManager.flush();
         return "search?faces-redirect=true";
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   /*
    * Support searching CardInfo entities with pagination
    */

   private int page;
   private long count;
   private List<CardInfo> pageItems;

   private CardInfo example = new CardInfo();

   public int getPage()
   {
      return this.page;
   }

   public void setPage(int page)
   {
      this.page = page;
   }

   public int getPageSize()
   {
      return 10;
   }

   public CardInfo getExample()
   {
      return this.example;
   }

   public void setExample(CardInfo example)
   {
      this.example = example;
   }

   public void search()
   {
      this.page = 0;
   }

   public void paginate()
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

      // Populate this.count

      CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
      Root<CardInfo> root = countCriteria.from(CardInfo.class);
      countCriteria = countCriteria.select(builder.count(root)).where(
            getSearchPredicates(root));
      this.count = this.entityManager.createQuery(countCriteria)
            .getSingleResult();

      // Populate this.pageItems

      CriteriaQuery<CardInfo> criteria = builder.createQuery(CardInfo.class);
      root = criteria.from(CardInfo.class);
      TypedQuery<CardInfo> query = this.entityManager.createQuery(criteria
            .select(root).where(getSearchPredicates(root)));
      query.setFirstResult(this.page * getPageSize()).setMaxResults(
            getPageSize());
      this.pageItems = query.getResultList();
   }

   private Predicate[] getSearchPredicates(Root<CardInfo> root)
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
      List<Predicate> predicatesList = new ArrayList<Predicate>();

      Integer cardLayout = this.example.getCardLayout();
      if (cardLayout != null && cardLayout.intValue() != 0)
      {
         predicatesList.add(builder.equal(root.get("cardLayout"), cardLayout));
      }
      String flirtText = this.example.getFlirtText();
      if (flirtText != null && !"".equals(flirtText))
      {
         predicatesList.add(builder.like(root.<String> get("flirtText"), '%' + flirtText + '%'));
      }
      String fontColor = this.example.getFontColor();
      if (fontColor != null && !"".equals(fontColor))
      {
         predicatesList.add(builder.like(root.<String> get("fontColor"), '%' + fontColor + '%'));
      }
      String fontFamily = this.example.getFontFamily();
      if (fontFamily != null && !"".equals(fontFamily))
      {
         predicatesList.add(builder.like(root.<String> get("fontFamily"), '%' + fontFamily + '%'));
      }
      String fontSize = this.example.getFontSize();
      if (fontSize != null && !"".equals(fontSize))
      {
         predicatesList.add(builder.like(root.<String> get("fontSize"), '%' + fontSize + '%'));
      }

      return predicatesList.toArray(new Predicate[predicatesList.size()]);
   }

   public List<CardInfo> getPageItems()
   {
      return this.pageItems;
   }

   public long getCount()
   {
      return this.count;
   }

   /*
    * Support listing and POSTing back CardInfo entities (e.g. from inside an
    * HtmlSelectOneMenu)
    */

   public List<CardInfo> getAll()
   {

      CriteriaQuery<CardInfo> criteria = this.entityManager
            .getCriteriaBuilder().createQuery(CardInfo.class);
      return this.entityManager.createQuery(
            criteria.select(criteria.from(CardInfo.class))).getResultList();
   }

   @Resource
   private SessionContext sessionContext;

   public Converter getConverter()
   {

      final CardInfoBean ejbProxy = this.sessionContext.getBusinessObject(CardInfoBean.class);

      return new Converter()
      {

         @Override
         public Object getAsObject(FacesContext context,
               UIComponent component, String value)
         {

            return ejbProxy.findById(Long.valueOf(value));
         }

         @Override
         public String getAsString(FacesContext context,
               UIComponent component, Object value)
         {

            if (value == null)
            {
               return "";
            }

            return String.valueOf(((CardInfo) value).getIdCardInfo());
         }
      };
   }

   /*
    * Support adding children to bidirectional, one-to-many tables
    */

   private CardInfo add = new CardInfo();

   public CardInfo getAdd()
   {
      return this.add;
   }

   public CardInfo getAdded()
   {
      CardInfo added = this.add;
      this.add = new CardInfo();
      return added;
   }
}