package de.binaris.greetingcardsadmin.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import de.binaris.greetingcardsadmin.model.CardSent;
import de.binaris.greetingcardsadmin.rest.dto.NestedCardInfoDTO;
import de.binaris.greetingcardsadmin.rest.dto.NestedImageDTO;

import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CardSentDTO implements Serializable {

	private static final long serialVersionUID = 1575672017127213151L;
	
	private String toEmail;
	private String toName;
	private NestedCardInfoDTO cardInfo;
	private Short isSent;
	private NestedImageDTO image;
	private Date seenDate;
	private Long idCardSent;
	private String fromVorname;
	private Date expireDate;
	private String sendOnPickup;
	private String toVorname;
	private Date expireArchiv;
	private String fromEmail;
	private Short seenCount;
	private String fromName;
	private Date createDate;

	public CardSentDTO() {
	}

	public CardSentDTO(final CardSent entity) {
		if (entity != null) {
			this.toEmail = entity.getToEmail();
			this.toName = entity.getToName();
			this.cardInfo = new NestedCardInfoDTO(entity.getCardInfo());
			this.isSent = entity.getIsSent();
			this.image = new NestedImageDTO(entity.getImage());
			this.seenDate = entity.getSeenDate();
			this.idCardSent = entity.getIdCardSent();
			this.fromVorname = entity.getFromVorname();
			this.expireDate = entity.getExpireDate();
			this.sendOnPickup = entity.getSendOnPickup();
			this.toVorname = entity.getToVorname();
			this.expireArchiv = entity.getExpireArchiv();
			this.fromEmail = entity.getFromEmail();
			this.seenCount = entity.getSeenCount();
			this.fromName = entity.getFromName();
			this.createDate = entity.getCreateDate();
		}
	}

	public CardSent fromDTO(CardSent entity, EntityManager em) {
		if (entity == null) {
			entity = new CardSent();
		}
		entity.setToEmail(this.toEmail);
		entity.setToName(this.toName);
		if (this.cardInfo != null) {
			entity.setCardInfo(this.cardInfo.fromDTO(entity.getCardInfo(), em));
		}
		entity.setIsSent(this.isSent);
		if (this.image != null) {
			entity.setImage(this.image.fromDTO(entity.getImage(), em));
		}
		entity.setSeenDate(this.seenDate);
		entity.setFromVorname(this.fromVorname);
		entity.setExpireDate(this.expireDate);
		entity.setSendOnPickup(this.sendOnPickup);
		entity.setToVorname(this.toVorname);
		entity.setExpireArchiv(this.expireArchiv);
		entity.setFromEmail(this.fromEmail);
		entity.setSeenCount(this.seenCount);
		entity.setFromName(this.fromName);
		entity.setCreateDate(this.createDate);
		entity = em.merge(entity);
		return entity;
	}

	public String getToEmail() {
		return this.toEmail;
	}

	public void setToEmail(final String toEmail) {
		this.toEmail = toEmail;
	}

	public String getToName() {
		return this.toName;
	}

	public void setToName(final String toName) {
		this.toName = toName;
	}

	public NestedCardInfoDTO getCardInfo() {
		return this.cardInfo;
	}

	public void setCardInfo(final NestedCardInfoDTO cardInfo) {
		this.cardInfo = cardInfo;
	}

	public Short getIsSent() {
		return this.isSent;
	}

	public void setIsSent(final Short isSent) {
		this.isSent = isSent;
	}

	public NestedImageDTO getImage() {
		return this.image;
	}

	public void setImage(final NestedImageDTO image) {
		this.image = image;
	}

	public Date getSeenDate() {
		return this.seenDate;
	}

	public void setSeenDate(final Date seenDate) {
		this.seenDate = seenDate;
	}

	public Long getIdCardSent() {
		return this.idCardSent;
	}

	public void setIdCardSent(final Long idCardSent) {
		this.idCardSent = idCardSent;
	}

	public String getFromVorname() {
		return this.fromVorname;
	}

	public void setFromVorname(final String fromVorname) {
		this.fromVorname = fromVorname;
	}

	public Date getExpireDate() {
		return this.expireDate;
	}

	public void setExpireDate(final Date expireDate) {
		this.expireDate = expireDate;
	}

	public String getSendOnPickup() {
		return this.sendOnPickup;
	}

	public void setSendOnPickup(final String sendOnPickup) {
		this.sendOnPickup = sendOnPickup;
	}

	public String getToVorname() {
		return this.toVorname;
	}

	public void setToVorname(final String toVorname) {
		this.toVorname = toVorname;
	}

	public Date getExpireArchiv() {
		return this.expireArchiv;
	}

	public void setExpireArchiv(final Date expireArchiv) {
		this.expireArchiv = expireArchiv;
	}

	public String getFromEmail() {
		return this.fromEmail;
	}

	public void setFromEmail(final String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public Short getSeenCount() {
		return this.seenCount;
	}

	public void setSeenCount(final Short seenCount) {
		this.seenCount = seenCount;
	}

	public String getFromName() {
		return this.fromName;
	}

	public void setFromName(final String fromName) {
		this.fromName = fromName;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(final Date createDate) {
		this.createDate = createDate;
	}
}