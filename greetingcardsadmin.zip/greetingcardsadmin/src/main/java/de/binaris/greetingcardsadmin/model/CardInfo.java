package de.binaris.greetingcardsadmin.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Query;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * The persistent class for the card_info database table.
 */
@Entity
@Table(name="card_info")
public class CardInfo implements Serializable {
	private static final long serialVersionUID = 773263212177976636L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="my_entity_seq_gen_info")
	@SequenceGenerator(name = "my_entity_seq_gen_info", sequenceName="sequence_card_info", allocationSize=1)
	private Long idCardInfo;

	@NotNull
	@Min(value = 1, message = "possible values: 1 (portrait), 2 (landscape)")
	@Max(value = 2, message = "possible values: 1 (portrait), 2 (landscape)")
	private Integer cardLayout;

	private String flirtText;

	private String jokeText;

	private String konfuzText;

	@Size(min = 0, max = 400, message = "must be 0-400 letters long")
	private String message;

	private String fontColor;

	private String fontFamily;

	private String fontSize;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Image image;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Category category;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Subcategory subcategory;

	@ManyToOne
	private Image imageBg;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Customer customer;
	
    @Temporal(TemporalType.DATE)
	@Column(name="send_date", updatable = false)
	private Date sendDate;

	private String thumbPath;

    public CardInfo() {
    }

    public CardInfo(Image image, Category category, Subcategory subcategory) {
    	this.image       = image;
    	this.category    = category;
    	this.subcategory = subcategory;
    }
    
	public Long getIdCardInfo() {
		return this.idCardInfo;
	}

	public void setIdCardInfo(Long idCardInfo) {
		this.idCardInfo = idCardInfo;
	}

	public Integer getCardLayout() {
		return this.cardLayout;
	}

	public void setCardLayout(Integer cardLayout) {
		this.cardLayout = cardLayout;
	}

	public String getFlirtText() {
		return this.flirtText;
	}

	public void setFlirtText(String flirtText) {
		this.flirtText = flirtText;
	}

	public String getFontColor() {
		return this.fontColor;
	}

	public void setFontColor(String fontColor) {
		this.fontColor = fontColor;
	}

	public String getFontFamily() {
		return this.fontFamily;
	}

	public void setFontFamily(String fontFamily) {
		this.fontFamily = fontFamily;
	}

	public String getFontSize() {
		return this.fontSize;
	}

	public void setFontSize(String fontSize) {
		this.fontSize = fontSize;
	}

	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Subcategory getSubcategory() {
		return this.subcategory;
	}

	public void setSubcategory(Subcategory subcategory) {
		this.subcategory = subcategory;
	}

	public Image getImageBg() {
		return this.imageBg;
	}

	public void setImageBg(Image imageBg) {
		this.imageBg = imageBg;
	}

	public Image getImage() {
		return this.image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public String getJokeText() {
		return this.jokeText;
	}

	public void setJokeText(String jokeText) {
		this.jokeText = jokeText;
	}

	public String getKonfuzText() {
		return this.konfuzText;
	}

	public void setKonfuzText(String konfuzText) {
		this.konfuzText = konfuzText;
	}

	public String getMessage() {
		return this.message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getSendDate() {
		return this.sendDate;
	}

	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}

	public String getThumbPath() {
		return this.thumbPath;
	}

	public void setThumbPath(String thumbPath) {
		this.thumbPath = thumbPath;
	}

    @Override
    public int hashCode() {
        return idCardInfo != null ? idCardInfo.hashCode() : System.identityHashCode(this);
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CardInfo)) {
            return false;
        }
        CardInfo castOther = (CardInfo) object;
        return idCardInfo != null ? idCardInfo.equals(castOther.getIdCardInfo()) : false;
    }
    
	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("CardInfo: ");
		sb.append('\'').append(message).append('\'');
		sb.append(", ").append('\'').append(sendDate).append('\'');
		sb.append(", ").append('\'').append(flirtText).append('\'');
		sb.append(", ").append('\'').append(jokeText).append('\'');
		sb.append(", ").append('\'').append(konfuzText).append('\'');
		return sb.toString();
	}
	
    public static Long getCardInfoMaxId(EntityManager em) {
        final Query q = em.createQuery("select max(c.idCardInfo) from CardInfo as c");
        return ((Long) q.getSingleResult());
    }
}