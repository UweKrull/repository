package de.binaris.greetingcardsadmin.rest.dto;

import java.io.Serializable;

import de.binaris.greetingcardsadmin.model.Category;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable {

	private static final long serialVersionUID = 5555672719129213151L;

	private String textColor;
	private Short approved;
	private String description;
	private String categoryDescription;
	private String htmlKeyword;
	private Long categoryId;
	private String htmlTitle;
	private String htmlDescription;
	private String fontSize;
	private String commercial;
	private String textLink;
	private Long idCategory;

	public CategoryDTO() {
	}

	public CategoryDTO(final Category entity) {
		if (entity != null) {
			this.textColor = entity.getTextColor();
			this.approved = entity.getApproved();
			this.description = entity.getDescription();
			this.categoryDescription = entity.getCategoryDescription();
			this.htmlKeyword = entity.getHtmlKeyword();
			this.categoryId = entity.getCategoryId();
			this.htmlTitle = entity.getHtmlTitle();
			this.htmlDescription = entity.getHtmlDescription();
			this.fontSize = entity.getFontSize();
			this.commercial = entity.getCommercial();
			this.textLink = entity.getTextLink();
			this.idCategory = entity.getIdCategory();
		}
	}

	public Category fromDTO(Category entity, EntityManager em) {
		if (entity == null) {
			entity = new Category();
		}
		entity.setTextColor(this.textColor);
		entity.setApproved(this.approved);
		entity.setDescription(this.description);
		entity.setCategoryDescription(this.categoryDescription);
		entity.setHtmlKeyword(this.htmlKeyword);
		entity.setCategoryId(this.categoryId);
		entity.setHtmlTitle(this.htmlTitle);
		entity.setHtmlDescription(this.htmlDescription);
		entity.setFontSize(this.fontSize);
		entity.setCommercial(this.commercial);
		entity.setTextLink(this.textLink);
		entity = em.merge(entity);
		return entity;
	}

	public String getTextColor() {
		return this.textColor;
	}

	public void setTextColor(final String textColor) {
		this.textColor = textColor;
	}

	public Short getApproved() {
		return this.approved;
	}

	public void setApproved(final Short approved) {
		this.approved = approved;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getCategoryDescription() {
		return this.categoryDescription;
	}

	public void setCategoryDescription(final String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}

	public String getHtmlKeyword() {
		return this.htmlKeyword;
	}

	public void setHtmlKeyword(final String htmlKeyword) {
		this.htmlKeyword = htmlKeyword;
	}

	public Long getCategoryId() {
		return this.categoryId;
	}

	public void setCategoryId(final Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getHtmlTitle() {
		return this.htmlTitle;
	}

	public void setHtmlTitle(final String htmlTitle) {
		this.htmlTitle = htmlTitle;
	}

	public String getHtmlDescription() {
		return this.htmlDescription;
	}

	public void setHtmlDescription(final String htmlDescription) {
		this.htmlDescription = htmlDescription;
	}

	public String getFontSize() {
		return this.fontSize;
	}

	public void setFontSize(final String fontSize) {
		this.fontSize = fontSize;
	}

	public String getCommercial() {
		return this.commercial;
	}

	public void setCommercial(final String commercial) {
		this.commercial = commercial;
	}

	public String getTextLink() {
		return this.textLink;
	}

	public void setTextLink(final String textLink) {
		this.textLink = textLink;
	}

	public Long getIdCategory() {
		return this.idCategory;
	}

	public void setIdCategory(final Long idCategory) {
		this.idCategory = idCategory;
	}
}