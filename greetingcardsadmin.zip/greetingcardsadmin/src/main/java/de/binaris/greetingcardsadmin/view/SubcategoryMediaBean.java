package de.binaris.greetingcardsadmin.view;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateful;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import de.binaris.greetingcardsadmin.model.Image;
import de.binaris.greetingcardsadmin.model.SubcategoryMedia;

/**
 * Backing bean for SubcategoryMedia entities.
 * <p>
 * This class provides CRUD functionality for all SubcategoryMedia entities. It focuses
 * purely on Java EE 6 standards (e.g. <tt>&#64;ConversationScoped</tt> for
 * state management, <tt>PersistenceContext</tt> for persistence,
 * <tt>CriteriaBuilder</tt> for searches) rather than introducing a CRUD framework or
 * custom base class.
 */

@Named
@Stateful
@ConversationScoped
public class SubcategoryMediaBean implements Serializable
{

   private static final long serialVersionUID = 1L;

   /*
    * Support creating and retrieving SubcategoryMedia entities
    */

   private Long id;

   public Long getId()
   {
      return this.id;
   }

   public void setId(Long id)
   {
      this.id = id;
   }

   private SubcategoryMedia subcategoryMedia;

   public SubcategoryMedia getSubcategoryMedia()
   {
      return this.subcategoryMedia;
   }

   @Inject
   private Conversation conversation;

   @PersistenceContext(type = PersistenceContextType.EXTENDED)
   private EntityManager entityManager;

   public String create()
   {

      this.conversation.begin();
      return "create?faces-redirect=true";
   }

   public void retrieve()
   {

      if (FacesContext.getCurrentInstance().isPostback())
      {
         return;
      }

      if (this.conversation.isTransient())
      {
         this.conversation.begin();
      }

      if (this.id == null)
      {
         this.subcategoryMedia = this.example;
      }
      else
      {
         this.subcategoryMedia = findById(getId());
      }
   }

   public SubcategoryMedia findById(Long id)
   {

      return this.entityManager.find(SubcategoryMedia.class, id);
   }

   /*
    * Support updating and deleting SubcategoryMedia entities
    */

   public String update()
   {
      this.conversation.end();

      try
      {
         if (this.id == null)
         {
            this.entityManager.persist(this.subcategoryMedia);
            return "search?faces-redirect=true";
         }
         else
         {
            this.entityManager.merge(this.subcategoryMedia);
            return "view?faces-redirect=true&id=" + this.subcategoryMedia.getIdSubcategoryMedia();
         }
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   public String delete()
   {
      this.conversation.end();

      try
      {
         SubcategoryMedia deletableEntity = findById(getId());
         Image media = deletableEntity.getMedia();
         media.getSubcategoryMedia().remove(deletableEntity);
         deletableEntity.setMedia(null);
         this.entityManager.merge(media);
         this.entityManager.remove(deletableEntity);
         this.entityManager.flush();
         return "search?faces-redirect=true";
      }
      catch (Exception e)
      {
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(e.getMessage()));
         return null;
      }
   }

   /*
    * Support searching SubcategoryMedia entities with pagination
    */

   private int page;
   private long count;
   private List<SubcategoryMedia> pageItems;

   private SubcategoryMedia example = new SubcategoryMedia();

   public int getPage()
   {
      return this.page;
   }

   public void setPage(int page)
   {
      this.page = page;
   }

   public int getPageSize()
   {
      return 10;
   }

   public SubcategoryMedia getExample()
   {
      return this.example;
   }

   public void setExample(SubcategoryMedia example)
   {
      this.example = example;
   }

   public void search()
   {
      this.page = 0;
   }

   public void paginate()
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();

      // Populate this.count

      CriteriaQuery<Long> countCriteria = builder.createQuery(Long.class);
      Root<SubcategoryMedia> root = countCriteria.from(SubcategoryMedia.class);
      countCriteria = countCriteria.select(builder.count(root)).where(
            getSearchPredicates(root));
      this.count = this.entityManager.createQuery(countCriteria)
            .getSingleResult();

      // Populate this.pageItems

      CriteriaQuery<SubcategoryMedia> criteria = builder.createQuery(SubcategoryMedia.class);
      root = criteria.from(SubcategoryMedia.class);
      TypedQuery<SubcategoryMedia> query = this.entityManager.createQuery(criteria
            .select(root).where(getSearchPredicates(root)));
      query.setFirstResult(this.page * getPageSize()).setMaxResults(
            getPageSize());
      this.pageItems = query.getResultList();
   }

   private Predicate[] getSearchPredicates(Root<SubcategoryMedia> root)
   {

      CriteriaBuilder builder = this.entityManager.getCriteriaBuilder();
      List<Predicate> predicatesList = new ArrayList<Predicate>();

      Image media = this.example.getMedia();
      if (media != null)
      {
         predicatesList.add(builder.equal(root.get("media"), media));
      }
      Integer mediaTypeId = this.example.getMediaTypeId();
      if (mediaTypeId != null && mediaTypeId.intValue() != 0)
      {
         predicatesList.add(builder.equal(root.get("mediaTypeId"), mediaTypeId));
      }
      Short rfolge = this.example.getRfolge();
      if (rfolge != null && rfolge.intValue() != 0)
      {
         predicatesList.add(builder.equal(root.get("rfolge"), rfolge));
      }
      Integer subcategoryId = this.example.getSubcategoryId();
      if (subcategoryId != null && subcategoryId.intValue() != 0)
      {
         predicatesList.add(builder.equal(root.get("subcategoryId"), subcategoryId));
      }

      return predicatesList.toArray(new Predicate[predicatesList.size()]);
   }

   public List<SubcategoryMedia> getPageItems()
   {
      return this.pageItems;
   }

   public long getCount()
   {
      return this.count;
   }

   /*
    * Support listing and POSTing back SubcategoryMedia entities (e.g. from inside an
    * HtmlSelectOneMenu)
    */

   public List<SubcategoryMedia> getAll()
   {

      CriteriaQuery<SubcategoryMedia> criteria = this.entityManager
            .getCriteriaBuilder().createQuery(SubcategoryMedia.class);
      return this.entityManager.createQuery(
            criteria.select(criteria.from(SubcategoryMedia.class))).getResultList();
   }

   @Resource
   private SessionContext sessionContext;

   public Converter getConverter()
   {

      final SubcategoryMediaBean ejbProxy = this.sessionContext.getBusinessObject(SubcategoryMediaBean.class);

      return new Converter()
      {

         @Override
         public Object getAsObject(FacesContext context,
               UIComponent component, String value)
         {

            return ejbProxy.findById(Long.valueOf(value));
         }

         @Override
         public String getAsString(FacesContext context,
               UIComponent component, Object value)
         {

            if (value == null)
            {
               return "";
            }

            return String.valueOf(((SubcategoryMedia) value).getIdSubcategoryMedia());
         }
      };
   }

   /*
    * Support adding children to bidirectional, one-to-many tables
    */

   private SubcategoryMedia add = new SubcategoryMedia();

   public SubcategoryMedia getAdd()
   {
      return this.add;
   }

   public SubcategoryMedia getAdded()
   {
      SubcategoryMedia added = this.add;
      this.add = new SubcategoryMedia();
      return added;
   }
}