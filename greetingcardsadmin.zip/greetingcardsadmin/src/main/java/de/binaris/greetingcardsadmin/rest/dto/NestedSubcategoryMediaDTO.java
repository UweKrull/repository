package de.binaris.greetingcardsadmin.rest.dto;

import java.io.Serializable;

import de.binaris.greetingcardsadmin.model.SubcategoryMedia;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedSubcategoryMediaDTO implements Serializable {

	private static final long serialVersionUID = 1559291353957199375L;

	private Integer subcategoryId;
	private Integer mediaTypeId;
	private Short rfolge;
	private Long idSubcategoryMedia;

	public NestedSubcategoryMediaDTO() {
	}

	public NestedSubcategoryMediaDTO(final SubcategoryMedia entity) {
		if (entity != null) {
			this.subcategoryId = entity.getSubcategoryId();
			this.mediaTypeId = entity.getMediaTypeId();
			this.rfolge = entity.getRfolge();
			this.idSubcategoryMedia = entity.getIdSubcategoryMedia();
		}
	}

	public SubcategoryMedia fromDTO(SubcategoryMedia entity, EntityManager em) {
		if (entity == null) {
			entity = new SubcategoryMedia();
		}
		if (this.idSubcategoryMedia != null) {
			TypedQuery<SubcategoryMedia> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT s FROM SubcategoryMedia s WHERE s.idSubcategoryMedia = :entityId",
							SubcategoryMedia.class);
			findByIdQuery.setParameter("entityId", this.idSubcategoryMedia);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setSubcategoryId(this.subcategoryId);
		entity.setMediaTypeId(this.mediaTypeId);
		entity.setRfolge(this.rfolge);
		entity = em.merge(entity);
		return entity;
	}

	public Integer getSubcategoryId() {
		return this.subcategoryId;
	}

	public void setSubcategoryId(final Integer subcategoryId) {
		this.subcategoryId = subcategoryId;
	}

	public Integer getMediaTypeId() {
		return this.mediaTypeId;
	}

	public void setMediaTypeId(final Integer mediaTypeId) {
		this.mediaTypeId = mediaTypeId;
	}

	public Short getRfolge() {
		return this.rfolge;
	}

	public void setRfolge(final Short rfolge) {
		this.rfolge = rfolge;
	}

	public Long getIdSubcategoryMedia() {
		return this.idSubcategoryMedia;
	}

	public void setIdSubcategoryMedia(final Long idSubcategoryMedia) {
		this.idSubcategoryMedia = idSubcategoryMedia;
	}
}