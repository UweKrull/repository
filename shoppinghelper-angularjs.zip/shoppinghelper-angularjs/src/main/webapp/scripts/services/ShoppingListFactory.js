angular.module('shoppinghelperangularjs').factory('ShoppingListResource', function($resource){
    var resource = $resource('rest/shoppinglists/:ShoppingListId',{ShoppingListId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});