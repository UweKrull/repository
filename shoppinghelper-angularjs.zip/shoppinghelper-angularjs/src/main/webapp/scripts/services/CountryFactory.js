angular.module('shoppinghelperangularjs').factory('CountryResource', function($resource){
    var resource = $resource('rest/countrys/:CountryId',{CountryId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});