
angular.module('shoppinghelperangularjs').controller('NewPriceAtRetailerController', function ($scope, $location, locationParser, PriceAtRetailerResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.price = $scope.priceAtRetailer || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/PriceAtRetailers/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PriceAtRetailerResource.save($scope.priceAtRetailer, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/PriceAtRetailers");
    };
});