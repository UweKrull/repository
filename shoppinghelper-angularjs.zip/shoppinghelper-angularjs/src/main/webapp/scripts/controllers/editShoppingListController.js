

angular.module('shoppinghelperangularjs').controller('EditShoppingListController', function($scope, $routeParams, $location, ShoppingListResource , UserResource, SelectedItemResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.shoppingList = new ShoppingListResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName+' '+item.lastName
                    };
                    if($scope.shoppingList.user && item.id == $scope.shoppingList.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.shoppingList.user = wrappedObject;
                        self.original.user = $scope.shoppingList.user;
                    }
                    return labelObject;
                });
            });
            SelectedItemResource.queryAll(function(items) {
                $scope.selectedItemSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.shoppingList.selectedItem){
                        $.each($scope.shoppingList.selectedItem, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.selectedItemSelection.push(labelObject);
                                $scope.shoppingList.selectedItem.push(wrappedObject);
                            }
                        });
                        self.original.selectedItem = $scope.shoppingList.selectedItem;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/ShoppingLists");
        };
        ShoppingListResource.get({ShoppingListId:$routeParams.ShoppingListId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.shoppingList);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.shoppingList.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/ShoppingLists");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/ShoppingLists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.shoppingList.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.shoppingList.user = {};
            $scope.shoppingList.user.id = selection.value;
        }
    });
    $scope.selectedItemSelection = $scope.selectedItemSelection || [];
    $scope.$watch("selectedItemSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.shoppingList) {
            $scope.shoppingList.selectedItem = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.shoppingList.selectedItem.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});