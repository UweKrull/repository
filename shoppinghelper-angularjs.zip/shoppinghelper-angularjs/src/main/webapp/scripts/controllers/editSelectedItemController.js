

angular.module('shoppinghelperangularjs').controller('EditSelectedItemController', function($scope, $routeParams, $location, SelectedItemResource , ShoppingListResource, CategoryResource, ItemResource, PriceAtRetailerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.selectedItem = new SelectedItemResource(self.original);
            ShoppingListResource.queryAll(function(items) {
                $scope.shoppingListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.selectedItem.shoppingList && item.id == $scope.selectedItem.shoppingList.id) {
                        $scope.shoppingListSelection = labelObject;
                        $scope.selectedItem.shoppingList = wrappedObject;
                        self.original.shoppingList = $scope.selectedItem.shoppingList;
                    }
                    return labelObject;
                });
            });
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.selectedItem.category && item.id == $scope.selectedItem.category.id) {
                        $scope.categorySelection = labelObject;
                        $scope.selectedItem.category = wrappedObject;
                        self.original.category = $scope.selectedItem.category;
                    }
                    return labelObject;
                });
            });
            ItemResource.queryAll(function(items) {
                $scope.itemSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.selectedItem.item && item.id == $scope.selectedItem.item.id) {
                        $scope.itemSelection = labelObject;
                        $scope.selectedItem.item = wrappedObject;
                        self.original.item = $scope.selectedItem.item;
                    }
                    return labelObject;
                });
            });
            PriceAtRetailerResource.queryAll(function(items) {
                $scope.priceAtRetailerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.pricePerPackage
                    };
                    if($scope.selectedItem.item && item.id == $scope.selectedItem.priceAtRetailer.id) {
                        $scope.priceAtRetailerSelection = labelObject;
                        $scope.selectedItem.priceAtRetailer = wrappedObject;
                        self.original.priceAtRetailer = $scope.selectedItem.priceAtRetailer;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/SelectedItems");
        };
        SelectedItemResource.get({SelectedItemId:$routeParams.SelectedItemId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.selectedItem);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.selectedItem.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/SelectedItems");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/SelectedItems");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.selectedItem.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("shoppingListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedItem.shoppingList = {};
            $scope.selectedItem.shoppingList.id = selection.value;
        }
    });
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedItem.category = {};
            $scope.selectedItem.category.id = selection.value;
        }
    });
    $scope.$watch("itemSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedItem.item = {};
            $scope.selectedItem.item.id = selection.value;
        }
    });
    $scope.$watch("priceAtRetailerSelection", function(selection) {
    	if (typeof selection != 'undefined') {
    		$scope.selectedItem.priceAtRetailer = {};
    		$scope.selectedItem.priceAtRetailer.id = selection.value;
    	}
    });
    
    $scope.get();
});