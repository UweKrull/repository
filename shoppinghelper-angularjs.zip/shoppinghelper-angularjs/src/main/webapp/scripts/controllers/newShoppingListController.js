
angular.module('shoppinghelperangularjs').controller('NewShoppingListController', function ($scope, $location, locationParser, ShoppingListResource , UserResource, SelectedItemResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.shoppingList = $scope.shoppingList || {};
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName+' '+item.lastName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.shoppingList.user = {};
            $scope.shoppingList.user.id = selection.value;
        }
    });
    
    $scope.selectedItemList = SelectedItemResource.queryAll(function(items){
        $scope.selectedItemSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("selectedItemSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.shoppingList.selectedItem = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.shoppingList.selectedItem.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/ShoppingLists/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ShoppingListResource.save($scope.shoppingList, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/ShoppingLists");
    };
});