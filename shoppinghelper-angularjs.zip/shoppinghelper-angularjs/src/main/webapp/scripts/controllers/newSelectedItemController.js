
angular.module('shoppinghelperangularjs').controller('NewSelectedItemController', function ($scope, $location, locationParser, SelectedItemResource , ShoppingListResource, CategoryResource, ItemResource, PriceAtRetailerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.selectedItem = $scope.selectedItem || {};
    
    $scope.shoppingListList = ShoppingListResource.queryAll(function(items){
        $scope.shoppingListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("shoppingListSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedItem.shoppingList = {};
            $scope.selectedItem.shoppingList.id = selection.value;
        }
    });
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedItem.category = {};
            $scope.selectedItem.category.id = selection.value;
        }
    });
    
    $scope.itemList = ItemResource.queryAll(function(items){
        $scope.itemSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("itemSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedItem.item = {};
            $scope.selectedItem.item.id = selection.value;
        }
    });
    
    $scope.itemList = PriceAtRetailerResource.queryAll(function(items){
    	$scope.priceAtRetailerSelectionList = $.map(items, function(item) {
    		return ( {
    			value : item.id,
    			text : item.pricePerPackage
    		});
    	});
    });
    $scope.$watch("priceAtRetailerSelection", function(selection) {
    	if ( typeof selection != 'undefined') {
    		$scope.selectedItem.priceAtRetailer = {};
    		$scope.selectedItem.priceAtRetailer.id = selection.value;
    	}
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/SelectedItems/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SelectedItemResource.save($scope.selectedItem, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/SelectedItems");
    };
});