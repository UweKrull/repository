

angular.module('shoppinghelperangularjs').controller('EditPriceAtRetailerController', function($scope, $routeParams, $location, PriceAtRetailerResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.priceAtRetailer = new PriceAtRetailerResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/PriceAtRetailers");
        };
        PriceAtRetailerResource.get({PriceAtRetailerId:$routeParams.PriceAtRetailerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.priceAtRetailer);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.priceAtRetailer.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PriceAtRetailers");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PriceAtRetailers");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.price.$remove(successCallback, errorCallback);
    };
    
    $scope.get();
});