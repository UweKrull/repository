'use strict';

angular.module('shoppinghelperangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Items',{templateUrl:'views/Item/search.html',controller:'SearchItemController'})
      .when('/Items/new',{templateUrl:'views/Item/detail.html',controller:'NewItemController'})
      .when('/Items/edit/:ItemId',{templateUrl:'views/Item/detail.html',controller:'EditItemController'})
      .when('/PriceAtRetailers',{templateUrl:'views/PriceAtRetailer/search.html',controller:'SearchPriceAtRetailerController'})
      .when('/PriceAtRetailers/new',{templateUrl:'views/PriceAtRetailer/detail.html',controller:'NewPriceAtRetailerController'})
      .when('/PriceAtRetailers/edit/:PriceAtRetailerId',{templateUrl:'views/PriceAtRetailer/detail.html',controller:'EditPriceAtRetailerController'})
      .when('/SelectedItems',{templateUrl:'views/SelectedItem/search.html',controller:'SearchSelectedItemController'})
      .when('/SelectedItems/new',{templateUrl:'views/SelectedItem/detail.html',controller:'NewSelectedItemController'})
      .when('/SelectedItems/edit/:SelectedItemId',{templateUrl:'views/SelectedItem/detail.html',controller:'EditSelectedItemController'})
      .when('/ShoppingLists',{templateUrl:'views/ShoppingList/search.html',controller:'SearchShoppingListController'})
      .when('/ShoppingLists/new',{templateUrl:'views/ShoppingList/detail.html',controller:'NewShoppingListController'})
      .when('/ShoppingLists/edit/:ShoppingListId',{templateUrl:'views/ShoppingList/detail.html',controller:'EditShoppingListController'})
      .when('/Users',{templateUrl:'views/User/search.html',controller:'SearchUserController'})
      .when('/Users/new',{templateUrl:'views/User/detail.html',controller:'NewUserController'})
      .when('/Users/edit/:UserId',{templateUrl:'views/User/detail.html',controller:'EditUserController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
