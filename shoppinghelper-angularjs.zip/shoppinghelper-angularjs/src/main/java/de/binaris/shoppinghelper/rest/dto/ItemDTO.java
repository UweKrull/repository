package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;
import de.binaris.shoppinghelper.model.Item;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ItemDTO implements Serializable
{

   private Long id;
   private String description;
   private String name;
   private String brand;

   public ItemDTO()
   {
   }

   public ItemDTO(final Item entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.brand = entity.getBrand();
      }
   }

   public Item fromDTO(Item entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Item();
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setBrand(this.brand);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getBrand()
   {
      return this.brand;
   }

   public void setBrand(final String brand)
   {
      this.brand = brand;
   }
}