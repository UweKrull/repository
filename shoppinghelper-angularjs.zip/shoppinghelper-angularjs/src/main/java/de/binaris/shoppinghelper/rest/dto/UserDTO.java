package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;

import de.binaris.shoppinghelper.model.User;

import javax.persistence.EntityManager;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;

import de.binaris.shoppinghelper.model.ShoppingList;
import de.binaris.shoppinghelper.rest.dto.AddressDTO;
import de.binaris.shoppinghelper.rest.dto.NestedShoppingListDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserDTO implements Serializable
{

   private String middleName;
   private Date dateOfBirth;
   private String lastName;
   private String phone;
   private String password;
   private Long id;
   private Set<NestedShoppingListDTO> shoppingList = new HashSet<NestedShoppingListDTO>();
   private AddressDTO address;
   private String email;
   private String login;
   private String firstName;

   public UserDTO()
   {
   }

   public UserDTO(final User entity)
   {
      if (entity != null)
      {
         this.middleName = entity.getMiddleName();
         this.dateOfBirth = entity.getDateOfBirth();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         this.password = entity.getPassword();
         this.id = entity.getId();
         Iterator<ShoppingList> iterShoppingList = entity.getShoppingList()
               .iterator();
         for (; iterShoppingList.hasNext();)
         {
            ShoppingList element = iterShoppingList.next();
            this.shoppingList.add(new NestedShoppingListDTO(element));
         }
         this.address = new AddressDTO(entity.getAddress());
         this.email = entity.getEmail();
         this.login = entity.getLogin();
         this.firstName = entity.getFirstName();
      }
   }

   public User fromDTO(User entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new User();
      }
      entity.setMiddleName(this.middleName);
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      entity.setPassword(this.password);
      Iterator<ShoppingList> iterShoppingList = entity.getShoppingList()
            .iterator();
      for (; iterShoppingList.hasNext();)
      {
         boolean found = false;
         ShoppingList shoppingList = iterShoppingList.next();
         Iterator<NestedShoppingListDTO> iterDtoShoppingList = this
               .getShoppingList().iterator();
         for (; iterDtoShoppingList.hasNext();)
         {
            NestedShoppingListDTO dtoShoppingList = iterDtoShoppingList
                  .next();
            if (dtoShoppingList.getId().equals(shoppingList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterShoppingList.remove();
         }
      }
      Iterator<NestedShoppingListDTO> iterDtoShoppingList = this
            .getShoppingList().iterator();
      for (; iterDtoShoppingList.hasNext();)
      {
         boolean found = false;
         NestedShoppingListDTO dtoShoppingList = iterDtoShoppingList.next();
         iterShoppingList = entity.getShoppingList().iterator();
         for (; iterShoppingList.hasNext();)
         {
            ShoppingList shoppingList = iterShoppingList.next();
            if (dtoShoppingList.getId().equals(shoppingList.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<ShoppingList> resultIter = em
                  .createQuery("SELECT DISTINCT s FROM ShoppingList s",
                        ShoppingList.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               ShoppingList result = resultIter.next();
               if (result.getId().equals(dtoShoppingList.getId()))
               {
                  entity.getShoppingList().add(result);
                  break;
               }
            }
         }
      }
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setEmail(this.email);
      entity.setLogin(this.login);
      entity.setFirstName(this.firstName);
      entity = em.merge(entity);
      return entity;
   }

   public String getMiddleName()
   {
      return this.middleName;
   }

   public void setMiddleName(final String middleName)
   {
      this.middleName = middleName;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public Set<NestedShoppingListDTO> getShoppingList()
   {
      return this.shoppingList;
   }

   public void setShoppingList(final Set<NestedShoppingListDTO> shoppingList)
   {
      this.shoppingList = shoppingList;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }
}