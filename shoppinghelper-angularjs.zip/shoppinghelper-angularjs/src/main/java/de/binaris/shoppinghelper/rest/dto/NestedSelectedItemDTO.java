package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;
import de.binaris.shoppinghelper.model.SelectedItem;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedSelectedItemDTO implements Serializable
{

   private Long id;
   private String title;

   public NestedSelectedItemDTO()
   {
   }

   public NestedSelectedItemDTO(final SelectedItem entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
      }
   }

   public SelectedItem fromDTO(SelectedItem entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new SelectedItem();
      }
      if (this.id != null)
      {
         TypedQuery<SelectedItem> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT s FROM SelectedItem s WHERE s.id = :entityId",
                     SelectedItem.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
}