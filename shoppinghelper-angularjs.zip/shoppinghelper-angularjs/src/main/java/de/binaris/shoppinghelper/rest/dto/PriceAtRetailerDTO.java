package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

import de.binaris.shoppinghelper.model.PriceAtRetailer;

@XmlRootElement
public class PriceAtRetailerDTO implements Serializable
{

   private Long id;
   private String pricePerPackage;

   public PriceAtRetailerDTO()
   {
   }

   public PriceAtRetailerDTO(final PriceAtRetailer entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.pricePerPackage = entity.getPricePerPackage();
      }
   }

   public PriceAtRetailer fromDTO(PriceAtRetailer entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new PriceAtRetailer();
      }
      entity.setPricePerPackage(this.pricePerPackage);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getPricePerPackage()
   {
      return this.pricePerPackage;
   }

   public void setPricePerPackage(final String pricePerPackage)
   {
      this.pricePerPackage = pricePerPackage;
   }
}