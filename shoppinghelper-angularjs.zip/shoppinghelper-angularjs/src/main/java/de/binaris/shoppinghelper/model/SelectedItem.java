package de.binaris.shoppinghelper.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "selected_item")
public class SelectedItem implements Serializable {

	private static final long serialVersionUID = 7975171029657126323L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_selected_item")
	@SequenceGenerator(name = "my_entity_seq_gen_selected_item", sequenceName = "sequence_selected_item", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private ShoppingList shoppingList;
	
	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String title;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Category category;
	
	@ManyToOne
	private Item item;
	
	@ManyToOne
	private PriceAtRetailer priceAtRetailer;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ShoppingList getShoppingList() {
		return shoppingList;
	}

	public void setShoppingList(ShoppingList shoppingList) {
		this.shoppingList = shoppingList;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public PriceAtRetailer getPriceAtRetailer() {
		return priceAtRetailer;
	}
	
	public void setPriceAtRetailer(PriceAtRetailer priceAtRetailer) {
		this.priceAtRetailer = priceAtRetailer;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof SelectedItem)) {
			return false;
		}
		SelectedItem castOther = (SelectedItem) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		if (title.length() > 20) {
			sb.append(title.substring(0, 20));
			sb.append("...");
		} else {
			sb.append(title);
		}
		sb.append(category.toString());
		return sb.toString();
	}
}
