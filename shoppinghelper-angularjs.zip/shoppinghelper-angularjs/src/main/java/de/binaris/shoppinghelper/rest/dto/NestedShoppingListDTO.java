package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;
import de.binaris.shoppinghelper.model.ShoppingList;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedShoppingListDTO implements Serializable
{

   private Long id;
   private String title;

   public NestedShoppingListDTO()
   {
   }

   public NestedShoppingListDTO(final ShoppingList entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
      }
   }

   public ShoppingList fromDTO(ShoppingList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ShoppingList();
      }
      if (this.id != null)
      {
         TypedQuery<ShoppingList> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT s FROM ShoppingList s WHERE s.id = :entityId",
                     ShoppingList.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
}