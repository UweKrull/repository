package de.binaris.shoppinghelper.rest.dto;

import java.io.Serializable;

import de.binaris.shoppinghelper.model.ShoppingList;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.shoppinghelper.model.SelectedItem;
import de.binaris.shoppinghelper.rest.dto.NestedSelectedItemDTO;
import de.binaris.shoppinghelper.rest.dto.NestedUserDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ShoppingListDTO implements Serializable
{

   private Long id;
   private String title;
   private Set<NestedSelectedItemDTO> selectedItem = new HashSet<NestedSelectedItemDTO>();
   private NestedUserDTO user;

   public ShoppingListDTO()
   {
   }

   public ShoppingListDTO(final ShoppingList entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         Iterator<SelectedItem> iterSelectedItem = entity.getSelectedItem()
               .iterator();
         for (; iterSelectedItem.hasNext();)
         {
            SelectedItem element = iterSelectedItem.next();
            this.selectedItem.add(new NestedSelectedItemDTO(element));
         }
         this.user = new NestedUserDTO(entity.getUser());
      }
   }

   public ShoppingList fromDTO(ShoppingList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new ShoppingList();
      }
      entity.setTitle(this.title);
      Iterator<SelectedItem> iterSelectedItem = entity.getSelectedItem()
            .iterator();
      for (; iterSelectedItem.hasNext();)
      {
         boolean found = false;
         SelectedItem selectedItem = iterSelectedItem.next();
         Iterator<NestedSelectedItemDTO> iterDtoSelectedItem = this
               .getSelectedItem().iterator();
         for (; iterDtoSelectedItem.hasNext();)
         {
            NestedSelectedItemDTO dtoSelectedItem = iterDtoSelectedItem
                  .next();
            if (dtoSelectedItem.getId().equals(selectedItem.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterSelectedItem.remove();
         }
      }
      Iterator<NestedSelectedItemDTO> iterDtoSelectedItem = this
            .getSelectedItem().iterator();
      for (; iterDtoSelectedItem.hasNext();)
      {
         boolean found = false;
         NestedSelectedItemDTO dtoSelectedItem = iterDtoSelectedItem.next();
         iterSelectedItem = entity.getSelectedItem().iterator();
         for (; iterSelectedItem.hasNext();)
         {
            SelectedItem selectedItem = iterSelectedItem.next();
            if (dtoSelectedItem.getId().equals(selectedItem.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<SelectedItem> resultIter = em
                  .createQuery("SELECT DISTINCT s FROM SelectedItem s",
                        SelectedItem.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               SelectedItem result = resultIter.next();
               if (result.getId().equals(dtoSelectedItem.getId()))
               {
                  entity.getSelectedItem().add(result);
                  break;
               }
            }
         }
      }
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public Set<NestedSelectedItemDTO> getSelectedItem()
   {
      return this.selectedItem;
   }

   public void setSelectedItem(final Set<NestedSelectedItemDTO> selectedItem)
   {
      this.selectedItem = selectedItem;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }
}