package de.binaris.library.rest.dto;

import java.io.Serializable;

import de.binaris.library.model.PreviewItem;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedPreviewItemDTO implements Serializable {

	private static final long serialVersionUID = 7775678910111213170L;

	private Long id;
	private float pricePerItem;
	private String previewPath;
	private String description;
	private String isbn;
	private String mhid;
	private String name;

	public NestedPreviewItemDTO() {
	}

	public NestedPreviewItemDTO(final PreviewItem entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.pricePerItem = entity.getPricePerItem();
			this.previewPath = entity.getPreviewPath();
			this.description = entity.getDescription();
			this.isbn = entity.getIsbn();
			this.mhid = entity.getMhid();
			this.name = entity.getName();
		}
	}

	public PreviewItem fromDTO(PreviewItem entity, EntityManager em) {
		if (entity == null) {
			entity = new PreviewItem();
		}
		if (this.id != null) {
			TypedQuery<PreviewItem> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT p FROM PreviewItem p WHERE p.id = :entityId",
							PreviewItem.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setPricePerItem(this.pricePerItem);
		entity.setPreviewPath(this.previewPath);
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity.setIsbn(this.isbn);
		entity.setMhid(this.mhid);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public float getPricePerItem() {
		return this.pricePerItem;
	}

	public void setPricePerItem(final float pricePerItem) {
		this.pricePerItem = pricePerItem;
	}

	public String getPreviewPath() {
		return this.previewPath;
	}

	public void setPreviewPath(final String previewPath) {
		this.previewPath = previewPath;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public void setIsbn(final String isbn) {
		this.isbn = isbn;
	}
	
	public String getMhid() {
		return this.mhid;
	}
	
	public void setMhid(final String mhid) {
		this.mhid = mhid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}
}