package de.binaris.library.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;

import de.binaris.library.model.Customer;
import de.binaris.library.model.LibraryPurchase;
import de.binaris.library.rest.dto.AddressDTO;
import de.binaris.library.rest.dto.NestedLibraryPurchaseDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerDTO implements Serializable {
	
	private static final long serialVersionUID = 7235678910111213152L;

	private Date dateOfBirth;
	private String lastName;
	private String phone;
	private Set<NestedLibraryPurchaseDTO> libraryPurchase = new HashSet<NestedLibraryPurchaseDTO>();
	private String password;
	private Long id;
	private String libraryCardCode;
	private String createdBy;
	private AddressDTO address;
	private String email;
	private Date lastChangeDate;
	private String login;
	private String firstName;

	public CustomerDTO() {
	}

	public CustomerDTO(final Customer entity) {
		if (entity != null) {
			this.dateOfBirth = entity.getDateOfBirth();
			this.lastName = entity.getLastName();
			this.phone = entity.getPhone();
			Iterator<LibraryPurchase> iterLibraryPurchase = entity
					.getLibraryPurchase().iterator();
			for (; iterLibraryPurchase.hasNext();) {
				LibraryPurchase element = iterLibraryPurchase.next();
				this.libraryPurchase.add(new NestedLibraryPurchaseDTO(element));
			}
			this.password = entity.getPassword();
			this.id = entity.getId();
			this.libraryCardCode = entity.getLibraryCardCode();
			this.createdBy = entity.getCreatedBy();
			this.address = new AddressDTO(entity.getAddress());
			this.email = entity.getEmail();
			this.lastChangeDate = entity.getLastChangeDate();
			this.login = entity.getLogin();
			this.firstName = entity.getFirstName();
		}
	}

	public Customer fromDTO(Customer entity, EntityManager em) {
		if (entity == null) {
			entity = new Customer();
		}
		entity.setDateOfBirth(this.dateOfBirth);
		entity.setLastName(this.lastName);
		entity.setPhone(this.phone);
		Iterator<LibraryPurchase> iterLibraryPurchase = entity
				.getLibraryPurchase().iterator();
		for (; iterLibraryPurchase.hasNext();) {
			boolean found = false;
			LibraryPurchase libraryPurchase = iterLibraryPurchase.next();
			Iterator<NestedLibraryPurchaseDTO> iterDtoLibraryPurchase = this
					.getLibraryPurchase().iterator();
			for (; iterDtoLibraryPurchase.hasNext();) {
				NestedLibraryPurchaseDTO dtoLibraryPurchase = iterDtoLibraryPurchase
						.next();
				if (dtoLibraryPurchase.getId().equals(libraryPurchase.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterLibraryPurchase.remove();
			}
		}
		Iterator<NestedLibraryPurchaseDTO> iterDtoLibraryPurchase = this
				.getLibraryPurchase().iterator();
		for (; iterDtoLibraryPurchase.hasNext();) {
			boolean found = false;
			NestedLibraryPurchaseDTO dtoLibraryPurchase = iterDtoLibraryPurchase
					.next();
			iterLibraryPurchase = entity.getLibraryPurchase().iterator();
			for (; iterLibraryPurchase.hasNext();) {
				LibraryPurchase libraryPurchase = iterLibraryPurchase.next();
				if (dtoLibraryPurchase.getId().equals(libraryPurchase.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<LibraryPurchase> resultIter = em
						.createQuery(
								"SELECT DISTINCT l FROM LibraryPurchase l",
								LibraryPurchase.class).getResultList()
						.iterator();
				for (; resultIter.hasNext();) {
					LibraryPurchase result = resultIter.next();
					if (result.getId().equals(dtoLibraryPurchase.getId())) {
						entity.getLibraryPurchase().add(result);
						break;
					}
				}
			}
		}
		entity.setPassword(this.password);
		entity.setLibraryCardCode(this.libraryCardCode);
		entity.setCreatedBy(this.createdBy);
		if (this.address != null) {
			entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
		}
		entity.setEmail(this.email);
		entity.setLastChangeDate(this.lastChangeDate);
		entity.setLogin(this.login);
		entity.setFirstName(this.firstName);
		entity = em.merge(entity);
		return entity;
	}

	public Date getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(final Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(final String phone) {
		this.phone = phone;
	}

	public Set<NestedLibraryPurchaseDTO> getLibraryPurchase() {
		return this.libraryPurchase;
	}

	public void setLibraryPurchase(
			final Set<NestedLibraryPurchaseDTO> libraryPurchase) {
		this.libraryPurchase = libraryPurchase;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(final String password) {
		this.password = password;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getLibraryCardCode() {
		return this.libraryCardCode;
	}

	public void setLibraryCardCode(final String libraryCardCode) {
		this.libraryCardCode = libraryCardCode;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(final String createdBy) {
		this.createdBy = createdBy;
	}

	public AddressDTO getAddress() {
		return this.address;
	}

	public void setAddress(final AddressDTO address) {
		this.address = address;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public Date getLastChangeDate() {
		return this.lastChangeDate;
	}

	public void setLastChangeDate(final Date lastChangeDate) {
		this.lastChangeDate = lastChangeDate;
	}

	public String getLogin() {
		return this.login;
	}

	public void setLogin(final String login) {
		this.login = login;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}
}