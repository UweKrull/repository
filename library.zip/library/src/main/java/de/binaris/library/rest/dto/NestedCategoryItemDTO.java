package de.binaris.library.rest.dto;

import java.io.Serializable;

import de.binaris.library.model.CategoryItem;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedCategoryItemDTO implements Serializable {

	private static final long serialVersionUID = 7175678910111213191L;

	private Long id;
	private String description;
	private String name;

	public NestedCategoryItemDTO() {
	}

	public NestedCategoryItemDTO(final CategoryItem entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.description = entity.getDescription();
			this.name = entity.getName();
		}
	}

	public CategoryItem fromDTO(CategoryItem entity, EntityManager em) {
		if (entity == null) {
			entity = new CategoryItem();
		}
		if (this.id != null) {
			TypedQuery<CategoryItem> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT c FROM CategoryItem c WHERE c.id = :entityId",
							CategoryItem.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}
}