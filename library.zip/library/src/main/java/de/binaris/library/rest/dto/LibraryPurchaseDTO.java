package de.binaris.library.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.library.model.LibraryPurchase;
import de.binaris.library.model.PurchaseLine;
import de.binaris.library.rest.dto.NestedCountryDTO;
import de.binaris.library.rest.dto.NestedCustomerDTO;
import de.binaris.library.rest.dto.NestedPurchaseLineDTO;

import java.util.Iterator;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LibraryPurchaseDTO implements Serializable {

	private static final long serialVersionUID = 7117712710111753397L;

	private Long id;
	private Set<NestedPurchaseLineDTO> purchaseLines = new HashSet<NestedPurchaseLineDTO>();
	private Date libraryDate;
	private NestedCustomerDTO customer;
	private Date estimatedReturnDate;
	private NestedCountryDTO country;

	public LibraryPurchaseDTO() {
	}

	public LibraryPurchaseDTO(final LibraryPurchase entity) {
		if (entity != null) {
			this.id = entity.getId();
			Iterator<PurchaseLine> iterPurchaseLines = entity
					.getPurchaseLines().iterator();
			for (; iterPurchaseLines.hasNext();) {
				PurchaseLine element = iterPurchaseLines.next();
				this.purchaseLines.add(new NestedPurchaseLineDTO(element));
			}
			this.libraryDate = entity.getLibraryDate();
			this.customer = new NestedCustomerDTO(entity.getCustomer());
			this.estimatedReturnDate = entity.getEstimatedReturnDate();
			this.country = new NestedCountryDTO(entity.getCountry());
		}
	}

	public LibraryPurchase fromDTO(LibraryPurchase entity, EntityManager em) {
		if (entity == null) {
			entity = new LibraryPurchase();
		}
		Iterator<PurchaseLine> iterPurchaseLines = entity.getPurchaseLines()
				.iterator();
		for (; iterPurchaseLines.hasNext();) {
			boolean found = false;
			PurchaseLine purchaseLine = iterPurchaseLines.next();
			Iterator<NestedPurchaseLineDTO> iterDtoPurchaseLines = this
					.getPurchaseLines().iterator();
			for (; iterDtoPurchaseLines.hasNext();) {
				NestedPurchaseLineDTO dtoPurchaseLine = iterDtoPurchaseLines
						.next();
				if (dtoPurchaseLine.getId().equals(purchaseLine.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterPurchaseLines.remove();
			}
		}
		Iterator<NestedPurchaseLineDTO> iterDtoPurchaseLines = this
				.getPurchaseLines().iterator();
		for (; iterDtoPurchaseLines.hasNext();) {
			boolean found = false;
			NestedPurchaseLineDTO dtoPurchaseLine = iterDtoPurchaseLines.next();
			iterPurchaseLines = entity.getPurchaseLines().iterator();
			for (; iterPurchaseLines.hasNext();) {
				PurchaseLine purchaseLine = iterPurchaseLines.next();
				if (dtoPurchaseLine.getId().equals(purchaseLine.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<PurchaseLine> resultIter = em
						.createQuery("SELECT DISTINCT p FROM PurchaseLine p",
								PurchaseLine.class).getResultList().iterator();
				for (; resultIter.hasNext();) {
					PurchaseLine result = resultIter.next();
					if (result.getId().equals(dtoPurchaseLine.getId())) {
						entity.getPurchaseLines().add(result);
						break;
					}
				}
			}
		}
		entity.setLibraryDate(this.libraryDate);
		if (this.customer != null) {
			entity.setCustomer(this.customer.fromDTO(entity.getCustomer(), em));
		}
		entity.setEstimatedReturnDate(this.estimatedReturnDate);
		if (this.country != null) {
			entity.setCountry(this.country.fromDTO(entity.getCountry(), em));
		}
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Set<NestedPurchaseLineDTO> getPurchaseLines() {
		return this.purchaseLines;
	}

	public void setPurchaseLines(final Set<NestedPurchaseLineDTO> purchaseLines) {
		this.purchaseLines = purchaseLines;
	}

	public Date getLibraryDate() {
		return this.libraryDate;
	}

	public void setLibraryDate(final Date libraryDate) {
		this.libraryDate = libraryDate;
	}

	public NestedCustomerDTO getCustomer() {
		return this.customer;
	}

	public void setCustomer(final NestedCustomerDTO customer) {
		this.customer = customer;
	}

	public Date getEstimatedReturnDate() {
		return this.estimatedReturnDate;
	}

	public void setEstimatedReturnDate(final Date estimatedReturnDate) {
		this.estimatedReturnDate = estimatedReturnDate;
	}

	public NestedCountryDTO getCountry() {
		return this.country;
	}

	public void setCountry(final NestedCountryDTO country) {
		this.country = country;
	}
}