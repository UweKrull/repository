﻿-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server Version:               5.1.53-community - MySQL Community Server (GPL)
-- Server Betriebssystem:        Win64
-- HeidiSQL Version:             8.0.0.4396
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Datenbank Struktur für bookstore
CREATE DATABASE IF NOT EXISTS `bookstore` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `bookstore`;


-- Exportiere Struktur von Tabelle bookstore.category
CREATE TABLE IF NOT EXISTS `category` (
  `id` bigint(20) NOT NULL,
  `description` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.category: ~1 rows (ungefähr)
DELETE FROM `category`;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`id`, `description`, `name`) VALUES
	(1, 'JEE 6 + 7 Examples and Documentations', 'JEE Examples + Documentations');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.country
CREATE TABLE IF NOT EXISTS `country` (
  `id` bigint(20) NOT NULL,
  `iso3` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `iso_code` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `numcode` varchar(3) COLLATE utf8_unicode_ci NOT NULL,
  `printable_name` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.country: ~2 rows (ungefähr)
DELETE FROM `country`;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` (`id`, `iso3`, `iso_code`, `name`, `numcode`, `printable_name`) VALUES
	(1, 'USA', 'US', 'United States Of America', '840', 'United States Of America'),
	(2, 'DEU', 'DE', 'Germany', '276', 'Germany');
/*!40000 ALTER TABLE `country` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.customer
CREATE TABLE IF NOT EXISTS `customer` (
  `id` bigint(20) NOT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_of_birth` date NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `firstName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lastName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `country_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_e02yd4eb7yu7l0il18e5tedru` (`country_id`),
  CONSTRAINT `FK_e02yd4eb7yu7l0il18e5tedru` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.customer: ~1 rows (ungefähr)
DELETE FROM `customer`;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`id`, `city`, `state`, `street1`, `street2`, `zip_code`, `date_of_birth`, `email`, `firstName`, `lastName`, `login`, `password`, `phone`, `country_id`) VALUES
	(1, 'Phoenix', 'Arizona', '98th, Maple Ave', '', '63544', '1979-04-01', 'bananajoe@bananajoe.com', 'Joe', 'Banana', 'bananajoe', 'bananarama', '02211123456789', 1);
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.item
CREATE TABLE IF NOT EXISTS `item` (
  `id` bigint(20) NOT NULL,
  `description` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `image_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `unit_cost` float NOT NULL,
  `product_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_i4xotma76q3ob250o90k3xgym` (`product_id`),
  CONSTRAINT `FK_i4xotma76q3ob250o90k3xgym` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.item: ~2 rows (ungefähr)
DELETE FROM `item`;
/*!40000 ALTER TABLE `item` DISABLE KEYS */;
INSERT INTO `item` (`id`, `description`, `image_path`, `name`, `unit_cost`, `product_id`) VALUES
	(1, 'greetingcards example project zip, greetingcards.pdf, maven project', 'http://localhost:8080/bookstore/greetingcards.pdf', 'greetingcards example project', 0, 1),
	(2, 'educationorganizer example project zip, educationorganizer.pdf, maven project', 'http://localhost:8080/bookstore/educationorganizer.pdf', 'eventorganizer example project', 0, 2);
/*!40000 ALTER TABLE `item` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.order_line
CREATE TABLE IF NOT EXISTS `order_line` (
  `id` bigint(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `item_id` bigint(20) NOT NULL,
  `purchaseOrder_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_dviu32bkoqmni5ftb7bynjgml` (`item_id`),
  KEY `FK_t560c97yk1h409p56wylen51` (`purchaseOrder_id`),
  CONSTRAINT `FK_dviu32bkoqmni5ftb7bynjgml` FOREIGN KEY (`item_id`) REFERENCES `item` (`id`),
  CONSTRAINT `FK_t560c97yk1h409p56wylen51` FOREIGN KEY (`purchaseOrder_id`) REFERENCES `purchase_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.order_line: ~2 rows (ungefähr)
DELETE FROM `order_line`;
/*!40000 ALTER TABLE `order_line` DISABLE KEYS */;
INSERT INTO `order_line` (`id`, `quantity`, `item_id`, `purchaseOrder_id`) VALUES
	(1, 2, 1, 1),
	(2, 1, 2, 2);
/*!40000 ALTER TABLE `order_line` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.product
CREATE TABLE IF NOT EXISTS `product` (
  `id` bigint(20) NOT NULL,
  `description` varchar(3000) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_b7afq93qsn7aoydaftixggf14` (`category_id`),
  CONSTRAINT `FK_b7afq93qsn7aoydaftixggf14` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.product: ~2 rows (ungefähr)
DELETE FROM `product`;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` (`id`, `description`, `name`, `category_id`) VALUES
	(1, 'JEE 6 + 7 Example, REST, Bootstrap, Backbone, jQuery, Underscore, QUnit, Selenium, JPA 2.0, EJB 3.1, JBoss EAP 6.3, WildFly 8.2, greetingcards.war', 'greetingcards.pdf', 1),
	(2, 'JEE 6 + 7 Example, REST, Angular, Backbone, jQuery, Underscore, Bootstrap, JPA 2.1, EJB 3.2, JBoss EAP 6.3, WildFly 8.2, educationorganizer.war', 'educationorganizer.pdf', 1);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.purchase_order
CREATE TABLE IF NOT EXISTS `purchase_order` (
  `id` bigint(20) NOT NULL,
  `credit_card_expiry_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `credit_card_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `credit_card_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `street2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `discount` float DEFAULT NULL,
  `discount_rate` float DEFAULT NULL,
  `order_date` date NOT NULL,
  `total` float DEFAULT NULL,
  `totalWithVat` float DEFAULT NULL,
  `totalWithoutVat` float DEFAULT NULL,
  `vat` float DEFAULT NULL,
  `vat_rate` float DEFAULT NULL,
  `customer_id` bigint(20) NOT NULL,
  `country_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_c1dxn8aye2kau4m0bevoes052` (`customer_id`),
  KEY `FK_3o1wockcqqdtcng1uyjf32dij` (`country_id`),
  CONSTRAINT `FK_3o1wockcqqdtcng1uyjf32dij` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`),
  CONSTRAINT `FK_c1dxn8aye2kau4m0bevoes052` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.purchase_order: ~2 rows (ungefähr)
DELETE FROM `purchase_order`;
/*!40000 ALTER TABLE `purchase_order` DISABLE KEYS */;
INSERT INTO `purchase_order` (`id`, `credit_card_expiry_date`, `credit_card_number`, `credit_card_type`, `city`, `state`, `street1`, `street2`, `zip_code`, `discount`, `discount_rate`, `order_date`, `total`, `totalWithVat`, `totalWithoutVat`, `vat`, `vat_rate`, `customer_id`, `country_id`) VALUES
	(1, '30.11.2020', '12345678910', 'VISA', 'Duisburg', 'NRW', 'Düsseldorfer Landstr. 350', '', '47259', 0, 0, '2015-06-12', 0, 0, 0, 0, 19, 1, 2),
	(2, '31.08.2016', '12345678912', 'VISA', 'Duisburg', 'NRW', 'Düsseldorfer Landstr. 350', '', '47259', 0, 0, '2015-06-14', 0, 0, 0, 0, 19, 1, 2);
/*!40000 ALTER TABLE `purchase_order` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.sequence_category
CREATE TABLE IF NOT EXISTS `sequence_category` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.sequence_category: ~1 rows (ungefähr)
DELETE FROM `sequence_category`;
/*!40000 ALTER TABLE `sequence_category` DISABLE KEYS */;
INSERT INTO `sequence_category` (`next_val`) VALUES
	(2);
/*!40000 ALTER TABLE `sequence_category` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.sequence_country
CREATE TABLE IF NOT EXISTS `sequence_country` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.sequence_country: ~1 rows (ungefähr)
DELETE FROM `sequence_country`;
/*!40000 ALTER TABLE `sequence_country` DISABLE KEYS */;
INSERT INTO `sequence_country` (`next_val`) VALUES
	(3);
/*!40000 ALTER TABLE `sequence_country` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.sequence_customer
CREATE TABLE IF NOT EXISTS `sequence_customer` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.sequence_customer: ~1 rows (ungefähr)
DELETE FROM `sequence_customer`;
/*!40000 ALTER TABLE `sequence_customer` DISABLE KEYS */;
INSERT INTO `sequence_customer` (`next_val`) VALUES
	(2);
/*!40000 ALTER TABLE `sequence_customer` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.sequence_item
CREATE TABLE IF NOT EXISTS `sequence_item` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.sequence_item: ~1 rows (ungefähr)
DELETE FROM `sequence_item`;
/*!40000 ALTER TABLE `sequence_item` DISABLE KEYS */;
INSERT INTO `sequence_item` (`next_val`) VALUES
	(3);
/*!40000 ALTER TABLE `sequence_item` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.sequence_order_line
CREATE TABLE IF NOT EXISTS `sequence_order_line` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.sequence_order_line: ~1 rows (ungefähr)
DELETE FROM `sequence_order_line`;
/*!40000 ALTER TABLE `sequence_order_line` DISABLE KEYS */;
INSERT INTO `sequence_order_line` (`next_val`) VALUES
	(3);
/*!40000 ALTER TABLE `sequence_order_line` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.sequence_product
CREATE TABLE IF NOT EXISTS `sequence_product` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.sequence_product: ~1 rows (ungefähr)
DELETE FROM `sequence_product`;
/*!40000 ALTER TABLE `sequence_product` DISABLE KEYS */;
INSERT INTO `sequence_product` (`next_val`) VALUES
	(3);
/*!40000 ALTER TABLE `sequence_product` ENABLE KEYS */;


-- Exportiere Struktur von Tabelle bookstore.sequence_purchase_order
CREATE TABLE IF NOT EXISTS `sequence_purchase_order` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Exportiere Daten aus Tabelle bookstore.sequence_purchase_order: ~1 rows (ungefähr)
DELETE FROM `sequence_purchase_order`;
/*!40000 ALTER TABLE `sequence_purchase_order` DISABLE KEYS */;
INSERT INTO `sequence_purchase_order` (`next_val`) VALUES
	(3);
/*!40000 ALTER TABLE `sequence_purchase_order` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
