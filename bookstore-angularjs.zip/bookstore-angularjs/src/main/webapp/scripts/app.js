'use strict';

angular.module('bookstore-angularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Customers',{templateUrl:'views/Customer/search.html',controller:'SearchCustomerController'})
      .when('/Customers/new',{templateUrl:'views/Customer/detail.html',controller:'NewCustomerController'})
      .when('/Customers/edit/:CustomerId',{templateUrl:'views/Customer/detail.html',controller:'EditCustomerController'})
      .when('/Items',{templateUrl:'views/Item/search.html',controller:'SearchItemController'})
      .when('/Items/new',{templateUrl:'views/Item/detail.html',controller:'NewItemController'})
      .when('/Items/edit/:ItemId',{templateUrl:'views/Item/detail.html',controller:'EditItemController'})
      .when('/OrderLines',{templateUrl:'views/OrderLine/search.html',controller:'SearchOrderLineController'})
      .when('/OrderLines/new',{templateUrl:'views/OrderLine/detail.html',controller:'NewOrderLineController'})
      .when('/OrderLines/edit/:OrderLineId',{templateUrl:'views/OrderLine/detail.html',controller:'EditOrderLineController'})
      .when('/Products',{templateUrl:'views/Product/search.html',controller:'SearchProductController'})
      .when('/Products/new',{templateUrl:'views/Product/detail.html',controller:'NewProductController'})
      .when('/Products/edit/:ProductId',{templateUrl:'views/Product/detail.html',controller:'EditProductController'})
      .when('/PurchaseOrders',{templateUrl:'views/PurchaseOrder/search.html',controller:'SearchPurchaseOrderController'})
      .when('/PurchaseOrders/new',{templateUrl:'views/PurchaseOrder/detail.html',controller:'NewPurchaseOrderController'})
      .when('/PurchaseOrders/edit/:PurchaseOrderId',{templateUrl:'views/PurchaseOrder/detail.html',controller:'EditPurchaseOrderController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
