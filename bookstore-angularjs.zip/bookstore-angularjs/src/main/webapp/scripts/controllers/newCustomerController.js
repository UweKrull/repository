
angular.module('bookstore-angularjs').controller('NewCustomerController', function ($scope, $location, locationParser, CustomerResource , PurchaseOrderResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.customer = $scope.customer || {};
    
    $scope.purchaseOrderList = PurchaseOrderResource.queryAll(function(items){
        $scope.purchaseOrderSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.orderDate
            });
        });
    });
    $scope.$watch("purchaseOrderSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.purchaseOrder = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.customer.purchaseOrder.push(collectionItem);
            });
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.customer.address.country = {};
            $scope.customer.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Customers/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CustomerResource.save($scope.customer, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Customers");
    };
});