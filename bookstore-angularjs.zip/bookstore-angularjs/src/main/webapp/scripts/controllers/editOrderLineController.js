

angular.module('bookstore-angularjs').controller('EditOrderLineController', function($scope, $routeParams, $location, OrderLineResource , ItemResource, PurchaseOrderResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.orderLine = new OrderLineResource(self.original);
            ItemResource.queryAll(function(items) {
                $scope.itemSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.orderLine.item && item.id == $scope.orderLine.item.id) {
                        $scope.itemSelection = labelObject;
                        $scope.orderLine.item = wrappedObject;
                        self.original.item = $scope.orderLine.item;
                    }
                    return labelObject;
                });
            });
            PurchaseOrderResource.queryAll(function(items) {
                $scope.purchaseOrderSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.orderDate
                    };
                    if($scope.orderLine.purchaseOrder && item.id == $scope.orderLine.purchaseOrder.id) {
                        $scope.purchaseOrderSelection = labelObject;
                        $scope.orderLine.purchaseOrder = wrappedObject;
                        self.original.purchaseOrder = $scope.orderLine.purchaseOrder;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/OrderLines");
        };
        OrderLineResource.get({OrderLineId:$routeParams.OrderLineId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.orderLine);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.orderLine.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/OrderLines");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/OrderLines");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.orderLine.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("itemSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.orderLine.item = {};
            $scope.orderLine.item.id = selection.value;
        }
    });
    $scope.$watch("purchaseOrderSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.orderLine.purchaseOrder = {};
            $scope.orderLine.purchaseOrder.id = selection.value;
        }
    });
    
    $scope.get();
});