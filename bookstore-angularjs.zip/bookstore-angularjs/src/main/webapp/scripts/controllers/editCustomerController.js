

angular.module('bookstore-angularjs').controller('EditCustomerController', function($scope, $routeParams, $location, CustomerResource , PurchaseOrderResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.customer = new CustomerResource(self.original);
            PurchaseOrderResource.queryAll(function(items) {
                $scope.purchaseOrderSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.orderDate + ', ' + item.orderLines[0].item.name
                    };
                    if($scope.customer.purchaseOrder){
                        $.each($scope.customer.purchaseOrder, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.purchaseOrderSelection.push(labelObject);
                                $scope.customer.purchaseOrder.push(wrappedObject);
                            }
                        });
                        self.original.purchaseOrder = $scope.customer.purchaseOrder;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.customer.address.country && item.id == $scope.customer.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.customer.address.country = wrappedObject;
                        self.original.address.country = $scope.customer.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Customers");
        };
        CustomerResource.get({CustomerId:$routeParams.CustomerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.customer);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.customer.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Customers");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Customers");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.customer.$remove(successCallback, errorCallback);
    };
    
    $scope.purchaseOrderSelection = $scope.purchaseOrderSelection || [];
    $scope.$watch("purchaseOrderSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.customer) {
            $scope.customer.purchaseOrder = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.customer.purchaseOrder.push(collectionItem);
            });
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.address.country = {};
            $scope.customer.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});