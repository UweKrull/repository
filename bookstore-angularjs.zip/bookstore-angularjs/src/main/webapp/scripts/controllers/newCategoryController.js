
angular.module('bookstore-angularjs').controller('NewCategoryController', function ($scope, $location, locationParser, CategoryResource , ProductResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.category = $scope.category || {};
    
    $scope.productsList = ProductResource.queryAll(function(items){
        $scope.productsSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("productsSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.category.products = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.category.products.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Categorys/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CategoryResource.save($scope.category, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Categorys");
    };
});