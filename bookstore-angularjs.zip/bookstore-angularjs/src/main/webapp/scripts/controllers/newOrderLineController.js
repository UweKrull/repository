
angular.module('bookstore-angularjs').controller('NewOrderLineController', function ($scope, $location, locationParser, OrderLineResource , ItemResource, PurchaseOrderResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.orderLine = $scope.orderLine || {};
    
    $scope.itemList = ItemResource.queryAll(function(items){
        $scope.itemSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("itemSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.orderLine.item = {};
            $scope.orderLine.item.id = selection.value;
        }
    });
    
    $scope.purchaseOrderList = PurchaseOrderResource.queryAll(function(items){
        $scope.purchaseOrderSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.orderDate
            });
        });
    });
    $scope.$watch("purchaseOrderSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.orderLine.purchaseOrder = {};
            $scope.orderLine.purchaseOrder.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/OrderLines/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        OrderLineResource.save($scope.orderLine, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/OrderLines");
    };
});