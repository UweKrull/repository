

angular.module('bookstore-angularjs').controller('EditItemController', function($scope, $routeParams, $location, ItemResource , ProductResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.item = new ItemResource(self.original);
            ProductResource.queryAll(function(items) {
                $scope.productSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.item.product && item.id == $scope.item.product.id) {
                        $scope.productSelection = labelObject;
                        $scope.item.product = wrappedObject;
                        self.original.product = $scope.item.product;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Items");
        };
        ItemResource.get({ItemId:$routeParams.ItemId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.item);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.item.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Items");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Items");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.item.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("productSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.item.product = {};
            $scope.item.product.id = selection.value;
        }
    });
    
    $scope.get();
});