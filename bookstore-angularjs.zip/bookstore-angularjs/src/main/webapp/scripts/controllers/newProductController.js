
angular.module('bookstore-angularjs').controller('NewProductController', function ($scope, $location, locationParser, ProductResource , CategoryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.product = $scope.product || {};
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.product.category = {};
            $scope.product.category.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Products/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ProductResource.save($scope.product, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Products");
    };
});