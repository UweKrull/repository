

angular.module('bookstore-angularjs').controller('EditPurchaseOrderController', function($scope, $routeParams, $location, PurchaseOrderResource , CustomerResource, OrderLineResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.purchaseOrder = new PurchaseOrderResource(self.original);
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName + ' ' + item.lastName + ', ' + item.email + ', ' + item.phone
                    };
                    if($scope.purchaseOrder.customer && item.id == $scope.purchaseOrder.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.purchaseOrder.customer = wrappedObject;
                        self.original.customer = $scope.purchaseOrder.customer;
                    }
                    return labelObject;
                });
            });
            OrderLineResource.queryAll(function(items) {
                $scope.orderLinesSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.quantity + ' ' + item.item.name
                    };
                    if($scope.purchaseOrder.orderLines){
                        $.each($scope.purchaseOrder.orderLines, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.orderLinesSelection.push(labelObject);
                                $scope.purchaseOrder.orderLines.push(wrappedObject);
                            }
                        });
                        self.original.orderLines = $scope.purchaseOrder.orderLines;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.deliveryAddresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.purchaseOrder.deliveryAddress.country && item.id == $scope.purchaseOrder.deliveryAddress.country.id) {
                        $scope.deliveryAddresscountrySelection = labelObject;
                        $scope.purchaseOrder.deliveryAddress.country = wrappedObject;
                        self.original.deliveryAddress.country = $scope.purchaseOrder.deliveryAddress.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/PurchaseOrders");
        };
        PurchaseOrderResource.get({PurchaseOrderId:$routeParams.PurchaseOrderId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.purchaseOrder);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.purchaseOrder.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PurchaseOrders");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PurchaseOrders");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.purchaseOrder.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.purchaseOrder.customer = {};
            $scope.purchaseOrder.customer.id = selection.value;
        }
    });
    $scope.orderLinesSelection = $scope.orderLinesSelection || [];
    $scope.$watch("orderLinesSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.purchaseOrder) {
            $scope.purchaseOrder.orderLines = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.purchaseOrder.orderLines.push(collectionItem);
            });
        }
    });
    $scope.$watch("deliveryAddresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.purchaseOrder.deliveryAddress.country = {};
            $scope.purchaseOrder.deliveryAddress.country.id = selection.value;
        }
    });
    $scope.creditCardcreditCardTypeList = [
        "VISA",  
        "MASTER_CARD",  
        "AMERICAN_EXPRESS"  
    ];
    
    $scope.get();
});