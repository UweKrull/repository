
angular.module('bookstore-angularjs').controller('NewPurchaseOrderController', function ($scope, $location, locationParser, PurchaseOrderResource , CustomerResource, OrderLineResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.purchaseOrder = $scope.purchaseOrder || {};
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.purchaseOrder.customer = {};
            $scope.purchaseOrder.customer.id = selection.value;
        }
    });
    
    $scope.orderLinesList = OrderLineResource.queryAll(function(items){
        $scope.orderLinesSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.quantity
            });
        });
    });
    $scope.$watch("orderLinesSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.purchaseOrder.orderLines = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.purchaseOrder.orderLines.push(collectionItem);
            });
        }
    });
    
    $scope.deliveryAddresscountryList = CountryResource.queryAll(function(items){
        $scope.deliveryAddresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("deliveryAddresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.purchaseOrder.deliveryAddress.country = {};
            $scope.purchaseOrder.deliveryAddress.country.id = selection.value;
        }
    });
    
    $scope.creditCardcreditCardTypeList = [
        "VISA",
        "MASTER_CARD",
        "AMERICAN_EXPRESS"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/PurchaseOrders/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PurchaseOrderResource.save($scope.purchaseOrder, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/PurchaseOrders");
    };
});