package de.binaris.bookstore.forge.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import de.binaris.bookstore.annotations.Login;

@Cacheable
@Entity
@NamedQueries({
    @NamedQuery(name = "findByLogin", query = "SELECT c FROM Customer c WHERE c.login = :login"),
    @NamedQuery(name = "findByLoginAndPassword", query = "SELECT c FROM Customer c WHERE c.login = :login AND c.password = :password")
})
@Table(name = "customer")
public class Customer implements Serializable {

	private static final long serialVersionUID = 7975789629699126629L;

    public static final String FIND_BY_LOGIN = "findByLogin";
    public static final String FIND_BY_LOGIN_PASSWORD = "findByLoginAndPassword";
    
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_customer")
	@SequenceGenerator(name = "my_entity_seq_gen_customer", sequenceName = "sequence_customer", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String firstName;

	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String lastName;

	@NotNull
	private String phone;

	@NotNull
	@NotEmpty
	@Email(message = "invalid email format")
	private String email;

	@NotNull
	@Size(min = 1, max = 10, message = "must be 1-10 letters and spaces")
	@Login
	private String login;

	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String password;

	@NotNull
	@Column(name = "date_of_birth")
	@Past
	@Temporal(TemporalType.DATE)
	private Date dateOfBirth;

	@Transient
	private Integer age;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "customer")
	private Set<PurchaseOrder> purchaseOrder = new HashSet<PurchaseOrder>();

	private Address address = new Address();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Set<PurchaseOrder> getPurchaseOrder() {
		return purchaseOrder;
	}

	public void setPurchaseOrder(Set<PurchaseOrder> purchaseOrder) {
		this.purchaseOrder = purchaseOrder;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Customer)) {
			return false;
		}
		Customer castOther = (Customer) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append("Customer: ");
		sb.append('\'').append(lastName).append('\'');
		sb.append(", ").append('\'').append(firstName).append('\'');
		sb.append(", ").append('\'').append(dateOfBirth).append('\'');
		sb.append(", ").append('\'').append(phone).append('\'');
		sb.append(", ").append('\'').append(email).append('\'');
		return sb.toString();
	}
}
