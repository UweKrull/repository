package de.binaris.bookstore.forge.rest.dto;

import java.io.Serializable;

import de.binaris.bookstore.forge.model.Category;
import de.binaris.bookstore.forge.model.Product;
import de.binaris.bookstore.forge.rest.dto.NestedProductDTO;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;
import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable
{

   private Long id;
   private String description;
   private String name;
   private Set<NestedProductDTO> products = new HashSet<NestedProductDTO>();

   public CategoryDTO()
   {
   }

   public CategoryDTO(final Category entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         Iterator<Product> iterProducts = entity.getProducts().iterator();
         for (; iterProducts.hasNext();)
         {
            Product element = iterProducts.next();
            this.products.add(new NestedProductDTO(element));
         }
      }
   }

   public Category fromDTO(Category entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Category();
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      Iterator<Product> iterProducts = entity.getProducts().iterator();
      for (; iterProducts.hasNext();)
      {
         boolean found = false;
         Product product = iterProducts.next();
         Iterator<NestedProductDTO> iterDtoProducts = this.getProducts()
               .iterator();
         for (; iterDtoProducts.hasNext();)
         {
            NestedProductDTO dtoProduct = iterDtoProducts.next();
            if (dtoProduct.getId().equals(product.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterProducts.remove();
         }
      }
      Iterator<NestedProductDTO> iterDtoProducts = this.getProducts()
            .iterator();
      for (; iterDtoProducts.hasNext();)
      {
         boolean found = false;
         NestedProductDTO dtoProduct = iterDtoProducts.next();
         iterProducts = entity.getProducts().iterator();
         for (; iterProducts.hasNext();)
         {
            Product product = iterProducts.next();
            if (dtoProduct.getId().equals(product.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Product> resultIter = em
                  .createQuery("SELECT DISTINCT p FROM Product p",
                        Product.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Product result = resultIter.next();
               if (result.getId().equals(dtoProduct.getId()))
               {
                  entity.getProducts().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Set<NestedProductDTO> getProducts()
   {
      return this.products;
   }

   public void setProducts(final Set<NestedProductDTO> products)
   {
      this.products = products;
   }
}