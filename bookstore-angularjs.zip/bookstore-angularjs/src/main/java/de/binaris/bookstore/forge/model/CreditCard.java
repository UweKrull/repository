package de.binaris.bookstore.forge.model;

import static javax.persistence.EnumType.STRING;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Enumerated;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@SuppressWarnings("serial")
@Embeddable
public class CreditCard implements Serializable {

	@NotNull
    @Size(min = 1, max = 30, message = "must be 1-30 numbers, letters and spaces")
    @Column(name = "credit_card_number")
    private String creditCardNumber;

    @Column(name = "credit_card_type")
    @NotNull
    @Enumerated(STRING)
    private CreditCardType creditCardType;
    
    @NotNull
    @Size(min = 8, max = 10, message = "must be 8-10 letters and spaces for the preferred date format")
    @Column(name = "credit_card_expiry_date")
    private String creditCardExpDate;
    
    public CreditCard() {
    }

    public CreditCard(String creditCardNumber, CreditCardType creditCardType, String creditCardExpDate) {
        this.creditCardNumber = creditCardNumber;
        this.creditCardType = creditCardType;
        this.creditCardExpDate = creditCardExpDate;
    }
    
    public String getCreditCardNumber() {
    	return creditCardNumber;
    }
    
    public void setCreditCardNumber(String creditCardNumber) {
    	this.creditCardNumber = creditCardNumber;
    }
    
    public CreditCardType getCreditCardType() {
    	return creditCardType;
    }
    
    public void setCreditCardType(CreditCardType creditCardType) {
    	this.creditCardType = creditCardType;
    }
    
    public String getCreditCardExpDate() {
    	return creditCardExpDate;
    }
    
    public void setCreditCardExpDate(String creditCardExpDate) {
    	this.creditCardExpDate = creditCardExpDate;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CreditCard)) return false;

        CreditCard that = (CreditCard) o;
        if (!creditCardNumber.equals(that.creditCardNumber)) {
        	return false;
        }
        return true;
    }

    @Override
    public int hashCode() {
        return creditCardNumber.hashCode();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append("creditCardNumber: '");
        for (int i=0; i < (creditCardNumber.length() - 3); i++) {
        	sb.append("*");
        }
        sb.append(creditCardNumber.substring(creditCardNumber.length() - 3)).append('\'');
        sb.append(", creditCardExpDate: '").append(creditCardExpDate).append('\'');
        return sb.toString();
    }
}
