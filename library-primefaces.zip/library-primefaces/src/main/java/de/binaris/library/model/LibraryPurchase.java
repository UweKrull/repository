package de.binaris.library.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import de.binaris.library.model.PurchaseLine;

/**
 * <p>
 * An LibraryPurchase may consist of one or more purchaseLines.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Entity
@Table(name = "library_purchase")
public class LibraryPurchase implements Serializable {

	private static final long serialVersionUID = 7277723756789162915L;

	/**
	 * The ID of the LibraryPurchase.
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_library_purchase")
	@SequenceGenerator(name = "my_entity_seq_gen_library_purchase", sequenceName = "sequence_library_purchase", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Customer customer;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "libraryPurchase")
	private Set<PurchaseLine> purchaseLines = new HashSet<PurchaseLine>();

	@Temporal(TemporalType.DATE)
	@Column(name="estimated_return_date")
	private Date estimatedReturnDate;

	@Temporal(TemporalType.DATE)
	@Column(name="library_date")
	private Date libraryDate;

	@ManyToOne(fetch = EAGER)
	private Country country;

	public LibraryPurchase() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getEstimatedReturnDate() {
		return this.estimatedReturnDate;
	}

	public void setEstimatedReturnDate(Date estimatedReturnDate) {
		this.estimatedReturnDate = estimatedReturnDate;
	}
	
	@PrePersist
	private void setDefaultData() {
		libraryDate = new Date();
	}

	public Date getLibraryDate() {
		return this.libraryDate;
	}

	public void setLibraryDate(Date libraryDate) {
		this.libraryDate = libraryDate;
	}

	public Country getCountry() {
		return this.country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public Customer getCustomer() {
		return this.customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Set<PurchaseLine> getPurchaseLines() {
		return this.purchaseLines;
	}

	public void setPurchaseLines(Set<PurchaseLine> purchaseLines) {
		this.purchaseLines = purchaseLines;
	}
	
	/*
	 * toString(), equals() and hashCode() for LibraryPurchase, using the natural
	 * identity of the object
	 */

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof LibraryPurchase)) {
			return false;
		}
		LibraryPurchase castOther = (LibraryPurchase) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(customer.toString());
		sb.append(", ").append(country.toString());
		for (PurchaseLine line : purchaseLines) {
			sb.append(", ").append(line.getSelectItemReducedString());
		}
//		sb.append(", ").append(customer.toString());
//		sb.append(", ").append(purchaseLines.toString());
//		sb.append(", ").append(country.toString());
//		sb.append(", ").append(libraryDate);
//		sb.append(", ").append(estimatedReturnDate);
		return sb.toString();
	}
}