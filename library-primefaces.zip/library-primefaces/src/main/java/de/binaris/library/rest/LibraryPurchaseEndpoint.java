package de.binaris.library.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.library.model.LibraryPurchase;
import de.binaris.library.rest.dto.LibraryPurchaseDTO;

/**
 * The REST Endpoint for LibraryPurchases
 */
@Stateless
@Path("/librarypurchases")
public class LibraryPurchaseEndpoint
{
   @PersistenceContext(unitName = "LibraryPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(LibraryPurchaseDTO dto)
   {
      LibraryPurchase entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(LibraryPurchaseEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      LibraryPurchase entity = em.find(LibraryPurchase.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<LibraryPurchase> findByIdQuery = em.createQuery("SELECT DISTINCT l FROM LibraryPurchase l LEFT JOIN FETCH l.customer LEFT JOIN FETCH l.purchaseLines LEFT JOIN FETCH l.country WHERE l.id = :entityId ORDER BY l.id", LibraryPurchase.class);
      findByIdQuery.setParameter("entityId", id);
      LibraryPurchase entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      LibraryPurchaseDTO dto = new LibraryPurchaseDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<LibraryPurchaseDTO> listAll()
   {
      final List<LibraryPurchase> searchResults = em.createQuery("SELECT DISTINCT l FROM LibraryPurchase l LEFT JOIN FETCH l.customer LEFT JOIN FETCH l.purchaseLines LEFT JOIN FETCH l.country ORDER BY l.id", LibraryPurchase.class).getResultList();
      final List<LibraryPurchaseDTO> results = new ArrayList<LibraryPurchaseDTO>();
      for (LibraryPurchase searchResult : searchResults)
      {
         LibraryPurchaseDTO dto = new LibraryPurchaseDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, LibraryPurchaseDTO dto)
   {
      TypedQuery<LibraryPurchase> findByIdQuery = em.createQuery("SELECT DISTINCT l FROM LibraryPurchase l LEFT JOIN FETCH l.customer LEFT JOIN FETCH l.purchaseLines LEFT JOIN FETCH l.country WHERE l.id = :entityId ORDER BY l.id", LibraryPurchase.class);
      findByIdQuery.setParameter("entityId", id);
      LibraryPurchase entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}