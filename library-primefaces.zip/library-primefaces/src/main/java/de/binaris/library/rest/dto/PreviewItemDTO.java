package de.binaris.library.rest.dto;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

import de.binaris.library.model.PreviewItem;

@XmlRootElement
public class PreviewItemDTO implements Serializable {

	private static final long serialVersionUID = 7235677710111213151L;
	
	private Long id;
	private NestedCategoryItemDTO categoryItem;
	private float pricePerItem;
	private String previewPath;
	private String description;
	private String isbn;
	private String mhid;
	private String name;

	public PreviewItemDTO() {
	}

	public PreviewItemDTO(final PreviewItem entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.categoryItem = new NestedCategoryItemDTO(
					entity.getCategoryItem());
			this.pricePerItem = entity.getPricePerItem();
			this.previewPath = entity.getPreviewPath();
			this.description = entity.getDescription();
			this.isbn = entity.getIsbn();
			this.mhid = entity.getMhid();
			this.name = entity.getName();
		}
	}

	public PreviewItem fromDTO(PreviewItem entity, EntityManager em) {
		if (entity == null) {
			entity = new PreviewItem();
		}
		if (this.categoryItem != null) {
			entity.setCategoryItem(this.categoryItem.fromDTO(
					entity.getCategoryItem(), em));
		}
		entity.setPricePerItem(this.pricePerItem);
		entity.setPreviewPath(this.previewPath);
		entity.setDescription(this.description);
		entity.setName(this.name);
		entity.setName(this.isbn);
		entity.setName(this.mhid);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public NestedCategoryItemDTO getCategoryItem() {
		return this.categoryItem;
	}

	public void setCategoryItem(final NestedCategoryItemDTO categoryItem) {
		this.categoryItem = categoryItem;
	}

	public float getPricePerItem() {
		return this.pricePerItem;
	}

	public void setPricePerItem(final float pricePerItem) {
		this.pricePerItem = pricePerItem;
	}

	public String getPreviewPath() {
		return this.previewPath;
	}

	public void setPreviewPath(final String previewPath) {
		this.previewPath = previewPath;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public void setIsbn(final String isbn) {
		this.isbn = isbn;
	}

	public String getMhid() {
		return this.mhid;
	}
	
	public void setMhid(final String mhid) {
		this.mhid = mhid;
	}
	
	public String getName() {
		return this.name;
	}

	public void setName(final String name) {
		this.name = name;
	}
}