package de.binaris.library.rest.dto;

import java.io.Serializable;

import de.binaris.library.model.LibraryPurchase;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import java.util.Date;

public class NestedLibraryPurchaseDTO implements Serializable {

	private static final long serialVersionUID = 7177677710111213391L;

	private Long id;
	private Date libraryDate;
	private Date estimatedReturnDate;

	public NestedLibraryPurchaseDTO() {
	}

	public NestedLibraryPurchaseDTO(final LibraryPurchase entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.libraryDate = entity.getLibraryDate();
			this.estimatedReturnDate = entity.getEstimatedReturnDate();
		}
	}

	public LibraryPurchase fromDTO(LibraryPurchase entity, EntityManager em) {
		if (entity == null) {
			entity = new LibraryPurchase();
		}
		if (this.id != null) {
			TypedQuery<LibraryPurchase> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT l FROM LibraryPurchase l WHERE l.id = :entityId",
							LibraryPurchase.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setLibraryDate(this.libraryDate);
		entity.setEstimatedReturnDate(this.estimatedReturnDate);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Date getLibraryDate() {
		return this.libraryDate;
	}

	public void setLibraryDate(final Date libraryDate) {
		this.libraryDate = libraryDate;
	}

	public Date getEstimatedReturnDate() {
		return this.estimatedReturnDate;
	}

	public void setEstimatedReturnDate(final Date estimatedReturnDate) {
		this.estimatedReturnDate = estimatedReturnDate;
	}
}