package de.binaris.library.rest.dto;

import java.io.Serializable;

import de.binaris.library.model.PurchaseLine;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedPurchaseLineDTO implements Serializable {

	private static final long serialVersionUID = 7757778910111213190L;

	private Long id;
	private Integer quantity;

	public NestedPurchaseLineDTO() {
	}

	public NestedPurchaseLineDTO(final PurchaseLine entity) {
		if (entity != null) {
			this.id = entity.getId();
			this.quantity = entity.getQuantity();
		}
	}

	public PurchaseLine fromDTO(PurchaseLine entity, EntityManager em) {
		if (entity == null) {
			entity = new PurchaseLine();
		}
		if (this.id != null) {
			TypedQuery<PurchaseLine> findByIdQuery = em
					.createQuery(
							"SELECT DISTINCT p FROM PurchaseLine p WHERE p.id = :entityId",
							PurchaseLine.class);
			findByIdQuery.setParameter("entityId", this.id);
			try {
				entity = findByIdQuery.getSingleResult();
			} catch (javax.persistence.NoResultException nre) {
				entity = null;
			}
			return entity;
		}
		entity.setQuantity(this.quantity);
		entity = em.merge(entity);
		return entity;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public Integer getQuantity() {
		return this.quantity;
	}

	public void setQuantity(final Integer quantity) {
		this.quantity = quantity;
	}
}