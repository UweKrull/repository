package de.binaris.library.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.library.model.CategoryItem;
import de.binaris.library.rest.dto.CategoryItemDTO;

/**
 * The REST Endpoint for CategoryItems
 */
@Stateless
@Path("/categoryitems")
public class CategoryItemEndpoint
{
   @PersistenceContext(unitName = "LibraryPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(CategoryItemDTO dto)
   {
      CategoryItem entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(CategoryItemEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      CategoryItem entity = em.find(CategoryItem.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<CategoryItem> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM CategoryItem c LEFT JOIN FETCH c.category WHERE c.id = :entityId ORDER BY c.id", CategoryItem.class);
      findByIdQuery.setParameter("entityId", id);
      CategoryItem entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      CategoryItemDTO dto = new CategoryItemDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<CategoryItemDTO> listAll()
   {
      final List<CategoryItem> searchResults = em.createQuery("SELECT DISTINCT c FROM CategoryItem c LEFT JOIN FETCH c.category ORDER BY c.id", CategoryItem.class).getResultList();
      final List<CategoryItemDTO> results = new ArrayList<CategoryItemDTO>();
      for (CategoryItem searchResult : searchResults)
      {
         CategoryItemDTO dto = new CategoryItemDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, CategoryItemDTO dto)
   {
      TypedQuery<CategoryItem> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM CategoryItem c LEFT JOIN FETCH c.category WHERE c.id = :entityId ORDER BY c.id", CategoryItem.class);
      findByIdQuery.setParameter("entityId", id);
      CategoryItem entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}