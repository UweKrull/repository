package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.parties.model.DrinksAndBeverages;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedCategoryTypeDTO;
import de.binaris.rest.dto.NestedPartyDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class DrinksAndBeveragesDTO implements Serializable
{

   private Long id;
   private String title;
   private NestedCategoryTypeDTO categoryType;
   private NestedPartyDTO party;

   public DrinksAndBeveragesDTO()
   {
   }

   public DrinksAndBeveragesDTO(final DrinksAndBeverages entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.categoryType = new NestedCategoryTypeDTO(
               entity.getCategoryType());
         this.party = new NestedPartyDTO(entity.getParty());
      }
   }

   public DrinksAndBeverages fromDTO(DrinksAndBeverages entity,
         EntityManager em)
   {
      if (entity == null)
      {
         entity = new DrinksAndBeverages();
      }
      entity.setTitle(this.title);
      if (this.categoryType != null)
      {
         entity.setCategoryType(this.categoryType.fromDTO(
               entity.getCategoryType(), em));
      }
      if (this.party != null)
      {
         entity.setParty(this.party.fromDTO(entity.getParty(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public NestedCategoryTypeDTO getCategoryType()
   {
      return this.categoryType;
   }

   public void setCategoryType(final NestedCategoryTypeDTO categoryType)
   {
      this.categoryType = categoryType;
   }

   public NestedPartyDTO getParty()
   {
      return this.party;
   }

   public void setParty(final NestedPartyDTO party)
   {
      this.party = party;
   }
}