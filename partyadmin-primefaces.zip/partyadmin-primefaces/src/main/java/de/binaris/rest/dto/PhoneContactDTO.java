package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.parties.model.PhoneContact;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedPartyDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PhoneContactDTO implements Serializable
{

   private Long id;
   private String phoneNumber;
   private String name;
   private NestedPartyDTO party;

   public PhoneContactDTO()
   {
   }

   public PhoneContactDTO(final PhoneContact entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.phoneNumber = entity.getPhoneNumber();
         this.name = entity.getName();
         this.party = new NestedPartyDTO(entity.getParty());
      }
   }

   public PhoneContact fromDTO(PhoneContact entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new PhoneContact();
      }
      entity.setPhoneNumber(this.phoneNumber);
      entity.setName(this.name);
      if (this.party != null)
      {
         entity.setParty(this.party.fromDTO(entity.getParty(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getPhoneNumber()
   {
      return this.phoneNumber;
   }

   public void setPhoneNumber(final String phoneNumber)
   {
      this.phoneNumber = phoneNumber;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public NestedPartyDTO getParty()
   {
      return this.party;
   }

   public void setParty(final NestedPartyDTO party)
   {
      this.party = party;
   }
}