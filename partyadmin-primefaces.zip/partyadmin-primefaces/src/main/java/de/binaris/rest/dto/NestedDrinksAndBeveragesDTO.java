package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.parties.model.DrinksAndBeverages;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedDrinksAndBeveragesDTO implements Serializable
{

   private Long id;
   private String title;

   public NestedDrinksAndBeveragesDTO()
   {
   }

   public NestedDrinksAndBeveragesDTO(final DrinksAndBeverages entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
      }
   }

   public DrinksAndBeverages fromDTO(DrinksAndBeverages entity,
         EntityManager em)
   {
      if (entity == null)
      {
         entity = new DrinksAndBeverages();
      }
      if (this.id != null)
      {
         TypedQuery<DrinksAndBeverages> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT d FROM DrinksAndBeverages d WHERE d.id = :entityId",
                     DrinksAndBeverages.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }
}