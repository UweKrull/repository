package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.parties.model.Party;
import javax.persistence.EntityManager;
import java.util.Set;
import java.util.HashSet;
import de.binaris.rest.dto.NestedDrinksAndBeveragesDTO;
import de.binaris.parties.model.DrinksAndBeverages;
import java.util.Iterator;
import de.binaris.rest.dto.NestedVenueDTO;
import de.binaris.rest.dto.NestedCategoryDTO;
import de.binaris.parties.model.AdultOnlyType;
import de.binaris.rest.dto.NestedTimeAndChargeDTO;
import de.binaris.parties.model.TimeAndCharge;
import de.binaris.rest.dto.NestedPhoneContactDTO;
import de.binaris.parties.model.PhoneContact;
import de.binaris.rest.dto.NestedCustomerDTO;
import de.binaris.parties.model.Customer;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PartyDTO implements Serializable
{

   private Set<NestedDrinksAndBeveragesDTO> drinksAndBeverages = new HashSet<NestedDrinksAndBeveragesDTO>();
   private String linkBookOnlineAtVenue;
   private String hostname;
   private NestedVenueDTO venue;
   private String dressCode;
   private Long id;
   private NestedCategoryDTO category;
   private String schedule;
   private AdultOnlyType adultOnly;
   private Set<NestedTimeAndChargeDTO> timeAndCharge = new HashSet<NestedTimeAndChargeDTO>();
   private String description;
   private String name;
   private Set<NestedPhoneContactDTO> phoneContact = new HashSet<NestedPhoneContactDTO>();
   private String linkDetails;
   private Set<NestedCustomerDTO> guest = new HashSet<NestedCustomerDTO>();

   public PartyDTO()
   {
   }

   public PartyDTO(final Party entity)
   {
      if (entity != null)
      {
         Iterator<DrinksAndBeverages> iterDrinksAndBeverages = entity
               .getDrinksAndBeverages().iterator();
         for (; iterDrinksAndBeverages.hasNext();)
         {
            DrinksAndBeverages element = iterDrinksAndBeverages.next();
            this.drinksAndBeverages.add(new NestedDrinksAndBeveragesDTO(
                  element));
         }
         this.linkBookOnlineAtVenue = entity.getLinkBookOnlineAtVenue();
         this.hostname = entity.getHostname();
         this.venue = new NestedVenueDTO(entity.getVenue());
         this.dressCode = entity.getDressCode();
         this.id = entity.getId();
         this.category = new NestedCategoryDTO(entity.getCategory());
         this.schedule = entity.getSchedule();
         this.adultOnly = entity.getAdultOnly();
         Iterator<TimeAndCharge> iterTimeAndCharge = entity
               .getTimeAndCharge().iterator();
         for (; iterTimeAndCharge.hasNext();)
         {
            TimeAndCharge element = iterTimeAndCharge.next();
            this.timeAndCharge.add(new NestedTimeAndChargeDTO(element));
         }
         this.description = entity.getDescription();
         this.name = entity.getName();
         Iterator<PhoneContact> iterPhoneContact = entity.getPhoneContact()
               .iterator();
         for (; iterPhoneContact.hasNext();)
         {
            PhoneContact element = iterPhoneContact.next();
            this.phoneContact.add(new NestedPhoneContactDTO(element));
         }
         this.linkDetails = entity.getLinkDetails();
         Iterator<Customer> iterGuest = entity.getGuest().iterator();
         for (; iterGuest.hasNext();)
         {
            Customer element = iterGuest.next();
            this.guest.add(new NestedCustomerDTO(element));
         }
      }
   }

   public Party fromDTO(Party entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Party();
      }
      Iterator<DrinksAndBeverages> iterDrinksAndBeverages = entity
            .getDrinksAndBeverages().iterator();
      for (; iterDrinksAndBeverages.hasNext();)
      {
         boolean found = false;
         DrinksAndBeverages drinksAndBeverages = iterDrinksAndBeverages
               .next();
         Iterator<NestedDrinksAndBeveragesDTO> iterDtoDrinksAndBeverages = this
               .getDrinksAndBeverages().iterator();
         for (; iterDtoDrinksAndBeverages.hasNext();)
         {
            NestedDrinksAndBeveragesDTO dtoDrinksAndBeverages = iterDtoDrinksAndBeverages
                  .next();
            if (dtoDrinksAndBeverages.getId().equals(
                  drinksAndBeverages.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterDrinksAndBeverages.remove();
         }
      }
      Iterator<NestedDrinksAndBeveragesDTO> iterDtoDrinksAndBeverages = this
            .getDrinksAndBeverages().iterator();
      for (; iterDtoDrinksAndBeverages.hasNext();)
      {
         boolean found = false;
         NestedDrinksAndBeveragesDTO dtoDrinksAndBeverages = iterDtoDrinksAndBeverages
               .next();
         iterDrinksAndBeverages = entity.getDrinksAndBeverages().iterator();
         for (; iterDrinksAndBeverages.hasNext();)
         {
            DrinksAndBeverages drinksAndBeverages = iterDrinksAndBeverages
                  .next();
            if (dtoDrinksAndBeverages.getId().equals(
                  drinksAndBeverages.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<DrinksAndBeverages> resultIter = em
                  .createQuery(
                        "SELECT DISTINCT d FROM DrinksAndBeverages d",
                        DrinksAndBeverages.class).getResultList()
                  .iterator();
            for (; resultIter.hasNext();)
            {
               DrinksAndBeverages result = resultIter.next();
               if (result.getId().equals(dtoDrinksAndBeverages.getId()))
               {
                  entity.getDrinksAndBeverages().add(result);
                  break;
               }
            }
         }
      }
      entity.setLinkBookOnlineAtVenue(this.linkBookOnlineAtVenue);
      entity.setHostname(this.hostname);
      if (this.venue != null)
      {
         entity.setVenue(this.venue.fromDTO(entity.getVenue(), em));
      }
      entity.setDressCode(this.dressCode);
      if (this.category != null)
      {
         entity.setCategory(this.category.fromDTO(entity.getCategory(), em));
      }
      entity.setSchedule(this.schedule);
      entity.setAdultOnly(this.adultOnly);
      Iterator<TimeAndCharge> iterTimeAndCharge = entity.getTimeAndCharge()
            .iterator();
      for (; iterTimeAndCharge.hasNext();)
      {
         boolean found = false;
         TimeAndCharge timeAndCharge = iterTimeAndCharge.next();
         Iterator<NestedTimeAndChargeDTO> iterDtoTimeAndCharge = this
               .getTimeAndCharge().iterator();
         for (; iterDtoTimeAndCharge.hasNext();)
         {
            NestedTimeAndChargeDTO dtoTimeAndCharge = iterDtoTimeAndCharge
                  .next();
            if (dtoTimeAndCharge.getId().equals(timeAndCharge.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterTimeAndCharge.remove();
         }
      }
      Iterator<NestedTimeAndChargeDTO> iterDtoTimeAndCharge = this
            .getTimeAndCharge().iterator();
      for (; iterDtoTimeAndCharge.hasNext();)
      {
         boolean found = false;
         NestedTimeAndChargeDTO dtoTimeAndCharge = iterDtoTimeAndCharge
               .next();
         iterTimeAndCharge = entity.getTimeAndCharge().iterator();
         for (; iterTimeAndCharge.hasNext();)
         {
            TimeAndCharge timeAndCharge = iterTimeAndCharge.next();
            if (dtoTimeAndCharge.getId().equals(timeAndCharge.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<TimeAndCharge> resultIter = em
                  .createQuery("SELECT DISTINCT t FROM TimeAndCharge t",
                        TimeAndCharge.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               TimeAndCharge result = resultIter.next();
               if (result.getId().equals(dtoTimeAndCharge.getId()))
               {
                  entity.getTimeAndCharge().add(result);
                  break;
               }
            }
         }
      }
      entity.setDescription(this.description);
      entity.setName(this.name);
      Iterator<PhoneContact> iterPhoneContact = entity.getPhoneContact()
            .iterator();
      for (; iterPhoneContact.hasNext();)
      {
         boolean found = false;
         PhoneContact phoneContact = iterPhoneContact.next();
         Iterator<NestedPhoneContactDTO> iterDtoPhoneContact = this
               .getPhoneContact().iterator();
         for (; iterDtoPhoneContact.hasNext();)
         {
            NestedPhoneContactDTO dtoPhoneContact = iterDtoPhoneContact
                  .next();
            if (dtoPhoneContact.getId().equals(phoneContact.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterPhoneContact.remove();
         }
      }
      Iterator<NestedPhoneContactDTO> iterDtoPhoneContact = this
            .getPhoneContact().iterator();
      for (; iterDtoPhoneContact.hasNext();)
      {
         boolean found = false;
         NestedPhoneContactDTO dtoPhoneContact = iterDtoPhoneContact.next();
         iterPhoneContact = entity.getPhoneContact().iterator();
         for (; iterPhoneContact.hasNext();)
         {
            PhoneContact phoneContact = iterPhoneContact.next();
            if (dtoPhoneContact.getId().equals(phoneContact.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<PhoneContact> resultIter = em
                  .createQuery("SELECT DISTINCT p FROM PhoneContact p",
                        PhoneContact.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               PhoneContact result = resultIter.next();
               if (result.getId().equals(dtoPhoneContact.getId()))
               {
                  entity.getPhoneContact().add(result);
                  break;
               }
            }
         }
      }
      entity.setLinkDetails(this.linkDetails);
      Iterator<Customer> iterGuest = entity.getGuest().iterator();
      for (; iterGuest.hasNext();)
      {
         boolean found = false;
         Customer customer = iterGuest.next();
         Iterator<NestedCustomerDTO> iterDtoGuest = this.getGuest()
               .iterator();
         for (; iterDtoGuest.hasNext();)
         {
            NestedCustomerDTO dtoCustomer = iterDtoGuest.next();
            if (dtoCustomer.getId().equals(customer.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterGuest.remove();
         }
      }
      Iterator<NestedCustomerDTO> iterDtoGuest = this.getGuest().iterator();
      for (; iterDtoGuest.hasNext();)
      {
         boolean found = false;
         NestedCustomerDTO dtoCustomer = iterDtoGuest.next();
         iterGuest = entity.getGuest().iterator();
         for (; iterGuest.hasNext();)
         {
            Customer customer = iterGuest.next();
            if (dtoCustomer.getId().equals(customer.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<Customer> resultIter = em
                  .createQuery("SELECT DISTINCT c FROM Customer c",
                        Customer.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               Customer result = resultIter.next();
               if (result.getId().equals(dtoCustomer.getId()))
               {
                  entity.getGuest().add(result);
                  break;
               }
            }
         }
      }
      entity = em.merge(entity);
      return entity;
   }

   public Set<NestedDrinksAndBeveragesDTO> getDrinksAndBeverages()
   {
      return this.drinksAndBeverages;
   }

   public void setDrinksAndBeverages(
         final Set<NestedDrinksAndBeveragesDTO> drinksAndBeverages)
   {
      this.drinksAndBeverages = drinksAndBeverages;
   }

   public String getLinkBookOnlineAtVenue()
   {
      return this.linkBookOnlineAtVenue;
   }

   public void setLinkBookOnlineAtVenue(final String linkBookOnlineAtVenue)
   {
      this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
   }

   public String getHostname()
   {
      return this.hostname;
   }

   public void setHostname(final String hostname)
   {
      this.hostname = hostname;
   }

   public NestedVenueDTO getVenue()
   {
      return this.venue;
   }

   public void setVenue(final NestedVenueDTO venue)
   {
      this.venue = venue;
   }

   public String getDressCode()
   {
      return this.dressCode;
   }

   public void setDressCode(final String dressCode)
   {
      this.dressCode = dressCode;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedCategoryDTO getCategory()
   {
      return this.category;
   }

   public void setCategory(final NestedCategoryDTO category)
   {
      this.category = category;
   }

   public String getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final String schedule)
   {
      this.schedule = schedule;
   }

   public AdultOnlyType getAdultOnly()
   {
      return this.adultOnly;
   }

   public void setAdultOnly(final AdultOnlyType adultOnly)
   {
      this.adultOnly = adultOnly;
   }

   public Set<NestedTimeAndChargeDTO> getTimeAndCharge()
   {
      return this.timeAndCharge;
   }

   public void setTimeAndCharge(final Set<NestedTimeAndChargeDTO> timeAndCharge)
   {
      this.timeAndCharge = timeAndCharge;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public Set<NestedPhoneContactDTO> getPhoneContact()
   {
      return this.phoneContact;
   }

   public void setPhoneContact(final Set<NestedPhoneContactDTO> phoneContact)
   {
      this.phoneContact = phoneContact;
   }

   public String getLinkDetails()
   {
      return this.linkDetails;
   }

   public void setLinkDetails(final String linkDetails)
   {
      this.linkDetails = linkDetails;
   }

   public Set<NestedCustomerDTO> getGuest()
   {
      return this.guest;
   }

   public void setGuest(final Set<NestedCustomerDTO> guest)
   {
      this.guest = guest;
   }
}