package de.binaris.rest.dto;

import java.io.Serializable;
import de.binaris.parties.model.TimeAndCharge;
import javax.persistence.EntityManager;
import de.binaris.rest.dto.NestedPartyDTO;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TimeAndChargeDTO implements Serializable
{

   private String startTime;
   private Long id;
   private String charge;
   private String days;
   private NestedPartyDTO party;

   public TimeAndChargeDTO()
   {
   }

   public TimeAndChargeDTO(final TimeAndCharge entity)
   {
      if (entity != null)
      {
         this.startTime = entity.getStartTime();
         this.id = entity.getId();
         this.charge = entity.getCharge();
         this.days = entity.getDays();
         this.party = new NestedPartyDTO(entity.getParty());
      }
   }

   public TimeAndCharge fromDTO(TimeAndCharge entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new TimeAndCharge();
      }
      entity.setStartTime(this.startTime);
      entity.setCharge(this.charge);
      entity.setDays(this.days);
      if (this.party != null)
      {
         entity.setParty(this.party.fromDTO(entity.getParty(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public String getStartTime()
   {
      return this.startTime;
   }

   public void setStartTime(final String startTime)
   {
      this.startTime = startTime;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getCharge()
   {
      return this.charge;
   }

   public void setCharge(final String charge)
   {
      this.charge = charge;
   }

   public String getDays()
   {
      return this.days;
   }

   public void setDays(final String days)
   {
      this.days = days;
   }

   public NestedPartyDTO getParty()
   {
      return this.party;
   }

   public void setParty(final NestedPartyDTO party)
   {
      this.party = party;
   }
}