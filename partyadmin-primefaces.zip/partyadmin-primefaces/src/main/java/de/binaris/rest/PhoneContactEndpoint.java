package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.parties.model.PhoneContact;
import de.binaris.rest.dto.PhoneContactDTO;

/**
 * 
 */
@Stateless
@Path("/phonecontacts")
public class PhoneContactEndpoint
{
   @PersistenceContext(unitName = "PartyadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(PhoneContactDTO dto)
   {
      PhoneContact entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(PhoneContactEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      PhoneContact entity = em.find(PhoneContact.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<PhoneContact> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM PhoneContact p LEFT JOIN FETCH p.party WHERE p.id = :entityId ORDER BY p.id", PhoneContact.class);
      findByIdQuery.setParameter("entityId", id);
      PhoneContact entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      PhoneContactDTO dto = new PhoneContactDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<PhoneContactDTO> listAll()
   {
      final List<PhoneContact> searchResults = em.createQuery("SELECT DISTINCT p FROM PhoneContact p LEFT JOIN FETCH p.party ORDER BY p.id", PhoneContact.class).getResultList();
      final List<PhoneContactDTO> results = new ArrayList<PhoneContactDTO>();
      for (PhoneContact searchResult : searchResults)
      {
         PhoneContactDTO dto = new PhoneContactDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, PhoneContactDTO dto)
   {
      TypedQuery<PhoneContact> findByIdQuery = em.createQuery("SELECT DISTINCT p FROM PhoneContact p LEFT JOIN FETCH p.party WHERE p.id = :entityId ORDER BY p.id", PhoneContact.class);
      findByIdQuery.setParameter("entityId", id);
      PhoneContact entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}