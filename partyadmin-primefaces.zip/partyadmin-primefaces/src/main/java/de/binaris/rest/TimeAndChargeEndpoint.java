package de.binaris.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;
import de.binaris.parties.model.TimeAndCharge;
import de.binaris.rest.dto.TimeAndChargeDTO;

/**
 * 
 */
@Stateless
@Path("/timeandcharges")
public class TimeAndChargeEndpoint
{
   @PersistenceContext(unitName = "PartyadminPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(TimeAndChargeDTO dto)
   {
      TimeAndCharge entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(TimeAndChargeEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      TimeAndCharge entity = em.find(TimeAndCharge.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<TimeAndCharge> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TimeAndCharge t LEFT JOIN FETCH t.party WHERE t.id = :entityId ORDER BY t.id", TimeAndCharge.class);
      findByIdQuery.setParameter("entityId", id);
      TimeAndCharge entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      TimeAndChargeDTO dto = new TimeAndChargeDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<TimeAndChargeDTO> listAll()
   {
      final List<TimeAndCharge> searchResults = em.createQuery("SELECT DISTINCT t FROM TimeAndCharge t LEFT JOIN FETCH t.party ORDER BY t.id", TimeAndCharge.class).getResultList();
      final List<TimeAndChargeDTO> results = new ArrayList<TimeAndChargeDTO>();
      for (TimeAndCharge searchResult : searchResults)
      {
         TimeAndChargeDTO dto = new TimeAndChargeDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, TimeAndChargeDTO dto)
   {
      TypedQuery<TimeAndCharge> findByIdQuery = em.createQuery("SELECT DISTINCT t FROM TimeAndCharge t LEFT JOIN FETCH t.party WHERE t.id = :entityId ORDER BY t.id", TimeAndCharge.class);
      findByIdQuery.setParameter("entityId", id);
      TimeAndCharge entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}