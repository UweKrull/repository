package de.binaris.parties.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "great_party")
public class Party implements Serializable {

	private static final long serialVersionUID = 7975779629657126329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_great_party")
	@SequenceGenerator(name = "my_entity_seq_gen_great_party", sequenceName = "sequence_great_party", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String name;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Venue venue;
	
	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;
	
    @Column(name = "host_name")
	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String hostname;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Category category;
	
	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
    private String schedule;
    
    @Column(name = "adult_only")
    @Enumerated(STRING)
    private AdultOnlyType adultOnly;
    
	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
	private String dressCode;
		
	@Size(min = 0, max = 200, message = "optional max. 200 letters and spaces")
	private String linkDetails;

	@Size(min = 0, max = 200, message = "optional max. 200 letters and spaces")
	private String linkBookOnlineAtVenue;
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "party")
	private Set<Customer> guest = new HashSet<Customer>();

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "party")
	private Set<DrinksAndBeverages> drinksAndBeverages = new HashSet<DrinksAndBeverages>();
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "party")
	private Set<TimeAndCharge> timeAndCharge = new HashSet<TimeAndCharge>();
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "party")
	private Set<PhoneContact> phoneContact = new HashSet<PhoneContact>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHostname() {
		return hostname;
	}
	
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}
	
	public Venue getVenue() {
		return venue;
	}
	
	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Set<DrinksAndBeverages> getDrinksAndBeverages() {
		return drinksAndBeverages;
	}

	public void setDrinksAndBeverages(Set<DrinksAndBeverages> drinksAndBeverages) {
		this.drinksAndBeverages = drinksAndBeverages;
	}

	public Set<TimeAndCharge> getTimeAndCharge() {
		return timeAndCharge;
	}
	
	public void setTimeAndCharge(Set<TimeAndCharge> timeAndCharge) {
		this.timeAndCharge = timeAndCharge;
	}
	
	public Set<PhoneContact> getPhoneContact() {
		return phoneContact;
	}

	public void setPhoneContact(Set<PhoneContact> phoneContact) {
		this.phoneContact = phoneContact;
	}

	public Set<Customer> getGuest() {
		return guest;
	}
	
	public void setGuest(Set<Customer> guest) {
		this.guest = guest;
	}
	
	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	public AdultOnlyType getAdultOnly() {
		return adultOnly;
	}

	public void setAdultOnly(AdultOnlyType adultOnly) {
		this.adultOnly = adultOnly;
	}

	public String getDressCode() {
		return dressCode;
	}

	public void setDressCode(String dressCode) {
		this.dressCode = dressCode;
	}

	public String getLinkDetails() {
		return linkDetails;
	}

	public void setLinkDetails(String linkDetails) {
		this.linkDetails = linkDetails;
	}

	public String getLinkBookOnlineAtVenue() {
		return linkBookOnlineAtVenue;
	}

	public void setLinkBookOnlineAtVenue(String linkBookOnlineAtVenue) {
		this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Party)) {
			return false;
		}
		Party castOther = (Party) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name);
		return sb.toString();
	}
}
