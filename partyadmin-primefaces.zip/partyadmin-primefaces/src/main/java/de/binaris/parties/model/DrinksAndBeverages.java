package de.binaris.parties.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "drinks_and_beverages")
public class DrinksAndBeverages implements Serializable {

	private static final long serialVersionUID = 7975779629657126329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_drinks_and_beverages")
	@SequenceGenerator(name = "my_entity_seq_gen_drinks_and_beverages", sequenceName = "sequence_drinks_and_beverages", allocationSize = 1)
	private Long id;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Party party;
	
	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String title;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private CategoryType categoryType;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Party getParty() {
		return party;
	}

	public void setParty(Party party) {
		this.party = party;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public CategoryType getCategoryType() {
		return categoryType;
	}

	public void setCategoryType(CategoryType categoryType) {
		this.categoryType = categoryType;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof DrinksAndBeverages)) {
			return false;
		}
		DrinksAndBeverages castOther = (DrinksAndBeverages) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(categoryType.toString());
		sb.append(", ");
		return sb.toString();
	}
}
