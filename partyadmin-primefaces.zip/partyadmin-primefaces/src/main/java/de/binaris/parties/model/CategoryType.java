package de.binaris.parties.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * This is the drinks and beverages category type 
 *   (e.g. drinks, sandwich, salad, burgers, etc.)
 * 
 * @author kuwe
 */
@Cacheable
@Entity
@Table(name = "category_type")
public class CategoryType implements Serializable {

	private static final long serialVersionUID = 1271789629777176727L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_category_type")
	@SequenceGenerator(name = "my_entity_seq_gen_category_type", sequenceName = "sequence_category_type", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "categoryType")
	private Set<DrinksAndBeverages> drinksAndBeverages = new HashSet<DrinksAndBeverages>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<DrinksAndBeverages> getDrinksAndBeverages() {
		return drinksAndBeverages;
	}

	public void setDrinksAndBeverages(Set<DrinksAndBeverages> drinksAndBeverages) {
		this.drinksAndBeverages = drinksAndBeverages;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof CategoryType)) {
			return false;
		}
		CategoryType castOther = (CategoryType) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return name + ", " + description;
	}
}
