package de.binaris.parties.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 * <p>
 * A time and charge related party offer.
 *
 * JPA requires to use the class level <code>@Table</code> name to ensure the
 * entity-table relation, if required.
 * </p>
 */
@Cacheable
@Entity
@Table(name = "time_and_charge")
public class TimeAndCharge implements Serializable {

	private static final long serialVersionUID = 7278971756722267965L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_time_and_charge")
	@SequenceGenerator(name = "my_entity_seq_gen_time_and_charge", sequenceName = "sequence_time_and_charge", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
	private String days;
	
	@NotNull
	@Size(min = 4, max = 40, message = "must be 4-40 letters and spaces")
	private String startTime;
	
	@NotNull
	@Size(min = 2, max = 40, message = "must be 2-40 letters and spaces")
	private String charge;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Party party;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String days) {
		this.days = days;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getCharge() {
		return charge;
	}

	public void setCharge(String charge) {
		this.charge = charge;
	}

	public Party getParty() {
		return party;
	}

	public void setParty(Party party) {
		this.party = party;
	}
	
	/*
	 * toString(), equals() and hashCode() for TimeAndCharge, using the natural
	 * identity of the object
	 */
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof TimeAndCharge)) {
			return false;
		}
		TimeAndCharge castOther = (TimeAndCharge) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(days).append(", ");
		sb.append(startTime).append(", ");
		sb.append(charge);
		return sb.toString();
	}
}
