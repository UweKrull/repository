package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;

import de.binaris.carpreselection.model.Category;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.carpreselection.model.SelectedCar;
import de.binaris.carpreselection.rest.dto.NestedSelectedCarDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CategoryDTO implements Serializable
{

   private Long id;
   private String description;
   private Set<NestedSelectedCarDTO> item = new HashSet<NestedSelectedCarDTO>();
   private String name;

   public CategoryDTO()
   {
   }

   public CategoryDTO(final Category entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.description = entity.getDescription();
         Iterator<SelectedCar> iterItem = entity.getItem().iterator();
         for (; iterItem.hasNext();)
         {
            SelectedCar element = iterItem.next();
            this.item.add(new NestedSelectedCarDTO(element));
         }
         this.name = entity.getName();
      }
   }

   public Category fromDTO(Category entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Category();
      }
      entity.setDescription(this.description);
      Iterator<SelectedCar> iterItem = entity.getItem().iterator();
      for (; iterItem.hasNext();)
      {
         boolean found = false;
         SelectedCar selectedCar = iterItem.next();
         Iterator<NestedSelectedCarDTO> iterDtoItem = this.getItem()
               .iterator();
         for (; iterDtoItem.hasNext();)
         {
            NestedSelectedCarDTO dtoSelectedCar = iterDtoItem.next();
            if (dtoSelectedCar.getId().equals(selectedCar.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterItem.remove();
         }
      }
      Iterator<NestedSelectedCarDTO> iterDtoItem = this.getItem().iterator();
      for (; iterDtoItem.hasNext();)
      {
         boolean found = false;
         NestedSelectedCarDTO dtoSelectedCar = iterDtoItem.next();
         iterItem = entity.getItem().iterator();
         for (; iterItem.hasNext();)
         {
            SelectedCar selectedCar = iterItem.next();
            if (dtoSelectedCar.getId().equals(selectedCar.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<SelectedCar> resultIter = em
                  .createQuery("SELECT DISTINCT s FROM SelectedCar s",
                        SelectedCar.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               SelectedCar result = resultIter.next();
               if (result.getId().equals(dtoSelectedCar.getId()))
               {
                  entity.getItem().add(result);
                  break;
               }
            }
         }
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public Set<NestedSelectedCarDTO> getItem()
   {
      return this.item;
   }

   public void setItem(final Set<NestedSelectedCarDTO> item)
   {
      this.item = item;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}