package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;
import de.binaris.carpreselection.model.WebDomain;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedWebDomainDTO implements Serializable
{

   private Long id;
   private String website;
   private String description;
   private String name;

   public NestedWebDomainDTO()
   {
   }

   public NestedWebDomainDTO(final WebDomain entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.website = entity.getWebsite();
         this.description = entity.getDescription();
         this.name = entity.getName();
      }
   }

   public WebDomain fromDTO(WebDomain entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new WebDomain();
      }
      if (this.id != null)
      {
         TypedQuery<WebDomain> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT w FROM WebDomain w WHERE w.id = :entityId",
                     WebDomain.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setWebsite(this.website);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getWebsite()
   {
      return this.website;
   }

   public void setWebsite(final String website)
   {
      this.website = website;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}