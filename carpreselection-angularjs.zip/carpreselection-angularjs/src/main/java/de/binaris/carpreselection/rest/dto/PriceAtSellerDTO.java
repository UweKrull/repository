package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;
import de.binaris.carpreselection.model.PriceAtSeller;
import javax.persistence.EntityManager;
import java.util.Date;
import de.binaris.carpreselection.model.TransportCostsType;
import de.binaris.carpreselection.model.OptionalFinancingType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PriceAtSellerDTO implements Serializable
{

   private Date dateOfPrice;
   private Long id;
   private TransportCostsType transportCosts;
   private String mwst;
   private OptionalFinancingType optionalFinancing;
   private String additionalFees;
   private String description;
   private String vat;
   private String currentPrice;

   public PriceAtSellerDTO()
   {
   }

   public PriceAtSellerDTO(final PriceAtSeller entity)
   {
      if (entity != null)
      {
         this.dateOfPrice = entity.getDateOfPrice();
         this.id = entity.getId();
         this.transportCosts = entity.getTransportCosts();
         this.mwst = entity.getMwst();
         this.optionalFinancing = entity.getOptionalFinancing();
         this.additionalFees = entity.getAdditionalFees();
         this.description = entity.getDescription();
         this.vat = entity.getVat();
         this.currentPrice = entity.getCurrentPrice();
      }
   }

   public PriceAtSeller fromDTO(PriceAtSeller entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new PriceAtSeller();
      }
      entity.setDateOfPrice(this.dateOfPrice);
      entity.setTransportCosts(this.transportCosts);
      entity.setMwst(this.mwst);
      entity.setOptionalFinancing(this.optionalFinancing);
      entity.setAdditionalFees(this.additionalFees);
      entity.setDescription(this.description);
      entity.setVat(this.vat);
      entity.setCurrentPrice(this.currentPrice);
      entity = em.merge(entity);
      return entity;
   }

   public Date getDateOfPrice()
   {
      return this.dateOfPrice;
   }

   public void setDateOfPrice(final Date dateOfPrice)
   {
      this.dateOfPrice = dateOfPrice;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public TransportCostsType getTransportCosts()
   {
      return this.transportCosts;
   }

   public void setTransportCosts(final TransportCostsType transportCosts)
   {
      this.transportCosts = transportCosts;
   }

   public String getMwst()
   {
      return this.mwst;
   }

   public void setMwst(final String mwst)
   {
      this.mwst = mwst;
   }

   public OptionalFinancingType getOptionalFinancing()
   {
      return this.optionalFinancing;
   }

   public void setOptionalFinancing(
         final OptionalFinancingType optionalFinancing)
   {
      this.optionalFinancing = optionalFinancing;
   }

   public String getAdditionalFees()
   {
      return this.additionalFees;
   }

   public void setAdditionalFees(final String additionalFees)
   {
      this.additionalFees = additionalFees;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getVat()
   {
      return this.vat;
   }

   public void setVat(final String vat)
   {
      this.vat = vat;
   }

   public String getCurrentPrice()
   {
      return this.currentPrice;
   }

   public void setCurrentPrice(final String currentPrice)
   {
      this.currentPrice = currentPrice;
   }
}