package de.binaris.carpreselection.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.carpreselection.model.SelectedCar;
import de.binaris.carpreselection.rest.dto.SelectedCarDTO;

@Stateless
@Path("/selectedcars")
public class SelectedCarEndpoint
{
   @PersistenceContext(unitName = "CarpreselectionPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(SelectedCarDTO dto)
   {
      SelectedCar entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(SelectedCarEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      SelectedCar entity = em.find(SelectedCar.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<SelectedCar> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM SelectedCar s LEFT JOIN FETCH s.car LEFT JOIN FETCH s.seller LEFT JOIN FETCH s.carSelectionList LEFT JOIN FETCH s.category LEFT JOIN FETCH s.priceAtSeller LEFT JOIN FETCH s.webDomain WHERE s.id = :entityId ORDER BY s.id", SelectedCar.class);
      findByIdQuery.setParameter("entityId", id);
      SelectedCar entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      SelectedCarDTO dto = new SelectedCarDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<SelectedCarDTO> listAll()
   {
      final List<SelectedCar> searchResults = em.createQuery("SELECT DISTINCT s FROM SelectedCar s LEFT JOIN FETCH s.car LEFT JOIN FETCH s.seller LEFT JOIN FETCH s.carSelectionList LEFT JOIN FETCH s.category LEFT JOIN FETCH s.priceAtSeller LEFT JOIN FETCH s.webDomain ORDER BY s.id", SelectedCar.class).getResultList();
      final List<SelectedCarDTO> results = new ArrayList<SelectedCarDTO>();
      for (SelectedCar searchResult : searchResults)
      {
         SelectedCarDTO dto = new SelectedCarDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, SelectedCarDTO dto)
   {
      TypedQuery<SelectedCar> findByIdQuery = em.createQuery("SELECT DISTINCT s FROM SelectedCar s LEFT JOIN FETCH s.car LEFT JOIN FETCH s.seller LEFT JOIN FETCH s.carSelectionList LEFT JOIN FETCH s.category LEFT JOIN FETCH s.priceAtSeller LEFT JOIN FETCH s.webDomain WHERE s.id = :entityId ORDER BY s.id", SelectedCar.class);
      findByIdQuery.setParameter("entityId", id);
      SelectedCar entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}