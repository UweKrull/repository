package de.binaris.carpreselection.model;

import static javax.persistence.EnumType.STRING;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "car")
public class Car implements Serializable {

	private static final long serialVersionUID = 75525222525127575L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_car")
	@SequenceGenerator(name = "my_entity_seq_gen_car", sequenceName = "sequence_car", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String name;

	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String brand;

	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String fuel;
	
	@Column(name = "transmission_type")
	@Enumerated(STRING)
	private TransmissionType transmission;
	
	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String age;
	
	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String km;
	
	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String PS;
	
	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String HU;
	
	@NotNull
	@Size(min = 1, max = 60, message = "must be 1-60 letters and spaces")
	@Column(name = "euro_sticker_type")
	private String euroNorm;
	
	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String EZ;
	
	@Size(min = 0, max = 500, message = "optional max. 500 letters and spaces")
	private String linkImage;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getFuel() {
		return fuel;
	}

	public void setFuel(String fuel) {
		this.fuel = fuel;
	}

	public TransmissionType getTransmission() {
		return transmission;
	}

	public void setTransmission(TransmissionType transmission) {
		this.transmission = transmission;
	}

	public String getKm() {
		return km;
	}

	public void setKm(String km) {
		this.km = km;
	}

	public String getPS() {
		return PS;
	}

	public void setPS(String pS) {
		PS = pS;
	}

	public String getHU() {
		return HU;
	}

	public void setHU(String hU) {
		HU = hU;
	}

	public String getEuroNorm() {
		return euroNorm;
	}

	public void setEuroNorm(String euroNorm) {
		this.euroNorm = euroNorm;
	}

	public String getEZ() {
		return EZ;
	}

	public void setEZ(String eZ) {
		EZ = eZ;
	}

	public String getLinkImage() {
		return linkImage;
	}

	public void setLinkImage(String linkImage) {
		this.linkImage = linkImage;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Car)) {
			return false;
		}
		Car castOther = (Car) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return name + ", " + brand;
	}
}
