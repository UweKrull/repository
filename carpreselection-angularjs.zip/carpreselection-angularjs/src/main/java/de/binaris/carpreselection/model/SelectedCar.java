package de.binaris.carpreselection.model;

import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "selected_car")
public class SelectedCar implements Serializable {

	private static final long serialVersionUID = 7975171029657126323L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_selected_car")
	@SequenceGenerator(name = "my_entity_seq_gen_selected_car", sequenceName = "sequence_selected_car", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 300, message = "must be 1-300 letters and spaces")
	private String title;
	
	@NotNull
	@Size(min = 1, max = 300, message = "must be 1-300 letters and spaces")
	private String linkToOffer;
	
	@ManyToOne
	private Car car;
	
	@ManyToOne
	private Seller seller;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private CarSelectionList carSelectionList;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Category category;
	
	@ManyToOne
	private PriceAtSeller priceAtSeller;
	
	@ManyToOne
	private WebDomain webDomain;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLinkToOffer() {
		return linkToOffer;
	}

	public void setLinkToOffer(String linkToOffer) {
		this.linkToOffer = linkToOffer;
	}

	public Car getCar() {
		return car;
	}
	
	public void setCar(Car car) {
		this.car = car;
	}
	
	public Seller getSeller() {
		return seller;
	}

	public void setSeller(Seller seller) {
		this.seller = seller;
	}

	public Category getCategory() {
		return category;
	}
	
	public void setCategory(Category category) {
		this.category = category;
	}
	
	public PriceAtSeller getPriceAtSeller() {
		return priceAtSeller;
	}
	
	public void setPriceAtSeller(PriceAtSeller priceAtSeller) {
		this.priceAtSeller = priceAtSeller;
	}
	
	public WebDomain getWebDomain() {
		return webDomain;
	}

	public void setWebDomain(WebDomain webDomain) {
		this.webDomain = webDomain;
	}

	public CarSelectionList getCarSelectionList() {
		return carSelectionList;
	}

	public void setCarSelectionList(CarSelectionList carSelectionList) {
		this.carSelectionList = carSelectionList;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof SelectedCar)) {
			return false;
		}
		SelectedCar castOther = (SelectedCar) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		if (title.length() > 20) {
			sb.append(title.substring(0, 20));
			sb.append("...");
		} else {
			sb.append(title);
		}
		sb.append(category.toString());
		return sb.toString();
	}
}
