package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;
import de.binaris.carpreselection.model.WebDomain;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class WebDomainDTO implements Serializable
{

   private Long id;
   private String website;
   private String description;
   private String name;

   public WebDomainDTO()
   {
   }

   public WebDomainDTO(final WebDomain entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.website = entity.getWebsite();
         this.description = entity.getDescription();
         this.name = entity.getName();
      }
   }

   public WebDomain fromDTO(WebDomain entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new WebDomain();
      }
      entity.setWebsite(this.website);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getWebsite()
   {
      return this.website;
   }

   public void setWebsite(final String website)
   {
      this.website = website;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}