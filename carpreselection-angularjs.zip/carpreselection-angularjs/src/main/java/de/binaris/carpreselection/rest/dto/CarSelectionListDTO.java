package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;

import de.binaris.carpreselection.model.CarSelectionList;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.carpreselection.model.SelectedCar;
import de.binaris.carpreselection.rest.dto.NestedSelectedCarDTO;
import de.binaris.carpreselection.rest.dto.NestedUserDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CarSelectionListDTO implements Serializable
{

   private Long id;
   private String title;
   private Set<NestedSelectedCarDTO> selectedCar = new HashSet<NestedSelectedCarDTO>();
   private NestedUserDTO user;

   public CarSelectionListDTO()
   {
   }

   public CarSelectionListDTO(final CarSelectionList entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         Iterator<SelectedCar> iterSelectedCar = entity.getSelectedCar()
               .iterator();
         for (; iterSelectedCar.hasNext();)
         {
            SelectedCar element = iterSelectedCar.next();
            this.selectedCar.add(new NestedSelectedCarDTO(element));
         }
         this.user = new NestedUserDTO(entity.getUser());
      }
   }

   public CarSelectionList fromDTO(CarSelectionList entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new CarSelectionList();
      }
      entity.setTitle(this.title);
      Iterator<SelectedCar> iterSelectedCar = entity.getSelectedCar()
            .iterator();
      for (; iterSelectedCar.hasNext();)
      {
         boolean found = false;
         SelectedCar selectedCar = iterSelectedCar.next();
         Iterator<NestedSelectedCarDTO> iterDtoSelectedCar = this
               .getSelectedCar().iterator();
         for (; iterDtoSelectedCar.hasNext();)
         {
            NestedSelectedCarDTO dtoSelectedCar = iterDtoSelectedCar.next();
            if (dtoSelectedCar.getId().equals(selectedCar.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterSelectedCar.remove();
         }
      }
      Iterator<NestedSelectedCarDTO> iterDtoSelectedCar = this
            .getSelectedCar().iterator();
      for (; iterDtoSelectedCar.hasNext();)
      {
         boolean found = false;
         NestedSelectedCarDTO dtoSelectedCar = iterDtoSelectedCar.next();
         iterSelectedCar = entity.getSelectedCar().iterator();
         for (; iterSelectedCar.hasNext();)
         {
            SelectedCar selectedCar = iterSelectedCar.next();
            if (dtoSelectedCar.getId().equals(selectedCar.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<SelectedCar> resultIter = em
                  .createQuery("SELECT DISTINCT s FROM SelectedCar s",
                        SelectedCar.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               SelectedCar result = resultIter.next();
               if (result.getId().equals(dtoSelectedCar.getId()))
               {
                  entity.getSelectedCar().add(result);
                  break;
               }
            }
         }
      }
      if (this.user != null)
      {
         entity.setUser(this.user.fromDTO(entity.getUser(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public Set<NestedSelectedCarDTO> getSelectedCar()
   {
      return this.selectedCar;
   }

   public void setSelectedCar(final Set<NestedSelectedCarDTO> selectedCar)
   {
      this.selectedCar = selectedCar;
   }

   public NestedUserDTO getUser()
   {
      return this.user;
   }

   public void setUser(final NestedUserDTO user)
   {
      this.user = user;
   }
}