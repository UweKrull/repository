package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;

import de.binaris.carpreselection.model.User;
import de.binaris.carpreselection.rest.dto.AddressDTO;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import java.util.Date;

public class NestedUserDTO implements Serializable
{

   private Date dateOfBirth;
   private String middleName;
   private Long id;
   private String lastName;
   private String phone;
   private AddressDTO address;
   private String email;
   private String login;
   private String firstName;
   private String password;

   public NestedUserDTO()
   {
   }

   public NestedUserDTO(final User entity)
   {
      if (entity != null)
      {
         this.dateOfBirth = entity.getDateOfBirth();
         this.middleName = entity.getMiddleName();
         this.id = entity.getId();
         this.lastName = entity.getLastName();
         this.phone = entity.getPhone();
         this.address = new AddressDTO(entity.getAddress());
         this.email = entity.getEmail();
         this.login = entity.getLogin();
         this.firstName = entity.getFirstName();
         this.password = entity.getPassword();
      }
   }

   public User fromDTO(User entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new User();
      }
      if (this.id != null)
      {
         TypedQuery<User> findByIdQuery = em.createQuery(
               "SELECT DISTINCT u FROM User u WHERE u.id = :entityId",
               User.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setDateOfBirth(this.dateOfBirth);
      entity.setMiddleName(this.middleName);
      entity.setLastName(this.lastName);
      entity.setPhone(this.phone);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setEmail(this.email);
      entity.setLogin(this.login);
      entity.setFirstName(this.firstName);
      entity.setPassword(this.password);
      entity = em.merge(entity);
      return entity;
   }

   public Date getDateOfBirth()
   {
      return this.dateOfBirth;
   }

   public void setDateOfBirth(final Date dateOfBirth)
   {
      this.dateOfBirth = dateOfBirth;
   }

   public String getMiddleName()
   {
      return this.middleName;
   }

   public void setMiddleName(final String middleName)
   {
      this.middleName = middleName;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getLastName()
   {
      return this.lastName;
   }

   public void setLastName(final String lastName)
   {
      this.lastName = lastName;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public String getLogin()
   {
      return this.login;
   }

   public void setLogin(final String login)
   {
      this.login = login;
   }

   public String getFirstName()
   {
      return this.firstName;
   }

   public void setFirstName(final String firstName)
   {
      this.firstName = firstName;
   }

   public String getPassword()
   {
      return this.password;
   }

   public void setPassword(final String password)
   {
      this.password = password;
   }
}