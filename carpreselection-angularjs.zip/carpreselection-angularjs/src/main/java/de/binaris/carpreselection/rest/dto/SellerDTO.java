package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;

import de.binaris.carpreselection.model.Seller;

import javax.persistence.EntityManager;

import java.util.Set;
import java.util.HashSet;

import de.binaris.carpreselection.model.SelectedCar;
import de.binaris.carpreselection.rest.dto.AddressDTO;
import de.binaris.carpreselection.rest.dto.NestedSelectedCarDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SellerDTO implements Serializable
{

   private Long id;
   private String phone;
   private AddressDTO address;
   private String website;
   private String email;
   private String location;
   private Set<NestedSelectedCarDTO> selectedCar = new HashSet<NestedSelectedCarDTO>();
   private String ownerFirstName;
   private String name;
   private String ownerLastName;
   private String linkGooglemaps;
   private String ownerMiddleName;

   public SellerDTO()
   {
   }

   public SellerDTO(final Seller entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.phone = entity.getPhone();
         this.address = new AddressDTO(entity.getAddress());
         this.website = entity.getWebsite();
         this.email = entity.getEmail();
         this.location = entity.getLocation();
         Iterator<SelectedCar> iterSelectedCar = entity.getSelectedCar()
               .iterator();
         for (; iterSelectedCar.hasNext();)
         {
            SelectedCar element = iterSelectedCar.next();
            this.selectedCar.add(new NestedSelectedCarDTO(element));
         }
         this.ownerFirstName = entity.getOwnerFirstName();
         this.name = entity.getName();
         this.ownerLastName = entity.getOwnerLastName();
         this.linkGooglemaps = entity.getLinkGooglemaps();
         this.ownerMiddleName = entity.getOwnerMiddleName();
      }
   }

   public Seller fromDTO(Seller entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Seller();
      }
      entity.setPhone(this.phone);
      if (this.address != null)
      {
         entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
      }
      entity.setWebsite(this.website);
      entity.setEmail(this.email);
      entity.setLocation(this.location);
      Iterator<SelectedCar> iterSelectedCar = entity.getSelectedCar()
            .iterator();
      for (; iterSelectedCar.hasNext();)
      {
         boolean found = false;
         SelectedCar selectedCar = iterSelectedCar.next();
         Iterator<NestedSelectedCarDTO> iterDtoSelectedCar = this
               .getSelectedCar().iterator();
         for (; iterDtoSelectedCar.hasNext();)
         {
            NestedSelectedCarDTO dtoSelectedCar = iterDtoSelectedCar.next();
            if (dtoSelectedCar.getId().equals(selectedCar.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            iterSelectedCar.remove();
         }
      }
      Iterator<NestedSelectedCarDTO> iterDtoSelectedCar = this
            .getSelectedCar().iterator();
      for (; iterDtoSelectedCar.hasNext();)
      {
         boolean found = false;
         NestedSelectedCarDTO dtoSelectedCar = iterDtoSelectedCar.next();
         iterSelectedCar = entity.getSelectedCar().iterator();
         for (; iterSelectedCar.hasNext();)
         {
            SelectedCar selectedCar = iterSelectedCar.next();
            if (dtoSelectedCar.getId().equals(selectedCar.getId()))
            {
               found = true;
               break;
            }
         }
         if (found == false)
         {
            Iterator<SelectedCar> resultIter = em
                  .createQuery("SELECT DISTINCT s FROM SelectedCar s",
                        SelectedCar.class).getResultList().iterator();
            for (; resultIter.hasNext();)
            {
               SelectedCar result = resultIter.next();
               if (result.getId().equals(dtoSelectedCar.getId()))
               {
                  entity.getSelectedCar().add(result);
                  break;
               }
            }
         }
      }
      entity.setOwnerFirstName(this.ownerFirstName);
      entity.setName(this.name);
      entity.setOwnerLastName(this.ownerLastName);
      entity.setLinkGooglemaps(this.linkGooglemaps);
      entity.setOwnerMiddleName(this.ownerMiddleName);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getPhone()
   {
      return this.phone;
   }

   public void setPhone(final String phone)
   {
      this.phone = phone;
   }

   public AddressDTO getAddress()
   {
      return this.address;
   }

   public void setAddress(final AddressDTO address)
   {
      this.address = address;
   }

   public String getWebsite()
   {
      return this.website;
   }

   public void setWebsite(final String website)
   {
      this.website = website;
   }

   public String getEmail()
   {
      return this.email;
   }

   public void setEmail(final String email)
   {
      this.email = email;
   }

   public String getLocation()
   {
      return this.location;
   }

   public void setLocation(final String location)
   {
      this.location = location;
   }

   public Set<NestedSelectedCarDTO> getSelectedCar()
   {
      return this.selectedCar;
   }

   public void setSelectedCar(final Set<NestedSelectedCarDTO> selectedCar)
   {
      this.selectedCar = selectedCar;
   }

   public String getOwnerFirstName()
   {
      return this.ownerFirstName;
   }

   public void setOwnerFirstName(final String ownerFirstName)
   {
      this.ownerFirstName = ownerFirstName;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getOwnerLastName()
   {
      return this.ownerLastName;
   }

   public void setOwnerLastName(final String ownerLastName)
   {
      this.ownerLastName = ownerLastName;
   }

   public String getLinkGooglemaps()
   {
      return this.linkGooglemaps;
   }

   public void setLinkGooglemaps(final String linkGooglemaps)
   {
      this.linkGooglemaps = linkGooglemaps;
   }

   public String getOwnerMiddleName()
   {
      return this.ownerMiddleName;
   }

   public void setOwnerMiddleName(final String ownerMiddleName)
   {
      this.ownerMiddleName = ownerMiddleName;
   }
}