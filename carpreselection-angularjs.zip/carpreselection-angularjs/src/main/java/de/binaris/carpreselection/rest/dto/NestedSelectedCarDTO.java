package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;
import de.binaris.carpreselection.model.SelectedCar;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedSelectedCarDTO implements Serializable
{

   private Long id;
   private String title;
   private String linkToOffer;

   public NestedSelectedCarDTO()
   {
   }

   public NestedSelectedCarDTO(final SelectedCar entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.title = entity.getTitle();
         this.linkToOffer = entity.getLinkToOffer();
      }
   }

   public SelectedCar fromDTO(SelectedCar entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new SelectedCar();
      }
      if (this.id != null)
      {
         TypedQuery<SelectedCar> findByIdQuery = em
               .createQuery(
                     "SELECT DISTINCT s FROM SelectedCar s WHERE s.id = :entityId",
                     SelectedCar.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setTitle(this.title);
      entity.setLinkToOffer(this.linkToOffer);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public String getLinkToOffer()
   {
      return this.linkToOffer;
   }

   public void setLinkToOffer(final String linkToOffer)
   {
      this.linkToOffer = linkToOffer;
   }
}