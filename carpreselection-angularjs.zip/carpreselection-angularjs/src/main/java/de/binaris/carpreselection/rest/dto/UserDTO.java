package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;

import de.binaris.carpreselection.model.User;

import javax.persistence.EntityManager;

import java.util.Date;
import java.util.Set;
import java.util.HashSet;

import de.binaris.carpreselection.model.CarSelectionList;
import de.binaris.carpreselection.rest.dto.AddressDTO;
import de.binaris.carpreselection.rest.dto.NestedCarSelectionListDTO;

import java.util.Iterator;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class UserDTO implements Serializable {

	private Date dateOfBirth;
	private String middleName;
	private Long id;
	private String lastName;
	private String phone;
	private Set<NestedCarSelectionListDTO> carSelectionList = new HashSet<NestedCarSelectionListDTO>();
	private AddressDTO address;
	private String email;
	private String login;
	private String firstName;
	private String password;

	public UserDTO() {
	}

	public UserDTO(final User entity) {
		if (entity != null) {
			this.dateOfBirth = entity.getDateOfBirth();
			this.middleName = entity.getMiddleName();
			this.id = entity.getId();
			this.lastName = entity.getLastName();
			this.phone = entity.getPhone();
			Iterator<CarSelectionList> iterCarSelectionList = entity.getCarSelectionList().iterator();
			for (; iterCarSelectionList.hasNext();) {
				CarSelectionList element = iterCarSelectionList.next();
				this.carSelectionList
						.add(new NestedCarSelectionListDTO(element));
			}
			this.address = new AddressDTO(entity.getAddress());
			this.email = entity.getEmail();
			this.login = entity.getLogin();
			this.firstName = entity.getFirstName();
			this.password = entity.getPassword();
		}
	}

	public User fromDTO(User entity, EntityManager em) {
		if (entity == null) {
			entity = new User();
		}
		entity.setDateOfBirth(this.dateOfBirth);
		entity.setMiddleName(this.middleName);
		entity.setLastName(this.lastName);
		entity.setPhone(this.phone);
		Iterator<CarSelectionList> iterCarSelectionList = entity
				.getCarSelectionList().iterator();
		for (; iterCarSelectionList.hasNext();) {
			boolean found = false;
			CarSelectionList carSelectionList = iterCarSelectionList.next();
			Iterator<NestedCarSelectionListDTO> iterDtoCarSelectionList = this
					.getCarSelectionList().iterator();
			for (; iterDtoCarSelectionList.hasNext();) {
				NestedCarSelectionListDTO dtoCarSelectionList = iterDtoCarSelectionList
						.next();
				if (dtoCarSelectionList.getId()
						.equals(carSelectionList.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				iterCarSelectionList.remove();
			}
		}
		Iterator<NestedCarSelectionListDTO> iterDtoCarSelectionList = this
				.getCarSelectionList().iterator();
		for (; iterDtoCarSelectionList.hasNext();) {
			boolean found = false;
			NestedCarSelectionListDTO dtoCarSelectionList = iterDtoCarSelectionList.next();
			iterCarSelectionList = entity.getCarSelectionList().iterator();
			for (; iterCarSelectionList.hasNext();) {
				CarSelectionList carSelectionList = iterCarSelectionList.next();
				if (dtoCarSelectionList.getId().equals(carSelectionList.getId())) {
					found = true;
					break;
				}
			}
			if (found == false) {
				Iterator<CarSelectionList> resultIter = em
						.createQuery(
								"SELECT DISTINCT c FROM CarSelectionList c",
								CarSelectionList.class).getResultList()
						.iterator();
				for (; resultIter.hasNext();) {
					CarSelectionList result = resultIter.next();
					if (result.getId().equals(dtoCarSelectionList.getId())) {
						entity.getCarSelectionList().add(result);
						break;
					}
				}
			}
		}
		if (this.address != null) {
			entity.setAddress(this.address.fromDTO(entity.getAddress(), em));
		}
		entity.setEmail(this.email);
		entity.setLogin(this.login);
		entity.setFirstName(this.firstName);
		entity.setPassword(this.password);
		entity = em.merge(entity);
		return entity;
	}

	public Date getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(final Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(final String middleName) {
		this.middleName = middleName;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(final Long id) {
		this.id = id;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(final String phone) {
		this.phone = phone;
	}

	public Set<NestedCarSelectionListDTO> getCarSelectionList() {
		return this.carSelectionList;
	}

	public void setCarSelectionList(final Set<NestedCarSelectionListDTO> carSelectionList) {
		this.carSelectionList = carSelectionList;
	}

	public AddressDTO getAddress() {
		return this.address;
	}

	public void setAddress(final AddressDTO address) {
		this.address = address;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(final String email) {
		this.email = email;
	}

	public String getLogin() {
		return this.login;
	}

	public void setLogin(final String login) {
		this.login = login;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(final String password) {
		this.password = password;
	}
}