package de.binaris.carpreselection.model;

import static javax.persistence.EnumType.STRING;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "price_at_seller")
public class PriceAtSeller implements Serializable {

	private static final long serialVersionUID = 2525779723359122329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_price_at_seller")
	@SequenceGenerator(name = "my_entity_seq_gen_price_at_seller", sequenceName = "sequence_price_at_seller", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 300, message = "must be 1-300 letters and spaces")
	private String description;
	
	@NotNull
	@Size(min = 1, max = 80, message = "must be 1-80 letters and spaces")
	private String currentPrice;

	@NotNull
	@Temporal(TemporalType.DATE)
	@Column(name = "date_of_price")
	private Date dateOfPrice;
	
	@NotNull
	@Size(min = 1, max = 20, message = "must be 1-20 letters and spaces")
	private String vat;
	
	@NotNull
	@Size(min = 1, max = 20, message = "must be 1-20 letters and spaces")
	private String mwst;
	
	@NotNull
	@Size(min = 1, max = 80, message = "must be 1-80 letters and spaces")
	private String additionalFees;

	@Column(name = "add_transport_costs")
	@Enumerated(STRING)
	private TransportCostsType transportCosts;
	
	@Column(name = "optional_financing")
	@Enumerated(STRING)
	private OptionalFinancingType optionalFinancing;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(String currentPrice) {
		this.currentPrice = currentPrice;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getDateOfPrice() {
		return dateOfPrice;
	}

	public void setDateOfPrice(Date dateOfPrice) {
		this.dateOfPrice = dateOfPrice;
	}

	public String getVat() {
		return vat;
	}

	public void setVat(String vat) {
		this.vat = vat;
	}

	public String getMwst() {
		return mwst;
	}

	public void setMwst(String mwst) {
		this.mwst = mwst;
	}

	public String getAdditionalFees() {
		return additionalFees;
	}

	public void setAdditionalFees(String additionalFees) {
		this.additionalFees = additionalFees;
	}

	public TransportCostsType getTransportCosts() {
		return transportCosts;
	}

	public void setTransportCosts(TransportCostsType transportCosts) {
		this.transportCosts = transportCosts;
	}

	public OptionalFinancingType getOptionalFinancing() {
		return optionalFinancing;
	}

	public void setOptionalFinancing(OptionalFinancingType optionalFinancing) {
		this.optionalFinancing = optionalFinancing;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof PriceAtSeller)) {
			return false;
		}
		PriceAtSeller castOther = (PriceAtSeller) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		return currentPrice;
	}
}
