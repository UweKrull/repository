package de.binaris.carpreselection.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import de.binaris.carpreselection.model.Address;

@Cacheable
@Entity
@Table(name = "seller")
public class Seller implements Serializable {

	private static final long serialVersionUID = 1575729729659127329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_seller")
	@SequenceGenerator(name = "my_entity_seq_gen_seller", sequenceName = "sequence_seller", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String name;								   // appointment place, e.g. a lounge

	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String location;							   // locationName of the lounge, e.g. Hilton Honours
	
	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String ownerFirstName;

	@Size(min = 0, max = 50, message = "must be max. 50 letters and spaces")
	private String ownerMiddleName;
	
	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String ownerLastName;

	@NotNull
	private String phone;

	@NotNull
	@NotEmpty
	@Email(message = "invalid email format")
	private String email;
	
	@Size(min = 0, max = 500, message = "optional max. 500 letters and spaces")
	private String website;

	@Size(min = 0, max = 500, message = "optional max. 500 letters and spaces")
	private String linkGooglemaps;
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "seller")
	private Set<SelectedCar> selectedCar = new HashSet<SelectedCar>();
	
	private Address address = new Address();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getOwnerFirstName() {
		return ownerFirstName;
	}

	public void setOwnerFirstName(String ownerFirstName) {
		this.ownerFirstName = ownerFirstName;
	}

	public String getOwnerMiddleName() {
		return ownerMiddleName;
	}

	public void setOwnerMiddleName(String ownerMiddleName) {
		this.ownerMiddleName = ownerMiddleName;
	}

	public String getOwnerLastName() {
		return ownerLastName;
	}

	public void setOwnerLastName(String ownerLastName) {
		this.ownerLastName = ownerLastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}
	
	public String getLinkGooglemaps() {
		return linkGooglemaps;
	}
	
	public void setLinkGooglemaps(String linkGooglemaps) {
		this.linkGooglemaps = linkGooglemaps;
	}
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public Set<SelectedCar> getSelectedCar() {
		return selectedCar;
	}

	public void setSelectedCar(Set<SelectedCar> selectedCar) {
		this.selectedCar = selectedCar;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Seller)) {
			return false;
		}
		Seller castOther = (Seller) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name).append(", ");
		sb.append(location).append(", ");
		return sb.toString();
	}
}
