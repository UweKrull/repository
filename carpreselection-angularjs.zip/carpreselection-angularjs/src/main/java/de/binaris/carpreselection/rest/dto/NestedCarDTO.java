package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;
import de.binaris.carpreselection.model.Car;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.carpreselection.model.TransmissionType;

public class NestedCarDTO implements Serializable
{

   private String euroNorm;
   private TransmissionType transmission;
   private String km;
   private String HU;
   private String EZ;
   private Long id;
   private String description;
   private String name;
   private String PS;
   private String linkImage;
   private String brand;
   private String fuel;

   public NestedCarDTO()
   {
   }

   public NestedCarDTO(final Car entity)
   {
      if (entity != null)
      {
         this.euroNorm = entity.getEuroNorm();
         this.transmission = entity.getTransmission();
         this.km = entity.getKm();
         this.HU = entity.getHU();
         this.EZ = entity.getEZ();
         this.id = entity.getId();
         this.description = entity.getDescription();
         this.name = entity.getName();
         this.PS = entity.getPS();
         this.linkImage = entity.getLinkImage();
         this.brand = entity.getBrand();
         this.fuel = entity.getFuel();
      }
   }

   public Car fromDTO(Car entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Car();
      }
      if (this.id != null)
      {
         TypedQuery<Car> findByIdQuery = em.createQuery(
               "SELECT DISTINCT c FROM Car c WHERE c.id = :entityId",
               Car.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setEuroNorm(this.euroNorm);
      entity.setTransmission(this.transmission);
      entity.setKm(this.km);
      entity.setHU(this.HU);
      entity.setEZ(this.EZ);
      entity.setDescription(this.description);
      entity.setName(this.name);
      entity.setPS(this.PS);
      entity.setLinkImage(this.linkImage);
      entity.setBrand(this.brand);
      entity.setFuel(this.fuel);
      entity = em.merge(entity);
      return entity;
   }

   public String getEuroNorm()
   {
      return this.euroNorm;
   }

   public void setEuroNorm(final String euroNorm)
   {
      this.euroNorm = euroNorm;
   }

   public TransmissionType getTransmission()
   {
      return this.transmission;
   }

   public void setTransmission(final TransmissionType transmission)
   {
      this.transmission = transmission;
   }

   public String getKm()
   {
      return this.km;
   }

   public void setKm(final String km)
   {
      this.km = km;
   }

   public String getHU()
   {
      return this.HU;
   }

   public void setHU(final String HU)
   {
      this.HU = HU;
   }

   public String getEZ()
   {
      return this.EZ;
   }

   public void setEZ(final String EZ)
   {
      this.EZ = EZ;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getPS()
   {
      return this.PS;
   }

   public void setPS(final String PS)
   {
      this.PS = PS;
   }

   public String getLinkImage()
   {
      return this.linkImage;
   }

   public void setLinkImage(final String linkImage)
   {
      this.linkImage = linkImage;
   }

   public String getBrand()
   {
      return this.brand;
   }

   public void setBrand(final String brand)
   {
      this.brand = brand;
   }

   public String getFuel()
   {
      return this.fuel;
   }

   public void setFuel(final String fuel)
   {
      this.fuel = fuel;
   }
}