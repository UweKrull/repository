package de.binaris.carpreselection.rest.dto;

import java.io.Serializable;

import de.binaris.carpreselection.model.SelectedCar;
import de.binaris.carpreselection.rest.dto.NestedCarDTO;
import de.binaris.carpreselection.rest.dto.NestedCarSelectionListDTO;
import de.binaris.carpreselection.rest.dto.NestedCategoryDTO;
import de.binaris.carpreselection.rest.dto.NestedPriceAtSellerDTO;
import de.binaris.carpreselection.rest.dto.NestedSellerDTO;
import de.binaris.carpreselection.rest.dto.NestedWebDomainDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class SelectedCarDTO implements Serializable
{

   private NestedCarDTO car;
   private Long id;
   private NestedCategoryDTO category;
   private String title;
   private String linkToOffer;
   private NestedWebDomainDTO webDomain;
   private NestedPriceAtSellerDTO priceAtSeller;
   private NestedCarSelectionListDTO carSelectionList;
   private NestedSellerDTO seller;

   public SelectedCarDTO()
   {
   }

   public SelectedCarDTO(final SelectedCar entity)
   {
      if (entity != null)
      {
         this.car = new NestedCarDTO(entity.getCar());
         this.id = entity.getId();
         this.category = new NestedCategoryDTO(entity.getCategory());
         this.title = entity.getTitle();
         this.linkToOffer = entity.getLinkToOffer();
         this.webDomain = new NestedWebDomainDTO(entity.getWebDomain());
         this.priceAtSeller = new NestedPriceAtSellerDTO(
               entity.getPriceAtSeller());
         this.carSelectionList = new NestedCarSelectionListDTO(
               entity.getCarSelectionList());
         this.seller = new NestedSellerDTO(entity.getSeller());
      }
   }

   public SelectedCar fromDTO(SelectedCar entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new SelectedCar();
      }
      if (this.car != null)
      {
         entity.setCar(this.car.fromDTO(entity.getCar(), em));
      }
      if (this.category != null)
      {
         entity.setCategory(this.category.fromDTO(entity.getCategory(), em));
      }
      entity.setTitle(this.title);
      entity.setLinkToOffer(this.linkToOffer);
      if (this.webDomain != null)
      {
         entity.setWebDomain(this.webDomain.fromDTO(entity.getWebDomain(),
               em));
      }
      if (this.priceAtSeller != null)
      {
         entity.setPriceAtSeller(this.priceAtSeller.fromDTO(
               entity.getPriceAtSeller(), em));
      }
      if (this.carSelectionList != null)
      {
         entity.setCarSelectionList(this.carSelectionList.fromDTO(
               entity.getCarSelectionList(), em));
      }
      if (this.seller != null)
      {
         entity.setSeller(this.seller.fromDTO(entity.getSeller(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public NestedCarDTO getCar()
   {
      return this.car;
   }

   public void setCar(final NestedCarDTO car)
   {
      this.car = car;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedCategoryDTO getCategory()
   {
      return this.category;
   }

   public void setCategory(final NestedCategoryDTO category)
   {
      this.category = category;
   }

   public String getTitle()
   {
      return this.title;
   }

   public void setTitle(final String title)
   {
      this.title = title;
   }

   public String getLinkToOffer()
   {
      return this.linkToOffer;
   }

   public void setLinkToOffer(final String linkToOffer)
   {
      this.linkToOffer = linkToOffer;
   }

   public NestedWebDomainDTO getWebDomain()
   {
      return this.webDomain;
   }

   public void setWebDomain(final NestedWebDomainDTO webDomain)
   {
      this.webDomain = webDomain;
   }

   public NestedPriceAtSellerDTO getPriceAtSeller()
   {
      return this.priceAtSeller;
   }

   public void setPriceAtSeller(final NestedPriceAtSellerDTO priceAtSeller)
   {
      this.priceAtSeller = priceAtSeller;
   }

   public NestedCarSelectionListDTO getCarSelectionList()
   {
      return this.carSelectionList;
   }

   public void setCarSelectionList(
         final NestedCarSelectionListDTO carSelectionList)
   {
      this.carSelectionList = carSelectionList;
   }

   public NestedSellerDTO getSeller()
   {
      return this.seller;
   }

   public void setSeller(final NestedSellerDTO seller)
   {
      this.seller = seller;
   }
}