package de.binaris.carpreselection.model;

/**
 * <p>
 * The {@link TransmissionType} describes the transmission types (AUTOMATIC, MANUAL)
 * 
 * Transmission is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the transmission types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link TransmissionType} describes, if the transmission
 * is an automatic or a manual one.
 * </p>
 */
public enum TransmissionType {

    /**
     * The TransmissionType.
     */
    AUTOMATIC("AUTOMATIC", true),
    MANUAL("MANUAL", true);

    /**
     * A human readable description of the transmission type.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the transmission type can be cached.
     */
    private final boolean cacheable;
    
    private TransmissionType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
