package de.binaris.carpreselection.model;

/**
 * <p>
 * The {@link OptionalFinancingType} describes the financing option (yes, no)
 * 
 * OptionalFinancing is represented by an enumeration. When used, you
 * should instruct JPA to store the enum value using it's String representation, 
 * to enable later reordering of the enum members,
 * without changing the data and keep the optional financing types changeable 
 *  
 * Simply add <code>@Enumerated(STRING)</code> to the field declaration.
 * 
 * The {@link OptionalFinancingType} describes, if additional transport 
 * costs exist or not.
 * </p>
 */
public enum OptionalFinancingType {

    /**
     * The OptionalFinancingType.
     */
    yes("yes", true),
    no("no", true);

    /**
     * A human readable description of the optional financing types.
     */
    private final String description;
    
    /**
     * A boolean flag indicating whether the optional financing type can be cached.
     */
    private final boolean cacheable;
    
    private OptionalFinancingType(String description, boolean cacheable) {
        this.description = description;
        this.cacheable = cacheable;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCacheable() {
        return cacheable;
    }
}
