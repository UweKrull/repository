

angular.module('carpreselectionangularjs').controller('EditCarController', function($scope, $routeParams, $location, CarResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.car = new CarResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/Cars");
        };
        CarResource.get({CarId:$routeParams.CarId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.car);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.car.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Cars");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Cars");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.car.$remove(successCallback, errorCallback);
    };
    
    $scope.transmissionList = [
        "AUTOMATIC",  
        "MANUAL"  
    ];
    
    $scope.get();
});