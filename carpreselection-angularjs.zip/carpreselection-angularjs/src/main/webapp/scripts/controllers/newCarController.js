
angular.module('carpreselectionangularjs').controller('NewCarController', function ($scope, $location, locationParser, CarResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.car = $scope.car || {};
    
    $scope.transmissionList = [
        "AUTOMATIC",
        "MANUAL"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Cars/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CarResource.save($scope.car, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Cars");
    };
});