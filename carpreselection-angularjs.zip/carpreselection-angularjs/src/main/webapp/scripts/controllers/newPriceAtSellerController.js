
angular.module('carpreselectionangularjs').controller('NewPriceAtSellerController', function ($scope, $location, locationParser, PriceAtSellerResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.priceAtSeller = $scope.priceAtSeller || {};
    
    $scope.transportCostsList = [
        "yes",
        "no"
    ];
    
    $scope.optionalFinancingList = [
        "yes",
        "no"
    ];
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/PriceAtSellers/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        PriceAtSellerResource.save($scope.priceAtSeller, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/PriceAtSellers");
    };
});