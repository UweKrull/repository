
angular.module('carpreselectionangularjs').controller('NewWebDomainController', function ($scope, $location, locationParser, WebDomainResource ) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.webDomain = $scope.webDomain || {};
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/WebDomains/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        WebDomainResource.save($scope.webDomain, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/WebDomains");
    };
});