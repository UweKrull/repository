

angular.module('carpreselectionangularjs').controller('EditSellerController', function($scope, $routeParams, $location, SellerResource , SelectedCarResource, CountryResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.seller = new SellerResource(self.original);
            SelectedCarResource.queryAll(function(items) {
                $scope.selectedCarSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.seller.selectedCar){
                        $.each($scope.seller.selectedCar, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.selectedCarSelection.push(labelObject);
                                $scope.seller.selectedCar.push(wrappedObject);
                            }
                        });
                        self.original.selectedCar = $scope.seller.selectedCar;
                    }
                    return labelObject;
                });
            });
            CountryResource.queryAll(function(items) {
                $scope.addresscountrySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.seller.address.country && item.id == $scope.seller.address.country.id) {
                        $scope.addresscountrySelection = labelObject;
                        $scope.seller.address.country = wrappedObject;
                        self.original.address.country = $scope.seller.address.country;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Sellers");
        };
        SellerResource.get({SellerId:$routeParams.SellerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.seller);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.seller.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Sellers");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Sellers");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.seller.$remove(successCallback, errorCallback);
    };
    
    $scope.selectedCarSelection = $scope.selectedCarSelection || [];
    $scope.$watch("selectedCarSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.seller) {
            $scope.seller.selectedCar = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.seller.selectedCar.push(collectionItem);
            });
        }
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.seller.address.country = {};
            $scope.seller.address.country.id = selection.value;
        }
    });
    
    $scope.get();
});