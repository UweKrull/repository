

angular.module('carpreselectionangularjs').controller('EditWebDomainController', function($scope, $routeParams, $location, WebDomainResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.webDomain = new WebDomainResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/WebDomains");
        };
        WebDomainResource.get({WebDomainId:$routeParams.WebDomainId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.webDomain);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.webDomain.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/WebDomains");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/WebDomains");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.webDomain.$remove(successCallback, errorCallback);
    };
    
    
    $scope.get();
});