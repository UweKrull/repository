

angular.module('carpreselectionangularjs').controller('EditSelectedCarController', function($scope, $routeParams, $location, SelectedCarResource , CarResource, SellerResource, CategoryResource, PriceAtSellerResource, WebDomainResource, CarSelectionListResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.selectedCar = new SelectedCarResource(self.original);
            CarResource.queryAll(function(items) {
                $scope.carSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.selectedCar.car && item.id == $scope.selectedCar.car.id) {
                        $scope.carSelection = labelObject;
                        $scope.selectedCar.car = wrappedObject;
                        self.original.car = $scope.selectedCar.car;
                    }
                    return labelObject;
                });
            });
            SellerResource.queryAll(function(items) {
                $scope.sellerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.selectedCar.seller && item.id == $scope.selectedCar.seller.id) {
                        $scope.sellerSelection = labelObject;
                        $scope.selectedCar.seller = wrappedObject;
                        self.original.seller = $scope.selectedCar.seller;
                    }
                    return labelObject;
                });
            });
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.selectedCar.category && item.id == $scope.selectedCar.category.id) {
                        $scope.categorySelection = labelObject;
                        $scope.selectedCar.category = wrappedObject;
                        self.original.category = $scope.selectedCar.category;
                    }
                    return labelObject;
                });
            });
            PriceAtSellerResource.queryAll(function(items) {
                $scope.priceAtSellerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.currentPrice
                    };
                    if($scope.selectedCar.priceAtSeller && item.id == $scope.selectedCar.priceAtSeller.id) {
                        $scope.priceAtSellerSelection = labelObject;
                        $scope.selectedCar.priceAtSeller = wrappedObject;
                        self.original.priceAtSeller = $scope.selectedCar.priceAtSeller;
                    }
                    return labelObject;
                });
            });
            WebDomainResource.queryAll(function(items) {
                $scope.webDomainSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.selectedCar.webDomain && item.id == $scope.selectedCar.webDomain.id) {
                        $scope.webDomainSelection = labelObject;
                        $scope.selectedCar.webDomain = wrappedObject;
                        self.original.webDomain = $scope.selectedCar.webDomain;
                    }
                    return labelObject;
                });
            });
            CarSelectionListResource.queryAll(function(items) {
                $scope.carSelectionListSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.selectedCar.carSelectionList && item.id == $scope.selectedCar.carSelectionList.id) {
                        $scope.carSelectionListSelection = labelObject;
                        $scope.selectedCar.carSelectionList = wrappedObject;
                        self.original.carSelectionList = $scope.selectedCar.carSelectionList;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/SelectedCars");
        };
        SelectedCarResource.get({SelectedCarId:$routeParams.SelectedCarId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.selectedCar);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.selectedCar.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/SelectedCars");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/SelectedCars");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.selectedCar.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("carSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedCar.car = {};
            $scope.selectedCar.car.id = selection.value;
        }
    });
    $scope.$watch("sellerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedCar.seller = {};
            $scope.selectedCar.seller.id = selection.value;
        }
    });
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedCar.category = {};
            $scope.selectedCar.category.id = selection.value;
        }
    });
    $scope.$watch("priceAtSellerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedCar.priceAtSeller = {};
            $scope.selectedCar.priceAtSeller.id = selection.value;
        }
    });
    $scope.$watch("webDomainSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedCar.webDomain = {};
            $scope.selectedCar.webDomain.id = selection.value;
        }
    });
    $scope.$watch("carSelectionListSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.selectedCar.carSelectionList = {};
            $scope.selectedCar.carSelectionList.id = selection.value;
        }
    });
    
    $scope.get();
});