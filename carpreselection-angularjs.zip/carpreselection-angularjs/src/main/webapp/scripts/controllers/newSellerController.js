
angular.module('carpreselectionangularjs').controller('NewSellerController', function ($scope, $location, locationParser, SellerResource , SelectedCarResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.seller = $scope.seller || {};
    
    $scope.selectedCarList = SelectedCarResource.queryAll(function(items){
        $scope.selectedCarSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("selectedCarSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.seller.selectedCar = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.seller.selectedCar.push(collectionItem);
            });
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.seller.address.country = {};
            $scope.seller.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Sellers/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SellerResource.save($scope.seller, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Sellers");
    };
});