

angular.module('carpreselectionangularjs').controller('EditCarSelectionListController', function($scope, $routeParams, $location, CarSelectionListResource , UserResource, SelectedCarResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.carSelectionList = new CarSelectionListResource(self.original);
            UserResource.queryAll(function(items) {
                $scope.userSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.firstName
                    };
                    if($scope.carSelectionList.user && item.id == $scope.carSelectionList.user.id) {
                        $scope.userSelection = labelObject;
                        $scope.carSelectionList.user = wrappedObject;
                        self.original.user = $scope.carSelectionList.user;
                    }
                    return labelObject;
                });
            });
            SelectedCarResource.queryAll(function(items) {
                $scope.selectedCarSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.title
                    };
                    if($scope.carSelectionList.selectedCar){
                        $.each($scope.carSelectionList.selectedCar, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.selectedCarSelection.push(labelObject);
                                $scope.carSelectionList.selectedCar.push(wrappedObject);
                            }
                        });
                        self.original.selectedCar = $scope.carSelectionList.selectedCar;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/CarSelectionLists");
        };
        CarSelectionListResource.get({CarSelectionListId:$routeParams.CarSelectionListId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.carSelectionList);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.carSelectionList.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/CarSelectionLists");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/CarSelectionLists");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.carSelectionList.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("userSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.carSelectionList.user = {};
            $scope.carSelectionList.user.id = selection.value;
        }
    });
    $scope.selectedCarSelection = $scope.selectedCarSelection || [];
    $scope.$watch("selectedCarSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.carSelectionList) {
            $scope.carSelectionList.selectedCar = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.carSelectionList.selectedCar.push(collectionItem);
            });
        }
    });
    
    $scope.get();
});