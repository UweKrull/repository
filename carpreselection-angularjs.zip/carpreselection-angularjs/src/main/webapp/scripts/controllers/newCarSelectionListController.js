
angular.module('carpreselectionangularjs').controller('NewCarSelectionListController', function ($scope, $location, locationParser, CarSelectionListResource , UserResource, SelectedCarResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.carSelectionList = $scope.carSelectionList || {};
    
    $scope.userList = UserResource.queryAll(function(items){
        $scope.userSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.firstName
            });
        });
    });
    $scope.$watch("userSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.carSelectionList.user = {};
            $scope.carSelectionList.user.id = selection.value;
        }
    });
    
    $scope.selectedCarList = SelectedCarResource.queryAll(function(items){
        $scope.selectedCarSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("selectedCarSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.carSelectionList.selectedCar = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.carSelectionList.selectedCar.push(collectionItem);
            });
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/CarSelectionLists/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CarSelectionListResource.save($scope.carSelectionList, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/CarSelectionLists");
    };
});