

angular.module('carpreselectionangularjs').controller('EditPriceAtSellerController', function($scope, $routeParams, $location, PriceAtSellerResource ) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.priceAtSeller = new PriceAtSellerResource(self.original);
        };
        var errorCallback = function() {
            $location.path("/PriceAtSellers");
        };
        PriceAtSellerResource.get({PriceAtSellerId:$routeParams.PriceAtSellerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.priceAtSeller);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.priceAtSeller.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/PriceAtSellers");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/PriceAtSellers");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.priceAtSeller.$remove(successCallback, errorCallback);
    };
    
    $scope.transportCostsList = [
        "yes",  
        "no"  
    ];
    $scope.optionalFinancingList = [
        "yes",  
        "no"  
    ];
    
    $scope.get();
});