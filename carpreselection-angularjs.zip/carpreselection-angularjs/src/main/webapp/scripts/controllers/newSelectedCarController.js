
angular.module('carpreselectionangularjs').controller('NewSelectedCarController', function ($scope, $location, locationParser, SelectedCarResource , CarResource, SellerResource, CategoryResource, PriceAtSellerResource, WebDomainResource, CarSelectionListResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.selectedCar = $scope.selectedCar || {};
    
    $scope.carList = CarResource.queryAll(function(items){
        $scope.carSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("carSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedCar.car = {};
            $scope.selectedCar.car.id = selection.value;
        }
    });
    
    $scope.sellerList = SellerResource.queryAll(function(items){
        $scope.sellerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("sellerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedCar.seller = {};
            $scope.selectedCar.seller.id = selection.value;
        }
    });
    
    $scope.categoryList = CategoryResource.queryAll(function(items){
        $scope.categorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("categorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedCar.category = {};
            $scope.selectedCar.category.id = selection.value;
        }
    });
    
    $scope.priceAtSellerList = PriceAtSellerResource.queryAll(function(items){
        $scope.priceAtSellerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.currentPrice
            });
        });
    });
    $scope.$watch("priceAtSellerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedCar.priceAtSeller = {};
            $scope.selectedCar.priceAtSeller.id = selection.value;
        }
    });
    
    $scope.webDomainList = WebDomainResource.queryAll(function(items){
        $scope.webDomainSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("webDomainSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedCar.webDomain = {};
            $scope.selectedCar.webDomain.id = selection.value;
        }
    });
    
    $scope.carSelectionListList = CarSelectionListResource.queryAll(function(items){
        $scope.carSelectionListSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.title
            });
        });
    });
    $scope.$watch("carSelectionListSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.selectedCar.carSelectionList = {};
            $scope.selectedCar.carSelectionList.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/SelectedCars/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        SelectedCarResource.save($scope.selectedCar, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/SelectedCars");
    };
});