angular.module('carpreselectionangularjs').factory('WebDomainResource', function($resource){
    var resource = $resource('rest/webdomains/:WebDomainId',{WebDomainId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});