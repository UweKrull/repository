'use strict';

angular.module('carpreselectionangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Cars',{templateUrl:'views/Car/search.html',controller:'SearchCarController'})
      .when('/Cars/new',{templateUrl:'views/Car/detail.html',controller:'NewCarController'})
      .when('/Cars/edit/:CarId',{templateUrl:'views/Car/detail.html',controller:'EditCarController'})
      .when('/CarSelectionLists',{templateUrl:'views/CarSelectionList/search.html',controller:'SearchCarSelectionListController'})
      .when('/CarSelectionLists/new',{templateUrl:'views/CarSelectionList/detail.html',controller:'NewCarSelectionListController'})
      .when('/CarSelectionLists/edit/:CarSelectionListId',{templateUrl:'views/CarSelectionList/detail.html',controller:'EditCarSelectionListController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/PriceAtSellers',{templateUrl:'views/PriceAtSeller/search.html',controller:'SearchPriceAtSellerController'})
      .when('/PriceAtSellers/new',{templateUrl:'views/PriceAtSeller/detail.html',controller:'NewPriceAtSellerController'})
      .when('/PriceAtSellers/edit/:PriceAtSellerId',{templateUrl:'views/PriceAtSeller/detail.html',controller:'EditPriceAtSellerController'})
      .when('/SelectedCars',{templateUrl:'views/SelectedCar/search.html',controller:'SearchSelectedCarController'})
      .when('/SelectedCars/new',{templateUrl:'views/SelectedCar/detail.html',controller:'NewSelectedCarController'})
      .when('/SelectedCars/edit/:SelectedCarId',{templateUrl:'views/SelectedCar/detail.html',controller:'EditSelectedCarController'})
      .when('/Sellers',{templateUrl:'views/Seller/search.html',controller:'SearchSellerController'})
      .when('/Sellers/new',{templateUrl:'views/Seller/detail.html',controller:'NewSellerController'})
      .when('/Sellers/edit/:SellerId',{templateUrl:'views/Seller/detail.html',controller:'EditSellerController'})
      .when('/Users',{templateUrl:'views/User/search.html',controller:'SearchUserController'})
      .when('/Users/new',{templateUrl:'views/User/detail.html',controller:'NewUserController'})
      .when('/Users/edit/:UserId',{templateUrl:'views/User/detail.html',controller:'EditUserController'})
      .when('/WebDomains',{templateUrl:'views/WebDomain/search.html',controller:'SearchWebDomainController'})
      .when('/WebDomains/new',{templateUrl:'views/WebDomain/detail.html',controller:'NewWebDomainController'})
      .when('/WebDomains/edit/:WebDomainId',{templateUrl:'views/WebDomain/detail.html',controller:'EditWebDomainController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
