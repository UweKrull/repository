'use strict';

angular.module('showadmin',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/BookByPhones',{templateUrl:'views/BookByPhone/search.html',controller:'SearchBookByPhoneController'})
      .when('/BookByPhones/new',{templateUrl:'views/BookByPhone/detail.html',controller:'NewBookByPhoneController'})
      .when('/BookByPhones/edit/:BookByPhoneId',{templateUrl:'views/BookByPhone/detail.html',controller:'EditBookByPhoneController'})
      .when('/Categorys',{templateUrl:'views/Category/search.html',controller:'SearchCategoryController'})
      .when('/Categorys/new',{templateUrl:'views/Category/detail.html',controller:'NewCategoryController'})
      .when('/Categorys/edit/:CategoryId',{templateUrl:'views/Category/detail.html',controller:'EditCategoryController'})
      .when('/Countrys',{templateUrl:'views/Country/search.html',controller:'SearchCountryController'})
      .when('/Countrys/new',{templateUrl:'views/Country/detail.html',controller:'NewCountryController'})
      .when('/Countrys/edit/:CountryId',{templateUrl:'views/Country/detail.html',controller:'EditCountryController'})
      .when('/Shows',{templateUrl:'views/Show/search.html',controller:'SearchShowController'})
      .when('/Shows/new',{templateUrl:'views/Show/detail.html',controller:'NewShowController'})
      .when('/Shows/edit/:ShowId',{templateUrl:'views/Show/detail.html',controller:'EditShowController'})
      .when('/TimeAndPrices',{templateUrl:'views/TimeAndPrice/search.html',controller:'SearchTimeAndPriceController'})
      .when('/TimeAndPrices/new',{templateUrl:'views/TimeAndPrice/detail.html',controller:'NewTimeAndPriceController'})
      .when('/TimeAndPrices/edit/:TimeAndPriceId',{templateUrl:'views/TimeAndPrice/detail.html',controller:'EditTimeAndPriceController'})
      .when('/Venues',{templateUrl:'views/Venue/search.html',controller:'SearchVenueController'})
      .when('/Venues/new',{templateUrl:'views/Venue/detail.html',controller:'NewVenueController'})
      .when('/Venues/edit/:VenueId',{templateUrl:'views/Venue/detail.html',controller:'EditVenueController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
