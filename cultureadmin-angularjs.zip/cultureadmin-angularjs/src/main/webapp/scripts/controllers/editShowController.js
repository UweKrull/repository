

angular.module('showadmin').controller('EditShowController', function($scope, $routeParams, $location, ShowResource , VenueResource, CategoryResource, TimeAndPriceResource, BookByPhoneResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.show = new ShowResource(self.original);
            VenueResource.queryAll(function(items) {
                $scope.venueSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.show.venue && item.id == $scope.show.venue.id) {
                        $scope.venueSelection = labelObject;
                        $scope.show.venue = wrappedObject;
                        self.original.venue = $scope.show.venue;
                    }
                    return labelObject;
                });
            });
            CategoryResource.queryAll(function(items) {
                $scope.categorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.show.category && item.id == $scope.show.category.id) {
                        $scope.categorySelection = labelObject;
                        $scope.show.category = wrappedObject;
                        self.original.category = $scope.show.category;
                    }
                    return labelObject;
                });
            });
            TimeAndPriceResource.queryAll(function(items) {
                $scope.timeAndPriceSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.days+','+item.startTime+','+item.price+','+item.seating+','+item.seller
                    };
                    if($scope.show.timeAndPrice){
                        $.each($scope.show.timeAndPrice, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.timeAndPriceSelection.push(labelObject);
                                $scope.show.timeAndPrice.push(wrappedObject);
                            }
                        });
                        self.original.timeAndPrice = $scope.show.timeAndPrice;
                    }
                    return labelObject;
                });
            });
            BookByPhoneResource.queryAll(function(items) {
                $scope.bookByPhoneSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.phoneNumber+', '+item.name
                    };
                    if($scope.show.bookByPhone){
                        $.each($scope.show.bookByPhone, function(idx, element) {
                            if(item.id == element.id) {
                                $scope.bookByPhoneSelection.push(labelObject);
                                $scope.show.bookByPhone.push(wrappedObject);
                            }
                        });
                        self.original.bookByPhone = $scope.show.bookByPhone;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Shows");
        };
        ShowResource.get({ShowId:$routeParams.ShowId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.show);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.show.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Shows");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/Shows");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.show.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("venueSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.show.venue = {};
            $scope.show.venue.id = selection.value;
        }
    });
    $scope.$watch("categorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.show.category = {};
            $scope.show.category.id = selection.value;
        }
    });
    $scope.timeAndPriceSelection = $scope.timeAndPriceSelection || [];
    $scope.$watch("timeAndPriceSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.show) {
            $scope.show.timeAndPrice = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.show.timeAndPrice.push(collectionItem);
            });
        }
    });
    $scope.bookByPhoneSelection = $scope.bookByPhoneSelection || [];
    $scope.$watch("bookByPhoneSelection", function(selection) {
        if (typeof selection != 'undefined' && $scope.show) {
            $scope.show.bookByPhone = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.show.bookByPhone.push(collectionItem);
            });
        }
    });
    $scope.adultOnlyList = [
        "yes",  
        "no"  
    ];
    
    $scope.get();
});