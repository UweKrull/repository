
angular.module('showadmin').controller('NewVenueController', function ($scope, $location, locationParser, VenueResource , ShowResource, CountryResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.venue = $scope.venue || {};
    
    $scope.showList = ShowResource.queryAll(function(items){
        $scope.showSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("showSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.venue.show = [];
            $.each(selection, function(idx,selectedItem) {
                var collectionItem = {};
                collectionItem.id = selectedItem.value;
                $scope.venue.show.push(collectionItem);
            });
        }
    });
    
    $scope.addresscountryList = CountryResource.queryAll(function(items){
        $scope.addresscountrySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("addresscountrySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.venue.address.country = {};
            $scope.venue.address.country.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Venues/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        VenueResource.save($scope.venue, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Venues");
    };
});