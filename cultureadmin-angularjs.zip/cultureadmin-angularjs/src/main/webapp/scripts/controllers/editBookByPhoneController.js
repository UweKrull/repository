

angular.module('showadmin').controller('EditBookByPhoneController', function($scope, $routeParams, $location, BookByPhoneResource , ShowResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.bookByPhone = new BookByPhoneResource(self.original);
            ShowResource.queryAll(function(items) {
                $scope.showSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.bookByPhone.show && item.id == $scope.bookByPhone.show.id) {
                        $scope.showSelection = labelObject;
                        $scope.bookByPhone.show = wrappedObject;
                        self.original.show = $scope.bookByPhone.show;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/BookByPhones");
        };
        BookByPhoneResource.get({BookByPhoneId:$routeParams.BookByPhoneId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.bookByPhone);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.bookByPhone.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/BookByPhones");
    };

    $scope.remove = function() {
        var successCallback = function() {
            $location.path("/BookByPhones");
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        }; 
        $scope.bookByPhone.$remove(successCallback, errorCallback);
    };
    
    $scope.$watch("showSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.bookByPhone.show = {};
            $scope.bookByPhone.show.id = selection.value;
        }
    });
    
    $scope.get();
});