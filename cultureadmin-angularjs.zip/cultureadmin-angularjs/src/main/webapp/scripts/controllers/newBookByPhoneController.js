
angular.module('showadmin').controller('NewBookByPhoneController', function ($scope, $location, locationParser, BookByPhoneResource , ShowResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.bookByPhone = $scope.bookByPhone || {};
    
    $scope.showList = ShowResource.queryAll(function(items){
        $scope.showSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("showSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.bookByPhone.show = {};
            $scope.bookByPhone.show.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/BookByPhones/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        BookByPhoneResource.save($scope.bookByPhone, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/BookByPhones");
    };
});