package de.binaris.shows.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "great_show")
public class Show implements Serializable {

	private static final long serialVersionUID = 7975779629657126329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_great_show")
	@SequenceGenerator(name = "my_entity_seq_gen_great_show", sequenceName = "sequence_great_show", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String name;
	
	@ManyToOne(fetch = EAGER)
	@NotNull
	private Venue venue;
	
	@NotNull
	@Size(min = 1, max = 3000, message = "must be 1-3000 letters and spaces")
	private String description;

	@ManyToOne(fetch = EAGER)
	@NotNull
	private Category category;
	
	@NotNull
	@Size(min = 2, max = 10, message = "must be 2-10 letters and spaces")
	private String priceRangeMin;
	
	@NotNull
	@Size(min = 2, max = 10, message = "must be 2-10 letters and spaces")
	private String priceRangeMax;
	
	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
    private String schedule;
    
    @Column(name = "adult_only")
    @Enumerated(STRING)
    private AdultOnlyType adultOnly;
    
	@NotNull
	@Size(min = 2, max = 100, message = "must be 2-100 letters and spaces")
	private String dressCode;
	
	@NotNull
	@Size(min = 5, max = 200, message = "must be 5-200 letters and spaces")
	private String linkDetails;
	
	@NotNull
	@Size(min = 5, max = 200, message = "must be 5-200 letters and spaces")
	private String linkSeatingChart;
	
	@NotNull
	@Size(min = 5, max = 200, message = "must be 5-200 letters and spaces")
	private String linkBookOnlineAtShowtickets;
	
	@NotNull
	@Size(min = 5, max = 200, message = "must be 5-200 letters and spaces")
	private String linkBookOnlineAtVenue;
	
	@NotNull
	@Size(min = 5, max = 200, message = "must be 5-200 letters and spaces")
	private String linkBookOnlineAtTicketmaster;
	
	@NotNull
	@Size(min = 5, max = 200, message = "must be 5-200 letters and spaces")
	private String linkBookOnlineLocally;
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "show")
	private Set<TimeAndPrice> timeAndPrice = new HashSet<TimeAndPrice>();
	
	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "show")
	private Set<BookByPhone> bookByPhone = new HashSet<BookByPhone>();
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Venue getVenue() {
		return venue;
	}
	
	public void setVenue(Venue venue) {
		this.venue = venue;
	}

	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Set<TimeAndPrice> getTimeAndPrice() {
		return timeAndPrice;
	}

	public void setTimeAndPrice(Set<TimeAndPrice> timeAndPrice) {
		this.timeAndPrice = timeAndPrice;
	}

	public Set<BookByPhone> getBookByPhone() {
		return bookByPhone;
	}

	public void setBookByPhone(Set<BookByPhone> bookByPhone) {
		this.bookByPhone = bookByPhone;
	}

	public String getPriceRangeMin() {
		return priceRangeMin;
	}

	public void setPriceRangeMin(String priceRangeMin) {
		this.priceRangeMin = priceRangeMin;
	}

	public String getPriceRangeMax() {
		return priceRangeMax;
	}

	public void setPriceRangeMax(String priceRangeMax) {
		this.priceRangeMax = priceRangeMax;
	}

	public String getSchedule() {
		return schedule;
	}

	public void setSchedule(String schedule) {
		this.schedule = schedule;
	}

	public AdultOnlyType getAdultOnly() {
		return adultOnly;
	}

	public void setAdultOnly(AdultOnlyType adultOnly) {
		this.adultOnly = adultOnly;
	}

	public String getDressCode() {
		return dressCode;
	}

	public void setDressCode(String dressCode) {
		this.dressCode = dressCode;
	}

	public String getLinkDetails() {
		return linkDetails;
	}

	public void setLinkDetails(String linkDetails) {
		this.linkDetails = linkDetails;
	}

	public String getLinkSeatingChart() {
		return linkSeatingChart;
	}

	public void setLinkSeatingChart(String linkSeatingChart) {
		this.linkSeatingChart = linkSeatingChart;
	}

	public String getLinkBookOnlineAtShowtickets() {
		return linkBookOnlineAtShowtickets;
	}

	public void setLinkBookOnlineAtShowtickets(String linkBookOnlineAtShowtickets) {
		this.linkBookOnlineAtShowtickets = linkBookOnlineAtShowtickets;
	}

	public String getLinkBookOnlineAtVenue() {
		return linkBookOnlineAtVenue;
	}

	public void setLinkBookOnlineAtVenue(String linkBookOnlineAtVenue) {
		this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
	}

	public String getLinkBookOnlineAtTicketmaster() {
		return linkBookOnlineAtTicketmaster;
	}

	public void setLinkBookOnlineAtTicketmaster(String linkBookOnlineAtTicketmaster) {
		this.linkBookOnlineAtTicketmaster = linkBookOnlineAtTicketmaster;
	}

	public String getLinkBookOnlineLocally() {
		return linkBookOnlineLocally;
	}

	public void setLinkBookOnlineLocally(String linkBookOnlineLocally) {
		this.linkBookOnlineLocally = linkBookOnlineLocally;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Show)) {
			return false;
		}
		Show castOther = (Show) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name);
		return sb.toString();
	}
}
