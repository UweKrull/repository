package de.binaris.shows.rest.dto;

import java.io.Serializable;
import de.binaris.shows.model.Show;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import de.binaris.shows.model.AdultOnlyType;

public class NestedShowDTO implements Serializable
{

   private String priceRangeMin;
   private String linkBookOnlineAtVenue;
   private String dressCode;
   private Long id;
   private String linkBookOnlineAtTicketmaster;
   private String schedule;
   private AdultOnlyType adultOnly;
   private String linkBookOnlineAtShowtickets;
   private String description;
   private String priceRangeMax;
   private String name;
   private String linkDetails;
   private String linkSeatingChart;
   private String linkBookOnlineLocally;

   public NestedShowDTO()
   {
   }

   public NestedShowDTO(final Show entity)
   {
      if (entity != null)
      {
         this.priceRangeMin = entity.getPriceRangeMin();
         this.linkBookOnlineAtVenue = entity.getLinkBookOnlineAtVenue();
         this.dressCode = entity.getDressCode();
         this.id = entity.getId();
         this.linkBookOnlineAtTicketmaster = entity
               .getLinkBookOnlineAtTicketmaster();
         this.schedule = entity.getSchedule();
         this.adultOnly = entity.getAdultOnly();
         this.linkBookOnlineAtShowtickets = entity
               .getLinkBookOnlineAtShowtickets();
         this.description = entity.getDescription();
         this.priceRangeMax = entity.getPriceRangeMax();
         this.name = entity.getName();
         this.linkDetails = entity.getLinkDetails();
         this.linkSeatingChart = entity.getLinkSeatingChart();
         this.linkBookOnlineLocally = entity.getLinkBookOnlineLocally();
      }
   }

   public Show fromDTO(Show entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Show();
      }
      if (this.id != null)
      {
         TypedQuery<Show> findByIdQuery = em.createQuery(
               "SELECT DISTINCT s FROM Show s WHERE s.id = :entityId",
               Show.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setPriceRangeMin(this.priceRangeMin);
      entity.setLinkBookOnlineAtVenue(this.linkBookOnlineAtVenue);
      entity.setDressCode(this.dressCode);
      entity.setLinkBookOnlineAtTicketmaster(this.linkBookOnlineAtTicketmaster);
      entity.setSchedule(this.schedule);
      entity.setAdultOnly(this.adultOnly);
      entity.setLinkBookOnlineAtShowtickets(this.linkBookOnlineAtShowtickets);
      entity.setDescription(this.description);
      entity.setPriceRangeMax(this.priceRangeMax);
      entity.setName(this.name);
      entity.setLinkDetails(this.linkDetails);
      entity.setLinkSeatingChart(this.linkSeatingChart);
      entity.setLinkBookOnlineLocally(this.linkBookOnlineLocally);
      entity = em.merge(entity);
      return entity;
   }

   public String getPriceRangeMin()
   {
      return this.priceRangeMin;
   }

   public void setPriceRangeMin(final String priceRangeMin)
   {
      this.priceRangeMin = priceRangeMin;
   }

   public String getLinkBookOnlineAtVenue()
   {
      return this.linkBookOnlineAtVenue;
   }

   public void setLinkBookOnlineAtVenue(final String linkBookOnlineAtVenue)
   {
      this.linkBookOnlineAtVenue = linkBookOnlineAtVenue;
   }

   public String getDressCode()
   {
      return this.dressCode;
   }

   public void setDressCode(final String dressCode)
   {
      this.dressCode = dressCode;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getLinkBookOnlineAtTicketmaster()
   {
      return this.linkBookOnlineAtTicketmaster;
   }

   public void setLinkBookOnlineAtTicketmaster(
         final String linkBookOnlineAtTicketmaster)
   {
      this.linkBookOnlineAtTicketmaster = linkBookOnlineAtTicketmaster;
   }

   public String getSchedule()
   {
      return this.schedule;
   }

   public void setSchedule(final String schedule)
   {
      this.schedule = schedule;
   }

   public AdultOnlyType getAdultOnly()
   {
      return this.adultOnly;
   }

   public void setAdultOnly(final AdultOnlyType adultOnly)
   {
      this.adultOnly = adultOnly;
   }

   public String getLinkBookOnlineAtShowtickets()
   {
      return this.linkBookOnlineAtShowtickets;
   }

   public void setLinkBookOnlineAtShowtickets(
         final String linkBookOnlineAtShowtickets)
   {
      this.linkBookOnlineAtShowtickets = linkBookOnlineAtShowtickets;
   }

   public String getDescription()
   {
      return this.description;
   }

   public void setDescription(final String description)
   {
      this.description = description;
   }

   public String getPriceRangeMax()
   {
      return this.priceRangeMax;
   }

   public void setPriceRangeMax(final String priceRangeMax)
   {
      this.priceRangeMax = priceRangeMax;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }

   public String getLinkDetails()
   {
      return this.linkDetails;
   }

   public void setLinkDetails(final String linkDetails)
   {
      this.linkDetails = linkDetails;
   }

   public String getLinkSeatingChart()
   {
      return this.linkSeatingChart;
   }

   public void setLinkSeatingChart(final String linkSeatingChart)
   {
      this.linkSeatingChart = linkSeatingChart;
   }

   public String getLinkBookOnlineLocally()
   {
      return this.linkBookOnlineLocally;
   }

   public void setLinkBookOnlineLocally(final String linkBookOnlineLocally)
   {
      this.linkBookOnlineLocally = linkBookOnlineLocally;
   }
}