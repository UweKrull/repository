package de.binaris.shows.model;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.FetchType.EAGER;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@Table(name = "venue")
public class Venue implements Serializable {

	private static final long serialVersionUID = 7575789729659127329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_venue")
	@SequenceGenerator(name = "my_entity_seq_gen_venue", sequenceName = "sequence_venue", allocationSize = 1)
	private Long id;

	@NotNull
	@Size(min = 2, max = 50, message = "must be 2-50 letters and spaces")
	private String name;								   // showRoom

	@Size(min = 1, max = 100, message = "must be 1-100 letters and spaces")
	private String location;							   // hotelName
	
	@NotNull
	@Size(min = 5, max = 200, message = "must be 5-200 letters and spaces")
	private String website;

	@OneToMany(cascade = MERGE, fetch = EAGER, mappedBy = "venue")
	private Set<Show> show = new HashSet<Show>();
	
	private Address address = new Address();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	public Set<Show> getShow() {
		return show;
	}
	
	public void setShow(Set<Show> show) {
		this.show = show;
	}
	
	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Venue)) {
			return false;
		}
		Venue castOther = (Venue) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(name).append(", ");
		sb.append(location).append(", ");
		return sb.toString();
	}
}
