
angular.module('surveyapplicationangularjs').controller('NewShoppingExperienceController', function ($scope, $location, locationParser, ShoppingExperienceResource , FeedbackResource, CustomerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.shoppingExperience = $scope.shoppingExperience || {};
    
    $scope.feedbackList = FeedbackResource.queryAll(function(items){
        $scope.feedbackSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("feedbackSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.shoppingExperience.feedback = {};
            $scope.shoppingExperience.feedback.id = selection.value;
        }
    });
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.login
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.shoppingExperience.customer = {};
            $scope.shoppingExperience.customer.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/ShoppingExperiences/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        ShoppingExperienceResource.save($scope.shoppingExperience, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/ShoppingExperiences/edit/1");
    };
});