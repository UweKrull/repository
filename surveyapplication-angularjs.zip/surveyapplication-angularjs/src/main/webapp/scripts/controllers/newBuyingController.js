
angular.module('surveyapplicationangularjs').controller('NewBuyingController', function ($scope, $location, locationParser, BuyingResource , ItemCategoryResource, PaymentOptionResource, CustomerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.buying = $scope.buying || {};
    
    $scope.itemCategoryList = ItemCategoryResource.queryAll(function(items){
        $scope.itemCategorySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("itemCategorySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.buying.itemCategory = {};
            $scope.buying.itemCategory.id = selection.value;
        }
    });
    
    $scope.paymentOptionList = PaymentOptionResource.queryAll(function(items){
        $scope.paymentOptionSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("paymentOptionSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.buying.paymentOption = {};
            $scope.buying.paymentOption.id = selection.value;
        }
    });
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.login
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.buying.customer = {};
            $scope.buying.customer.id = selection.value;
        }
    });

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Buyings/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        BuyingResource.save($scope.buying, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Buyings/edit/1");
    };
});