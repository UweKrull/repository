
angular.module('surveyapplicationangularjs').controller('NewRecommendationIntentionController', function ($scope, $location, locationParser, RecommendationIntentionResource , RecommendabilityResource, CustomerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.recommendationIntention = $scope.recommendationIntention || {};
    
    $scope.recommendabilityList = RecommendabilityResource.queryAll(function(items){
        $scope.recommendabilitySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("recommendabilitySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.recommendationIntention.recommendability = {};
            $scope.recommendationIntention.recommendability.id = selection.value;
        }
    });
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.login
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.recommendationIntention.customer = {};
            $scope.recommendationIntention.customer.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/RecommendationIntentions/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        RecommendationIntentionResource.save($scope.recommendationIntention, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/RecommendationIntentions/edit/1");
    };
});