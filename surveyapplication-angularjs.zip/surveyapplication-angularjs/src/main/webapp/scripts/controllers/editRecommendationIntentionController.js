

angular.module('surveyapplicationangularjs').controller('EditRecommendationIntentionController', function($scope, $routeParams, $location, RecommendationIntentionResource , RecommendabilityResource, CustomerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.recommendationIntention = new RecommendationIntentionResource(self.original);
            RecommendabilityResource.queryAll(function(items) {
                $scope.recommendabilitySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.recommendationIntention.recommendability && item.id == $scope.recommendationIntention.recommendability.id) {
                        $scope.recommendabilitySelection = labelObject;
                        $scope.recommendationIntention.recommendability = wrappedObject;
                        self.original.recommendability = $scope.recommendationIntention.recommendability;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.login
                    };
                    if($scope.recommendationIntention.customer && item.id == $scope.recommendationIntention.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.recommendationIntention.customer = wrappedObject;
                        self.original.customer = $scope.recommendationIntention.customer;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/RecommendationIntentions");
        };
        RecommendationIntentionResource.get({RecommendationIntentionId:$routeParams.RecommendationIntentionId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.recommendationIntention);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.recommendationIntention.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/RecommendationIntentions/edit/1");
    };

    $scope.previous = function() {
        $location.path("/ShoppingExperiences/edit/1");
    };

    $scope.$watch("recommendabilitySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recommendationIntention.recommendability = {};
            $scope.recommendationIntention.recommendability.id = selection.value;
        }
    });
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.recommendationIntention.customer = {};
            $scope.recommendationIntention.customer.id = selection.value;
        }
    });
    
    $scope.get();
});