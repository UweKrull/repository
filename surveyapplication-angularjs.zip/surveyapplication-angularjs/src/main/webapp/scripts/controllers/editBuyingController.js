

angular.module('surveyapplicationangularjs').controller('EditBuyingController', function($scope, $routeParams, $location, BuyingResource , ItemCategoryResource, PaymentOptionResource, CustomerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.buying = new BuyingResource(self.original);
            ItemCategoryResource.queryAll(function(items) {
                $scope.itemCategorySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.buying.itemCategory && item.id == $scope.buying.itemCategory.id) {
                        $scope.itemCategorySelection = labelObject;
                        $scope.buying.itemCategory = wrappedObject;
                        self.original.itemCategory = $scope.buying.itemCategory;
                    }
                    return labelObject;
                });
            });
            PaymentOptionResource.queryAll(function(items) {
                $scope.paymentOptionSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.buying.paymentOption && item.id == $scope.buying.paymentOption.id) {
                        $scope.paymentOptionSelection = labelObject;
                        $scope.buying.paymentOption = wrappedObject;
                        self.original.paymentOption = $scope.buying.paymentOption;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.login
                    };
                    if($scope.buying.customer && item.id == $scope.buying.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.buying.customer = wrappedObject;
                        self.original.customer = $scope.buying.customer;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Buyings");
        };
        BuyingResource.get({BuyingId:$routeParams.BuyingId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.buying);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.buying.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Buyings/edit/1");
    };
    
    $scope.previous = function() {
        $location.path("/RetailShoppers/edit/1");
    };

    $scope.next = function() {
        $location.path("/ShoppingExperiences/edit/1");
    };

    $scope.$watch("itemCategorySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.buying.itemCategory = {};
            $scope.buying.itemCategory.id = selection.value;
        }
    });
    $scope.$watch("paymentOptionSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.buying.paymentOption = {};
            $scope.buying.paymentOption.id = selection.value;
        }
    });
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.buying.customer = {};
            $scope.buying.customer.id = selection.value;
        }
    });
    
    $scope.get();
});