

angular.module('surveyapplicationangularjs').controller('EditCustomerController', function($scope, $routeParams, $location, CustomerResource , RangeOfAgeResource, SexResource, MaritialStatusResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.customer = new CustomerResource(self.original);
            RangeOfAgeResource.queryAll(function(items) {
                $scope.rangeOfAgeSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.customer.rangeOfAge && item.id == $scope.customer.rangeOfAge.id) {
                        $scope.rangeOfAgeSelection = labelObject;
                        $scope.customer.rangeOfAge = wrappedObject;
                        self.original.rangeOfAge = $scope.customer.rangeOfAge;
                    }
                    return labelObject;
                });
            });
            SexResource.queryAll(function(items) {
                $scope.sexSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.customer.sex && item.id == $scope.customer.sex.id) {
                        $scope.sexSelection = labelObject;
                        $scope.customer.sex = wrappedObject;
                        self.original.sex = $scope.customer.sex;
                    }
                    return labelObject;
                });
            });
            MaritialStatusResource.queryAll(function(items) {
                $scope.maritialStatusSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.customer.maritialStatus && item.id == $scope.customer.maritialStatus.id) {
                        $scope.maritialStatusSelection = labelObject;
                        $scope.customer.maritialStatus = wrappedObject;
                        self.original.maritialStatus = $scope.customer.maritialStatus;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/Customers");
        };
        CustomerResource.get({CustomerId:$routeParams.CustomerId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.customer);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.customer.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/Customers/edit/1");
    };

    $scope.next = function() {
        $location.path("/RetailShoppers/edit/1");
    };

    $scope.$watch("rangeOfAgeSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.rangeOfAge = {};
            $scope.customer.rangeOfAge.id = selection.value;
        }
    });
    $scope.$watch("sexSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.sex = {};
            $scope.customer.sex.id = selection.value;
        }
    });
    $scope.$watch("maritialStatusSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.customer.maritialStatus = {};
            $scope.customer.maritialStatus.id = selection.value;
        }
    });
    
    $scope.get();
});