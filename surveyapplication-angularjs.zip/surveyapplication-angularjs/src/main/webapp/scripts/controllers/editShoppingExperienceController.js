

angular.module('surveyapplicationangularjs').controller('EditShoppingExperienceController', function($scope, $routeParams, $location, ShoppingExperienceResource , FeedbackResource, CustomerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.shoppingExperience = new ShoppingExperienceResource(self.original);
            FeedbackResource.queryAll(function(items) {
                $scope.feedbackSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.shoppingExperience.feedback && item.id == $scope.shoppingExperience.feedback.id) {
                        $scope.feedbackSelection = labelObject;
                        $scope.shoppingExperience.feedback = wrappedObject;
                        self.original.feedback = $scope.shoppingExperience.feedback;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.login
                    };
                    if($scope.shoppingExperience.customer && item.id == $scope.shoppingExperience.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.shoppingExperience.customer = wrappedObject;
                        self.original.customer = $scope.shoppingExperience.customer;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/ShoppingExperiences");
        };
        ShoppingExperienceResource.get({ShoppingExperienceId:$routeParams.ShoppingExperienceId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.shoppingExperience);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.shoppingExperience.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/ShoppingExperiences/edit/1");
    };
    
    $scope.previous = function() {
        $location.path("/Buyings/edit/1");
    };
    
    $scope.next = function() {
        $location.path("/RecommendationIntentions/edit/1");
    };

    $scope.$watch("feedbackSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.shoppingExperience.feedback = {};
            $scope.shoppingExperience.feedback.id = selection.value;
        }
    });
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.shoppingExperience.customer = {};
            $scope.shoppingExperience.customer.id = selection.value;
        }
    });
    
    $scope.get();
});