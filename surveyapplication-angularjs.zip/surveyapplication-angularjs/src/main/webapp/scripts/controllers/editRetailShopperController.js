

angular.module('surveyapplicationangularjs').controller('EditRetailShopperController', function($scope, $routeParams, $location, RetailShopperResource , OnlineShopResource, FrequencyResource, CustomerResource) {
    var self = this;
    $scope.disabled = false;
    $scope.$location = $location;
    
    $scope.get = function() {
        var successCallback = function(data){
            self.original = data;
            $scope.retailShopper = new RetailShopperResource(self.original);
            OnlineShopResource.queryAll(function(items) {
                $scope.onlineShopSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.retailShopper.onlineShop && item.id == $scope.retailShopper.onlineShop.id) {
                        $scope.onlineShopSelection = labelObject;
                        $scope.retailShopper.onlineShop = wrappedObject;
                        self.original.onlineShop = $scope.retailShopper.onlineShop;
                    }
                    return labelObject;
                });
            });
            FrequencyResource.queryAll(function(items) {
                $scope.frequencySelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.name
                    };
                    if($scope.retailShopper.frequency && item.id == $scope.retailShopper.frequency.id) {
                        $scope.frequencySelection = labelObject;
                        $scope.retailShopper.frequency = wrappedObject;
                        self.original.frequency = $scope.retailShopper.frequency;
                    }
                    return labelObject;
                });
            });
            CustomerResource.queryAll(function(items) {
                $scope.customerSelectionList = $.map(items, function(item) {
                    var wrappedObject = {
                        id : item.id
                    };
                    var labelObject = {
                        value : item.id,
                        text : item.login
                    };
                    if($scope.retailShopper.customer && item.id == $scope.retailShopper.customer.id) {
                        $scope.customerSelection = labelObject;
                        $scope.retailShopper.customer = wrappedObject;
                        self.original.customer = $scope.retailShopper.customer;
                    }
                    return labelObject;
                });
            });
        };
        var errorCallback = function() {
            $location.path("/RetailShoppers");
        };
        RetailShopperResource.get({RetailShopperId:$routeParams.RetailShopperId}, successCallback, errorCallback);
    };

    $scope.isClean = function() {
        return angular.equals(self.original, $scope.retailShopper);
    };

    $scope.save = function() {
        var successCallback = function(){
            $scope.get();
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError=true;
        };
        $scope.retailShopper.$update(successCallback, errorCallback);
    };

    $scope.cancel = function() {
        $location.path("/RetailShoppers/edit/1");
    };

    $scope.previous = function() {
        $location.path("/Customers/edit/1");
    };

    $scope.next = function() {
        $location.path("/Buyings/edit/1");
    };

    $scope.$watch("onlineShopSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.retailShopper.onlineShop = {};
            $scope.retailShopper.onlineShop.id = selection.value;
        }
    });
    $scope.$watch("frequencySelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.retailShopper.frequency = {};
            $scope.retailShopper.frequency.id = selection.value;
        }
    });
    $scope.$watch("customerSelection", function(selection) {
        if (typeof selection != 'undefined') {
            $scope.retailShopper.customer = {};
            $scope.retailShopper.customer.id = selection.value;
        }
    });
    
    $scope.get();
});