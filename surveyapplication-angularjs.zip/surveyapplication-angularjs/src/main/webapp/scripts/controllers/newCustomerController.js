
angular.module('surveyapplicationangularjs').controller('NewCustomerController', function ($scope, $location, locationParser, CustomerResource , RangeOfAgeResource, SexResource, MaritialStatusResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.customer = $scope.customer || {};
    
    $scope.rangeOfAgeList = RangeOfAgeResource.queryAll(function(items){
        $scope.rangeOfAgeSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("rangeOfAgeSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.customer.rangeOfAge = {};
            $scope.customer.rangeOfAge.id = selection.value;
        }
    });
    
    $scope.sexList = SexResource.queryAll(function(items){
        $scope.sexSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("sexSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.customer.sex = {};
            $scope.customer.sex.id = selection.value;
        }
    });
    
    $scope.maritialStatusList = MaritialStatusResource.queryAll(function(items){
        $scope.maritialStatusSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("maritialStatusSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.customer.maritialStatus = {};
            $scope.customer.maritialStatus.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/Customers/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        CustomerResource.save($scope.customer, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/Customers/edit/1");
    };
});