
angular.module('surveyapplicationangularjs').controller('NewRetailShopperController', function ($scope, $location, locationParser, RetailShopperResource , OnlineShopResource, FrequencyResource, CustomerResource) {
    $scope.disabled = false;
    $scope.$location = $location;
    $scope.retailShopper = $scope.retailShopper || {};
    
    $scope.onlineShopList = OnlineShopResource.queryAll(function(items){
        $scope.onlineShopSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("onlineShopSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.retailShopper.onlineShop = {};
            $scope.retailShopper.onlineShop.id = selection.value;
        }
    });
    
    $scope.frequencyList = FrequencyResource.queryAll(function(items){
        $scope.frequencySelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.name
            });
        });
    });
    $scope.$watch("frequencySelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.retailShopper.frequency = {};
            $scope.retailShopper.frequency.id = selection.value;
        }
    });
    
    $scope.customerList = CustomerResource.queryAll(function(items){
        $scope.customerSelectionList = $.map(items, function(item) {
            return ( {
                value : item.id,
                text : item.login
            });
        });
    });
    $scope.$watch("customerSelection", function(selection) {
        if ( typeof selection != 'undefined') {
            $scope.retailShopper.customer = {};
            $scope.retailShopper.customer.id = selection.value;
        }
    });
    

    $scope.save = function() {
        var successCallback = function(data,responseHeaders){
            var id = locationParser(responseHeaders);
            $location.path('/RetailShoppers/edit/' + id);
            $scope.displayError = false;
        };
        var errorCallback = function() {
            $scope.displayError = true;
        };
        RetailShopperResource.save($scope.retailShopper, successCallback, errorCallback);
    };
    
    $scope.cancel = function() {
        $location.path("/RetailShoppers/edit/1");
    };
});