'use strict';

angular.module('surveyapplicationangularjs',['ngRoute','ngResource'])
  .config(['$routeProvider', function($routeProvider) {
    $routeProvider
      .when('/',{templateUrl:'views/landing.html',controller:'LandingPageController'})
      .when('/Buyings/new',{templateUrl:'views/Buying/detail.html',controller:'NewBuyingController'})
      .when('/Buyings/edit/:BuyingId',{templateUrl:'views/Buying/detail.html',controller:'EditBuyingController'})
      .when('/Contacts',{templateUrl:'views/Contact/search.html',controller:'SearchContactController'})
      .when('/Contacts/new',{templateUrl:'views/Contact/detail.html',controller:'NewContactController'})
      .when('/Contacts/edit/:ContactId',{templateUrl:'views/Contact/detail.html',controller:'EditContactController'})
      .when('/Customers/new',{templateUrl:'views/Customer/detail.html',controller:'NewCustomerController'})
      .when('/Customers/edit/:CustomerId',{templateUrl:'views/Customer/detail.html',controller:'EditCustomerController'})
      .when('/RecommendationIntentions/new',{templateUrl:'views/RecommendationIntention/detail.html',controller:'NewRecommendationIntentionController'})
      .when('/RecommendationIntentions/edit/:RecommendationIntentionId',{templateUrl:'views/RecommendationIntention/detail.html',controller:'EditRecommendationIntentionController'})
      .when('/RetailShoppers/new',{templateUrl:'views/RetailShopper/detail.html',controller:'NewRetailShopperController'})
      .when('/RetailShoppers/edit/:RetailShopperId',{templateUrl:'views/RetailShopper/detail.html',controller:'EditRetailShopperController'})
      .when('/ShoppingExperiences/new',{templateUrl:'views/ShoppingExperience/detail.html',controller:'NewShoppingExperienceController'})
      .when('/ShoppingExperiences/edit/:ShoppingExperienceId',{templateUrl:'views/ShoppingExperience/detail.html',controller:'EditShoppingExperienceController'})
      .otherwise({
        redirectTo: '/'
      });
  }])
  .controller('LandingPageController', function LandingPageController() {
  })
  .controller('NavController', function NavController($scope, $location) {
    $scope.matchesRoute = function(route) {
        var path = $location.path();
        return (path === ("/" + route) || path.indexOf("/" + route + "/") == 0);
    };
  });
