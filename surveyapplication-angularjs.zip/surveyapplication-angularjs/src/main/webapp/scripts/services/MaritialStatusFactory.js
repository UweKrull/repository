angular.module('surveyapplicationangularjs').factory('MaritialStatusResource', function($resource){
    var resource = $resource('rest/maritialstatuss/:MaritialStatusId',{MaritialStatusId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});