angular.module('surveyapplicationangularjs').factory('ShoppingExperienceResource', function($resource){
    var resource = $resource('rest/shoppingexperiences/:ShoppingExperienceId',{ShoppingExperienceId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});