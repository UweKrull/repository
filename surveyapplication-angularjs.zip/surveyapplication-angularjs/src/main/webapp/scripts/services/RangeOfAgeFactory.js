angular.module('surveyapplicationangularjs').factory('RangeOfAgeResource', function($resource){
    var resource = $resource('rest/rangeofages/:RangeOfAgeId',{RangeOfAgeId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});