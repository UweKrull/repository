angular.module('surveyapplicationangularjs').factory('RecommendationIntentionResource', function($resource){
    var resource = $resource('rest/recommendationintentions/:RecommendationIntentionId',{RecommendationIntentionId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});