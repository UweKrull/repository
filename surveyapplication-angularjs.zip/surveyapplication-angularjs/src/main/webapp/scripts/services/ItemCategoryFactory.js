angular.module('surveyapplicationangularjs').factory('ItemCategoryResource', function($resource){
    var resource = $resource('rest/itemcategorys/:ItemCategoryId',{ItemCategoryId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});