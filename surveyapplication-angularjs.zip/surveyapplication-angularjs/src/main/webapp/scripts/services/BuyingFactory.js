angular.module('surveyapplicationangularjs').factory('BuyingResource', function($resource){
    var resource = $resource('rest/buyings/:BuyingId',{BuyingId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});