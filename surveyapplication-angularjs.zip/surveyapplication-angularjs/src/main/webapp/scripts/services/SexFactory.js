angular.module('surveyapplicationangularjs').factory('SexResource', function($resource){
    var resource = $resource('rest/sexs/:SexId',{SexId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});