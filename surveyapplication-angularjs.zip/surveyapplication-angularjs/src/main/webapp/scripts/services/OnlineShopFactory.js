angular.module('surveyapplicationangularjs').factory('OnlineShopResource', function($resource){
    var resource = $resource('rest/onlineshops/:OnlineShopId',{OnlineShopId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});