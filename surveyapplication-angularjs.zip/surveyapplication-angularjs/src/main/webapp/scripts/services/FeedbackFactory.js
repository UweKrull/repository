angular.module('surveyapplicationangularjs').factory('FeedbackResource', function($resource){
    var resource = $resource('rest/feedbacks/:FeedbackId',{FeedbackId:'@id'},{'queryAll':{method:'GET',isArray:true},'query':{method:'GET',isArray:false},'update':{method:'PUT'}});
    return resource;
});