package de.binaris.surveyapplication.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

//import de.binaris.jobapplication.annotations.Login;

@Cacheable
@Entity
@Table(name = "buying")
public class Buying implements Serializable {

	private static final long serialVersionUID = 123457971579122329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_buying")
	@SequenceGenerator(name = "my_entity_seq_gen_buying", sequenceName = "sequence_buying", allocationSize = 1)
	private Long id;

	@ManyToOne
	private ItemCategory itemCategory;

	@ManyToOne
	private PaymentOption paymentOption;
	
    @ManyToOne
    private Customer customer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public ItemCategory getItemCategory() {
		return itemCategory;
	}
	
	public void setItemCategory(ItemCategory itemCategory) {
		this.itemCategory = itemCategory;
	}
	
	public PaymentOption getPaymentOption() {
		return paymentOption;
	}

	public void setPaymentOption(PaymentOption paymentOption) {
		this.paymentOption = paymentOption;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Buying)) {
			return false;
		}
		Buying castOther = (Buying) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(itemCategory.getName());
		sb.append(", ");
		sb.append(paymentOption.getName());
		return sb.toString();
	}
}
