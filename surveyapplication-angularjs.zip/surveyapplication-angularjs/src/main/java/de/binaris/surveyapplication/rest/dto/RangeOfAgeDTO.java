package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;
import de.binaris.surveyapplication.model.RangeOfAge;
import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RangeOfAgeDTO implements Serializable
{

   private Long id;
   private String name;

   public RangeOfAgeDTO()
   {
   }

   public RangeOfAgeDTO(final RangeOfAge entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public RangeOfAge fromDTO(RangeOfAge entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new RangeOfAge();
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}