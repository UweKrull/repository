package de.binaris.surveyapplication.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.surveyapplication.model.RecommendationIntention;
import de.binaris.surveyapplication.rest.dto.RecommendationIntentionDTO;

@Stateless
@Path("/recommendationintentions")
public class RecommendationIntentionEndpoint
{
   @PersistenceContext(unitName = "SurveyapplicationPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(RecommendationIntentionDTO dto)
   {
      RecommendationIntention entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(RecommendationIntentionEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      RecommendationIntention entity = em.find(RecommendationIntention.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<RecommendationIntention> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM RecommendationIntention r LEFT JOIN FETCH r.recommendability LEFT JOIN FETCH r.customer WHERE r.id = :entityId ORDER BY r.id", RecommendationIntention.class);
      findByIdQuery.setParameter("entityId", id);
      RecommendationIntention entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      RecommendationIntentionDTO dto = new RecommendationIntentionDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<RecommendationIntentionDTO> listAll()
   {
      final List<RecommendationIntention> searchResults = em.createQuery("SELECT DISTINCT r FROM RecommendationIntention r LEFT JOIN FETCH r.recommendability LEFT JOIN FETCH r.customer ORDER BY r.id", RecommendationIntention.class).getResultList();
      final List<RecommendationIntentionDTO> results = new ArrayList<RecommendationIntentionDTO>();
      for (RecommendationIntention searchResult : searchResults)
      {
         RecommendationIntentionDTO dto = new RecommendationIntentionDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, RecommendationIntentionDTO dto)
   {
      TypedQuery<RecommendationIntention> findByIdQuery = em.createQuery("SELECT DISTINCT r FROM RecommendationIntention r LEFT JOIN FETCH r.recommendability LEFT JOIN FETCH r.customer WHERE r.id = :entityId ORDER BY r.id", RecommendationIntention.class);
      findByIdQuery.setParameter("entityId", id);
      RecommendationIntention entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}