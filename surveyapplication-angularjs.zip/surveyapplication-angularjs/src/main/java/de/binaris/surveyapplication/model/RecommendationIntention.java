package de.binaris.surveyapplication.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Cacheable
@Entity
@Table(name = "recommendation_intention")
public class RecommendationIntention implements Serializable {

	private static final long serialVersionUID = 733556789579123329L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_recommendation_intention")
	@SequenceGenerator(name = "my_entity_seq_gen_recommendation_intention", sequenceName = "sequence_recommendation_intention", allocationSize = 1)
	private Long id;

	@ManyToOne
	private Recommendability recommendability;

    @ManyToOne
    private Customer customer;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Recommendability getRecommendability() {
		return recommendability;
	}
	
	public void setRecommendability(Recommendability recommendability) {
		this.recommendability = recommendability;
	}
	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof RecommendationIntention)) {
			return false;
		}
		RecommendationIntention castOther = (RecommendationIntention) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(recommendability.getName());
		return sb.toString();
	}
}
