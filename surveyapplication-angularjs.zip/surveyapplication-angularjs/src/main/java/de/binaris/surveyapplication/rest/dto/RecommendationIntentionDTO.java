package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;

import de.binaris.surveyapplication.model.RecommendationIntention;
import de.binaris.surveyapplication.rest.dto.NestedCustomerDTO;
import de.binaris.surveyapplication.rest.dto.NestedRecommendabilityDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class RecommendationIntentionDTO implements Serializable
{

   private Long id;
   private NestedRecommendabilityDTO recommendability;
   private NestedCustomerDTO customer;

   public RecommendationIntentionDTO()
   {
   }

   public RecommendationIntentionDTO(final RecommendationIntention entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.recommendability = new NestedRecommendabilityDTO(
               entity.getRecommendability());
         this.customer = new NestedCustomerDTO(entity.getCustomer());
      }
   }

   public RecommendationIntention fromDTO(RecommendationIntention entity,
         EntityManager em)
   {
      if (entity == null)
      {
         entity = new RecommendationIntention();
      }
      if (this.recommendability != null)
      {
         entity.setRecommendability(this.recommendability.fromDTO(
               entity.getRecommendability(), em));
      }
      if (this.customer != null)
      {
         entity.setCustomer(this.customer.fromDTO(entity.getCustomer(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedRecommendabilityDTO getRecommendability()
   {
      return this.recommendability;
   }

   public void setRecommendability(
         final NestedRecommendabilityDTO recommendability)
   {
      this.recommendability = recommendability;
   }

   public NestedCustomerDTO getCustomer()
   {
      return this.customer;
   }

   public void setCustomer(final NestedCustomerDTO customer)
   {
      this.customer = customer;
   }
}