package de.binaris.surveyapplication.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.surveyapplication.model.Customer;
import de.binaris.surveyapplication.rest.dto.CustomerDTO;

@Stateless
@Path("/customers")
public class CustomerEndpoint
{
   @PersistenceContext(unitName = "SurveyapplicationPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(CustomerDTO dto)
   {
      Customer entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(CustomerEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Customer entity = em.find(Customer.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Customer> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM Customer c LEFT JOIN FETCH c.rangeOfAge LEFT JOIN FETCH c.sex LEFT JOIN FETCH c.maritialStatus WHERE c.id = :entityId ORDER BY c.id", Customer.class);
      findByIdQuery.setParameter("entityId", id);
      Customer entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      CustomerDTO dto = new CustomerDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<CustomerDTO> listAll()
   {
      final List<Customer> searchResults = em.createQuery("SELECT DISTINCT c FROM Customer c LEFT JOIN FETCH c.rangeOfAge LEFT JOIN FETCH c.sex LEFT JOIN FETCH c.maritialStatus ORDER BY c.id", Customer.class).getResultList();
      final List<CustomerDTO> results = new ArrayList<CustomerDTO>();
      for (Customer searchResult : searchResults)
      {
         CustomerDTO dto = new CustomerDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, CustomerDTO dto)
   {
      TypedQuery<Customer> findByIdQuery = em.createQuery("SELECT DISTINCT c FROM Customer c LEFT JOIN FETCH c.rangeOfAge LEFT JOIN FETCH c.sex LEFT JOIN FETCH c.maritialStatus WHERE c.id = :entityId ORDER BY c.id", Customer.class);
      findByIdQuery.setParameter("entityId", id);
      Customer entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}