package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;

import de.binaris.surveyapplication.model.Customer;
import de.binaris.surveyapplication.rest.dto.NestedMaritialStatusDTO;
import de.binaris.surveyapplication.rest.dto.NestedRangeOfAgeDTO;
import de.binaris.surveyapplication.rest.dto.NestedSexDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class CustomerDTO implements Serializable
{

   public static final String LOGIN_NAME = "bananajoe";
   public static final String LOGIN_PWD  = "bananarama";
   
   private Long id;
   private NestedSexDTO sex;
   private String login;
   private NestedRangeOfAgeDTO rangeOfAge;
   private NestedMaritialStatusDTO maritialStatus;
   private String password;

   public CustomerDTO()
   {
	   this.login    = LOGIN_NAME;
	   this.password = LOGIN_PWD;
   }

   public CustomerDTO(final Customer entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.sex = new NestedSexDTO(entity.getSex());
         this.login = entity.getLogin();
         this.rangeOfAge = new NestedRangeOfAgeDTO(entity.getRangeOfAge());
         this.maritialStatus = new NestedMaritialStatusDTO(
               entity.getMaritialStatus());
         this.password = entity.getPassword();
      }
   }

   public Customer fromDTO(Customer entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Customer();
      }
      if (this.sex != null)
      {
         entity.setSex(this.sex.fromDTO(entity.getSex(), em));
      }
      entity.setLogin(this.login);
      if (this.rangeOfAge != null)
      {
         entity.setRangeOfAge(this.rangeOfAge.fromDTO(
               entity.getRangeOfAge(), em));
      }
      if (this.maritialStatus != null)
      {
         entity.setMaritialStatus(this.maritialStatus.fromDTO(
               entity.getMaritialStatus(), em));
      }
      entity.setPassword(this.password);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedSexDTO getSex()
   {
      return this.sex;
   }

   public void setSex(final NestedSexDTO sex)
   {
      this.sex = sex;
   }

   public String getLogin()
   {
      return LOGIN_NAME;
   }

   public void setLogin(final String login)
   {
      this.login = LOGIN_NAME;
   }

   public NestedRangeOfAgeDTO getRangeOfAge()
   {
      return this.rangeOfAge;
   }

   public void setRangeOfAge(final NestedRangeOfAgeDTO rangeOfAge)
   {
      this.rangeOfAge = rangeOfAge;
   }

   public NestedMaritialStatusDTO getMaritialStatus()
   {
      return this.maritialStatus;
   }

   public void setMaritialStatus(final NestedMaritialStatusDTO maritialStatus)
   {
      this.maritialStatus = maritialStatus;
   }

   public String getPassword()
   {
      return LOGIN_PWD;
   }

   public void setPassword(final String password)
   {
      this.password = LOGIN_PWD;
   }
}