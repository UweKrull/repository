package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;
import de.binaris.surveyapplication.model.Sex;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

public class NestedSexDTO implements Serializable
{

   private Long id;
   private String name;

   public NestedSexDTO()
   {
   }

   public NestedSexDTO(final Sex entity)
   {
      if (entity != null)
      {
         this.id = entity.getId();
         this.name = entity.getName();
      }
   }

   public Sex fromDTO(Sex entity, EntityManager em)
   {
      if (entity == null)
      {
         entity = new Sex();
      }
      if (this.id != null)
      {
         TypedQuery<Sex> findByIdQuery = em.createQuery(
               "SELECT DISTINCT s FROM Sex s WHERE s.id = :entityId",
               Sex.class);
         findByIdQuery.setParameter("entityId", this.id);
         try
         {
            entity = findByIdQuery.getSingleResult();
         }
         catch (javax.persistence.NoResultException nre)
         {
            entity = null;
         }
         return entity;
      }
      entity.setName(this.name);
      entity = em.merge(entity);
      return entity;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public String getName()
   {
      return this.name;
   }

   public void setName(final String name)
   {
      this.name = name;
   }
}