package de.binaris.surveyapplication.model;

import java.io.Serializable;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Cacheable
@Entity
@NamedQueries({
    @NamedQuery(name = "findByLogin", query = "SELECT c FROM Customer c WHERE c.login = :login"),
    @NamedQuery(name = "findByLoginAndPassword", query = "SELECT c FROM Customer c WHERE c.login = :login AND c.password = :password")
})
@Table(name = "customer")
public class Customer implements Serializable {

	private static final long serialVersionUID = 7575789729659127329L;

    public static final String LOGIN_NAME = "bananajoe";
    public static final String LOGIN_PWD  = "bananarama";

	public static final String FIND_BY_LOGIN = "findByLogin";
    public static final String FIND_BY_LOGIN_PASSWORD = "findByLoginAndPassword";
    
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "my_entity_seq_gen_customer")
	@SequenceGenerator(name = "my_entity_seq_gen_customer", sequenceName = "sequence_customer", allocationSize = 1)
	private Long id;

	@ManyToOne
	private RangeOfAge rangeOfAge;

	@ManyToOne
	private Sex sex;

	@ManyToOne
	private MaritialStatus maritialStatus;
	
	@NotNull
	@Size(min = 1, max = 30, message = "must be 1-30 letters and spaces")
	private String login;
	
	@NotNull
	@Size(min = 1, max = 256, message = "must be 1-256 letters and spaces")
	private String password;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public RangeOfAge getRangeOfAge() {
		return rangeOfAge;
	}
	
	public void setRangeOfAge(RangeOfAge rangeOfAge) {
		this.rangeOfAge = rangeOfAge;
	}
	
	public Sex getSex() {
		return sex;
	}

	public void setSex(Sex sex) {
		this.sex = sex;
	}

	public MaritialStatus getMaritialStatus() {
		return maritialStatus;
	}

	public void setMaritialStatus(MaritialStatus maritialStatus) {
		this.maritialStatus = maritialStatus;
	}

	public String getLogin() {
		return LOGIN_NAME;
	}

	public void setLogin(String login) {
		this.login = LOGIN_NAME;
	}

	public String getPassword() {
		return LOGIN_PWD;
	}

	public void setPassword(String password) {
		this.password = LOGIN_PWD;
	}

	@Override
	public boolean equals(Object object) {
		if (!(object instanceof Customer)) {
			return false;
		}
		Customer castOther = (Customer) object;
		return id != null ? id.equals(castOther.getId()) : false;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : System.identityHashCode(this);
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder();
		sb.append(login).append(", ");
		sb.append(rangeOfAge);
		sb.append(" years");
		return sb.toString();
	}
}
