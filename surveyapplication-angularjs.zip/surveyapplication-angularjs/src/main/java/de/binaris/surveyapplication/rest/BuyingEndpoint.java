package de.binaris.surveyapplication.rest;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import de.binaris.surveyapplication.model.Buying;
import de.binaris.surveyapplication.rest.dto.BuyingDTO;

@Stateless
@Path("/buyings")
public class BuyingEndpoint
{
   @PersistenceContext(unitName = "SurveyapplicationPU")
   private EntityManager em;

   @POST
   @Consumes("application/json")
   public Response create(BuyingDTO dto)
   {
      Buying entity = dto.fromDTO(null, em);
      em.persist(entity);
      return Response.created(UriBuilder.fromResource(BuyingEndpoint.class).path(String.valueOf(entity.getId())).build()).build();
   }

   @DELETE
   @Path("/{id:[0-9][0-9]*}")
   public Response deleteById(@PathParam("id") Long id)
   {
      Buying entity = em.find(Buying.class, id);
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      em.remove(entity);
      return Response.noContent().build();
   }

   @GET
   @Path("/{id:[0-9][0-9]*}")
   @Produces("application/json")
   public Response findById(@PathParam("id") Long id)
   {
      TypedQuery<Buying> findByIdQuery = em.createQuery("SELECT DISTINCT b FROM Buying b LEFT JOIN FETCH b.itemCategory LEFT JOIN FETCH b.paymentOption LEFT JOIN FETCH b.customer WHERE b.id = :entityId ORDER BY b.id", Buying.class);
      findByIdQuery.setParameter("entityId", id);
      Buying entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      if (entity == null)
      {
         return Response.status(Status.NOT_FOUND).build();
      }
      BuyingDTO dto = new BuyingDTO(entity);
      return Response.ok(dto).build();
   }

   @GET
   @Produces("application/json")
   public List<BuyingDTO> listAll()
   {
      final List<Buying> searchResults = em.createQuery("SELECT DISTINCT b FROM Buying b LEFT JOIN FETCH b.itemCategory LEFT JOIN FETCH b.paymentOption LEFT JOIN FETCH b.customer ORDER BY b.id", Buying.class).getResultList();
      final List<BuyingDTO> results = new ArrayList<BuyingDTO>();
      for (Buying searchResult : searchResults)
      {
         BuyingDTO dto = new BuyingDTO(searchResult);
         results.add(dto);
      }
      return results;
   }

   @PUT
   @Path("/{id:[0-9][0-9]*}")
   @Consumes("application/json")
   public Response update(@PathParam("id") Long id, BuyingDTO dto)
   {
      TypedQuery<Buying> findByIdQuery = em.createQuery("SELECT DISTINCT b FROM Buying b LEFT JOIN FETCH b.itemCategory LEFT JOIN FETCH b.paymentOption LEFT JOIN FETCH b.customer WHERE b.id = :entityId ORDER BY b.id", Buying.class);
      findByIdQuery.setParameter("entityId", id);
      Buying entity;
      try
      {
         entity = findByIdQuery.getSingleResult();
      }
      catch (NoResultException nre)
      {
         entity = null;
      }
      entity = dto.fromDTO(entity, em);
      entity = em.merge(entity);
      return Response.noContent().build();
   }
}