package de.binaris.surveyapplication.rest.dto;

import java.io.Serializable;

import de.binaris.surveyapplication.model.ShoppingExperience;
import de.binaris.surveyapplication.rest.dto.NestedCustomerDTO;
import de.binaris.surveyapplication.rest.dto.NestedFeedbackDTO;

import javax.persistence.EntityManager;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ShoppingExperienceDTO implements Serializable
{

   private NestedFeedbackDTO feedback;
   private Long id;
   private NestedCustomerDTO customer;

   public ShoppingExperienceDTO()
   {
   }

   public ShoppingExperienceDTO(final ShoppingExperience entity)
   {
      if (entity != null)
      {
         this.feedback = new NestedFeedbackDTO(entity.getFeedback());
         this.id = entity.getId();
         this.customer = new NestedCustomerDTO(entity.getCustomer());
      }
   }

   public ShoppingExperience fromDTO(ShoppingExperience entity,
         EntityManager em)
   {
      if (entity == null)
      {
         entity = new ShoppingExperience();
      }
      if (this.feedback != null)
      {
         entity.setFeedback(this.feedback.fromDTO(entity.getFeedback(), em));
      }
      if (this.customer != null)
      {
         entity.setCustomer(this.customer.fromDTO(entity.getCustomer(), em));
      }
      entity = em.merge(entity);
      return entity;
   }

   public NestedFeedbackDTO getFeedback()
   {
      return this.feedback;
   }

   public void setFeedback(final NestedFeedbackDTO feedback)
   {
      this.feedback = feedback;
   }

   public Long getId()
   {
      return this.id;
   }

   public void setId(final Long id)
   {
      this.id = id;
   }

   public NestedCustomerDTO getCustomer()
   {
      return this.customer;
   }

   public void setCustomer(final NestedCustomerDTO customer)
   {
      this.customer = customer;
   }
}